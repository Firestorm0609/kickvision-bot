10 clubs

- **Sydney FC**
- **Western Sydney Wanderers** : (3) W Sydney · Western Sydney · WS Wanderers FC
- **Central Coast Mariners** : (1) Central Coast
- **Newcastle United Jets** : (2) Newcastle · Newcastle Jets
- **Melbourne City FC** : (2) Melb City · Melbourne Heart
- **Melbourne Victory** : (1) Melb Victory
- **Western United** : (1) Western United FC
- **Brisbane Roar** : (1) Brisbane
- **Adelaide United** : (2) Adelaide · Adelaide United FC
- **Perth Glory**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Melbourne, Victoria** (2): 
  - Melbourne City FC  (2) Melb City · Melbourne Heart
  - Melbourne Victory  (1) Melb Victory
- **Sydney, New South Wales** (2): 
  - Sydney FC 
  - Western Sydney Wanderers  (3) W Sydney · Western Sydney · WS Wanderers FC
- **Adelaide, South Australia** (1): Adelaide United  (2) Adelaide · Adelaide United FC
- **Brisbane Roar, Queensland** (1): Brisbane Roar  (1) Brisbane
- **Geelong, Victoria** (1): Western United  (1) Western United FC
- **Gosford, New South Wales** (1): Central Coast Mariners  (1) Central Coast
- **Newcastle, New South Wales** (1): Newcastle United Jets  (2) Newcastle · Newcastle Jets
- **Perth, Western Australia** (1): Perth Glory 




By Region

- **New South Wales** (4):   Sydney FC · Western Sydney Wanderers · Central Coast Mariners · Newcastle United Jets
- **Victoria** (3):   Melbourne City FC · Melbourne Victory · Western United
- **Queensland** (1):   Brisbane Roar
- **South Australia** (1):   Adelaide United
- **Western Australia** (1):   Perth Glory




By Year

- ? (10):   Sydney FC · Western Sydney Wanderers · Central Coast Mariners · Newcastle United Jets · Melbourne City FC · Melbourne Victory · Western United · Brisbane Roar · Adelaide United · Perth Glory






By A to Z

- **A** (3): Adelaide · Adelaide United · Adelaide United FC
- **B** (2): Brisbane · Brisbane Roar
- **C** (2): Central Coast · Central Coast Mariners
- **M** (5): Melb City · Melb Victory · Melbourne Heart · Melbourne City FC · Melbourne Victory
- **N** (3): Newcastle · Newcastle Jets · Newcastle United Jets
- **P** (1): Perth Glory
- **S** (1): Sydney FC
- **W** (6): W Sydney · Western Sydney · Western United · WS Wanderers FC · Western United FC · Western Sydney Wanderers




