2 datafiles, 19 clubs

**pacific/australia/au.clubs.txt** _(10)_:  Sydney FC · Western Sydney Wanderers · Central Coast Mariners · Newcastle United Jets · Melbourne City FC · Melbourne Victory · Western United · Brisbane Roar · Adelaide United · Perth Glory

**pacific/new-zealand/nz.clubs.txt** _(9)_:  Auckland City FC · Waitakere United · Hawke's Bay United · Team Wellington · Waikato FC · YoungHeart Manawatu · Canterbury United · Otago United · Wellington Phoenix

