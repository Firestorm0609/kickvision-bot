# New Zealand, nz

### New Zealand Football Championship

- 8 teams

#### Wikipedia

- [2012–13_ASB_Premiership](http://en.wikipedia.org/wiki/2012–13_ASB_Premiership)

