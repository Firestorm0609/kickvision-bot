9 clubs

- **Auckland City FC** : (1) Auckland City
- **Waitakere United**
- **Hawke's Bay United**
- **Team Wellington**
- **Waikato FC**
- **YoungHeart Manawatu**
- **Canterbury United**
- **Otago United**
- **Wellington Phoenix** : (2) Wellington · Wellington Phoenix FC




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Auckland, Auckland › North Island** (2): 
  - Auckland City FC  (1) Auckland City
  - Waitakere United 
- **Wellington, Wellington › North Island** (2): 
  - Team Wellington 
  - Wellington Phoenix  (2) Wellington · Wellington Phoenix FC
- **Christchurch, Canterbury › South Island** (1): Canterbury United 
- **Dunedin, Otago › South Island** (1): Otago United 
- **Hamilton, Waikato › North Island** (1): Waikato FC 
- **Napier, Hawke's Bay › North Island** (1): Hawke's Bay United 
- **Palmerston North, Manawatu-Wanganui › North Island** (1): YoungHeart Manawatu 




By Region

- **Auckland › North Island** (2):   Auckland City FC · Waitakere United
- **Hawke's Bay › North Island** (1):   Hawke's Bay United
- **Wellington › North Island** (2):   Team Wellington · Wellington Phoenix
- **Waikato › North Island** (1):   Waikato FC
- **Manawatu-Wanganui › North Island** (1):   YoungHeart Manawatu
- **Canterbury › South Island** (1):   Canterbury United
- **Otago › South Island** (1):   Otago United




By Year

- ? (9):   Auckland City FC · Waitakere United · Hawke's Bay United · Team Wellington · Waikato FC · YoungHeart Manawatu · Canterbury United · Otago United · Wellington Phoenix






By A to Z

- **A** (2): Auckland City · Auckland City FC
- **C** (1): Canterbury United
- **H** (1): Hawke's Bay United
- **O** (1): Otago United
- **T** (1): Team Wellington
- **W** (5): Waikato FC · Wellington · Waitakere United · Wellington Phoenix · Wellington Phoenix FC
- **Y** (1): YoungHeart Manawatu




