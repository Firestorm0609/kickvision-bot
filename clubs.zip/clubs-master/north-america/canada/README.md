10 clubs

- [**Montreal Impact**](https://en.wikipedia.org/wiki/Montreal_Impact) : (4) Montreal · Montreal I. · Impact Montréal · Impact de Montréal ⇒ (2) ≈Impact Montreal≈ · ≈Impact de Montreal≈
- [**Toronto FC**](https://en.wikipedia.org/wiki/Toronto_FC) : (3) TFC · Toronto · FC Toronto
- **York9 FC** : (2) York9 · York 9 Football Club
- **Forge FC** : (2) Forge · Forge Football Club
- **HFX Wanderers** : (3) HFX Wanderers FC · Halifax Wanderers · HFX Wanderers Football Club
- **Valour FC** : (2) Valour · Valour Football Club
- **Cavalry FC** : (2) Cavalry · Cavalry Football Club
- **FC Edmonton**
- [**Vancouver Whitecaps FC**](https://en.wikipedia.org/wiki/Vancouver_Whitecaps_FC) : (3) Vancouver · Vancouver W'caps · Vancouver Whitecaps
- **Pacific FC** : (2) Pacific · Pacific Football Club




Alphabet

- **Alphabet Specials** (1):  **é** 
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e




Duplicates





By City

- **Toronto, Ontario** (2): 
  - Toronto FC  (3) TFC · Toronto · FC Toronto
  - York9 FC  (2) York9 · York 9 Football Club
- **Calgary, Alberta** (1): Cavalry FC  (2) Cavalry · Cavalry Football Club
- **Edmonton, Alberta** (1): FC Edmonton 
- **Halifax, Nova Scotia** (1): HFX Wanderers  (3) Halifax Wanderers · HFX Wanderers FC · HFX Wanderers Football Club
- **Hamilton, Ontario** (1): Forge FC  (2) Forge · Forge Football Club
- **Montréal, Quebec** (1): Montreal Impact  (4) Montreal · Montreal I. · Impact Montréal · Impact de Montréal
- **Vancouver, British Columbia** (1): Vancouver Whitecaps FC  (3) Vancouver · Vancouver W'caps · Vancouver Whitecaps
- **Victoria, British Columbia** (1): Pacific FC  (2) Pacific · Pacific Football Club
- **Winnipeg, Manitoba** (1): Valour FC  (2) Valour · Valour Football Club




By Region

- **Quebec** (1):   Montreal Impact
- **Ontario** (3):   Toronto FC · York9 FC · Forge FC
- **Nova Scotia** (1):   HFX Wanderers
- **Manitoba** (1):   Valour FC
- **Alberta** (2):   Cavalry FC · FC Edmonton
- **British Columbia** (2):   Vancouver Whitecaps FC · Pacific FC




By Year

- **1974** (1):   Vancouver Whitecaps FC
- **2006** (1):   Toronto FC
- **2010** (2):   Montreal Impact · FC Edmonton
- **2017** (2):   Forge FC · Valour FC
- **2018** (4):   York9 FC · HFX Wanderers · Cavalry FC · Pacific FC






By A to Z

- **C** (3): Cavalry · Cavalry FC · Cavalry Football Club
- **F** (5): Forge · Forge FC · FC Toronto · FC Edmonton · Forge Football Club
- **H** (4): HFX Wanderers · HFX Wanderers FC · Halifax Wanderers · HFX Wanderers Football Club
- **I** (2): Impact Montréal · Impact de Montréal
- **M** (3): Montreal · Montreal I. · Montreal Impact
- **P** (3): Pacific · Pacific FC · Pacific Football Club
- **T** (3): TFC · Toronto · Toronto FC
- **V** (7): Valour · Valour FC · Vancouver · Vancouver W'caps · Vancouver Whitecaps · Valour Football Club · Vancouver Whitecaps FC
- **Y** (3): York9 · York9 FC · York 9 Football Club




