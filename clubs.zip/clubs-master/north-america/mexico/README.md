41 clubs

- [**Club América**](https://en.wikipedia.org/wiki/Club_América) : (3) América · Águilas · América de Mexico ⇒ (4) ≈Aguilas≈ · ≈America≈ · ≈Club America≈ · ≈America de Mexico≈
- [**Cruz Azul**](https://en.wikipedia.org/wiki/Cruz_Azul) : (2) Cruz Azul FC · Cruz Azul Fútbol Club ⇒ (1) ≈Cruz Azul Futbol Club≈
- [**Pumas UNAM**](https://en.wikipedia.org/wiki/Club_Universidad_Nacional) : (5) UNAM · Pumas · UNAM Pumas · Universidad Nacional · Club Universidad Nacional
- [**Deportivo Toluca FC**](https://en.wikipedia.org/wiki/Club_Toluca) : (3) Toluca · Club Toluca · Deportivo Toluca
- **Potros UAEM** : (3) UAEM · UAEM Potros · Club de Fútbol Potros de la Universidad Autónoma del Estado de México ⇒ (1) ≈Club de Futbol Potros de la Universidad Autonoma del Estado de Mexico≈
- [**CD Guadalajara Chivas**](https://en.wikipedia.org/wiki/C.D._Guadalajara) : (6) Chivas · Guadalajara · CD Guadalajara · Guadalajara Chivas · Deportivo Guadalajara · Club Deportivo Guadalajara
- [**Club Atlas**](https://en.wikipedia.org/wiki/Club_Atlas) : (3) Atlas · Atlas FC · Club Atlas de Guadalajara
- **Leones Negros U. de G.** : (6) UDG · U. de G. · Leones Negros · U. Guadalajara · U. de Guadalajara · Universidad de Guadalajara
- **Estudiantes UAG** : (5) UAG · Estudiantes · UA. Guadalajara · Estudiantes Tecos · Universidad Autónoma de Guadalajara ⇒ (1) ≈Universidad Autonoma de Guadalajara≈
- [**CF Monterrey**](https://en.wikipedia.org/wiki/C.F._Monterrey) : (3) Monterrey · Rayados (de Monterrey) · Club de Fútbol Monterrey ⇒ (1) ≈Club de Futbol Monterrey≈
- [**Tigres UANL**](https://en.wikipedia.org/wiki/Tigres_UANL) : (5) UANL · Tigres · UANL Tigres · UA. Nuevo León · Club de Fútbol Tigres de la Universidad Autónoma de Nuevo León ⇒ (2) ≈UA. Nuevo Leon≈ · ≈Club de Futbol Tigres de la Universidad Autonoma de Nuevo Leon≈
- [**Club Puebla**](https://en.wikipedia.org/wiki/Puebla_F.C.) : (3) Puebla · Puebla FC · Puebla Fútbol Club ⇒ (1) ≈Puebla Futbol Club≈
- [**Lobos BUAP**](https://en.wikipedia.org/wiki/Lobos_BUAP) : (2) BUAP · Benemérita Universidad Autónoma de Puebla ⇒ (1) ≈Benemerita Universidad Autonoma de Puebla≈
- [**Tiburones Rojos Veracruz**](https://en.wikipedia.org/wiki/Tiburones_Rojos_de_Veracruz) : (2) Veracruz · Tiburones Rojos (de Veracruz)
- [**FC Juárez**](https://en.wikipedia.org/wiki/FC_Juárez) : (2) Juárez · Fútbol Club Juárez ⇒ (3) ≈Juarez≈ · ≈FC Juarez≈ · ≈Futbol Club Juarez≈
- **Altamira**
- **Correcaminos** : (3) UAT · UA. Tamaulipas · Correcaminos UAT
- **Tampico Madero** : (1) Tampico Madero FC
- [**Atlético San Luis**](https://en.wikipedia.org/wiki/Atlético_San_Luis) : (4) San Luis · Atlético · Atl. San Luis · Club San Luis ⇒ (2) ≈Atletico≈ · ≈Atletico San Luis≈
- [**Club León**](https://en.wikipedia.org/wiki/Club_León) : (1) León ⇒ (2) ≈Leon≈ · ≈Club Leon≈
- **Celaya**
- **Galeana** : (1) Ballenas Galeana
- **Zacatepec** : (3) CA Zacatepec · Atlético Zacatepec · Club Atlético Zacatepec ⇒ (2) ≈Atletico Zacatepec≈ · ≈Club Atletico Zacatepec≈
- [**Club Tijuana**](https://en.wikipedia.org/wiki/Club_Tijuana) : (3) Xolos · Tijuana · Club Tijuana Xoloitzcuintles de Caliente
- **Dorados Sinaloa** : (3) Sinaloa · Dorados · Dorados de Sinaloa
- **Mineros Zacatecas** : (2) Mineros de Zacatecas · Club Deportivo Mineros de Zacatecas
- [**Monarcas Morelia**](https://en.wikipedia.org/wiki/Monarcas_Morelia) : (3) Morelia · Monarcas · Atletico Monarcas Morelia
- [**Club Necaxa**](https://en.wikipedia.org/wiki/Club_Necaxa) : (1) Necaxa
- [**CF Pachuca**](https://en.wikipedia.org/wiki/C.F._Pachuca) : (2) Pachuca · Club de Fútbol Pachuca ⇒ (1) ≈Club de Futbol Pachuca≈
- **Cruz Azul Hidalgo** : (1) Cruz Azul Hgo.
- [**Querétaro FC**](https://en.wikipedia.org/wiki/Querétaro_FC) : (3) Querétaro · Querétaro Fútbol Club · Gallos Blancos (de Querétaro) ⇒ (4) ≈Queretaro≈ · ≈Queretaro FC≈ · ≈Queretaro Futbol Club≈ · ≈Gallos Blancos (de Queretaro)≈
- [**Santos Laguna**](https://en.wikipedia.org/wiki/Santos_Laguna) : (2) Santos · Club Santos Laguna
- **U. de C.** : (3) Loros U. de C. · Loros Universidad · Club de Fútbol Loros de la Universidad de Colima ⇒ (1) ≈Club de Futbol Loros de la Universidad de Colima≈
- **Cimarrones de Sonora** : (2) Sonora · Cimarrones de Sonora Fútbol Club ⇒ (1) ≈Cimarrones de Sonora Futbol Club≈
- **Oaxaca**
- **Jaguares Chiapas** : (4) Chiapas · Jaguares · Jaguares de Chiapas · Chiapas Fútbol Club ⇒ (1) ≈Chiapas Futbol Club≈
- **Cafetaleros de Chiapas** : (2) Caf. de Tapachula · Cafetaleros de Tapachula
- **Delfines** : (1) Delfines del Carmen
- **Mérida** ⇒ (1) ≈Merida≈
- **Venados FC** : (1) Venados Fútbol Club ⇒ (1) ≈Venados Futbol Club≈
- **Atlante FC** : (3) Atlante · Potros (de Hierro) · Club de Fútbol Atlante ⇒ (1) ≈Club de Futbol Atlante≈




Alphabet

- **Alphabet Specials** (5):  **Á**  **á**  **é**  **ó**  **ú** 
  - **Á**×1 U+00C1 (193) - LATIN CAPITAL LETTER A WITH ACUTE ⇒ A
  - **á**×3 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×14 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×8 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×13 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Ciudad de México, Ciudad de México** (3): 
  - Club América  (3) América · América de Mexico · Águilas
  - Cruz Azul  (2) Cruz Azul FC · Cruz Azul Fútbol Club
  - Pumas UNAM  (5) UNAM · Pumas · UNAM Pumas · Universidad Nacional · Club Universidad Nacional
- **Guadalajara, Jalisco** (3): 
  - CD Guadalajara Chivas  (6) Guadalajara · Chivas · Guadalajara Chivas · CD Guadalajara · Deportivo Guadalajara · Club Deportivo Guadalajara
  - Club Atlas  (3) Atlas · Club Atlas de Guadalajara · Atlas FC
  - Leones Negros U. de G.  (6) Leones Negros · UDG · U. de G. · U. Guadalajara · U. de Guadalajara · Universidad de Guadalajara
- **Monterrey, Nuevo León** (2): 
  - CF Monterrey  (3) Monterrey · Rayados (de Monterrey) · Club de Fútbol Monterrey
  - Tigres UANL  (5) UANL · Tigres · UANL Tigres · UA. Nuevo León · Club de Fútbol Tigres de la Universidad Autónoma de Nuevo León
- **Mérida, Yucatán** (2): 
  - Mérida 
  - Venados FC  (1) Venados Fútbol Club
- **Puebla, Puebla** (2): 
  - Club Puebla  (3) Puebla · Puebla FC · Puebla Fútbol Club
  - Lobos BUAP  (2) BUAP · Benemérita Universidad Autónoma de Puebla
- **Toluca, México** (2): 
  - Deportivo Toluca FC  (3) Toluca · Club Toluca · Deportivo Toluca
  - Potros UAEM  (3) UAEM · UAEM Potros · Club de Fútbol Potros de la Universidad Autónoma del Estado de México
- **Tuxtla Gutiérrez, Chiapas** (2): 
  - Jaguares Chiapas  (4) Chiapas · Jaguares · Jaguares de Chiapas · Chiapas Fútbol Club
  - Cafetaleros de Chiapas  (2) Cafetaleros de Tapachula · Caf. de Tapachula
- **2012 Cd. del Carmen, Campeche** (1): Delfines  (1) Delfines del Carmen
- **Aguascalientes, Aguascalientes** (1): Club Necaxa  (1) Necaxa
- **Altamira, Tamaulipas** (1): Altamira 
- **Cancún, Quintana Roo** (1): Atlante FC  (3) Atlante · Potros (de Hierro) · Club de Fútbol Atlante
- **Cd. Cooperativa Cruz Azul, Hidalgo** (1): Cruz Azul Hidalgo  (1) Cruz Azul Hgo.
- **Colima City, Colima** (1): U. de C.  (3) Loros Universidad · Loros U. de C. · Club de Fútbol Loros de la Universidad de Colima
- **Culiacán, Sinaloa** (1): Dorados Sinaloa  (3) Dorados de Sinaloa · Dorados · Sinaloa
- **Hermosillo, Sonora** (1): Cimarrones de Sonora  (2) Sonora · Cimarrones de Sonora Fútbol Club
- **Juárez, Chihuahua** (1): FC Juárez  (2) Juárez · Fútbol Club Juárez
- **León, Guanajuato** (1): Club León  (1) León
- **Morelia, Michoacán** (1): Monarcas Morelia  (3) Monarcas · Morelia · Atletico Monarcas Morelia
- **Oaxaca, Oaxaca** (1): Oaxaca 
- **Pachuca, Hidalgo** (1): CF Pachuca  (2) Pachuca · Club de Fútbol Pachuca
- **Querétaro, Querétaro** (1): Querétaro FC  (3) Querétaro · Gallos Blancos (de Querétaro) · Querétaro Fútbol Club
- **San Luis Potosí, San Luis Potosí** (1): Atlético San Luis  (4) San Luis · Atlético · Atl. San Luis · Club San Luis
- **Tampico, Tamaulipas** (1): Tampico Madero  (1) Tampico Madero FC
- **Tijuana, Baja California** (1): Club Tijuana  (3) Tijuana · Xolos · Club Tijuana Xoloitzcuintles de Caliente
- **Torreón, Coahuila** (1): Santos Laguna  (2) Santos · Club Santos Laguna
- **Veracruz, Veracruz** (1): Tiburones Rojos Veracruz  (2) Veracruz · Tiburones Rojos (de Veracruz)
- **Victoria, Tamaulipas** (1): Correcaminos  (3) UAT · Correcaminos UAT · UA. Tamaulipas
- **Xochitepec, Morelos** (1): Galeana  (1) Ballenas Galeana
- **Zacatecas, Zacatecas** (1): Mineros Zacatecas  (2) Mineros de Zacatecas · Club Deportivo Mineros de Zacatecas
- **Zacatepec, Morelos** (1): Zacatepec  (3) CA Zacatepec · Atlético Zacatepec · Club Atlético Zacatepec
- ? (2): 
  - Estudiantes UAG  (5) UAG · Estudiantes · Estudiantes Tecos · UA. Guadalajara · Universidad Autónoma de Guadalajara
  - Celaya 




By Region

- **Ciudad de México** (3):   Club América · Cruz Azul · Pumas UNAM
- **México** (2):   Deportivo Toluca FC · Potros UAEM
- **Jalisco** (3):   CD Guadalajara Chivas · Club Atlas · Leones Negros U. de G.
- **Nuevo León** (2):   CF Monterrey · Tigres UANL
- **Puebla** (2):   Club Puebla · Lobos BUAP
- **Veracruz** (1):   Tiburones Rojos Veracruz
- **Chihuahua** (1):   FC Juárez
- **Tamaulipas** (3):   Altamira · Correcaminos · Tampico Madero
- **San Luis Potosí** (1):   Atlético San Luis
- **Guanajuato** (1):   Club León
- **Morelos** (2):   Galeana · Zacatepec
- **Baja California** (1):   Club Tijuana
- **Sinaloa** (1):   Dorados Sinaloa
- **Zacatecas** (1):   Mineros Zacatecas
- **Michoacán** (1):   Monarcas Morelia
- **Aguascalientes** (1):   Club Necaxa
- **Hidalgo** (2):   CF Pachuca · Cruz Azul Hidalgo
- **Querétaro** (1):   Querétaro FC
- **Coahuila** (1):   Santos Laguna
- **Colima** (1):   U. de C.
- **Sonora** (1):   Cimarrones de Sonora
- **Oaxaca** (1):   Oaxaca
- **Chiapas** (2):   Jaguares Chiapas · Cafetaleros de Chiapas
- **Campeche** (1):   Delfines
- **Yucatán** (2):   Mérida · Venados FC
- **Quintana Roo** (1):   Atlante FC




By Year

- **1901** (1):   CF Pachuca
- **1906** (1):   CD Guadalajara Chivas
- **1916** (3):   Club América · Club Atlas · Atlante FC
- **1917** (1):   Deportivo Toluca FC
- **1923** (1):   Club Necaxa
- **1924** (1):   Monarcas Morelia
- **1927** (1):   Cruz Azul
- **1943** (1):   Tiburones Rojos Veracruz
- **1944** (2):   Club Puebla · Club León
- **1945** (1):   CF Monterrey
- **1948** (1):   Zacatepec
- **1950** (1):   Querétaro FC
- **1954** (2):   Pumas UNAM · Celaya
- **1956** (1):   Galeana
- **1960** (1):   Tigres UANL
- **1967** (1):   Lobos BUAP
- **1970** (2):   Potros UAEM · Leones Negros U. de G.
- **1971** (1):   Estudiantes UAG
- **1980** (1):   Correcaminos
- **1983** (1):   Santos Laguna
- **1988** (1):   Venados FC
- **1993** (1):   Cruz Azul Hidalgo
- **1998** (1):   Atlético San Luis
- **2001** (1):   Altamira
- **2002** (1):   Jaguares Chiapas
- **2003** (2):   Dorados Sinaloa · Mérida
- **2007** (1):   Club Tijuana
- **2012** (1):   Oaxaca
- **2015** (1):   FC Juárez
- ? (6):   Tampico Madero · Mineros Zacatecas · U. de C. · Cimarrones de Sonora · Cafetaleros de Chiapas · Delfines






By A to Z

- **A** (12): Atlas · América · Atlante · Altamira · Atlas FC · Atlético · Atlante FC · Atl. San Luis · América de Mexico · Atlético San Luis · Atlético Zacatepec · Atletico Monarcas Morelia
- **B** (3): BUAP · Ballenas Galeana · Benemérita Universidad Autónoma de Puebla
- **C** (42): Celaya · Chivas · Chiapas · Club León · Cruz Azul · CF Pachuca · Club Atlas · Club Necaxa · Club Puebla · Club Toluca · CA Zacatepec · CF Monterrey · Club América · Club Tijuana · Correcaminos · Cruz Azul FC · Club San Luis · CD Guadalajara · Cruz Azul Hgo. · Correcaminos UAT · Caf. de Tapachula · Cruz Azul Hidalgo · Club Santos Laguna · Chiapas Fútbol Club · Cimarrones de Sonora · CD Guadalajara Chivas · Cruz Azul Fútbol Club · Cafetaleros de Chiapas · Club de Fútbol Atlante · Club de Fútbol Pachuca · Club Atlético Zacatepec · Cafetaleros de Tapachula · Club de Fútbol Monterrey · Club Atlas de Guadalajara · Club Universidad Nacional · Club Deportivo Guadalajara · Cimarrones de Sonora Fútbol Club · Club Deportivo Mineros de Zacatecas · Club Tijuana Xoloitzcuintles de Caliente · Club de Fútbol Loros de la Universidad de Colima · Club de Fútbol Tigres de la Universidad Autónoma de Nuevo León · Club de Fútbol Potros de la Universidad Autónoma del Estado de México
- **D** (8): Dorados · Delfines · Dorados Sinaloa · Deportivo Toluca · Dorados de Sinaloa · Delfines del Carmen · Deportivo Toluca FC · Deportivo Guadalajara
- **E** (3): Estudiantes · Estudiantes UAG · Estudiantes Tecos
- **F** (2): FC Juárez · Fútbol Club Juárez
- **G** (4): Galeana · Guadalajara · Guadalajara Chivas · Gallos Blancos (de Querétaro)
- **J** (4): Juárez · Jaguares · Jaguares Chiapas · Jaguares de Chiapas
- **L** (6): León · Lobos BUAP · Leones Negros · Loros U. de C. · Loros Universidad · Leones Negros U. de G.
- **M** (7): Mérida · Morelia · Monarcas · Monterrey · Monarcas Morelia · Mineros Zacatecas · Mineros de Zacatecas
- **N** (1): Necaxa
- **O** (1): Oaxaca
- **P** (8): Pumas · Puebla · Pachuca · Puebla FC · Pumas UNAM · Potros UAEM · Potros (de Hierro) · Puebla Fútbol Club
- **Q** (3): Querétaro · Querétaro FC · Querétaro Fútbol Club
- **R** (1): Rayados (de Monterrey)
- **S** (5): Santos · Sonora · Sinaloa · San Luis · Santos Laguna
- **T** (8): Tigres · Toluca · Tijuana · Tigres UANL · Tampico Madero · Tampico Madero FC · Tiburones Rojos Veracruz · Tiburones Rojos (de Veracruz)
- **U** (19): UAG · UAT · UDG · UAEM · UANL · UNAM · U. de C. · U. de G. · UNAM Pumas · UAEM Potros · UANL Tigres · U. Guadalajara · UA. Nuevo León · UA. Tamaulipas · UA. Guadalajara · U. de Guadalajara · Universidad Nacional · Universidad de Guadalajara · Universidad Autónoma de Guadalajara
- **V** (3): Veracruz · Venados FC · Venados Fútbol Club
- **X** (1): Xolos
- **Z** (1): Zacatepec
- **Á** (1): Águilas




