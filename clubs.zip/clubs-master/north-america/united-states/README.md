99 clubs

- [**Atlanta United FC**](https://en.wikipedia.org/wiki/Atlanta_United_FC) : (3) Atlanta · Atlanta Utd · Atlanta United
- **Atlanta United 2**
- **South Georgia Tormenta FC** : (1) Tormenta FC
- **South Georgia Tormenta 2** : (1) South Georgia Tormenta FC 2
- **Birmingham Legion FC**
- **Little Rock Rangers** : (1) Little Rock Rangers Soccer Club
- **Charleston Battery**
- **Greenville Triumph** : (1) Greenville Triumph SC
- **Charlotte Independence**
- **North Carolina FC**
- **Forward Madison FC**
- **Milwaukee Bavarian SC**
- [**Chicago Fire**](https://en.wikipedia.org/wiki/Chicago_Fire_Soccer_Club) : (2) Chicago · Chicago Fire Soccer Club
- **AFC Ann Arbor**
- **Lansing Ignite FC**
- [**Columbus Crew SC**](https://en.wikipedia.org/wiki/Columbus_Crew_SC) : (2) Columbus · Columbus Crew
- [**FC Cincinnati**](https://en.wikipedia.org/wiki/FC_Cincinnati) : (1) Cincinnati
- **Dayton Dutch Lions**
- **Des Moines Menace**
- [**D.C. United**](https://en.wikipedia.org/wiki/D.C._United) : (1) Washington D.C. United
- **FC Baltimore** : (1) FC Baltimore Christos
- **Loudoun United FC**
- **Richmond Kickers**
- **Virginia United FC**
- [**New England Revolution**](https://en.wikipedia.org/wiki/New_England_Revolution) : (3) New England · N.E. Revolution · New England Rev.
- **Black Rock FC**
- [**New York City FC**](https://en.wikipedia.org/wiki/New_York_City_FC) : (2) NYC FC · New York City
- **New York Cosmos**
- [**New York Red Bulls**](https://en.wikipedia.org/wiki/New_York_Red_Bulls) : (3) Metrostars · NY Red Bulls · New York Metrostars
- **New York Red Bulls II**
- **New York Red Bulls U23** : (1) New York Red Bulls U-23
- **FC Motown** : (1) FC Morristown
- **Hartford Athletic**
- **Saint Louis FC**
- [**Orlando City SC**](https://en.wikipedia.org/wiki/Orlando_City_SC) : (2) Orlando · Orlando City
- **Inter Miami CF** : (2) Inter Miami · Club Internacional de Fútbol Miami ⇒ (1) ≈Club Internacional de Futbol Miami≈
- **Miami FC**
- **Tampa Bay Rowdies**
- **Florida Soccer Soldiers**
- **Lakeland Tropics**
- **The Villages SC** : (1) The Villages Soccer Club
- [**Philadelphia Union**](https://en.wikipedia.org/wiki/Philadelphia_Union) : (1) Philadelphia
- **Philadelphia Union II**
- **Philadelphia Lone Star FC**
- **Pittsburgh Riverhounds SC** : (1) Pittsburgh Riverhounds
- **Erie Commodores FC**
- **Reading United AC**
- **West Chester Predators**
- **Nashville SC** : (1) Nashville Soccer Club
- **Memphis 901 FC**
- **Chattanooga Red Wolves** : (1) Chattanooga Red Wolves SC
- **Indy Eleven**
- [**Colorado Rapids**](https://en.wikipedia.org/wiki/Colorado_Rapids) : (1) Colorado
- **Colorado Springs Switchbacks FC**
- **FC Denver**
- [**FC Dallas**](https://en.wikipedia.org/wiki/FC_Dallas) : (1) Dallas
- **NTX Rayados** : (1) North Texas Rayados
- [**Houston Dynamo**](https://en.wikipedia.org/wiki/Houston_Dynamo) : (2) Houston · H. Dynamo
- **Austin Bold FC**
- **El Paso Locomotive FC**
- **Rio Grande Valley FC Toros**
- **San Antonio FC**
- **Brazos Valley Cavalry FC**
- **Laredo Heat**
- **Midland-Odessa Sockers FC**
- [**LA Galaxy**](https://en.wikipedia.org/wiki/LA_Galaxy) : (1) Los Angeles Galaxy
- **LA Galaxy II**
- [**Los Angeles FC**](https://en.wikipedia.org/wiki/Los_Angeles_FC) : (1) LAFC
- [**San Jose Earthquakes**](https://en.wikipedia.org/wiki/San_Jose_Earthquakes) : (3) San Jose · Earthquakes · SJ Earthquakes
- **Orange County SC**
- **Orange County FC**
- **Sacramento Republic FC**
- **San Diego Loyal SC**
- **Academica SC**
- **Cal FC**
- **El Farolito**
- **Golden State Force** : (1) FC Golden State Force
- **Fresno FC**
- [**Seattle Sounders FC**](https://en.wikipedia.org/wiki/Seattle_Sounders_FC) : (2) Seattle · Seattle Sounders
- **Tacoma Defiance**
- [**Portland Timbers**](https://en.wikipedia.org/wiki/Portland_Timbers) : (1) Portland
- **Portland Timbers 2**
- **FC Mulhouse Portland** : (1) International Portland Select FC
- [**Minnesota United FC**](https://en.wikipedia.org/wiki/Minnesota_United_FC) : (3) Minnesota · Minnesota United · FC Minnesota Utd.
- **Duluth FC**
- [**Real Salt Lake**](https://en.wikipedia.org/wiki/Real_Salt_Lake) : (1) Real Salt Lake City
- **Real Monarchs** : (1) Real Monarchs SLC
- [**Sporting Kansas City**](https://en.wikipedia.org/wiki/Sporting_Kansas_City) : (3) Sporting KC · Sp. Kansas City · Kansas City Wizards
- **Sporting Kansas City II**
- **OKC Energy FC** : (1) Oklahoma City Energy FC
- **FC Tulsa**
- **Louisville City FC**
- **Las Vegas Lights FC**
- **Reno 1868 FC**
- **New Mexico United**
- **Phoenix Rising FC**
- [**Tampa Bay Mutiny (1996-2001)**](https://en.wikipedia.org/wiki/Tampa_Bay_Mutiny)
- [**Miami Fusion (1998-2001)**](https://en.wikipedia.org/wiki/Miami_Fusion)
- [**CD Chivas USA (2005-2014)**](https://en.wikipedia.org/wiki/Chivas_USA) : (2) Chivas USA · Club Deportivo Chivas US




Alphabet

- **Alphabet Specials** (1):  **ú** 
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates

- **New York Red Bulls U23**, Harrison (1):
  - `newyorkredbullsu23` (2): New York Red Bulls U23 · New York Red Bulls U-23




By City

- **Carson, California** (3): 
  - LA Galaxy  (1) Los Angeles Galaxy
  - LA Galaxy II 
  - CD Chivas USA (2005-2014)  (2) Chivas USA · Club Deportivo Chivas US
- **Harrison, New Jersey** (3): 
  - New York Red Bulls  (3) NY Red Bulls · New York Metrostars · Metrostars
  - New York Red Bulls II 
  - New York Red Bulls U23  (1) New York Red Bulls U-23
- **Portland, Oregon** (3): 
  - Portland Timbers  (1) Portland
  - Portland Timbers 2 
  - FC Mulhouse Portland  (1) International Portland Select FC
- **Atlanta, Georgia** (2): 
  - Atlanta United FC  (3) Atlanta · Atlanta United · Atlanta Utd
  - Atlanta United 2 
- **Chester, Pennsylvania** (2): 
  - Philadelphia Union  (1) Philadelphia
  - Philadelphia Union II 
- **Kansas City, Kansas** (2): 
  - Sporting Kansas City  (3) Sp. Kansas City · Sporting KC · Kansas City Wizards
  - Sporting Kansas City II 
- **Miami, Florida** (2): 
  - Inter Miami CF  (2) Inter Miami · Club Internacional de Fútbol Miami
  - Miami FC 
- **New York City, New York** (2): 
  - New York City FC  (2) NYC FC · New York City
  - New York Cosmos 
- **Statesboro, Georgia** (2): 
  - South Georgia Tormenta FC  (1) Tormenta FC
  - South Georgia Tormenta 2  (1) South Georgia Tormenta FC 2
- **Albuquerque, New Mexico** (1): New Mexico United 
- **Ann Arbor, Michigan** (1): AFC Ann Arbor 
- **Austin, Texas** (1): Austin Bold FC 
- **Baltimore, Maryland** (1): FC Baltimore  (1) FC Baltimore Christos
- **Birmingham, Alabama** (1): Birmingham Legion FC 
- **Bridgeview, Illinois** (1): Chicago Fire  (2) Chicago · Chicago Fire Soccer Club
- **Bryan, Texas** (1): Brazos Valley Cavalry FC 
- **Cary, North Carolina** (1): North Carolina FC 
- **Charleston, South Carolina** (1): Charleston Battery 
- **Chattanooga, Tennessee** (1): Chattanooga Red Wolves  (1) Chattanooga Red Wolves SC
- **Cincinnati, Ohio** (1): FC Cincinnati  (1) Cincinnati
- **Colorado Springs, Colorado** (1): Colorado Springs Switchbacks FC 
- **Columbus, Ohio** (1): Columbus Crew SC  (2) Columbus · Columbus Crew
- **Commerce City, Colorado** (1): Colorado Rapids  (1) Colorado
- **Dallas, Texas** (1): NTX Rayados  (1) North Texas Rayados
- **Dayton, Ohio** (1): Dayton Dutch Lions 
- **Denver, Colorado** (1): FC Denver 
- **Des Moines, Iowa** (1): Des Moines Menace 
- **Duluth, Minnesota** (1): Duluth FC 
- **Edinburg, Texas** (1): Rio Grande Valley FC Toros 
- **El Paso, Texas** (1): El Paso Locomotive FC 
- **Erie, Pennsylvania** (1): Erie Commodores FC 
- **Fenton, Missouri** (1): Saint Louis FC 
- **Fort Lauderdale, Florida** (1): Miami Fusion (1998-2001) 
- **Foxborough, Massachusetts** (1): New England Revolution  (3) New England · N.E. Revolution · New England Rev.
- **Fresno, California** (1): Fresno FC 
- **Frisco, Texas** (1): FC Dallas  (1) Dallas
- **Greenville, South Carolina** (1): Greenville Triumph  (1) Greenville Triumph SC
- **Hartford, Connecticut** (1): Hartford Athletic 
- **Herriman, Utah** (1): Real Monarchs  (1) Real Monarchs SLC
- **Houston, Texas** (1): Houston Dynamo  (2) Houston · H. Dynamo
- **Indianapolis, Indiana** (1): Indy Eleven 
- **Irvine, California** (1): Orange County SC 
- **Lake Forest, California** (1): Orange County FC 
- **Lakeland, Florida** (1): Lakeland Tropics 
- **Lakeville, Massachusetts** (1): Black Rock FC 
- **Lansing, Michigan** (1): Lansing Ignite FC 
- **Laredo, Texas** (1): Laredo Heat 
- **Las Vegas, Nevada** (1): Las Vegas Lights FC 
- **Leesburg, Virginia** (1): Loudoun United FC 
- **Little Rock, Arkansas** (1): Little Rock Rangers  (1) Little Rock Rangers Soccer Club
- **Los Angeles, California** (1): Los Angeles FC  (1) LAFC
- **Louisville, Kentucky** (1): Louisville City FC 
- **Madison, Wisconsin** (1): Forward Madison FC 
- **Matthews, North Carolina** (1): Charlotte Independence 
- **Memphis, Tennessee** (1): Memphis 901 FC 
- **Midland, Texas** (1): Midland-Odessa Sockers FC 
- **Milwaukee, Wisconsin** (1): Milwaukee Bavarian SC 
- **Minneapolis, Minnesota** (1): Minnesota United FC  (3) Minnesota · Minnesota United · FC Minnesota Utd.
- **Morristown, New Jersey** (1): FC Motown  (1) FC Morristown
- **Nashville, Tennessee** (1): Nashville SC  (1) Nashville Soccer Club
- **North Miami Beach, Florida** (1): Florida Soccer Soldiers 
- **Oklahoma City, Oklahoma** (1): OKC Energy FC  (1) Oklahoma City Energy FC
- **Orlando, Florida** (1): Orlando City SC  (2) Orlando · Orlando City
- **Philadelphia, Pennsylvania** (1): Philadelphia Lone Star FC 
- **Pittsburgh, Pennsylvania** (1): Pittsburgh Riverhounds SC  (1) Pittsburgh Riverhounds
- **Reading, Pennsylvania** (1): Reading United AC 
- **Reno, Nevada** (1): Reno 1868 FC 
- **Richmond, Virginia** (1): Richmond Kickers 
- **Sacramento, California** (1): Sacramento Republic FC 
- **San Antonio, Texas** (1): San Antonio FC 
- **San Diego, California** (1): San Diego Loyal SC 
- **San Francisco, California** (1): El Farolito 
- **San Jose, California** (1): San Jose Earthquakes  (3) San Jose · SJ Earthquakes · Earthquakes
- **Sandy, Utah** (1): Real Salt Lake  (1) Real Salt Lake City
- **Seattle, Washington** (1): Seattle Sounders FC  (2) Seattle · Seattle Sounders
- **St. Petersburg, Florida** (1): Tampa Bay Rowdies 
- **Tacoma, Washington** (1): Tacoma Defiance 
- **Tampa, Florida** (1): Tampa Bay Mutiny (1996-2001) 
- **Tempe, Arizona** (1): Phoenix Rising FC 
- **The Villages, Florida** (1): The Villages SC  (1) The Villages Soccer Club
- **Thousand Oaks, California** (1): Cal FC 
- **Tulsa, Oklahoma** (1): FC Tulsa 
- **Turlock, California** (1): Academica SC 
- **Washington, D.C.** (1): D.C. United  (1) Washington D.C. United
- **West Chester, Pennsylvania** (1): West Chester Predators 
- **Whittier, California** (1): Golden State Force  (1) FC Golden State Force
- **Woodbridge, Virginia** (1): Virginia United FC 




By Region

- **Georgia** (4):   Atlanta United FC · Atlanta United 2 · South Georgia Tormenta FC · South Georgia Tormenta 2
- **Alabama** (1):   Birmingham Legion FC
- **Arkansas** (1):   Little Rock Rangers
- **South Carolina** (2):   Charleston Battery · Greenville Triumph
- **North Carolina** (2):   Charlotte Independence · North Carolina FC
- **Wisconsin** (2):   Forward Madison FC · Milwaukee Bavarian SC
- **Illinois** (1):   Chicago Fire
- **Michigan** (2):   AFC Ann Arbor · Lansing Ignite FC
- **Ohio** (3):   Columbus Crew SC · FC Cincinnati · Dayton Dutch Lions
- **Iowa** (1):   Des Moines Menace
- **D.C.** (1):   D.C. United
- **Maryland** (1):   FC Baltimore
- **Virginia** (3):   Loudoun United FC · Richmond Kickers · Virginia United FC
- **Massachusetts** (2):   New England Revolution · Black Rock FC
- **New York** (2):   New York City FC · New York Cosmos
- **New Jersey** (4):   New York Red Bulls · New York Red Bulls II · New York Red Bulls U23 · FC Motown
- **Connecticut** (1):   Hartford Athletic
- **Missouri** (1):   Saint Louis FC
- **Florida** (9):   Orlando City SC · Inter Miami CF · Miami FC · Tampa Bay Rowdies · Florida Soccer Soldiers · Lakeland Tropics · The Villages SC · Tampa Bay Mutiny (1996-2001) · Miami Fusion (1998-2001)
- **Pennsylvania** (7):   Philadelphia Union · Philadelphia Union II · Philadelphia Lone Star FC · Pittsburgh Riverhounds SC · Erie Commodores FC · Reading United AC · West Chester Predators
- **Tennessee** (3):   Nashville SC · Memphis 901 FC · Chattanooga Red Wolves
- **Indiana** (1):   Indy Eleven
- **Colorado** (3):   Colorado Rapids · Colorado Springs Switchbacks FC · FC Denver
- **Texas** (10):   FC Dallas · NTX Rayados · Houston Dynamo · Austin Bold FC · El Paso Locomotive FC · Rio Grande Valley FC Toros · San Antonio FC · Brazos Valley Cavalry FC · Laredo Heat · Midland-Odessa Sockers FC
- **California** (14):   LA Galaxy · LA Galaxy II · Los Angeles FC · San Jose Earthquakes · Orange County SC · Orange County FC · Sacramento Republic FC · San Diego Loyal SC · Academica SC · Cal FC · El Farolito · Golden State Force · Fresno FC · CD Chivas USA (2005-2014)
- **Washington** (2):   Seattle Sounders FC · Tacoma Defiance
- **Oregon** (3):   Portland Timbers · Portland Timbers 2 · FC Mulhouse Portland
- **Minnesota** (2):   Minnesota United FC · Duluth FC
- **Utah** (2):   Real Salt Lake · Real Monarchs
- **Kansas** (2):   Sporting Kansas City · Sporting Kansas City II
- **Oklahoma** (2):   OKC Energy FC · FC Tulsa
- **Kentucky** (1):   Louisville City FC
- **Nevada** (2):   Las Vegas Lights FC · Reno 1868 FC
- **New Mexico** (1):   New Mexico United
- **Arizona** (1):   Phoenix Rising FC




By Year

- **1996** (10):   Columbus Crew SC · D.C. United · New England Revolution · New York Red Bulls · Colorado Rapids · FC Dallas · LA Galaxy · San Jose Earthquakes · Sporting Kansas City · Tampa Bay Mutiny (1996-2001)
- **1998** (2):   Chicago Fire · Miami Fusion (1998-2001)
- **2005** (2):   Real Salt Lake · CD Chivas USA (2005-2014)
- **2006** (1):   Houston Dynamo
- **2009** (1):   Seattle Sounders FC
- **2010** (2):   New York Cosmos · Philadelphia Union
- **2011** (1):   Portland Timbers
- **2015** (2):   New York City FC · Orlando City SC
- **2017** (3):   Atlanta United FC · Nashville SC · Minnesota United FC
- **2018** (2):   Inter Miami CF · Los Angeles FC
- **2019** (1):   FC Cincinnati
- ? (72):   Atlanta United 2 · South Georgia Tormenta FC · South Georgia Tormenta 2 · Birmingham Legion FC · Little Rock Rangers · Charleston Battery · Greenville Triumph · Charlotte Independence · North Carolina FC · Forward Madison FC · Milwaukee Bavarian SC · AFC Ann Arbor · Lansing Ignite FC · Dayton Dutch Lions · Des Moines Menace · FC Baltimore · Loudoun United FC · Richmond Kickers · Virginia United FC · Black Rock FC · New York Red Bulls II · New York Red Bulls U23 · FC Motown · Hartford Athletic · Saint Louis FC · Miami FC · Tampa Bay Rowdies · Florida Soccer Soldiers · Lakeland Tropics · The Villages SC · Philadelphia Union II · Philadelphia Lone Star FC · Pittsburgh Riverhounds SC · Erie Commodores FC · Reading United AC · West Chester Predators · Memphis 901 FC · Chattanooga Red Wolves · Indy Eleven · Colorado Springs Switchbacks FC · FC Denver · NTX Rayados · Austin Bold FC · El Paso Locomotive FC · Rio Grande Valley FC Toros · San Antonio FC · Brazos Valley Cavalry FC · Laredo Heat · Midland-Odessa Sockers FC · LA Galaxy II · Orange County SC · Orange County FC · Sacramento Republic FC · San Diego Loyal SC · Academica SC · Cal FC · El Farolito · Golden State Force · Fresno FC · Tacoma Defiance · Portland Timbers 2 · FC Mulhouse Portland · Duluth FC · Real Monarchs · Sporting Kansas City II · OKC Energy FC · FC Tulsa · Louisville City FC · Las Vegas Lights FC · Reno 1868 FC · New Mexico United · Phoenix Rising FC




Historic

- **2001** (2):   Tampa Bay Mutiny (1996-2001) · Miami Fusion (1998-2001)
- **2014** (1):   CD Chivas USA (2005-2014)






By A to Z

- **A** (8): Atlanta · Atlanta Utd · Academica SC · AFC Ann Arbor · Atlanta United · Austin Bold FC · Atlanta United 2 · Atlanta United FC
- **B** (3): Black Rock FC · Birmingham Legion FC · Brazos Valley Cavalry FC
- **C** (19): Cal FC · Chicago · Colorado · Columbus · Chivas USA · Cincinnati · Chicago Fire · Columbus Crew · Colorado Rapids · Columbus Crew SC · Charleston Battery · Charlotte Independence · Chattanooga Red Wolves · Chicago Fire Soccer Club · Club Deportivo Chivas US · CD Chivas USA (2005-2014) · Chattanooga Red Wolves SC · Colorado Springs Switchbacks FC · Club Internacional de Fútbol Miami
- **D** (5): Dallas · Duluth FC · D.C. United · Des Moines Menace · Dayton Dutch Lions
- **E** (4): Earthquakes · El Farolito · Erie Commodores FC · El Paso Locomotive FC
- **F** (14): FC Tulsa · FC Dallas · FC Denver · FC Motown · Fresno FC · FC Baltimore · FC Cincinnati · FC Morristown · FC Minnesota Utd. · Forward Madison FC · FC Mulhouse Portland · FC Baltimore Christos · FC Golden State Force · Florida Soccer Soldiers
- **G** (3): Golden State Force · Greenville Triumph · Greenville Triumph SC
- **H** (4): Houston · H. Dynamo · Houston Dynamo · Hartford Athletic
- **I** (4): Indy Eleven · Inter Miami · Inter Miami CF · International Portland Select FC
- **K** (1): Kansas City Wizards
- **L** (13): LAFC · LA Galaxy · Laredo Heat · LA Galaxy II · Los Angeles FC · Lakeland Tropics · Lansing Ignite FC · Loudoun United FC · Los Angeles Galaxy · Louisville City FC · Las Vegas Lights FC · Little Rock Rangers · Little Rock Rangers Soccer Club
- **M** (9): Miami FC · Minnesota · Metrostars · Memphis 901 FC · Minnesota United · Minnesota United FC · Milwaukee Bavarian SC · Miami Fusion (1998-2001) · Midland-Odessa Sockers FC
- **N** (20): NYC FC · NTX Rayados · New England · NY Red Bulls · Nashville SC · New York City · N.E. Revolution · New York Cosmos · New England Rev. · New York City FC · New Mexico United · North Carolina FC · New York Red Bulls · New York Metrostars · North Texas Rayados · Nashville Soccer Club · New York Red Bulls II · New England Revolution · New York Red Bulls U23 · New York Red Bulls U-23
- **O** (7): Orlando · Orlando City · OKC Energy FC · Orlando City SC · Orange County FC · Orange County SC · Oklahoma City Energy FC
- **P** (10): Portland · Philadelphia · Portland Timbers · Phoenix Rising FC · Philadelphia Union · Portland Timbers 2 · Philadelphia Union II · Pittsburgh Riverhounds · Philadelphia Lone Star FC · Pittsburgh Riverhounds SC
- **R** (8): Reno 1868 FC · Real Monarchs · Real Salt Lake · Richmond Kickers · Reading United AC · Real Monarchs SLC · Real Salt Lake City · Rio Grande Valley FC Toros
- **S** (17): Seattle · San Jose · Sporting KC · SJ Earthquakes · Saint Louis FC · San Antonio FC · Sp. Kansas City · Seattle Sounders · San Diego Loyal SC · Seattle Sounders FC · San Jose Earthquakes · Sporting Kansas City · Sacramento Republic FC · Sporting Kansas City II · South Georgia Tormenta 2 · South Georgia Tormenta FC · South Georgia Tormenta FC 2
- **T** (6): Tormenta FC · Tacoma Defiance · The Villages SC · Tampa Bay Rowdies · The Villages Soccer Club · Tampa Bay Mutiny (1996-2001)
- **V** (1): Virginia United FC
- **W** (2): Washington D.C. United · West Chester Predators




