5 datafiles, 44 clubs

**africa/congo-dr/cd.clubs.txt** _(1)_:  AS Vita Club

**africa/egypt/eg.clubs.txt** _(23)_:  Al Ahly · Al Mokawloon Al Arab · El Dakhleya · El Entag El Harby · ENPPI SC · Ittihad El Shorta · Tala'ea El Gaish · Wadi Degla · FC Masr · Pyramids FC · Al Ittihad Al Sakandary · Haras El Hodood · Smouha SC · Zamalek · Ismaily · El Gouna · Ghazl El Mahalla · Misr El Makasa · Petrojet · Telephonat Bani Sweif · Tanta SC · Aswan SC · Al Masry SC

**africa/morocco/ma.clubs.txt** _(2)_:  Raja Casablanca · Wydad Casabl.

**africa/south-africa/za.clubs.txt** _(16)_:  Highlands Park · Kaizer Chiefs · Orlando Pirates · Bidwest Wits · Cape Town City · SuperSport United · Mamelodi Sundowns · Baroka · Polokwane City · Black Leopards · Bloemfontein Celtic · Chippa United · Maritzburg United · Stellenbosch United · AmaZulu Durban · Golden Arrows

**africa/tunisia/tn.clubs.txt** _(2)_:  Espérance Sportive de Tunis · JS Kairouanaise

