2 clubs

- **Espérance Sportive de Tunis** : (1) Esp. Sp. Tunis ⇒ (1) ≈Esperance Sportive de Tunis≈
- **JS Kairouanaise** : (2) JSK · Jeunesse Sportive Kairouanaise




Alphabet

- **Alphabet Specials** (1):  **é** 
  - **é**×1 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e




Duplicates





By City

- **Kairouan** (1): JS Kairouanaise  (2) JSK · Jeunesse Sportive Kairouanaise
- **Tunis** (1): Espérance Sportive de Tunis  (1) Esp. Sp. Tunis




By Region

- **Tunis†** (1):   Espérance Sportive de Tunis
- **Kairouan†** (1):   JS Kairouanaise




By Year

- ? (2):   Espérance Sportive de Tunis · JS Kairouanaise






By A to Z

- **E** (2): Esp. Sp. Tunis · Espérance Sportive de Tunis
- **J** (3): JSK · JS Kairouanaise · Jeunesse Sportive Kairouanaise




