23 clubs

- **Al Ahly** : (4) Al-Ahly · Al Ahly SC · Al Ahly Cairo · Al Ahly Sporting Club
- **Al Mokawloon Al Arab** : (2) Al Moqawloon · Arab Contractors (Sporting Club)
- **El Dakhleya**
- **El Entag El Harby** : (1) Military Production
- **ENPPI SC** : (2) Enppi · ENPPI Club
- **Ittihad El Shorta** : (1) Police Union
- **Tala'ea El Gaish** : (2) Army's Vanguards · Tala'ea El-Gaish SC
- **Wadi Degla** : (2) Wadi Degla SC · Wadi Degla FC
- **FC Masr** : (1) Football Club Masr
- **Pyramids FC** : (1) Pyramids Football Club
- **Al Ittihad Al Sakandary** : (2) Al Ittihad · Alexandrian Union Club
- **Haras El Hodood** : (1) Haras El-Hodood SC
- **Smouha SC** : (2) Smouha · Smouha Sporting Club
- **Zamalek** : (3) Zamalek SC · El Zamalek · Zamalek Sporting Club
- **Ismaily** : (1) Ismaily SC
- **El Gouna** : (1) El Gouna FC
- **Ghazl El Mahalla** : (2) Ghazl El Mahalla SC · Ghazl El Mahalla Sporting Club
- **Misr El Makasa** : (3) Misr LeL Makasa · Misr Lel Makkasa SC · Misr Lel Makkasa Sporting Club
- **Petrojet** : (2) Petrojet FC · Petrojet Football Club
- **Telephonat Bani Sweif** : (1) TE Beni Suef
- **Tanta SC** : (2) FC Tanta · Tanta Sports Club
- **Aswan SC** : (2) Aswan FC · Aswan Sporting Club
- **Al Masry SC** : (2) Al-Masry Club · Al Masry Sporting Club




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Al Ahly**, Cairo (1):
  - `alahly` (2): Al Ahly · Al-Ahly




By City

- **Cairo, Cairo** (10): 
  - Al Ahly  (4) Al-Ahly · Al Ahly Cairo · Al Ahly SC · Al Ahly Sporting Club
  - Al Mokawloon Al Arab  (2) Arab Contractors (Sporting Club) · Al Moqawloon
  - El Dakhleya 
  - El Entag El Harby  (1) Military Production
  - ENPPI SC  (2) Enppi · ENPPI Club
  - Ittihad El Shorta  (1) Police Union
  - Tala'ea El Gaish  (2) Army's Vanguards · Tala'ea El-Gaish SC
  - Wadi Degla  (2) Wadi Degla SC · Wadi Degla FC
  - FC Masr  (1) Football Club Masr
  - Pyramids FC  (1) Pyramids Football Club
- **Alexandria, Alexandria** (3): 
  - Al Ittihad Al Sakandary  (2) Al Ittihad · Alexandrian Union Club
  - Haras El Hodood  (1) Haras El-Hodood SC
  - Smouha SC  (2) Smouha · Smouha Sporting Club
- **Aswan** (1): Aswan SC  (2) Aswan Sporting Club · Aswan FC
- **Beni Suef, Beni Suef** (1): Telephonat Bani Sweif  (1) TE Beni Suef
- **El Mahalla El Kubra, Gharbia** (1): Ghazl El Mahalla  (2) Ghazl El Mahalla SC · Ghazl El Mahalla Sporting Club
- **Faiyum, Faiyum** (1): Misr El Makasa  (3) Misr LeL Makasa · Misr Lel Makkasa SC · Misr Lel Makkasa Sporting Club
- **Giza, Giza** (1): Zamalek  (3) Zamalek SC · Zamalek Sporting Club · El Zamalek
- **Hurghada, Red Sea** (1): El Gouna  (1) El Gouna FC
- **Ismailia, Ismailia** (1): Ismaily  (1) Ismaily SC
- **Port Said** (1): Al Masry SC  (2) Al-Masry Club · Al Masry Sporting Club
- **Suez, Suez** (1): Petrojet  (2) Petrojet FC · Petrojet Football Club
- **Tanta** (1): Tanta SC  (2) Tanta Sports Club · FC Tanta




By Region

- **Cairo** (10):   Al Ahly · Al Mokawloon Al Arab · El Dakhleya · El Entag El Harby · ENPPI SC · Ittihad El Shorta · Tala'ea El Gaish · Wadi Degla · FC Masr · Pyramids FC
- **Alexandria** (3):   Al Ittihad Al Sakandary · Haras El Hodood · Smouha SC
- **Giza** (1):   Zamalek
- **Ismailia** (1):   Ismaily
- **Red Sea** (1):   El Gouna
- **Gharbia** (1):   Ghazl El Mahalla
- **Faiyum** (1):   Misr El Makasa
- **Suez** (1):   Petrojet
- **Beni Suef** (1):   Telephonat Bani Sweif
- **Tanta†** (1):   Tanta SC
- **Aswan†** (1):   Aswan SC
- **Port Said†** (1):   Al Masry SC




By Year

- ? (23):   Al Ahly · Al Mokawloon Al Arab · El Dakhleya · El Entag El Harby · ENPPI SC · Ittihad El Shorta · Tala'ea El Gaish · Wadi Degla · FC Masr · Pyramids FC · Al Ittihad Al Sakandary · Haras El Hodood · Smouha SC · Zamalek · Ismaily · El Gouna · Ghazl El Mahalla · Misr El Makasa · Petrojet · Telephonat Bani Sweif · Tanta SC · Aswan SC · Al Masry SC






By A to Z

- **A** (18): Al Ahly · Al-Ahly · Aswan FC · Aswan SC · Al Ahly SC · Al Ittihad · Al Masry SC · Al Moqawloon · Al Ahly Cairo · Al-Masry Club · Army's Vanguards · Aswan Sporting Club · Al Mokawloon Al Arab · Al Ahly Sporting Club · Al Masry Sporting Club · Alexandrian Union Club · Al Ittihad Al Sakandary · Arab Contractors (Sporting Club)
- **E** (8): Enppi · ENPPI SC · El Gouna · ENPPI Club · El Zamalek · El Dakhleya · El Gouna FC · El Entag El Harby
- **F** (3): FC Masr · FC Tanta · Football Club Masr
- **G** (3): Ghazl El Mahalla · Ghazl El Mahalla SC · Ghazl El Mahalla Sporting Club
- **H** (2): Haras El Hodood · Haras El-Hodood SC
- **I** (3): Ismaily · Ismaily SC · Ittihad El Shorta
- **M** (5): Misr El Makasa · Misr LeL Makasa · Military Production · Misr Lel Makkasa SC · Misr Lel Makkasa Sporting Club
- **P** (6): Petrojet · Petrojet FC · Pyramids FC · Police Union · Petrojet Football Club · Pyramids Football Club
- **S** (3): Smouha · Smouha SC · Smouha Sporting Club
- **T** (6): Tanta SC · TE Beni Suef · Tala'ea El Gaish · Tanta Sports Club · Tala'ea El-Gaish SC · Telephonat Bani Sweif
- **W** (3): Wadi Degla · Wadi Degla FC · Wadi Degla SC
- **Z** (3): Zamalek · Zamalek SC · Zamalek Sporting Club




