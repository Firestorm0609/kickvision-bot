# Egypt (eg)

### Egyptian Premier League

- 18 Teams

#### Wikipedia

- [2012–13_Egyptian_Premier_League](http://en.wikipedia.org/wiki/2012–13_Egyptian_Premier_League)
