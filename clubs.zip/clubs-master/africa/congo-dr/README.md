1 clubs

- **AS Vita Club** : (3) Vita Club · AS V. Club · Association Sportive Vita Club




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Kinshasa** (1): AS Vita Club  (3) AS V. Club · Vita Club · Association Sportive Vita Club




By Region

- **Kinshasa†** (1):   AS Vita Club




By Year

- ? (1):   AS Vita Club






By A to Z

- **A** (3): AS V. Club · AS Vita Club · Association Sportive Vita Club
- **V** (1): Vita Club




