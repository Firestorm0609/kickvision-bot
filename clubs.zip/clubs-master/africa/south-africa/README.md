16 clubs

- **Highlands Park** : (1) Highlands Park FC
- **Kaizer Chiefs** : (1) Kaizer Chiefs FC
- **Orlando Pirates** : (1) Orlando Pirates FC
- **Bidwest Wits** : (2) Wits · Bidwest Wits FC
- **Cape Town City** : (1) Cape Town City FC
- **SuperSport United** : (1) SuperSport United FC
- **Mamelodi Sundowns** : (2) Mamelodi FC · Mamelodi Sundowns FC
- **Baroka** : (1) Baroka FC
- **Polokwane City** : (1) Polokwane City FC
- **Black Leopards** : (1) Black Leopards FC
- **Bloemfontein Celtic** : (2) Bloemfontein · Bloemfontein Celtic FC
- **Chippa United** : (1) Chippa United FC
- **Maritzburg United** : (1) Maritzburg United FC
- **Stellenbosch United** : (1) Stellenbosch FC
- **AmaZulu Durban** : (1) AmaZulu FC
- **Golden Arrows** : (2) Lamontville FC · Lamontville Golden Arrows FC




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Johannesburg** (4): 
  - Highlands Park  (1) Highlands Park FC
  - Kaizer Chiefs  (1) Kaizer Chiefs FC
  - Orlando Pirates  (1) Orlando Pirates FC
  - Bidwest Wits  (2) Wits · Bidwest Wits FC
- **Polokwane** (2): 
  - Baroka  (1) Baroka FC
  - Polokwane City  (1) Polokwane City FC
- **Pretoria** (2): 
  - SuperSport United  (1) SuperSport United FC
  - Mamelodi Sundowns  (2) Mamelodi FC · Mamelodi Sundowns FC
- **Bloemfontein** (1): Bloemfontein Celtic  (2) Bloemfontein · Bloemfontein Celtic FC
- **Cape Town** (1): Cape Town City  (1) Cape Town City FC
- **Durban** (1): Golden Arrows  (2) Lamontville FC · Lamontville Golden Arrows FC
- **Durban North** (1): AmaZulu Durban  (1) AmaZulu FC
- **Pietermaritzburg** (1): Maritzburg United  (1) Maritzburg United FC
- **Port Elizabeth** (1): Chippa United  (1) Chippa United FC
- **Stellenbosch** (1): Stellenbosch United  (1) Stellenbosch FC
- **Thohoyandou** (1): Black Leopards  (1) Black Leopards FC




By Region

- **Johannesburg†** (4):   Highlands Park · Kaizer Chiefs · Orlando Pirates · Bidwest Wits
- **Cape Town†** (1):   Cape Town City
- **Pretoria†** (2):   SuperSport United · Mamelodi Sundowns
- **Polokwane†** (2):   Baroka · Polokwane City
- **Thohoyandou†** (1):   Black Leopards
- **Bloemfontein†** (1):   Bloemfontein Celtic
- **Port Elizabeth†** (1):   Chippa United
- **Pietermaritzburg†** (1):   Maritzburg United
- **Stellenbosch†** (1):   Stellenbosch United
- **Durban North†** (1):   AmaZulu Durban
- **Durban†** (1):   Golden Arrows




By Year

- ? (16):   Highlands Park · Kaizer Chiefs · Orlando Pirates · Bidwest Wits · Cape Town City · SuperSport United · Mamelodi Sundowns · Baroka · Polokwane City · Black Leopards · Bloemfontein Celtic · Chippa United · Maritzburg United · Stellenbosch United · AmaZulu Durban · Golden Arrows






By A to Z

- **A** (2): AmaZulu FC · AmaZulu Durban
- **B** (9): Baroka · Baroka FC · Bidwest Wits · Bloemfontein · Black Leopards · Bidwest Wits FC · Black Leopards FC · Bloemfontein Celtic · Bloemfontein Celtic FC
- **C** (4): Chippa United · Cape Town City · Chippa United FC · Cape Town City FC
- **G** (1): Golden Arrows
- **H** (2): Highlands Park · Highlands Park FC
- **K** (2): Kaizer Chiefs · Kaizer Chiefs FC
- **L** (2): Lamontville FC · Lamontville Golden Arrows FC
- **M** (5): Mamelodi FC · Mamelodi Sundowns · Maritzburg United · Mamelodi Sundowns FC · Maritzburg United FC
- **O** (2): Orlando Pirates · Orlando Pirates FC
- **P** (2): Polokwane City · Polokwane City FC
- **S** (4): Stellenbosch FC · SuperSport United · Stellenbosch United · SuperSport United FC
- **W** (1): Wits




