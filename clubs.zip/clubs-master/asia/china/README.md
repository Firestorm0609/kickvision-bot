25 clubs

- [**Beijing Sinobo Guoan**](https://en.wikipedia.org/wiki/Beijing_Sinobo_Guoan) : (2) Beijing Guoan · Beijing Guoan FC
- [**Beijing Renhe**](https://en.wikipedia.org/wiki/Beijing_Renhe_F.C.) : (1) Beijing Renhe FC
- [**Shanghai SIPG**](https://en.wikipedia.org/wiki/Shanghai_SIPG_F.C.) : (2) SIPG Shanghai · Shanghai SIPG FC
- [**Shanghai Greenland Shenhua**](https://en.wikipedia.org/wiki/Shanghai_Greenland_Shenhua) : (2) Shanghai Shenhua · Shenhua Shanghai
- **Shanghai Shenxin** : (2) Shanghai Shen · Shanghai Shenxin FC
- [**Guangzhou Evergrande Taobao**](https://en.wikipedia.org/wiki/Guangzhou_Evergrande_Taobao_F.C.) : (4) Guangzhou Ev. · Guangzhou Evg · Guangzhou Evergrande · Guangzhou Evergrande Taobao FC
- [**Guangzhou R&F**](https://en.wikipedia.org/wiki/Guangzhou_R&F) : (1) Guangzhou R&F FC
- [**Chongqing Dangdai Lifan**](https://en.wikipedia.org/wiki/Chongqing_Dangdai_Lifan_F.C.) : (3) Chongqing SWM · Chongqing Lifan · Chongqing Dangdai Lifan FC
- [**Changchun Yatai**](https://en.wikipedia.org/wiki/Changchun_Yatai)
- [**Dalian Yifang**](https://en.wikipedia.org/wiki/Dalian_Yifang_F.C.) : (2) Dalian Yifang FC · Dalian Aerbin FC
- [**Guizhou Hengfeng**](https://en.wikipedia.org/wiki/Guizhou_Hengfeng_Zhicheng_F.C.) : (2) Guizhou Zhicheng · Guizhou Hengfeng Zhicheng FC
- **Hangzhou Greentown**
- [**Shandong Luneng Taishan**](https://en.wikipedia.org/wiki/Shandong_Luneng_Taishan) : (3) Shandong L. · Shandong Lunen · Shandong Luneng
- [**Hebei China Fortune**](https://en.wikipedia.org/wiki/Hebei_China_Fortune_F.C.) : (4) Hebei · Hebei Fortune · Hebei China Fortun · Hebei China Fortune FC
- [**Jiangsu Suning**](https://en.wikipedia.org/wiki/Jiangsu_Suning_F.C.) : (1) Jiangsu Suning FC
- **Shenzhen FC** : (1) Shenzhen
- **Shijiazhuang Ever Bright** : (1) Shijiazhuang
- **Tianjin Tianhai** : (1) Tianjin Songjiang
- [**Tianjin TEDA**](https://en.wikipedia.org/wiki/Tianjin_Teda_F.C.) : (2) Tianjin Teda FC · FC Tianjin Taida
- [**Tianjin Quanjian**](https://en.wikipedia.org/wiki/Tianjin_Quanjian)
- **Wuhan Zall**
- [**Henan Jianye**](https://en.wikipedia.org/wiki/Henan_Jianye) : (1) FC Henan Jianye
- **Liaoning FC** : (1) Liaoning
- **Yanbian Funde** : (1) Yanbian
- **Zhejiang Yiteng FC** : (2) Harbin Yiteng · Zhejiang Yiteng




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Shanghai** (3): 
  - Shanghai SIPG  (2) Shanghai SIPG FC · SIPG Shanghai
  - Shanghai Greenland Shenhua  (2) Shanghai Shenhua · Shenhua Shanghai
  - Shanghai Shenxin  (2) Shanghai Shen · Shanghai Shenxin FC
- **Tianjin** (3): 
  - Tianjin Tianhai  (1) Tianjin Songjiang
  - Tianjin TEDA  (2) Tianjin Teda FC · FC Tianjin Taida
  - Tianjin Quanjian 
- **Beijing** (2): 
  - Beijing Sinobo Guoan  (2) Beijing Guoan · Beijing Guoan FC
  - Beijing Renhe  (1) Beijing Renhe FC
- **Guangzhou** (2): 
  - Guangzhou Evergrande Taobao  (4) Guangzhou Ev. · Guangzhou Evg · Guangzhou Evergrande · Guangzhou Evergrande Taobao FC
  - Guangzhou R&F  (1) Guangzhou R&F FC
- **Changchun** (1): Changchun Yatai 
- **Chongqing** (1): Chongqing Dangdai Lifan  (3) Chongqing Lifan · Chongqing Dangdai Lifan FC · Chongqing SWM
- **Dalian** (1): Dalian Yifang  (2) Dalian Yifang FC · Dalian Aerbin FC
- **Guiyang** (1): Guizhou Hengfeng  (2) Guizhou Zhicheng · Guizhou Hengfeng Zhicheng FC
- **Hangzhou** (1): Hangzhou Greentown 
- **Harbin** (1): Zhejiang Yiteng FC  (2) Zhejiang Yiteng · Harbin Yiteng
- **Jinan** (1): Shandong Luneng Taishan  (3) Shandong L. · Shandong Lunen · Shandong Luneng
- **Langfang** (1): Hebei China Fortune  (4) Hebei · Hebei Fortune · Hebei China Fortun · Hebei China Fortune FC
- **Nanjing** (1): Jiangsu Suning  (1) Jiangsu Suning FC
- **Shenyang** (1): Liaoning FC  (1) Liaoning
- **Shenzhen** (1): Shenzhen FC  (1) Shenzhen
- **Shijiazhuang** (1): Shijiazhuang Ever Bright  (1) Shijiazhuang
- **Wuhan** (1): Wuhan Zall 
- **Yanji** (1): Yanbian Funde  (1) Yanbian
- **Zhengzhou** (1): Henan Jianye  (1) FC Henan Jianye




By Region

- **Beijing†** (2):   Beijing Sinobo Guoan · Beijing Renhe
- **Shanghai†** (3):   Shanghai SIPG · Shanghai Greenland Shenhua · Shanghai Shenxin
- **Guangzhou†** (2):   Guangzhou Evergrande Taobao · Guangzhou R&F
- **Chongqing†** (1):   Chongqing Dangdai Lifan
- **Changchun†** (1):   Changchun Yatai
- **Dalian†** (1):   Dalian Yifang
- **Guiyang†** (1):   Guizhou Hengfeng
- **Hangzhou†** (1):   Hangzhou Greentown
- **Jinan†** (1):   Shandong Luneng Taishan
- **Langfang†** (1):   Hebei China Fortune
- **Nanjing†** (1):   Jiangsu Suning
- **Shenzhen†** (1):   Shenzhen FC
- **Shijiazhuang†** (1):   Shijiazhuang Ever Bright
- **Tianjin†** (3):   Tianjin Tianhai · Tianjin TEDA · Tianjin Quanjian
- **Wuhan†** (1):   Wuhan Zall
- **Zhengzhou†** (1):   Henan Jianye
- **Shenyang†** (1):   Liaoning FC
- **Yanji†** (1):   Yanbian Funde
- **Harbin†** (1):   Zhejiang Yiteng FC




By Year

- ? (25):   Beijing Sinobo Guoan · Beijing Renhe · Shanghai SIPG · Shanghai Greenland Shenhua · Shanghai Shenxin · Guangzhou Evergrande Taobao · Guangzhou R&F · Chongqing Dangdai Lifan · Changchun Yatai · Dalian Yifang · Guizhou Hengfeng · Hangzhou Greentown · Shandong Luneng Taishan · Hebei China Fortune · Jiangsu Suning · Shenzhen FC · Shijiazhuang Ever Bright · Tianjin Tianhai · Tianjin TEDA · Tianjin Quanjian · Wuhan Zall · Henan Jianye · Liaoning FC · Yanbian Funde · Zhejiang Yiteng FC






By A to Z

- **B** (5): Beijing Guoan · Beijing Renhe · Beijing Guoan FC · Beijing Renhe FC · Beijing Sinobo Guoan
- **C** (5): Chongqing SWM · Changchun Yatai · Chongqing Lifan · Chongqing Dangdai Lifan · Chongqing Dangdai Lifan FC
- **D** (3): Dalian Yifang · Dalian Aerbin FC · Dalian Yifang FC
- **F** (2): FC Henan Jianye · FC Tianjin Taida
- **G** (10): Guangzhou Ev. · Guangzhou Evg · Guangzhou R&F · Guangzhou R&F FC · Guizhou Hengfeng · Guizhou Zhicheng · Guangzhou Evergrande · Guangzhou Evergrande Taobao · Guizhou Hengfeng Zhicheng FC · Guangzhou Evergrande Taobao FC
- **H** (8): Hebei · Henan Jianye · Harbin Yiteng · Hebei Fortune · Hangzhou Greentown · Hebei China Fortun · Hebei China Fortune · Hebei China Fortune FC
- **J** (2): Jiangsu Suning · Jiangsu Suning FC
- **L** (2): Liaoning · Liaoning FC
- **S** (17): Shenzhen · Shandong L. · Shenzhen FC · Shijiazhuang · SIPG Shanghai · Shanghai SIPG · Shanghai Shen · Shandong Lunen · Shandong Luneng · Shanghai SIPG FC · Shanghai Shenhua · Shanghai Shenxin · Shenhua Shanghai · Shanghai Shenxin FC · Shandong Luneng Taishan · Shijiazhuang Ever Bright · Shanghai Greenland Shenhua
- **T** (5): Tianjin TEDA · Tianjin Teda FC · Tianjin Tianhai · Tianjin Quanjian · Tianjin Songjiang
- **W** (1): Wuhan Zall
- **Y** (2): Yanbian · Yanbian Funde
- **Z** (2): Zhejiang Yiteng · Zhejiang Yiteng FC




