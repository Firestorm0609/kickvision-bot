28 clubs

- [**FC Tokyo**](https://en.wikipedia.org/wiki/FC_Tokyo) : (1) Tokyo
- **Tokyo Verdy** : (1) Verdy
- **Albirex Niigata**
- **Omiya Ardija**
- [**Cerezo Osaka**](https://en.wikipedia.org/wiki/Cerezo_Osaka) : (1) C-Osaka
- [**Gamba Osaka**](https://en.wikipedia.org/wiki/Gamba_Osaka) : (1) G-Osaka
- [**Yokohama F. Marinos**](https://en.wikipedia.org/wiki/Yokohama_F._Marinos) : (3) Marinos · Yokohama · Yokohama M.
- [**Kawasaki Frontale**](https://en.wikipedia.org/wiki/Kawasaki_Frontale) : (1) Kawa Frontale
- [**Nagoya Grampus**](https://en.wikipedia.org/wiki/Nagoya_Grampus) : (2) Nagoya · Grampus
- [**Júbilo Iwata**](https://en.wikipedia.org/wiki/Júbilo_Iwata) : (1) Iwata ⇒ (1) ≈Jubilo Iwata≈
- [**Shimizu S-Pulse**](https://en.wikipedia.org/wiki/Shimizu_S-Pulse) : (2) Shimizu · S-Pulse
- **Honda FC**
- [**Urawa Red Diamonds**](https://en.wikipedia.org/wiki/Urawa_Red_Diamonds) : (3) Urawa · Urawa RD · Urawa Reds
- **Kashiwa Reysol** : (1) Kashiwa
- [**Sagan Tosu**](https://en.wikipedia.org/wiki/Sagan_Tosu)
- [**Sanfrecce Hiroshima**](https://en.wikipedia.org/wiki/Sanfrecce_Hiroshima) : (4) Hiroshima · Sanfrecce · S. Hiroshima · Sanfr. Hiroshima
- [**Vegalta Sendai**](https://en.wikipedia.org/wiki/Vegalta_Sendai)
- [**Hokkaido Consadole Sapporo**](https://en.wikipedia.org/wiki/Consadole_Sapporo) : (4) Sapporo · Consa Sapporo · Consadole Sapporo · Hokkaido Consadole
- **Avispa Fukuoka**
- [**Matsumoto Yamaga**](https://en.wikipedia.org/wiki/Matsumoto_Yamaga) : (2) Yamaga · Matsumoto Yamaga FC
- [**Vissel Kobe**](https://en.wikipedia.org/wiki/Vissel_Kobe) : (1) Kobe
- **V-Varen Nagasaki**
- [**Kashima Antlers**](https://en.wikipedia.org/wiki/Kashima_Antlers) : (2) Kashima · Kashima A.
- [**Oita Trinita**](https://en.wikipedia.org/wiki/Oita_Trinita) : (1) Oita
- [**Shonan Bellmare**](https://en.wikipedia.org/wiki/Shonan_Bellmare) : (1) Shonan
- **Ventforet Kofu** : (1) Kofu
- **Montedio Yamagata**
- **Tokushima Vortis** : (1) Tokushima




Alphabet

- **Alphabet Specials** (1):  **ú** 
  - **ú**×1 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Tokyo** (2): 
  - FC Tokyo  (1) Tokyo
  - Tokyo Verdy  (1) Verdy
- **Hakata, Fukuoka** (1): Avispa Fukuoka 
- **Hamamatsu, Shizuoka** (1): Honda FC 
- **Hiroshima, Hiroshima** (1): Sanfrecce Hiroshima  (4) Hiroshima · Sanfrecce · S. Hiroshima · Sanfr. Hiroshima
- **Iwata, Shizuoka** (1): Júbilo Iwata  (1) Iwata
- **Kashiwa, Chiba** (1): Kashiwa Reysol  (1) Kashiwa
- **Kawasaki, Kanagawa** (1): Kawasaki Frontale  (1) Kawa Frontale
- **Matsumoto, Nagano** (1): Matsumoto Yamaga  (2) Yamaga · Matsumoto Yamaga FC
- **Miyagi** (1): Vegalta Sendai 
- **Nagoya, Aichi** (1): Nagoya Grampus  (2) Nagoya · Grampus
- **Niigata & Seiro, Niigata** (1): Albirex Niigata 
- **Omiya, Saitama** (1): Omiya Ardija 
- **Osaka, Osaka** (1): Cerezo Osaka  (1) C-Osaka
- **Sapporo, Hokkaido** (1): Hokkaido Consadole Sapporo  (4) Sapporo · Consa Sapporo · Consadole Sapporo · Hokkaido Consadole
- **Shizuoka, Shizuoka** (1): Shimizu S-Pulse  (2) Shimizu · S-Pulse
- **Suita, Osaka** (1): Gamba Osaka  (1) G-Osaka
- **Tosu, Saga** (1): Sagan Tosu 
- **Urawa, Saitama** (1): Urawa Red Diamonds  (3) Urawa · Urawa RD · Urawa Reds
- **Yokohama & Yokosuka, Kanagawa** (1): Yokohama F. Marinos  (3) Yokohama · Yokohama M. · Marinos
- ? (8): 
  - Vissel Kobe  (1) Kobe
  - V-Varen Nagasaki 
  - Kashima Antlers  (2) Kashima · Kashima A.
  - Oita Trinita  (1) Oita
  - Shonan Bellmare  (1) Shonan
  - Ventforet Kofu  (1) Kofu
  - Montedio Yamagata 
  - Tokushima Vortis  (1) Tokushima




By Region

- **Tokyo†** (2):   FC Tokyo · Tokyo Verdy
- **Niigata** (1):   Albirex Niigata
- **Saitama** (2):   Omiya Ardija · Urawa Red Diamonds
- **Osaka** (2):   Cerezo Osaka · Gamba Osaka
- **Kanagawa** (2):   Yokohama F. Marinos · Kawasaki Frontale
- **Aichi** (1):   Nagoya Grampus
- **Shizuoka** (3):   Júbilo Iwata · Shimizu S-Pulse · Honda FC
- **Chiba** (1):   Kashiwa Reysol
- **Saga** (1):   Sagan Tosu
- **Hiroshima** (1):   Sanfrecce Hiroshima
- **Miyagi†** (1):   Vegalta Sendai
- **Hokkaido** (1):   Hokkaido Consadole Sapporo
- **Fukuoka** (1):   Avispa Fukuoka
- **Nagano** (1):   Matsumoto Yamaga




By Year

- ? (28):   FC Tokyo · Tokyo Verdy · Albirex Niigata · Omiya Ardija · Cerezo Osaka · Gamba Osaka · Yokohama F. Marinos · Kawasaki Frontale · Nagoya Grampus · Júbilo Iwata · Shimizu S-Pulse · Honda FC · Urawa Red Diamonds · Kashiwa Reysol · Sagan Tosu · Sanfrecce Hiroshima · Vegalta Sendai · Hokkaido Consadole Sapporo · Avispa Fukuoka · Matsumoto Yamaga · Vissel Kobe · V-Varen Nagasaki · Kashima Antlers · Oita Trinita · Shonan Bellmare · Ventforet Kofu · Montedio Yamagata · Tokushima Vortis






By A to Z

- **A** (2): Avispa Fukuoka · Albirex Niigata
- **C** (4): C-Osaka · Cerezo Osaka · Consa Sapporo · Consadole Sapporo
- **F** (1): FC Tokyo
- **G** (3): G-Osaka · Grampus · Gamba Osaka
- **H** (4): Honda FC · Hiroshima · Hokkaido Consadole · Hokkaido Consadole Sapporo
- **I** (1): Iwata
- **J** (1): Júbilo Iwata
- **K** (9): Kobe · Kofu · Kashima · Kashiwa · Kashima A. · Kawa Frontale · Kashiwa Reysol · Kashima Antlers · Kawasaki Frontale
- **M** (4): Marinos · Matsumoto Yamaga · Montedio Yamagata · Matsumoto Yamaga FC
- **N** (2): Nagoya · Nagoya Grampus
- **O** (3): Oita · Oita Trinita · Omiya Ardija
- **S** (11): Shonan · S-Pulse · Sapporo · Shimizu · Sanfrecce · Sagan Tosu · S. Hiroshima · Shimizu S-Pulse · Shonan Bellmare · Sanfr. Hiroshima · Sanfrecce Hiroshima
- **T** (4): Tokyo · Tokushima · Tokyo Verdy · Tokushima Vortis
- **U** (4): Urawa · Urawa RD · Urawa Reds · Urawa Red Diamonds
- **V** (5): Verdy · Vissel Kobe · Vegalta Sendai · Ventforet Kofu · V-Varen Nagasaki
- **Y** (4): Yamaga · Yokohama · Yokohama M. · Yokohama F. Marinos




