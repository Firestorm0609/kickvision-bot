# Japan (jp)


### J. League Division 1

- 18 teams

#### Wikipedia

- [2013_J._League_Division_1](http://en.wikipedia.org/wiki/2013_J._League_Division_1)
