14 clubs

- [**FC Astana**](https://en.wikipedia.org/wiki/FC_Astana) : (4) Astana · Astana FK · FK Astana · Football Club Astana
- **FC Astana-1964** : (4) Astana-64 · Astana-1964 · FC Astana 64 · FK Astana-64
- **FC Aktobe** : (2) Aktobe · FK Aktobe
- **FC Shakhter Karagandy** : (4) Shakhter · Shakter Karaganda · Shakhter Karagandy · Shakhtyor Karaganda
- **FC Tobol Kostanay** : (3) Tobol · Tobol Kustanai · Tobyl Kostanay
- **FC Irtysh Pavlodar** : (2) Irtysh · Irtysh Pavlodar
- **FC Ordabasy Shymkent** : (2) Ordabasy · Ordabasy Shymkent
- **FC Atyrau** : (1) Atyrau
- **FC Zhetysu Taldykorgan** : (1) Zhetysu
- **FC Okzhetpes Kokshetau** : (1) Okzhetpes
- **FC Kairat Almaty** : (3) Kairat · FK Kairat · Kairat Almaty
- **FC Alma-Ata (2000-2008)**
- **FC Kaysar Kyzylorda** : (1) Kaysar
- **FC Taraz**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Almaty** (2): 
  - FC Kairat Almaty  (3) Kairat · Kairat Almaty · FK Kairat
  - FC Alma-Ata (2000-2008) 
- ? (12): 
  - FC Astana  (4) Astana · Football Club Astana · Astana FK · FK Astana
  - FC Astana-1964  (4) Astana-64 · Astana-1964 · FC Astana 64 · FK Astana-64
  - FC Aktobe  (2) Aktobe · FK Aktobe
  - FC Shakhter Karagandy  (4) Shakhter · Shakhter Karagandy · Shakter Karaganda · Shakhtyor Karaganda
  - FC Tobol Kostanay  (3) Tobol · Tobol Kustanai · Tobyl Kostanay
  - FC Irtysh Pavlodar  (2) Irtysh · Irtysh Pavlodar
  - FC Ordabasy Shymkent  (2) Ordabasy · Ordabasy Shymkent
  - FC Atyrau  (1) Atyrau
  - FC Zhetysu Taldykorgan  (1) Zhetysu
  - FC Okzhetpes Kokshetau  (1) Okzhetpes
  - FC Kaysar Kyzylorda  (1) Kaysar
  - FC Taraz 




By Region

- **Almaty†** (2):   FC Kairat Almaty · FC Alma-Ata (2000-2008)




By Year

- **1954** (1):   FC Kairat Almaty
- **2000** (1):   FC Alma-Ata (2000-2008)
- **2009** (1):   FC Astana
- ? (11):   FC Astana-1964 · FC Aktobe · FC Shakhter Karagandy · FC Tobol Kostanay · FC Irtysh Pavlodar · FC Ordabasy Shymkent · FC Atyrau · FC Zhetysu Taldykorgan · FC Okzhetpes Kokshetau · FC Kaysar Kyzylorda · FC Taraz




Historic

- **2008** (1):   FC Alma-Ata (2000-2008)






By A to Z

- **A** (6): Aktobe · Astana · Atyrau · Astana FK · Astana-64 · Astana-1964
- **F** (20): FC Taraz · FC Aktobe · FC Astana · FC Atyrau · FK Aktobe · FK Astana · FK Kairat · FC Astana 64 · FK Astana-64 · FC Astana-1964 · FC Kairat Almaty · FC Tobol Kostanay · FC Irtysh Pavlodar · FC Kaysar Kyzylorda · FC Ordabasy Shymkent · Football Club Astana · FC Shakhter Karagandy · FC Okzhetpes Kokshetau · FC Zhetysu Taldykorgan · FC Alma-Ata (2000-2008)
- **I** (2): Irtysh · Irtysh Pavlodar
- **K** (3): Kairat · Kaysar · Kairat Almaty
- **O** (3): Ordabasy · Okzhetpes · Ordabasy Shymkent
- **S** (4): Shakhter · Shakter Karaganda · Shakhter Karagandy · Shakhtyor Karaganda
- **T** (3): Tobol · Tobol Kustanai · Tobyl Kostanay
- **Z** (1): Zhetysu




