Duplicates

- **2** matching clubs for **`alittihad`**:
  - Al Ittihad Al Sakandary, Alexandria, Egypt (eg)
  - Al-Ittihad, , Saudi Arabia (sa)
- **2** matching clubs for **`valencia`**:
  - Valencia FC, Léogâne, Haiti (ht)
  - Valencia CF, Valencia, Spain (es)
- **3** matching clubs for **`santos`**:
  - Santos de Guápiles, Guápiles, Costa Rica (cr)
  - Santos Laguna, Torreón, Mexico (mx)
  - Santos SP, Santos, Brazil (br)
- **2** matching clubs for **`olimpia`**:
  - CD Olimpia, city:tegucigalpa, Honduras (hn)
  - Club Olimpia, Asunción, Paraguay (py)
- **2** matching clubs for **`rangers`**:
  - FC Rànger's, Andorra la Vella, Andorra (ad)
  - Rangers FC, Glasgow, Scotland (sco)
- **2** matching clubs for **`velez`**:
  - FK Velež, , Bosnia and Herzegovina (ba)
  - Vélez Sarsfield, Buenos Aires, Argentina (ar)
- **2** matching clubs for **`olympiakos`**:
  - Olympiakos Nicosia FC, Nicosia, Cyprus (cy)
  - Olympiacos Piraeus FC, Piraeus, Greece (gr)
- **2** matching clubs for **`ael`**:
  - AEL Limassol, Limassol, Cyprus (cy)
  - AE Larissa FC, Larissa, Greece (gr)
- **2** matching clubs for **`apollon`**:
  - Apollon Limassol FC, Limassol, Cyprus (cy)
  - Apollon Smyrnis FC, Athens, Greece (gr)
- **2** matching clubs for **`doxa`**:
  - Doxa Katokopia FC, Katokopia, Cyprus (cy)
  - Doxa Dramas FC, Drama, Greece (gr)
- **2** matching clubs for **`arsenalfc`**:
  - Arsenal FC, London, England (eng)
  - Arsenal de Sarandí, Sarandí, Argentina (ar)
- **3** matching clubs for **`arsenal`**:
  - Arsenal FC, London, England (eng)
  - Arsenal Tula, Tula, Russia (ru)
  - Arsenal de Sarandí, Sarandí, Argentina (ar)
- **2** matching clubs for **`everton`**:
  - Everton FC, Liverpool, England (eng)
  - Everton de Viña del Mar, Viña del Mar, Chile (cl)
- **2** matching clubs for **`liverpoolfc`**:
  - Liverpool FC, Liverpool, England (eng)
  - Liverpool Montevideo, Montevideo, Uruguay (uy)
- **2** matching clubs for **`liverpool`**:
  - Liverpool FC, Liverpool, England (eng)
  - Liverpool Montevideo, Montevideo, Uruguay (uy)
- **2** matching clubs for **`newcastle`**:
  - Newcastle United FC, Newcastle upon Tyne, England (eng)
  - Newcastle United Jets, Newcastle, Australia (au)
- **2** matching clubs for **`lincoln`**:
  - Lincoln City FC, Lincoln, England (eng)
  - Lincoln FC, , Gibraltar (gi)
- **2** matching clubs for **`redstar`**:
  - Red Star FC, Saint-Ouen, France (fr)
  - Red Star Belgrade, Belgrade, Serbia (rs)
- **2** matching clubs for **`bocajuniors`**:
  - Boca Juniors Gibraltar FC, , Gibraltar (gi)
  - Boca Juniors, Buenos Aires, Argentina (ar)
- **2** matching clubs for **`heracles`**:
  - Iraklis 1908 Thessaloniki FC, Thessaloniki, Greece (gr)
  - Heracles Almelo, Almelo, Netherlands (nl)
- **2** matching clubs for **`hibernians`**:
  - Hibernians FC, , Malta (mt)
  - Hibernian FC, Edinburgh, Scotland (sco)
- **2** matching clubs for **`sporting`**:
  - Sporting CP, Lisboa, Portugal (pt)
  - Sporting Gijón, Gijón, Spain (es)
- **2** matching clubs for **`vitória`**:
  - Vitória de Guimarães, Guimarães, Portugal (pt)
  - EC Vitória, Salvador, Brazil (br)
- **2** matching clubs for **`vitoria`**:
  - Vitória de Guimarães, Guimarães, Portugal (pt)
  - EC Vitória, Salvador, Brazil (br)
- **3** matching clubs for **`nacional`**:
  - CD Nacional Madeira, Funchal, Portugal (pt)
  - Club Nacional, Asunción, Paraguay (py)
  - Nacional de Montevideo, Montevideo, Uruguay (uy)
- **2** matching clubs for **`tekstilshchik`**:
  - FC Tekstilshchik Ivanovo, Ivanovo, Russia (ru)
  - FC Tekstilshchik Kamyshin, Kamyshin, Russia (ru)
- **2** matching clubs for **`atlético`**:
  - Atlético Madrid, Madrid, Spain (es)
  - Atlético San Luis, San Luis Potosí, Mexico (mx)
- **2** matching clubs for **`atletico`**:
  - Atlético Madrid, Madrid, Spain (es)
  - Atlético San Luis, San Luis Potosí, Mexico (mx)
- **2** matching clubs for **`barcelona`**:
  - FC Barcelona, Barcelona, Spain (es)
  - Barcelona Guayaquil, Guayaquil, Ecuador (ec)
- **2** matching clubs for **`cdguadalajara`**:
  - CD Guadalajara, Guadalajara, Spain (es)
  - CD Guadalajara Chivas, Guadalajara, Mexico (mx)
- **2** matching clubs for **`guadalajara`**:
  - CD Guadalajara, Guadalajara, Spain (es)
  - CD Guadalajara Chivas, Guadalajara, Mexico (mx)
- **2** matching clubs for **`mérida`**:
  - CP Mérida, Mérida, Spain (es)
  - Mérida, Mérida, Mexico (mx)
- **2** matching clubs for **`merida`**:
  - CP Mérida, Mérida, Spain (es)
  - Mérida, Mérida, Mexico (mx)
- **3** matching clubs for **`estudiantes`**:
  - Estudiantes UAG, , Mexico (mx)
  - Estudiantes LP, La Plata, Argentina (ar)
  - Estudiantes de Mérida, Mérida, Venezuela (ve)
- **2** matching clubs for **`jaguares`**:
  - Jaguares Chiapas, Tuxtla Gutiérrez, Mexico (mx)
  - Jaguares de Córdoba, Montería, Colombia (co)
- **2** matching clubs for **`atlanta`**:
  - Atlanta United FC, Atlanta, United States (us)
  - Atlanta, Buenos Aires, Argentina (ar)
- **2** matching clubs for **`sanjose`**:
  - San Jose Earthquakes, San Jose, United States (us)
  - Club Deportivo San José, Oruro, Bolivia (bo)
- **3** matching clubs for **`riverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - Club River Plate, Asunción, Paraguay (py)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`cariverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`clubatléticoriverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`clubatleticoriverplate`**:
  - River Plate, Buenos Aires, Argentina (ar)
  - CA River Plate, Montevideo, Uruguay (uy)
- **2** matching clubs for **`sanlorenzo`**:
  - San Lorenzo, Buenos Aires, Argentina (ar)
  - Club Sportivo San Lorenzo, San Lorenzo, Paraguay (py)
- **2** matching clubs for **`racing`**:
  - Racing Club, Avellaneda, Argentina (ar)
  - Racing CM, Montevideo, Uruguay (uy)
- **2** matching clubs for **`gimnasiayesgrima`**:
  - Gimnasia y Esgrima LP, La Plata, Argentina (ar)
  - Gimnasia y Esgrima de Mendoza, Mendoza, Argentina (ar)
- **2** matching clubs for **`sanmartín`**:
  - San Martín San Juan, San Juan, Argentina (ar)
  - San Martín de Tucumán, San Miguel de Tucumán, Argentina (ar)
- **2** matching clubs for **`clubatléticosanmartín`**:
  - San Martín San Juan, San Juan, Argentina (ar)
  - San Martín de Tucumán, San Miguel de Tucumán, Argentina (ar)
- **2** matching clubs for **`sanmartin`**:
  - San Martín San Juan, San Juan, Argentina (ar)
  - San Martín de Tucumán, San Miguel de Tucumán, Argentina (ar)
- **2** matching clubs for **`clubatleticosanmartin`**:
  - San Martín San Juan, San Juan, Argentina (ar)
  - San Martín de Tucumán, San Miguel de Tucumán, Argentina (ar)
- **2** matching clubs for **`sportboys`**:
  - Sport Boys Warnes, Warnes, Bolivia (bo)
  - Sport Boys, Callao, Peru (pe)
- **2** matching clubs for **`bragantino`**:
  - CA Bragantino, Bragança Paulista, Brazil (br)
  - RB Bragantino, Bragança Paulista, Brazil (br)
- **2** matching clubs for **`portuguesa`**:
  - Portuguesa, São Paulo, Brazil (br)
  - Portuguesa FC, Acarigua, Venezuela (ve)
- **2** matching clubs for **`guarani`**:
  - Guarani FC, Campinas, Brazil (br)
  - Club Guaraní, Asunción, Paraguay (py)
- **2** matching clubs for **`universidadcatólica`**:
  - Universidad Católica, Santiago, Chile (cl)
  - CD Universidad Católica del Ecuador, Quito, Ecuador (ec)
- **2** matching clubs for **`universidadcatolica`**:
  - Universidad Católica, Santiago, Chile (cl)
  - CD Universidad Católica del Ecuador, Quito, Ecuador (ec)
- **2** matching clubs for **`clubnacional`**:
  - Club Nacional, Asunción, Paraguay (py)
  - Nacional de Montevideo, Montevideo, Uruguay (uy)




Club Name Duplicates

**Congo DR (cd)**





**Egypt (eg)**

- **Al Ahly**, Cairo (1):
  - `alahly` (2): Al Ahly · Al-Ahly




**Morocco (ma)**





**South Africa (za)**





**Tunisia (tn)**





**China (cn)**





**Japan (jp)**





**Kazakhstan (kz)**





**Saudi Arabia (sa)**





**Singapore (sg)**





**South Korea (kr)**

- **Busan I'Park**, Busan (1):
  - `busanipark` (2): Busan I'Park · Busan IPark




**Thailand (th)**





**Anguilla (ai)**





**Haiti (ht)**





**Puerto Rico (pr)**





**Trinidad and Tobago (tt)**





**Costa Rica (cr)**





**El Salvador (sv)**





**Guatemala (gt)**





**Honduras (hn)**





**Nicaragua (ni)**





**Panama (pa)**





**Albania (al)**





**Andorra (ad)**





**Armenia (am)**

- **FC Gandzasar Kapan**, Kapan (1):
  - `fcgandzasarkapan` (2): FC Gandzasar Kapan · FC Gandzasar-Kapan




**Austria (at)**

- **SC-ESV Parndorf**, Parndorf (2):
  - `scesvparndorf` (2): SC-ESV Parndorf · SC/ESV Parndorf
  - `scesvparndorf1919` (2): SC-ESV Parndorf 1919 · SC/ESV Parndorf 1919




**Azerbaijan (az)**

- **Zirä FK**, Baku (1):
  - `zirafk` (2): **Zira FK** · **Zira FK**
- **PFK Turan Tovuz**, Tovuz (4):
  - `turantik` (2): Turan-T İK · Turan-T IK
  - `turantovuzik` (2): Turan-Tovuz İK · Turan-Tovuz IK
  - `turanik` (2): Turan İK · Turan IK
  - `turanidmanklubu` (2): Turan İdman Klubu · Turan Idman Klubu




**Belarus (by)**





**Belgium (be)**

- **Club Brugge**, Brugge (1):
  - `clubbrugge` (2): **Club Brugge** · **Club Brugge**
- **Cercle Brugge**, Brugge (1):
  - `cerclebruggeksv` (2): **Cercle Brugge KSV** · **Cercle Brugge KSV**




**Bosnia and Herzegovina (ba)**





**Bulgaria (bg)**

- **PFC CSKA Sofia**, Sofia (2):
  - `pfccskasofia` (2): PFC CSKA Sofia · PFC CSKA-Sofia
  - `cskasofia` (2): CSKA Sofia · CSKA-Sofia




**Croatia (hr)**





**Cyprus (cy)**





**Czech Republic (cz)**





**Denmark (dk)**

- **KB København (1876-1992)**, København (1):
  - `kjobenhavnsboldklub` (2): **Kjobenhavns Boldklub** · **Kjobenhavns Boldklub**
- **Brønshøj BK**, København (1):
  - `bronshojbk` (2): **Bronshoj BK** · **Bronshoj BK**
- **Vanløse IF**, København (1):
  - `vanloseif` (2): **Vanlose IF** · **Vanlose IF**
- **HB Køge**, Køge (1):
  - `hbkoge` (2): **HB Koge** · **HB Koge**
- **Nykøbing FC**, Nykøbing Falster (1):
  - `nykobingfc` (2): **Nykobing FC** · **Nykobing FC**
- **Hillerød Fodbold**, Hillerød (1):
  - `hillerodfodbold` (2): **Hillerod Fodbold** · **Hillerod Fodbold**
- **B 1901 Nykøbing (1901-1994)**, Nykøbing Falster (1):
  - `b1901nykobing` (2): B 1901 Nykobing · B1901 Nykobing




**England (eng)**

- **Manchester City FC**, Manchester (1):
  - `mancity` (2): Man City · Man. City
- **AFC Bournemouth**, Bournemouth (1):
  - `afcbournemouth` (2): AFC Bournemouth · A.F.C. Bournemouth
- **Accrington FC (1878-1896)**, Accrington (1):
  - `accringtonfc` (2): Accrington FC (1878-1896) · Accrington F.C.




**Estonia (ee)**





**Faroe Islands (fo)**

- **Víkingur**,  (1):
  - `vikingur` (2): **Vikingur** · **Vikingur**
- **FC Suðuroy**, Vágur (1):
  - `fcsuduroy` (2): **FC Suduroy** · **FC Suduroy**




**Finland (fi)**

- **Myllykosken Pallo -47**, Myllykoski (2):
  - `myllykoskenpallo47` (3): Myllykosken Pallo -47 · Myllykosken Pallo-47 · Myllykosken Pallo −47
  - `mypa` (2): MYPA · MyPa
- **JJK Jyväskylä**, Jyväskylä (1):
  - `jjkjyvaskyla` (2): **JJK Jyvaskyla** · **JJK Jyvaskyla**




**France (fr)**

- **Paris Saint-Germain**, Paris (1):
  - `parissaintgermain` (2): Paris Saint-Germain · Paris Saint Germain
- **AS Nancy Lorraine**, Nancy (1):
  - `asnancylorraine` (2): AS Nancy Lorraine · AS Nancy-Lorraine
- **US Quevilly-Rouen Métropole**, Petit-Quevilly (1):
  - `quevillyrouen` (2): Quevilly Rouen · Quevilly-Rouen
- **AC Arles-Avignon**, Avignon (1):
  - `acarlesavignon` (2): AC Arles-Avignon · AC Arles Avignon
- **Évian TG FC**, Thonon-les-Bains (2):
  - `évianthonongaillardfc` (2): Évian Thonon Gaillard FC · Évian Thonon-Gaillard FC
  - `evianthonongaillardfc` (2): Evian Thonon Gaillard FC · Evian Thonon-Gaillard FC




**Georgia (ge)**





**Germany (de)**

- **Rot-Weiß Oberhausen**, Oberhausen (1):
  - `rotweissoberhausen` (2): **Rot-Weiss Oberhausen** · **Rot-Weiss Oberhausen**
- **Blau-Weiß 90 Berlin (-1992)**, Berlin (1):
  - `blauweiss90berlin` (2): **Blau-Weiss 90 Berlin** · **Blau-Weiss 90 Berlin**
- **FC St. Pauli**, Hamburg (1):
  - `stpauli` (2): St Pauli · St. Pauli




**Gibraltar (gi)**





**Greece (gr)**





**Hungary (hu)**

- **Ferencvárosi TC**, Budapest (1):
  - `ferencvaros` (2): **Ferencvaros** · **Ferencvaros**
- **Győri ETO FC**, Győr (3):
  - `gyorieto` (2): **Gyori ETO** · **Gyori ETO**
  - `rabaetogyor` (2): **Raba ETO Gyor** · **Raba ETO Gyor**
  - `etogyor` (2): **ETO Gyor** · **ETO Gyor**
- **Diósgyőri VTK**, Miskolc (2):
  - `diosgyorivtk` (2): **Diosgyori VTK** · **Diosgyori VTK**
  - `diosgyor` (2): **Diosgyor** · **Diosgyor**
- **Békéscsaba 1912 Előre**, Békéscsaba (1):
  - `bekescsabaielore` (2): **Bekescsabai Elore** · **Bekescsabai Elore**




**Iceland (is)**

- **FH Hafnarfjörður**, Hafnarfjörður (1):
  - `fhhafnarfjordur` (2): **FH Hafnarfjordur** · **FH Hafnarfjordur**
- **Breiðablik**, Kópavogur (1):
  - `breidablik` (2): **Breidablik** · **Breidablik**
- **Stjarnan**, Garðabær (1):
  - `stjarnangardab` (2): **Stjarnan Gardab.** · **Stjarnan Gardab.**




**Ireland (ie)**

- **St Patrick's Athletic FC**, Dublin (1):
  - `stpatricks` (2): St Patrick's · St. Patricks




**Italy (it)**





**Kosovo (xk)**





**Latvia (lv)**





**Liechtenstein (li)**





**Lithuania (lt)**





**Luxembourg (lu)**





**North Macedonia (mk)**





**Malta (mt)**





**Moldova (md)**





**Monaco (mc)**





**Montenegro (me)**





**Netherlands (nl)**

- **VVV Venlo**, Venlo (1):
  - `vvvvenlo` (2): VVV Venlo · VVV-Venlo




**Northern Ireland (nir)**





**Norway (no)**

- **Lillestrøm SK**, Lillestrøm (1):
  - `lillestromsk` (2): **Lillestrom SK** · **Lillestrom SK**
- **Mjøndalen IF**, Mjøndalen (1):
  - `mjondalen` (2): **Mjondalen** · **Mjondalen**
- **Bodø/Glimt**, Bodø (1):
  - `bodoglimt` (2): Bodo/Glimt · Bodo Glimt
- **Hamarkameratene**, Hamar (1):
  - `hamkam` (2): HamKam · Ham-Kam
- **Strømmen IF**, Strømmen (1):
  - `strommenif` (2): **Strommen IF** · **Strommen IF**




**Poland (pl)**

- **Raków Częstochowa**, Częstochowa (1):
  - `rakowczestochowa` (2): **Rakow Czestochowa** · **Rakow Czestochowa**




**Portugal (pt)**





**Romania (ro)**

- **Steaua București**, București (2):
  - `steauabucuresti` (2): **Steaua Bucuresti** · **Steaua Bucuresti**
  - `fcsteauabucuresti` (2): **FC Steaua Bucuresti** · **FC Steaua Bucuresti**
- **Dinamo București**, București (2):
  - `dinamobucuresti` (3): **Dinamo Bucuresti** · **Dinamo Bucuresti** · **Dinamo Bucuresti**
  - `fcdinamobucuresti` (2): **FC Dinamo Bucuresti** · **FC Dinamo Bucuresti**
- **Rapid București**, București (2):
  - `fcrapidbucuresti` (2): **FC Rapid Bucuresti** · **FC Rapid Bucuresti**
  - `rapidbucuresti` (2): **Rapid Bucuresti** · **Rapid Bucuresti**
- **Daco-Getica București**, București (1):
  - `dacogeticabucuresti` (2): **Daco-Getica Bucuresti** · **Daco-Getica Bucuresti**
- **U Cluj**, Cluj (1):
  - `ucluj` (2): U Cluj · U. Cluj
- **Ceahlăul Piatra Neamț**, Piatra Neamț (1):
  - `ceahlaulpiatraneamt` (2): **Ceahlaul Piatra Neamt** · **Ceahlaul Piatra Neamt**
- **Gaz Metan Mediaș**, Mediaș (2):
  - `gazmetanmedias` (2): **Gaz Metan Medias** · **Gaz Metan Medias**
  - `csgazmetanmedias` (2): **CS Gaz Metan Medias** · **CS Gaz Metan Medias**
- **Gloria Bistrița**, Bistrița (1):
  - `gloriabistrita` (2): **Gloria Bistrita** · **Gloria Bistrita**
- **FC Petrolul Ploiești**, Ploiești (2):
  - `petrolulploiesti` (2): **Petrolul Ploiesti** · **Petrolul Ploiesti**
  - `fcpetrolulploiesti` (2): **FC Petrolul Ploiesti** · **FC Petrolul Ploiesti**
- **FC Botoșani**, Botoșani (1):
  - `fcbotosani` (2): **FC Botosani** · **FC Botosani**
- **Oțelul Galați**, Galați (1):
  - `otelul` (2): **Otelul** · **Otelul**
- **FC Politehnica Iași**, Iași (3):
  - `poliiasi` (2): **Poli Iasi** · **Poli Iasi**
  - `politehnicaiasi` (2): **Politehnica Iasi** · **Politehnica Iasi**
  - `csmpolitehnicaiasi` (2): **CSM Politehnica Iasi** · **CSM Politehnica Iasi**
- **ASA Târgu Mureș (2008-2018)**, Târgu Mureș (2):
  - `asatargumures` (2): **ASA Targu Mures** · **ASA Targu Mures**
  - `targumures` (2): **Targu Mures** · **Targu Mures**




**Russia (ru)**

- **FC Sibir Novosibirsk**, Novosibirsk (1):
  - `sibir` (2): Sibir · Sibir'
- **PFC Krylya Sovetov Samara**, Samara (1):
  - `kryliasovetov` (2): Krylia Sovetov · Kryl'ia Sovetov
- **FC Kuban**, Krasnodar (1):
  - `kuban` (2): Kuban · Kuban'
- **Tom Tomsk**, Tomsk (1):
  - `tom` (2): Tom · Tom'




**San Marino (sm)**

- **AC Juvenes-Dogana**,  (1):
  - `acjuvenesdogana` (2): AC Juvenes-Dogana · AC Juvenes/Dogana




**Scotland (sco)**

- **Queen's Park**, Glasgow (1):
  - `queenspark` (2): Queen's Park · Queens Park
- **St Johnstone FC**, Perth (1):
  - `stjohnstone` (2): St Johnstone · St. Johnstone




**Serbia (rs)**





**Slovakia (sk)**

- **ŠK Slovan Bratislava**, Bratislava (1):
  - `skslovanbratislava` (2): **SK Slovan Bratislava** · **SK Slovan Bratislava**




**Slovenia (si)**





**Spain (es)**





**Sweden (se)**

- **Djurgårdens IF**, Stockholm (1):
  - `djurgarden` (2): **Djurgarden** · **Djurgarden**
- **IFK Göteborg**, Göteborg (2):
  - `goteborg` (2): **Goteborg** · **Goteborg**
  - `ifkgoteborg` (2): **IFK Goteborg** · **IFK Goteborg**
- **BK Häcken**, Göteborg (1):
  - `hacken` (2): **Hacken** · **Hacken**
- **Malmö FF**, Malmö (1):
  - `malmoff` (2): **Malmo FF** · **Malmo FF**
- **Örebro SK**, Örebro (1):
  - `orebro` (2): **Orebro** · **Orebro**
- **IFK Norrköping**, Norrköping (1):
  - `norrkoping` (2): **Norrkoping** · **Norrkoping**




**Switzerland (ch)**





**Turkey (tr)**

- **Galatasaray İstanbul AŞ**, İstanbul (2):
  - `galatasaristanbul` (2): Galatasar. İstanbul · Galatasar. Istanbul
  - `galatasarayistanbul` (2): Galatasaray İstanbul · Galatasaray Istanbul
- **İstanbulspor**, İstanbul (2):
  - `istanbulspor` (2): İstanbulspor · Istanbulspor
  - `istanbulsporas` (2): İstanbulspor AS · Istanbulspor AS
- **Altay SK**, İzmir (1):
  - `altayizmir` (2): Altay İzmir · Altay Izmir
- **Mersin İdmanyurdu**, Mersin (1):
  - `mersinidmanyurdu` (4): Mersin İdmanyurdu · Mersin İdman Yurdu · Mersin Idmanyurdu · Mersin Idman Yurdu




**Ukraine (ua)**





**Wales (wal)**





**Iran (ir)**





**Israel (il)**





**Jordan (jo)**





**Lebanon (lb)**





**Qatar (qa)**





**Canada (ca)**





**Mexico (mx)**





**United States (us)**

- **New York Red Bulls U23**, Harrison (1):
  - `newyorkredbullsu23` (2): New York Red Bulls U23 · New York Red Bulls U-23




**Australia (au)**





**New Zealand (nz)**





**Argentina (ar)**

- **Vélez Sarsfield**, Buenos Aires (1):
  - `velezsarsfield` (2): **Velez Sarsfield** · **Velez Sarsfield**
- **Colón Santa Fe**, Santa Fe (1):
  - `colonsantafe` (2): Colon Santa FE · Colon Santa Fe
- **Newell's Old Boys**, Rosario (1):
  - `newellsoldboys` (2): Newell's Old Boys · Newells Old Boys




**Bolivia (bo)**





**Brazil (br)**

- **Botafogo RJ**, Rio de Janeiro (1):
  - `botafogorj` (2): Botafogo RJ · Botafogo (RJ)
- **Atlético MG**, Belo Horizonte (2):
  - `atléticomg` (2): Atlético MG · Atlético/MG
  - `atleticomg` (3): Atletico-MG · Atletico MG · Atletico/MG
- **Grêmio RS**, Porto Alegre (1):
  - `gremio` (2): **Gremio** · **Gremio**
- **Náutico PE**, Recife (1):
  - `nautico` (2): **Nautico** · **Nautico**
- **Atlético GO**, Goiânia (1):
  - `atleticogo` (2): **Atletico GO** · **Atletico GO**




**Chile (cl)**





**Colombia (co)**





**Ecuador (ec)**





**Guyana (gy)**





**Paraguay (py)**





**Peru (pe)**





**Uruguay (uy)**





**Venezuela (ve)**









