# Club Notes


## Club Names Trivia

### Starting with/Ending in Numbers

In Germany

Starting with Numbers:
- 1\. FC Köln
- 1\. FC Nürnberg
- 1\. FC Heidenheim
- 1\. FC Kaiserslautern
- 1\. FC Magdeburg
- 1899 Hoffenheim
- 1860 München

Ending with Numbers:
- FC Schalke 04
- FSV Mainz 05
- Darmstadt 98
- Hannover 96
- FC Ingolstadt 04
- KFC Uerdingen 05


B-Teams:
- Barcelona 2
- Bayern 2 
- etc.    

note - do NOT use, as an alternative use Barcelona B or Barcelona II 
or such




In South America

- 23 de Mayo     -- check proper name in league ???
- 7 de Febrero   -- check proper name in league ???

