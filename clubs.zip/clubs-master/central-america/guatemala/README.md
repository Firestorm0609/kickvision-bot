13 clubs

- **CSD Municipal** : (2) Municipal · Club Social y Deportivo Municipal
- **Comunicaciones FC** : (3) CSD Comuni. · Comunicaciones · Comunicaciones Fútbol Club ⇒ (1) ≈Comunicaciones Futbol Club≈
- **Deportivo Mixco** : (2) Mixco · Club Social y Deportivo Mixco
- **Club Xelajú MC** : (4) Xela · Xelajú · Xelajú MC · Club Social y Deportivo Xelajú Mario Camposeco ⇒ (4) ≈Xelaju≈ · ≈Xelaju MC≈ · ≈Club Xelaju MC≈ · ≈Club Social y Deportivo Xelaju Mario Camposeco≈
- **Heredia Jaguares de Peten** : (1) Heredia
- **Antigua GFC** : (2) Antigua · Antigua Guatemala Fútbol Club ⇒ (1) ≈Antigua Guatemala Futbol Club≈
- **Cobán Imperial** : (2) CSD Cobán Imperial · Club Social y Deportivo Cobán Imperial ⇒ (3) ≈Coban Imperial≈ · ≈CSD Coban Imperial≈ · ≈Club Social y Deportivo Coban Imperial≈
- **CD Guastatoya** : (2) Guastatoya · Club Deportivo Guastatoya
- **Deportivo Iztapa** : (2) Iztapa · Club Deportivo Iztapa
- **CD Malacateco** : (3) Malacateco · Deportivo Malacateco · Club Deportivo Malacateco-Coatepeque
- **Deportivo Sanarate** : (4) Sanarate · Sanarate FC · Deportivo Sanarate FC · Club Social y Deportivo Sanarate Fútbol Club ⇒ (1) ≈Club Social y Deportivo Sanarate Futbol Club≈
- **Santa Lucía Cotzumalguapa** : (1) FC Santa Lucía Cotzumalguapa ⇒ (2) ≈Santa Lucia Cotzumalguapa≈ · ≈FC Santa Lucia Cotzumalguapa≈
- **Deportivo Siquinalá** : (1) Siquinalá ⇒ (2) ≈Siquinala≈ · ≈Deportivo Siquinala≈




Alphabet

- **Alphabet Specials** (3):  **á**  **í**  **ú** 
  - **á**×5 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ú**×7 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Guatemala City** (2): 
  - CSD Municipal  (2) Municipal · Club Social y Deportivo Municipal
  - Comunicaciones FC  (3) Comunicaciones · CSD Comuni. · Comunicaciones Fútbol Club
- **Antigua** (1): Antigua GFC  (2) Antigua · Antigua Guatemala Fútbol Club
- **Cobán** (1): Cobán Imperial  (2) CSD Cobán Imperial · Club Social y Deportivo Cobán Imperial
- **Guastatoya** (1): CD Guastatoya  (2) Guastatoya · Club Deportivo Guastatoya
- **Iztapa** (1): Deportivo Iztapa  (2) Iztapa · Club Deportivo Iztapa
- **Malacatán** (1): CD Malacateco  (3) Malacateco · Deportivo Malacateco · Club Deportivo Malacateco-Coatepeque
- **Mixco** (1): Deportivo Mixco  (2) Mixco · Club Social y Deportivo Mixco
- **Quetzaltenango** (1): Club Xelajú MC  (4) Xela · Xelajú · Xelajú MC · Club Social y Deportivo Xelajú Mario Camposeco
- **Sanarate** (1): Deportivo Sanarate  (4) Sanarate · Sanarate FC · Deportivo Sanarate FC · Club Social y Deportivo Sanarate Fútbol Club
- **Siquinalá** (1): Deportivo Siquinalá  (1) Siquinalá
- ? (2): 
  - Heredia Jaguares de Peten  (1) Heredia
  - Santa Lucía Cotzumalguapa  (1) FC Santa Lucía Cotzumalguapa




By Region

- **Guatemala City†** (2):   CSD Municipal · Comunicaciones FC
- **Mixco†** (1):   Deportivo Mixco
- **Quetzaltenango†** (1):   Club Xelajú MC
- **Antigua†** (1):   Antigua GFC
- **Cobán†** (1):   Cobán Imperial
- **Guastatoya†** (1):   CD Guastatoya
- **Iztapa†** (1):   Deportivo Iztapa
- **Malacatán†** (1):   CD Malacateco
- **Sanarate†** (1):   Deportivo Sanarate
- **Siquinalá†** (1):   Deportivo Siquinalá




By Year

- **1928** (1):   Club Xelajú MC
- **1936** (1):   CSD Municipal
- **1949** (1):   Comunicaciones FC
- ? (10):   Deportivo Mixco · Heredia Jaguares de Peten · Antigua GFC · Cobán Imperial · CD Guastatoya · Deportivo Iztapa · CD Malacateco · Deportivo Sanarate · Santa Lucía Cotzumalguapa · Deportivo Siquinalá






By A to Z

- **A** (3): Antigua · Antigua GFC · Antigua Guatemala Fútbol Club
- **C** (18): CSD Comuni. · CD Guastatoya · CD Malacateco · CSD Municipal · Club Xelajú MC · Cobán Imperial · Comunicaciones · Comunicaciones FC · CSD Cobán Imperial · Club Deportivo Iztapa · Club Deportivo Guastatoya · Comunicaciones Fútbol Club · Club Social y Deportivo Mixco · Club Social y Deportivo Municipal · Club Deportivo Malacateco-Coatepeque · Club Social y Deportivo Cobán Imperial · Club Social y Deportivo Sanarate Fútbol Club · Club Social y Deportivo Xelajú Mario Camposeco
- **D** (6): Deportivo Mixco · Deportivo Iztapa · Deportivo Sanarate · Deportivo Siquinalá · Deportivo Malacateco · Deportivo Sanarate FC
- **F** (1): FC Santa Lucía Cotzumalguapa
- **G** (1): Guastatoya
- **H** (2): Heredia · Heredia Jaguares de Peten
- **I** (1): Iztapa
- **M** (3): Mixco · Municipal · Malacateco
- **S** (4): Sanarate · Siquinalá · Sanarate FC · Santa Lucía Cotzumalguapa
- **X** (3): Xela · Xelajú · Xelajú MC




