6 datafiles, 43 clubs

**central-america/costa-rica/cr.clubs.txt** _(14)_:  LD Alajuelense · Carmelita · CS Cartaginés · Municipal Grecia · Guadalupe FC · CS Herediano · AD Municipal Liberia · Limón FC · Municipal Pérez Zeledón · Santos de Guápiles · Deportivo Saprissa · Universidad de Costa Rica · AD San Carlos · ADR Jicaral

**central-america/el-salvador/sv.clubs.txt** _(5)_:  I. Metapán · Club Deportivo Águila · Club Deportivo FAS · Alianza FC · Luis Ángel Firpo

**central-america/guatemala/gt.clubs.txt** _(13)_:  CSD Municipal · Comunicaciones FC · Deportivo Mixco · Club Xelajú MC · Heredia Jaguares de Peten · Antigua GFC · Cobán Imperial · CD Guastatoya · Deportivo Iztapa · CD Malacateco · Deportivo Sanarate · Santa Lucía Cotzumalguapa · Deportivo Siquinalá

**central-america/honduras/hn.clubs.txt** _(5)_:  CD Olimpia · CD Marathón · Real CD España · CD Motagua · CD Victoria

**central-america/nicaragua/ni.clubs.txt** _(1)_:  Real Estelí

**central-america/panama/pa.clubs.txt** _(5)_:  Chorrillo FC · Tauro FC · Club Deportivo Árabe Unido · San Francisco FC · Sporting San Miguelito

