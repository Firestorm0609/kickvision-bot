14 clubs

- **LD Alajuelense** : (1) Alajuelense
- **Carmelita** : (1) Asociación Deportiva Carmelita ⇒ (1) ≈Asociacion Deportiva Carmelita≈
- **CS Cartaginés** : (1) Cartaginés ⇒ (2) ≈Cartagines≈ · ≈CS Cartagines≈
- **Municipal Grecia** : (1) Grecia
- **Guadalupe FC** : (1) Guadalupe
- **CS Herediano** : (2) Herediano · Club Sport Herediano
- **AD Municipal Liberia** : (1) Liberia
- **Limón FC** : (1) Limón ⇒ (2) ≈Limon≈ · ≈Limon FC≈
- **Municipal Pérez Zeledón** : (2) Pérez Zeledón · AD Municipal Pérez Zeledón ⇒ (3) ≈Perez Zeledon≈ · ≈Municipal Perez Zeledon≈ · ≈AD Municipal Perez Zeledon≈
- **Santos de Guápiles** : (1) Santos ⇒ (1) ≈Santos de Guapiles≈
- **Deportivo Saprissa** : (1) Saprissa
- **Universidad de Costa Rica** : (3) UCR · CF Universidad de Costa Rica · Club de Futbol Universidad de Costa Rica
- **AD San Carlos** : (2) San Carlos · Asociación Deportiva San Carlos ⇒ (1) ≈Asociacion Deportiva San Carlos≈
- **ADR Jicaral** : (1) Asociación Deportiva y Recreativa Jicaral ⇒ (1) ≈Asociacion Deportiva y Recreativa Jicaral≈




Alphabet

- **Alphabet Specials** (3):  **á**  **é**  **ó** 
  - **á**×1 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×5 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×8 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **1941 Montes de Oca, San José** (1): Universidad de Costa Rica  (3) UCR · CF Universidad de Costa Rica · Club de Futbol Universidad de Costa Rica
- **Alajuela, Alajuela** (1): LD Alajuelense  (1) Alajuelense
- **Cartago, Cartago** (1): CS Cartaginés  (1) Cartaginés
- **Ciudad Quesada, San Carlos** (1): AD San Carlos  (2) San Carlos · Asociación Deportiva San Carlos
- **Grecia, Alajuela** (1): Municipal Grecia  (1) Grecia
- **Guadalupe, San José** (1): Guadalupe FC  (1) Guadalupe
- **Guápiles, Limón** (1): Santos de Guápiles  (1) Santos
- **Heredia, Heredia** (1): CS Herediano  (2) Herediano · Club Sport Herediano
- **Liberia, Guanacaste** (1): AD Municipal Liberia  (1) Liberia
- **Limón, Limón** (1): Limón FC  (1) Limón
- **San Isidro de El General, San José** (1): Municipal Pérez Zeledón  (2) Pérez Zeledón · AD Municipal Pérez Zeledón
- **San Juan de Tibás, San José** (1): Deportivo Saprissa  (1) Saprissa
- **Santa Bárbara, Heredia** (1): Carmelita  (1) Asociación Deportiva Carmelita
- ? (1): ADR Jicaral  (1) Asociación Deportiva y Recreativa Jicaral




By Region

- **Alajuela** (2):   LD Alajuelense · Municipal Grecia
- **Heredia** (2):   Carmelita · CS Herediano
- **Cartago** (1):   CS Cartaginés
- **San José** (4):   Guadalupe FC · Municipal Pérez Zeledón · Deportivo Saprissa · Universidad de Costa Rica
- **Guanacaste** (1):   AD Municipal Liberia
- **Limón** (2):   Limón FC · Santos de Guápiles
- **San Carlos** (1):   AD San Carlos




By Year

- **1962** (1):   Municipal Pérez Zeledón
- **1965** (1):   AD San Carlos
- **1981** (1):   ADR Jicaral
- ? (11):   LD Alajuelense · Carmelita · CS Cartaginés · Municipal Grecia · Guadalupe FC · CS Herediano · AD Municipal Liberia · Limón FC · Santos de Guápiles · Deportivo Saprissa · Universidad de Costa Rica






By A to Z

- **A** (8): ADR Jicaral · Alajuelense · AD San Carlos · AD Municipal Liberia · AD Municipal Pérez Zeledón · Asociación Deportiva Carmelita · Asociación Deportiva San Carlos · Asociación Deportiva y Recreativa Jicaral
- **C** (7): Carmelita · Cartaginés · CS Herediano · CS Cartaginés · Club Sport Herediano · CF Universidad de Costa Rica · Club de Futbol Universidad de Costa Rica
- **D** (1): Deportivo Saprissa
- **G** (3): Grecia · Guadalupe · Guadalupe FC
- **H** (1): Herediano
- **L** (4): Limón · Liberia · Limón FC · LD Alajuelense
- **M** (2): Municipal Grecia · Municipal Pérez Zeledón
- **P** (1): Pérez Zeledón
- **S** (4): Santos · Saprissa · San Carlos · Santos de Guápiles
- **U** (2): UCR · Universidad de Costa Rica




