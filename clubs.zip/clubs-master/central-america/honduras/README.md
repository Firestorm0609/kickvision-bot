5 clubs

- **CD Olimpia** : (1) Olimpia
- **CD Marathón** : (1) Marathón ⇒ (2) ≈Marathon≈ · ≈CD Marathon≈
- **Real CD España** : (1) Real España ⇒ (2) ≈Real Espana≈ · ≈Real CD Espana≈
- **CD Motagua** : (1) Motagua
- **CD Victoria** : (1) Victoria




Alphabet

- **Alphabet Specials** (2):  **ñ**  **ó** 
  - **ñ**×2 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×2 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **city:sanpedrosula** (2): 
  - CD Marathón  (1) Marathón
  - Real CD España  (1) Real España
- **city:tegucigalpa** (2): 
  - CD Olimpia  (1) Olimpia
  - CD Motagua  (1) Motagua
- ? (1): CD Victoria  (1) Victoria




By Region

- **city:tegucigalpa†** (2):   CD Olimpia · CD Motagua
- **city:sanpedrosula†** (2):   CD Marathón · Real CD España




By Year

- ? (5):   CD Olimpia · CD Marathón · Real CD España · CD Motagua · CD Victoria






By A to Z

- **C** (4): CD Motagua · CD Olimpia · CD Marathón · CD Victoria
- **M** (2): Motagua · Marathón
- **O** (1): Olimpia
- **R** (2): Real España · Real CD España
- **V** (1): Victoria




