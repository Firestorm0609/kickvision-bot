16 clubs

- **FC Yerevan** : (2) Yerevan · FK Yerevan
- **FC Ararat Yerevan** : (3) Ararat · FC Ararat · Ararat Yerevan
- **Ararat-Armenia FC** : (2) Ararat-Armenia · FC Ararat-Armenia
- **Kilikia FC (1992-2011)** : (1) FC Kilikia
- **Zvartnots-AAL FC (1997-2003)** : (1) FC Zvartnots AAL
- **FC Pyunik** : (3) Pyunik · Pyunik FC · Pyunik Yerevan
- **Ulisses FC** : (2) Ulisses · Ulisses Yerevan
- **FC Mika** : (1) Mika Ashtarak
- **FC Gandzasar** : (3) Gandzasar · Gandzasar FC · Gandzasar Kapan
- **FC Urartu** : (4) Urartu · Banants · FC Banants · Banants Yerevan
- **FC Shirak** : (3) Shirak · Shirak FC · Shirak Gyumri
- **Araks Ararat (-2005)** : (1) FC Araks Ararat
- **Alashkert FC** : (2) Alashkert · FC Alashkert
- **FSC Lori** : (1) Lori
- **Artsakh FC**
- **FC Gandzasar Kapan** : (1) FC Gandzasar-Kapan




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **FC Gandzasar Kapan**, Kapan (1):
  - `fcgandzasarkapan` (2): FC Gandzasar Kapan · FC Gandzasar-Kapan




By City

- **Yerevan** (5): 
  - FC Yerevan  (2) Yerevan · FK Yerevan
  - FC Ararat Yerevan  (3) Ararat · FC Ararat · Ararat Yerevan
  - Ararat-Armenia FC  (2) Ararat-Armenia · FC Ararat-Armenia
  - Kilikia FC (1992-2011)  (1) FC Kilikia
  - Zvartnots-AAL FC (1997-2003)  (1) FC Zvartnots AAL
- **Ararat** (1): Araks Ararat (-2005)  (1) FC Araks Ararat
- **Kapan** (1): FC Gandzasar Kapan  (1) FC Gandzasar-Kapan
- ? (9): 
  - FC Pyunik  (3) Pyunik · Pyunik FC · Pyunik Yerevan
  - Ulisses FC  (2) Ulisses · Ulisses Yerevan
  - FC Mika  (1) Mika Ashtarak
  - FC Gandzasar  (3) Gandzasar · Gandzasar FC · Gandzasar Kapan
  - FC Urartu  (4) Urartu · FC Banants · Banants · Banants Yerevan
  - FC Shirak  (3) Shirak · Shirak FC · Shirak Gyumri
  - Alashkert FC  (2) Alashkert · FC Alashkert
  - FSC Lori  (1) Lori
  - Artsakh FC 




By Region

- **Yerevan†** (5):   FC Yerevan · FC Ararat Yerevan · Ararat-Armenia FC · Kilikia FC (1992-2011) · Zvartnots-AAL FC (1997-2003)
- **Ararat†** (1):   Araks Ararat (-2005)
- **Kapan†** (1):   FC Gandzasar Kapan




By Year

- **1935** (1):   FC Ararat Yerevan
- **1992** (1):   Kilikia FC (1992-2011)
- **1995** (1):   FC Yerevan
- **1997** (1):   Zvartnots-AAL FC (1997-2003)
- **2004** (1):   FC Gandzasar Kapan
- **2017** (1):   Ararat-Armenia FC
- ? (10):   FC Pyunik · Ulisses FC · FC Mika · FC Gandzasar · FC Urartu · FC Shirak · Araks Ararat (-2005) · Alashkert FC · FSC Lori · Artsakh FC




Historic

- **2003** (1):   Zvartnots-AAL FC (1997-2003)
- **2005** (1):   Araks Ararat (-2005)
- **2011** (1):   Kilikia FC (1992-2011)






By A to Z

- **A** (8): Ararat · Alashkert · Artsakh FC · Alashkert FC · Ararat Yerevan · Ararat-Armenia · Ararat-Armenia FC · Araks Ararat (-2005)
- **B** (2): Banants · Banants Yerevan
- **F** (18): FC Mika · FSC Lori · FC Ararat · FC Pyunik · FC Shirak · FC Urartu · FC Banants · FC Kilikia · FC Yerevan · FK Yerevan · FC Alashkert · FC Gandzasar · FC Araks Ararat · FC Zvartnots AAL · FC Ararat Yerevan · FC Ararat-Armenia · FC Gandzasar Kapan · FC Gandzasar-Kapan
- **G** (3): Gandzasar · Gandzasar FC · Gandzasar Kapan
- **K** (1): Kilikia FC (1992-2011)
- **L** (1): Lori
- **M** (1): Mika Ashtarak
- **P** (3): Pyunik · Pyunik FC · Pyunik Yerevan
- **S** (3): Shirak · Shirak FC · Shirak Gyumri
- **U** (4): Urartu · Ulisses · Ulisses FC · Ulisses Yerevan
- **Y** (1): Yerevan
- **Z** (1): Zvartnots-AAL FC (1997-2003)




