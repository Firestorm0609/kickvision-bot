15 clubs

- **FK RFS** : (4) RFS · JFK Olimps/RFS · Rīgas Futb. Skola · FK Rīgas Futbola Skola ⇒ (2) ≈Rigas Futb. Skola≈ · ≈FK Rigas Futbola Skola≈
- **Riga FC** : (3) Riga · FC Riga · FK Rīga ⇒ (1) ≈FK Riga≈
- **FS METTA** : (4) METTA · FS METTA/LU · FK Universitate · FS METTA/Latvijas Universitāte ⇒ (1) ≈FS METTA/Latvijas Universitate≈
- **FK LU/Daugava (1979-2000)** : (2) Torpedo Rīga · FK Latvijas Universitāte/Daugava ⇒ (2) ≈Torpedo Riga≈ · ≈FK Latvijas Universitate/Daugava≈
- **FC Daugava Rīga (2003-2015)** : (2) Daugava Rīga · FK Daugava Rīga ⇒ (3) ≈Daugava Riga≈ · ≈FC Daugava Riga≈ · ≈FK Daugava Riga≈
- **Skonto FC (1991-2006)** : (3) Skonto · Skonto Riga · FC Skonto Riga
- **FK Ventspils** : (1) Ventspils
- **FK Liepāja** : (1) Liepāja ⇒ (2) ≈Liepaja≈ · ≈FK Liepaja≈
- **SK Liepājas Metalurgs** : (3) Metalurgs Liepāja · Liepājas Metalurgs · FK Liepājas Metalurgs ⇒ (4) ≈Metalurgs Liepaja≈ · ≈Liepajas Metalurgs≈ · ≈FK Liepajas Metalurgs≈ · ≈SK Liepajas Metalurgs≈
- **FK Jelgava** : (1) Jelgava
- **FK Valmiera** : (1) Valmiera FK
- **FK Spartaks Jūrmala** : (2) FK Spartaks · Spartaks Jūrmala ⇒ (2) ≈Spartaks Jurmala≈ · ≈FK Spartaks Jurmala≈
- **FC Daugava Daugavpils** : (2) FC Daugava · Daugava Daugavpils
- **BFC Daugavpils** : (1) Daugavpils
- **FC Dinaburg**




Alphabet

- **Alphabet Specials** (3):  **ā**  **ī**  **ū** 
  - **ā**×8 U+0101 (257) - LATIN SMALL LETTER A WITH MACRON ⇒ a
  - **ī**×7 U+012B (299) - LATIN SMALL LETTER I WITH MACRON ⇒ i
  - **ū**×2 U+016B (363) - LATIN SMALL LETTER U WITH MACRON ⇒ u




Duplicates





By City

- **Riga** (6): 
  - FK RFS  (4) RFS · Rīgas Futb. Skola · FK Rīgas Futbola Skola · JFK Olimps/RFS
  - Riga FC  (3) Riga · FC Riga · FK Rīga
  - FS METTA  (4) METTA · FS METTA/LU · FS METTA/Latvijas Universitāte · FK Universitate
  - FK LU/Daugava (1979-2000)  (2) FK Latvijas Universitāte/Daugava · Torpedo Rīga
  - FC Daugava Rīga (2003-2015)  (2) Daugava Rīga · FK Daugava Rīga
  - Skonto FC (1991-2006)  (3) Skonto · Skonto Riga · FC Skonto Riga
- **Daugavpils** (2): 
  - FC Daugava Daugavpils  (2) FC Daugava · Daugava Daugavpils
  - BFC Daugavpils  (1) Daugavpils
- **Liepāja** (2): 
  - FK Liepāja  (1) Liepāja
  - SK Liepājas Metalurgs  (3) Liepājas Metalurgs · FK Liepājas Metalurgs · Metalurgs Liepāja
- **Jelgava** (1): FK Jelgava  (1) Jelgava
- **Jūrmala** (1): FK Spartaks Jūrmala  (2) Spartaks Jūrmala · FK Spartaks
- **Valmiera** (1): FK Valmiera  (1) Valmiera FK
- **Ventspils** (1): FK Ventspils  (1) Ventspils
- ? (1): FC Dinaburg 




By Region

- **Riga†** (6):   FK RFS · Riga FC · FS METTA · FK LU/Daugava (1979-2000) · FC Daugava Rīga (2003-2015) · Skonto FC (1991-2006)
- **Ventspils†** (1):   FK Ventspils
- **Liepāja†** (2):   FK Liepāja · SK Liepājas Metalurgs
- **Jelgava†** (1):   FK Jelgava
- **Valmiera†** (1):   FK Valmiera
- **Jūrmala†** (1):   FK Spartaks Jūrmala
- **Daugavpils†** (2):   FC Daugava Daugavpils · BFC Daugavpils




By Year

- **1979** (1):   FK LU/Daugava (1979-2000)
- **1991** (1):   Skonto FC (1991-2006)
- **2003** (1):   FC Daugava Rīga (2003-2015)
- ? (12):   FK RFS · Riga FC · FS METTA · FK Ventspils · FK Liepāja · SK Liepājas Metalurgs · FK Jelgava · FK Valmiera · FK Spartaks Jūrmala · FC Daugava Daugavpils · BFC Daugavpils · FC Dinaburg




Historic

- **2000** (1):   FK LU/Daugava (1979-2000)
- **2006** (1):   Skonto FC (1991-2006)
- **2015** (1):   FC Daugava Rīga (2003-2015)






By A to Z

- **B** (1): BFC Daugavpils
- **D** (3): Daugavpils · Daugava Rīga · Daugava Daugavpils
- **F** (23): FK RFS · FC Riga · FK Rīga · FS METTA · FC Daugava · FK Jelgava · FK Liepāja · FC Dinaburg · FK Spartaks · FK Valmiera · FS METTA/LU · FK Ventspils · FC Skonto Riga · FK Daugava Rīga · FK Universitate · FK Spartaks Jūrmala · FC Daugava Daugavpils · FK Liepājas Metalurgs · FK Rīgas Futbola Skola · FK LU/Daugava (1979-2000) · FC Daugava Rīga (2003-2015) · FS METTA/Latvijas Universitāte · FK Latvijas Universitāte/Daugava
- **J** (2): Jelgava · JFK Olimps/RFS
- **L** (2): Liepāja · Liepājas Metalurgs
- **M** (2): METTA · Metalurgs Liepāja
- **R** (4): RFS · Riga · Riga FC · Rīgas Futb. Skola
- **S** (5): Skonto · Skonto Riga · Spartaks Jūrmala · SK Liepājas Metalurgs · Skonto FC (1991-2006)
- **T** (1): Torpedo Rīga
- **V** (2): Ventspils · Valmiera FK




