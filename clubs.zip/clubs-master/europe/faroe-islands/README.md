15 clubs

- **HB Tórshavn** : (3) HB · Havnar Bóltfelag · Havnar Bóltfelag Tórshavn ⇒ (3) ≈HB Torshavn≈ · ≈Havnar Boltfelag≈ · ≈Havnar Boltfelag Torshavn≈
- **B36 Tórshavn** : (1) B36 ⇒ (1) ≈B36 Torshavn≈
- **EB/Streymur**
- **NSÍ Runavík** : (1) NSÍ ⇒ (2) ≈NSI≈ · ≈NSI Runavik≈
- **Víkingur** : (1) Vikingur ⇒ (1) ≈Vikingur≈
- **GÍ Gøta (1926-2008)** : (2) GÍ · Gøtu Ítróttarfelag ⇒ (3) ≈GI≈ · ≈GI Gota≈ · ≈Gotu Itrottarfelag≈
- **ÍF Fuglafjørdur** : (1) ÍF ⇒ (2) ≈IF≈ · ≈IF Fuglafjordur≈
- **KÍ Klaksvík** : (1) KÍ ⇒ (2) ≈KI≈ · ≈KI Klaksvik≈
- **Skála ÍF** : (1) Skála ⇒ (2) ≈Skala≈ · ≈Skala IF≈
- **TB Tvøroyri** : (1) TB ⇒ (1) ≈TB Tvoroyri≈
- **AB Argir** : (1) AB
- **B68 Toftir** : (2) B68 · Tofta Ítróttarfelag ⇒ (1) ≈Tofta Itrottarfelag≈
- **FC Suðuroy** : (2) VB/Sumba · FC Suduroy ⇒ (1) ≈FC Suduroy≈
- **VB Vágur (1905-2005)** : (1) Vágur ⇒ (2) ≈Vagur≈ · ≈VB Vagur≈
- **B71 Sandoy** : (3) B71 · Bóltfelagið 1971 · Sandoyar Ítróttarfelag B71 ⇒ (2) ≈Boltfelagid 1971≈ · ≈Sandoyar Itrottarfelag B71≈




Alphabet

- **Alphabet Specials** (6):  **Í**  **á**  **í**  **ð**  **ó**  **ø** 
  - **Í**×12 U+00CD (205) - LATIN CAPITAL LETTER I WITH ACUTE ⇒ I
  - **á**×4 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **í**×3 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ð**×2 U+00F0 (240) - LATIN SMALL LETTER ETH ⇒ d
  - **ó**×9 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ø**×4 U+00F8 (248) - LATIN SMALL LETTER O WITH STROKE ⇒ o




Duplicates

- **Víkingur**,  (1):
  - `vikingur` (2): **Vikingur** · **Vikingur**
- **FC Suðuroy**, Vágur (1):
  - `fcsuduroy` (2): **FC Suduroy** · **FC Suduroy**




By City

- **Vágur** (2): 
  - FC Suðuroy  (2) FC Suduroy · VB/Sumba
  - VB Vágur (1905-2005)  (1) Vágur
- **Gøta** (1): GÍ Gøta (1926-2008)  (2) GÍ · Gøtu Ítróttarfelag
- **Sandur** (1): B71 Sandoy  (3) B71 · Bóltfelagið 1971 · Sandoyar Ítróttarfelag B71
- ? (11): 
  - HB Tórshavn  (3) HB · Havnar Bóltfelag · Havnar Bóltfelag Tórshavn
  - B36 Tórshavn  (1) B36
  - EB/Streymur 
  - NSÍ Runavík  (1) NSÍ
  - Víkingur  (1) Vikingur
  - ÍF Fuglafjørdur  (1) ÍF
  - KÍ Klaksvík  (1) KÍ
  - Skála ÍF  (1) Skála
  - TB Tvøroyri  (1) TB
  - AB Argir  (1) AB
  - B68 Toftir  (2) B68 · Tofta Ítróttarfelag




By Region

- **Gøta†** (1):   GÍ Gøta (1926-2008)
- **Vágur†** (2):   FC Suðuroy · VB Vágur (1905-2005)
- **Sandur†** (1):   B71 Sandoy




By Year

- **1905** (1):   VB Vágur (1905-2005)
- **1926** (1):   GÍ Gøta (1926-2008)
- **2005** (1):   FC Suðuroy
- ? (12):   HB Tórshavn · B36 Tórshavn · EB/Streymur · NSÍ Runavík · Víkingur · ÍF Fuglafjørdur · KÍ Klaksvík · Skála ÍF · TB Tvøroyri · AB Argir · B68 Toftir · B71 Sandoy




Historic

- **2005** (1):   VB Vágur (1905-2005)
- **2008** (1):   GÍ Gøta (1926-2008)






By A to Z

- **A** (2): AB · AB Argir
- **B** (7): B36 · B68 · B71 · B68 Toftir · B71 Sandoy · B36 Tórshavn · Bóltfelagið 1971
- **E** (1): EB/Streymur
- **F** (2): FC Suduroy · FC Suðuroy
- **G** (3): GÍ · Gøtu Ítróttarfelag · GÍ Gøta (1926-2008)
- **H** (4): HB · HB Tórshavn · Havnar Bóltfelag · Havnar Bóltfelag Tórshavn
- **K** (2): KÍ · KÍ Klaksvík
- **N** (2): NSÍ · NSÍ Runavík
- **S** (3): Skála · Skála ÍF · Sandoyar Ítróttarfelag B71
- **T** (3): TB · TB Tvøroyri · Tofta Ítróttarfelag
- **V** (5): Vágur · VB/Sumba · Vikingur · Víkingur · VB Vágur (1905-2005)
- **Í** (2): ÍF · ÍF Fuglafjørdur




