29 clubs

- **Red Star Belgrade** : (5) Red Star · Crvena Zvezda · FK Crvena Zvezda · Roter Stern B. [de] · FK Red Star Belgrade
- **FK Partizan Belgrade** : (5) Partizan · FK Partizan · Partizan Beograd · Partizan Belgrade · Partizan Belgrad [de]
- **OFK Beograd** : (1) Omladinski Fudbalski Klub Beograd
- **FK Rad Belgrade** : (4) Rad · FK Rad · Rad Beograd · FK Rad Beograd
- **FK Čukarički** : (2) Čukarički · Čukarički Belgrade ⇒ (3) ≈Cukaricki≈ · ≈FK Cukaricki≈ · ≈Cukaricki Belgrade≈
- **FK Bežanija** : (1) Fudbalski Klub Bežanija ⇒ (2) ≈FK Bezanija≈ · ≈Fudbalski Klub Bezanija≈
- **FK Obilić (1924-2015)** : (2) Obilić · Obilić Belgrade ⇒ (3) ≈Obilic≈ · ≈FK Obilic≈ · ≈Obilic Belgrade≈
- **FK Vojvodina** : (3) Vojvodina · Vojvodina Novi Sad · FK Vojvodina Novi Sad
- **FK Proleter Novi Sad** : (1) Proleter Novi Sad
- **FK Spartak Zlatibor Voda**
- **FK Sloboda Užice** : (1) Sloboda Užice ⇒ (2) ≈Sloboda Uzice≈ · ≈FK Sloboda Uzice≈
- **FK Sevojno (1950-2010)** : (1) FK Sloboda Sevojno
- **FK Jagodina** : (1) Jagodina
- **FK Borac Čačak** : (2) Borac Čačak · Fudbalski Klub Borac Čačak ⇒ (3) ≈Borac Cacak≈ · ≈FK Borac Cacak≈ · ≈Fudbalski Klub Borac Cacak≈
- **FK Spartak Subotica** : (2) Spartak Subotica · FC Spartak Subotica
- **FK Radnicki Niš** : (1) Radnicki Niš ⇒ (2) ≈Radnicki Nis≈ · ≈FK Radnicki Nis≈
- **FK Mladost Lučani** : (1) Mladost Lučani ⇒ (2) ≈Mladost Lucani≈ · ≈FK Mladost Lucani≈
- **Bačka Topola** : (3) TSC Bačka Topola · FK TSC Bačka Topola · Topolski Sportski Club ⇒ (3) ≈Backa Topola≈ · ≈TSC Backa Topola≈ · ≈FK TSC Backa Topola≈
- **FK Napredak** : (3) Napredak · Napredak Krusevac · FK Napredak Krusevac
- **FK Voždovac** : (1) Voždovac ⇒ (2) ≈Vozdovac≈ · ≈FK Vozdovac≈
- **FK Indjija** : (2) Indjija · FK Inđija
- **FK Javor** : (1) Javor
- **FK Proleter** : (1) Proleter
- **FK Radnik Surdulica** : (1) Radnik Surdulica
- **Macva Sabac**
- **FK Smederevo** : (4) Smederevo · Sartid Smederevo · FK Smederevo 1924 · Fudbalski Klub Smederevo 1924
- **FK Banat Zrenjanin (2006-2016)** : (1) Banat Zrenjanin
- **FK Hajduk Kula (1925-2013)** : (1) Hajduk Kula
- **OFK Bečej 1918** : (1) FK Bečej ⇒ (2) ≈FK Becej≈ · ≈OFK Becej 1918≈




Alphabet

- **Alphabet Specials** (6):  **ć**  **Č**  **č**  **đ**  **š**  **ž** 
  - **ć**×3 U+0107 (263) - LATIN SMALL LETTER C WITH ACUTE ⇒ c
  - **Č**×6 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **č**×13 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **đ**×1 U+0111 (273) - LATIN SMALL LETTER D WITH STROKE ⇒ **?**
  - **š**×2 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **ž**×6 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Belgrade** (7): 
  - Red Star Belgrade  (5) Crvena Zvezda · FK Crvena Zvezda · Red Star · FK Red Star Belgrade · Roter Stern B. [de]
  - FK Partizan Belgrade  (5) Partizan · FK Partizan · Partizan Belgrade · Partizan Beograd · Partizan Belgrad [de]
  - OFK Beograd  (1) Omladinski Fudbalski Klub Beograd
  - FK Rad Belgrade  (4) FK Rad · Rad · FK Rad Beograd · Rad Beograd
  - FK Čukarički  (2) Čukarički · Čukarički Belgrade
  - FK Bežanija  (1) Fudbalski Klub Bežanija
  - FK Obilić (1924-2015)  (2) Obilić · Obilić Belgrade
- **Novi Sad** (2): 
  - FK Vojvodina  (3) Vojvodina · Vojvodina Novi Sad · FK Vojvodina Novi Sad
  - FK Proleter Novi Sad  (1) Proleter Novi Sad
- **Užice** (2): 
  - FK Sloboda Užice  (1) Sloboda Užice
  - FK Sevojno (1950-2010)  (1) FK Sloboda Sevojno
- **Bačka Topola** (1): Bačka Topola  (3) TSC Bačka Topola · FK TSC Bačka Topola · Topolski Sportski Club
- **Bečej** (1): OFK Bečej 1918  (1) FK Bečej
- **Kula** (1): FK Hajduk Kula (1925-2013)  (1) Hajduk Kula
- **Niš** (1): FK Radnicki Niš  (1) Radnicki Niš
- **Smederevo** (1): FK Smederevo  (4) Smederevo · FK Smederevo 1924 · Fudbalski Klub Smederevo 1924 · Sartid Smederevo
- **Zrenjanin** (1): FK Banat Zrenjanin (2006-2016)  (1) Banat Zrenjanin
- **Čačak** (1): FK Borac Čačak  (2) Borac Čačak · Fudbalski Klub Borac Čačak
- ? (11): 
  - FK Spartak Zlatibor Voda 
  - FK Jagodina  (1) Jagodina
  - FK Spartak Subotica  (2) FC Spartak Subotica · Spartak Subotica
  - FK Mladost Lučani  (1) Mladost Lučani
  - FK Napredak  (3) Napredak · Napredak Krusevac · FK Napredak Krusevac
  - FK Voždovac  (1) Voždovac
  - FK Indjija  (2) Indjija · FK Inđija
  - FK Javor  (1) Javor
  - FK Proleter  (1) Proleter
  - FK Radnik Surdulica  (1) Radnik Surdulica
  - Macva Sabac 




By Region

- **Belgrade†** (7):   Red Star Belgrade · FK Partizan Belgrade · OFK Beograd · FK Rad Belgrade · FK Čukarički · FK Bežanija · FK Obilić (1924-2015)
- **Novi Sad†** (2):   FK Vojvodina · FK Proleter Novi Sad
- **Užice†** (2):   FK Sloboda Užice · FK Sevojno (1950-2010)
- **Čačak†** (1):   FK Borac Čačak
- **Niš†** (1):   FK Radnicki Niš
- **Bačka Topola†** (1):   Bačka Topola
- **Smederevo†** (1):   FK Smederevo
- **Zrenjanin†** (1):   FK Banat Zrenjanin (2006-2016)
- **Kula†** (1):   FK Hajduk Kula (1925-2013)
- **Bečej†** (1):   OFK Bečej 1918




By Year

- **1911** (1):   OFK Beograd
- **1913** (1):   Bačka Topola
- **1918** (1):   OFK Bečej 1918
- **1921** (1):   FK Bežanija
- **1924** (2):   FK Obilić (1924-2015) · FK Smederevo
- **1925** (1):   FK Hajduk Kula (1925-2013)
- **1926** (2):   FK Čukarički · FK Borac Čačak
- **1950** (1):   FK Sevojno (1950-2010)
- **1951** (1):   FK Proleter Novi Sad
- **2006** (1):   FK Banat Zrenjanin (2006-2016)
- ? (17):   Red Star Belgrade · FK Partizan Belgrade · FK Rad Belgrade · FK Vojvodina · FK Spartak Zlatibor Voda · FK Sloboda Užice · FK Jagodina · FK Spartak Subotica · FK Radnicki Niš · FK Mladost Lučani · FK Napredak · FK Voždovac · FK Indjija · FK Javor · FK Proleter · FK Radnik Surdulica · Macva Sabac




Historic

- **2010** (1):   FK Sevojno (1950-2010)
- **2013** (1):   FK Hajduk Kula (1925-2013)
- **2015** (1):   FK Obilić (1924-2015)
- **2016** (1):   FK Banat Zrenjanin (2006-2016)






By A to Z

- **B** (3): Borac Čačak · Bačka Topola · Banat Zrenjanin
- **C** (1): Crvena Zvezda
- **F** (40): FK Rad · FK Bečej · FK Javor · FK Inđija · FK Indjija · FK Bežanija · FK Jagodina · FK Napredak · FK Partizan · FK Proleter · FK Voždovac · FK Smederevo · FK Vojvodina · FK Čukarički · FK Borac Čačak · FK Rad Beograd · FK Rad Belgrade · FK Radnicki Niš · FK Crvena Zvezda · FK Sloboda Užice · FK Mladost Lučani · FK Smederevo 1924 · FK Sloboda Sevojno · FC Spartak Subotica · FK Radnik Surdulica · FK Spartak Subotica · FK TSC Bačka Topola · FK Napredak Krusevac · FK Partizan Belgrade · FK Proleter Novi Sad · FK Red Star Belgrade · FK Obilić (1924-2015) · FK Vojvodina Novi Sad · FK Sevojno (1950-2010) · Fudbalski Klub Bežanija · FK Spartak Zlatibor Voda · FK Hajduk Kula (1925-2013) · Fudbalski Klub Borac Čačak · Fudbalski Klub Smederevo 1924 · FK Banat Zrenjanin (2006-2016)
- **H** (1): Hajduk Kula
- **I** (1): Indjija
- **J** (2): Javor · Jagodina
- **M** (2): Macva Sabac · Mladost Lučani
- **N** (2): Napredak · Napredak Krusevac
- **O** (5): Obilić · OFK Beograd · OFK Bečej 1918 · Obilić Belgrade · Omladinski Fudbalski Klub Beograd
- **P** (6): Partizan · Proleter · Partizan Beograd · Partizan Belgrade · Proleter Novi Sad · Partizan Belgrad [de]
- **R** (7): Rad · Red Star · Rad Beograd · Radnicki Niš · Radnik Surdulica · Red Star Belgrade · Roter Stern B. [de]
- **S** (4): Smederevo · Sloboda Užice · Sartid Smederevo · Spartak Subotica
- **T** (2): TSC Bačka Topola · Topolski Sportski Club
- **V** (3): Voždovac · Vojvodina · Vojvodina Novi Sad
- **Č** (2): Čukarički · Čukarički Belgrade




