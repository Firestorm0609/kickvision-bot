49 clubs

- **AEK Athens FC** : (3) AEK · AEK Athens · AEK Athen [de]
- **Panathinaikos FC** : (2) Panathinaikos · Panathinaikos Athens
- **Apollon Smyrnis FC** : (3) Apollon · Apollon Smyrnis · Apollon Athens FC
- **Atromitos FC** : (2) Atromitos · Atromitos Athen [de]
- **Panionios GSS** : (2) Panionios · Panionios Athen [de]
- **APO Akratitos** : (1) Akratitos
- **Athinaikos AS FC** : (1) Athinaikos
- **Chalkidona FC** : (1) Chalkidona
- **Egaleo FC** : (2) Egaleo · AO Aigaleo
- **Ethnikos Asteras FC** : (2) Eth Asteras · Ethnikos Asteras
- **Kallithea FC** : (2) Kalithea · Kallithea
- **Thrasyvoulos FC** : (1) Thrasyvoulos
- **Panelefsiniakos FC** : (1) Eleysina
- **Proodeftiki FC** : (2) Proodeftiki · Proodeytiki
- **Ionikos FC** : (2) Ionikos · Ionikos Nikea
- **Olympiacos Piraeus FC** : (6) Olympiacos · Olympiakos · Olympiacos FC · Olympiakos P. · Olympiakos Piräus · Olympiacos Piraeus ⇒ (2) ≈Olympiakos Piraus≈ · ≈Olympiakos Piraeus≈
- **Ethnikos Piraeus FC** : (2) Ethnikos · Ethnikos Piraeus
- **PAOK FC** : (5) PAOK · PAOK Thessal. · PAOK Saloniki · PAOK Thessaloniki · PAOK Thessaloniki FC
- **Aris Thessaloniki FC** : (3) Aris · Aris Saloniki · Aris Thessaloniki
- **Iraklis 1908 Thessaloniki FC** : (5) Iraklis · Iraklis FC · Heracles [en] · AEP Iraklis FC · Iraklis Thessaloniki
- **Apollon Pontou FC** : (1) Kalamaria
- **Asteras Tripolis FC** : (2) Asteras · Asteras Tripolis
- **Xanthi FC** : (2) Xanthi · Skoda Xanthi FC
- **Panetolikos GFS** : (2) Panetolikos · Panaitolikos
- **PAS Giannina FC** : (3) Giannina · Yiannina · PAS Giannina
- **Levadiakos FC** : (2) Levadiakos · Levadeiakos
- **AE Larissa FC** : (10) AEL · Larisa · Larissa · AE Larisa · Larissa FC · AE Larissa · Larisa AEL · AEL Football Club · Athlitiki Enosi Larissa · Athlitiki Enosi Larissa FC
- **PAS Lamia 1964** : (3) Lamia · PAS Lamia · Lamia 1964
- **Kerkyra FC** : (4) Kerkyra · AOK Kerkyra · PAE Kerkyra · Kerkyra Kassiopi
- **Doxa Dramas FC** : (2) Doxa · Doxa Dramas
- **Edessaikos FC** : (1) Edessaikos
- **Platanias FC** : (3) Platanias · AO Platanias · Athlitikós Ómilos Plataniá Chaníon ⇒ (1) ≈Athlitikos Omilos Platania Chanion≈
- **PAE Chania** : (1) Chania FC
- **Ergotelis FC** : (1) Ergotelis
- **OFI Crete FC** : (4) OFI · OFI Crete · OFI Heraklion · OFI Kreta FC [de]
- **Kalamata FC** : (3) Kalamata · PAE PS Kalamata · Kalamata Football Club
- **AEL Kalloni FC** : (1) Kallonis
- **Kastoria FC** : (1) Kastoria
- **Kavala FC** : (1) Kavala
- **Volos FC** : (5) Volos · Volos NFC · Volos NPS · Volos Football Club · Volos New Football Club
- **Niki Volou FC** : (2) Niki Volou · Niki Volos
- **Olympiacos Volou 1937 FC** : (4) Olympiacos Volou · Olympiakos Volos · Olympiakos Volou · Olympiacos Volou FC
- **Panachaiki FC** : (5) Panahaiki · Panahaiki FC · Panachaiki GE · Panachaiki Patras · Panachaiki 1891 Football Club
- **Paniliakos FC** : (1) Paniliakos
- **Panserraikos FC** : (1) Panserraikos
- **Panthrakikos FC** : (2) Panthrakikos · Panthrakikos Komotini
- **Trikala FC** : (1) Trikala
- **AO Trikala 1963** : (2) Trikala 1963 FC · AO Trikala 1963 FC
- **Veria FC** : (2) Veria · Veroia




Alphabet

- **Alphabet Specials** (5):  **Ó**  **á**  **ä**  **í**  **ó** 
  - **Ó**×1 U+00D3 (211) - LATIN CAPITAL LETTER O WITH ACUTE ⇒ O
  - **á**×1 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **ä**×1 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **í**×1 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Athens** (10): 
  - AEK Athens FC  (3) AEK · AEK Athens · AEK Athen [de]
  - Panathinaikos FC  (2) Panathinaikos · Panathinaikos Athens
  - Apollon Smyrnis FC  (3) Apollon · Apollon Smyrnis · Apollon Athens FC
  - Atromitos FC  (2) Atromitos · Atromitos Athen [de]
  - Panionios GSS  (2) Panionios · Panionios Athen [de]
  - APO Akratitos  (1) Akratitos
  - Athinaikos AS FC  (1) Athinaikos
  - Chalkidona FC  (1) Chalkidona
  - Egaleo FC  (2) Egaleo · AO Aigaleo
  - Ethnikos Asteras FC  (2) Ethnikos Asteras · Eth Asteras
- **Thessaloniki, Central Macedonia** (3): 
  - PAOK FC  (5) PAOK · PAOK Thessal. · PAOK Thessaloniki · PAOK Saloniki · PAOK Thessaloniki FC
  - Aris Thessaloniki FC  (3) Aris · Aris Thessaloniki · Aris Saloniki
  - Iraklis 1908 Thessaloniki FC  (5) Iraklis · Iraklis FC · Iraklis Thessaloniki · AEP Iraklis FC · Heracles [en]
- **Volos, Thessaly** (3): 
  - Volos FC  (5) Volos · Volos NFC · Volos Football Club · Volos NPS · Volos New Football Club
  - Niki Volou FC  (2) Niki Volou · Niki Volos
  - Olympiacos Volou 1937 FC  (4) Olympiacos Volou · Olympiacos Volou FC · Olympiakos Volou · Olympiakos Volos
- **Chania, Crete** (2): 
  - Platanias FC  (3) Platanias · AO Platanias · Athlitikós Ómilos Plataniá Chaníon
  - PAE Chania  (1) Chania FC
- **Heraklion, Crete** (2): 
  - Ergotelis FC  (1) Ergotelis
  - OFI Crete FC  (4) OFI · OFI Crete · OFI Kreta FC [de] · OFI Heraklion
- **Nikaia, Attica** (2): 
  - Proodeftiki FC  (2) Proodeftiki · Proodeytiki
  - Ionikos FC  (2) Ionikos · Ionikos Nikea
- **Piraeus, Attica** (2): 
  - Olympiacos Piraeus FC  (6) Olympiacos · Olympiacos Piraeus · Olympiacos FC · Olympiakos · Olympiakos Piräus · Olympiakos P.
  - Ethnikos Piraeus FC  (2) Ethnikos Piraeus · Ethnikos
- **Trikala, Thessaly** (2): 
  - Trikala FC  (1) Trikala
  - AO Trikala 1963  (2) Trikala 1963 FC · AO Trikala 1963 FC
- **Agrinio, West Greece** (1): Panetolikos GFS  (2) Panetolikos · Panaitolikos
- **Corfu, Ionian Islands** (1): Kerkyra FC  (4) Kerkyra · Kerkyra Kassiopi · AOK Kerkyra · PAE Kerkyra
- **Drama, Macedonia** (1): Doxa Dramas FC  (2) Doxa · Doxa Dramas
- **Edessa, Macedonia** (1): Edessaikos FC  (1) Edessaikos
- **Elefsina, Attica** (1): Panelefsiniakos FC  (1) Eleysina
- **Fyli** (1): Thrasyvoulos FC  (1) Thrasyvoulos
- **Ioannina, Epirus** (1): PAS Giannina FC  (3) Giannina · PAS Giannina · Yiannina
- **Kalamaria, Central Macedonia** (1): Apollon Pontou FC  (1) Kalamaria
- **Kalamata, Peloponnese** (1): Kalamata FC  (3) Kalamata · Kalamata Football Club · PAE PS Kalamata
- **Kallithea** (1): Kallithea FC  (2) Kalithea · Kallithea
- **Kalloni, Aegean Islands** (1): AEL Kalloni FC  (1) Kallonis
- **Kastoria, Macedonia** (1): Kastoria FC  (1) Kastoria
- **Kavala, Macedonia** (1): Kavala FC  (1) Kavala
- **Komotini, Thrace** (1): Panthrakikos FC  (2) Panthrakikos · Panthrakikos Komotini
- **Lamia, Central Greece** (1): PAS Lamia 1964  (3) Lamia · PAS Lamia · Lamia 1964
- **Larissa, Thessaly** (1): AE Larissa FC  (10) Larissa · Larissa FC · AE Larissa · Larisa · AE Larisa · Larisa AEL · AEL · Athlitiki Enosi Larissa · Athlitiki Enosi Larissa FC · AEL Football Club
- **Livadeia, Central Greece** (1): Levadiakos FC  (2) Levadeiakos · Levadiakos
- **Patras, Peloponnese** (1): Panachaiki FC  (5) Panahaiki · Panahaiki FC · Panachaiki Patras · Panachaiki 1891 Football Club · Panachaiki GE
- **Pyrgos, Peloponnese** (1): Paniliakos FC  (1) Paniliakos
- **Serres, Macedonia** (1): Panserraikos FC  (1) Panserraikos
- **Tripoli, Peloponnese** (1): Asteras Tripolis FC  (2) Asteras · Asteras Tripolis
- **Veria, Macedonia** (1): Veria FC  (2) Veria · Veroia
- **Xanthi, Thrace** (1): Xanthi FC  (2) Xanthi · Skoda Xanthi FC




By Region

- **Athens†** (10):   AEK Athens FC · Panathinaikos FC · Apollon Smyrnis FC · Atromitos FC · Panionios GSS · APO Akratitos · Athinaikos AS FC · Chalkidona FC · Egaleo FC · Ethnikos Asteras FC
- **Kallithea†** (1):   Kallithea FC
- **Fyli†** (1):   Thrasyvoulos FC
- **Attica** (5):   Panelefsiniakos FC · Proodeftiki FC · Ionikos FC · Olympiacos Piraeus FC · Ethnikos Piraeus FC
- **Central Macedonia** (4):   PAOK FC · Aris Thessaloniki FC · Iraklis 1908 Thessaloniki FC · Apollon Pontou FC
- **Peloponnese** (4):   Asteras Tripolis FC · Kalamata FC · Panachaiki FC · Paniliakos FC
- **Thrace** (2):   Xanthi FC · Panthrakikos FC
- **West Greece** (1):   Panetolikos GFS
- **Epirus** (1):   PAS Giannina FC
- **Central Greece** (2):   Levadiakos FC · PAS Lamia 1964
- **Thessaly** (6):   AE Larissa FC · Volos FC · Niki Volou FC · Olympiacos Volou 1937 FC · Trikala FC · AO Trikala 1963
- **Ionian Islands** (1):   Kerkyra FC
- **Macedonia** (6):   Doxa Dramas FC · Edessaikos FC · Kastoria FC · Kavala FC · Panserraikos FC · Veria FC
- **Crete** (4):   Platanias FC · PAE Chania · Ergotelis FC · OFI Crete FC
- **Aegean Islands** (1):   AEL Kalloni FC




By Year

- **1891** (1):   Panachaiki FC
- **1964** (1):   AE Larissa FC
- **2017** (1):   Volos FC
- ? (46):   AEK Athens FC · Panathinaikos FC · Apollon Smyrnis FC · Atromitos FC · Panionios GSS · APO Akratitos · Athinaikos AS FC · Chalkidona FC · Egaleo FC · Ethnikos Asteras FC · Kallithea FC · Thrasyvoulos FC · Panelefsiniakos FC · Proodeftiki FC · Ionikos FC · Olympiacos Piraeus FC · Ethnikos Piraeus FC · PAOK FC · Aris Thessaloniki FC · Iraklis 1908 Thessaloniki FC · Apollon Pontou FC · Asteras Tripolis FC · Xanthi FC · Panetolikos GFS · PAS Giannina FC · Levadiakos FC · PAS Lamia 1964 · Kerkyra FC · Doxa Dramas FC · Edessaikos FC · Platanias FC · PAE Chania · Ergotelis FC · OFI Crete FC · Kalamata FC · AEL Kalloni FC · Kastoria FC · Kavala FC · Niki Volou FC · Olympiacos Volou 1937 FC · Paniliakos FC · Panserraikos FC · Panthrakikos FC · Trikala FC · AO Trikala 1963 · Veria FC






By A to Z

- **A** (38): AEK · AEL · Aris · Apollon · Asteras · AE Larisa · Akratitos · Atromitos · AE Larissa · AEK Athens · AO Aigaleo · Athinaikos · AOK Kerkyra · AO Platanias · Atromitos FC · AE Larissa FC · AEK Athens FC · APO Akratitos · Aris Saloniki · AEK Athen [de] · AEL Kalloni FC · AEP Iraklis FC · AO Trikala 1963 · Apollon Smyrnis · Asteras Tripolis · Athinaikos AS FC · AEL Football Club · Apollon Athens FC · Apollon Pontou FC · Aris Thessaloniki · AO Trikala 1963 FC · Apollon Smyrnis FC · Asteras Tripolis FC · Aris Thessaloniki FC · Atromitos Athen [de] · Athlitiki Enosi Larissa · Athlitiki Enosi Larissa FC · Athlitikós Ómilos Plataniá Chaníon
- **C** (3): Chania FC · Chalkidona · Chalkidona FC
- **D** (3): Doxa · Doxa Dramas · Doxa Dramas FC
- **E** (13): Egaleo · Eleysina · Ethnikos · Egaleo FC · Ergotelis · Edessaikos · Eth Asteras · Ergotelis FC · Edessaikos FC · Ethnikos Asteras · Ethnikos Piraeus · Ethnikos Asteras FC · Ethnikos Piraeus FC
- **G** (1): Giannina
- **H** (1): Heracles [en]
- **I** (7): Ionikos · Iraklis · Ionikos FC · Iraklis FC · Ionikos Nikea · Iraklis Thessaloniki · Iraklis 1908 Thessaloniki FC
- **K** (15): Kavala · Kerkyra · Kalamata · Kalithea · Kallonis · Kastoria · Kalamaria · Kallithea · Kavala FC · Kerkyra FC · Kalamata FC · Kastoria FC · Kallithea FC · Kerkyra Kassiopi · Kalamata Football Club
- **L** (9): Lamia · Larisa · Larissa · Lamia 1964 · Larisa AEL · Larissa FC · Levadiakos · Levadeiakos · Levadiakos FC
- **N** (3): Niki Volos · Niki Volou · Niki Volou FC
- **O** (17): OFI · OFI Crete · Olympiacos · Olympiakos · OFI Crete FC · OFI Heraklion · Olympiacos FC · Olympiakos P. · Olympiacos Volou · Olympiakos Volos · Olympiakos Volou · OFI Kreta FC [de] · Olympiakos Piräus · Olympiacos Piraeus · Olympiacos Volou FC · Olympiacos Piraeus FC · Olympiacos Volou 1937 FC
- **P** (41): PAOK · PAOK FC · PAS Lamia · Panahaiki · Panionios · Platanias · PAE Chania · Paniliakos · PAE Kerkyra · Panetolikos · Proodeftiki · Proodeytiki · PAS Giannina · Panahaiki FC · Panaitolikos · Panserraikos · Panthrakikos · Platanias FC · PAOK Saloniki · PAOK Thessal. · Panachaiki FC · Panachaiki GE · Panathinaikos · Paniliakos FC · Panionios GSS · PAS Lamia 1964 · Proodeftiki FC · PAE PS Kalamata · PAS Giannina FC · Panetolikos GFS · Panserraikos FC · Panthrakikos FC · Panathinaikos FC · PAOK Thessaloniki · Panachaiki Patras · Panelefsiniakos FC · PAOK Thessaloniki FC · Panathinaikos Athens · Panionios Athen [de] · Panthrakikos Komotini · Panachaiki 1891 Football Club
- **S** (1): Skoda Xanthi FC
- **T** (5): Trikala · Trikala FC · Thrasyvoulos · Thrasyvoulos FC · Trikala 1963 FC
- **V** (9): Veria · Volos · Veroia · Veria FC · Volos FC · Volos NFC · Volos NPS · Volos Football Club · Volos New Football Club
- **X** (2): Xanthi · Xanthi FC
- **Y** (1): Yiannina




