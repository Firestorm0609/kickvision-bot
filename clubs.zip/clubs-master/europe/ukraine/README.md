26 clubs

- **FC Dynamo Kyiv** : (6) Dynamo Kyiv · Dynamo Kiev · Dinamo Kiev · FC Dynamo Kiev · Dynamo Kiew [de] · FC Dynamo Kiew [de]
- **FC Arsenal Kyiv** : (4) Arsenal Kyiv · Arsenal Kiev · FC Arsenal Kiev · Arsenal Kiew [de]
- **FC Obolon Kyiv** : (1) Obolon'
- **FC Shakhtar Donetsk** : (5) Shakhtar · Shakhtar Don. · Shakhtar Donetsk · Schachtar Donezk · Schachtjor Donezk
- **FC Metalurh Donetsk** : (2) Metalurh Donetsk · Metalurg Donetsk
- **FC Olimpik Donetsk** : (1) Olimpik Donetsk
- **FC Metalist Kharkiv** : (3) Metalist · Metalist Kharkiv · Metalist Kharkov
- **FC Dnipro** : (5) Dnipro · SC Dnipro · Dnepr Dnepropetrovsk · Dnipro Dnipropetrovsk · FC Dnipro Dnipropetrovsk
- **SC Dnipro-1** : (2) Dnipro-1 · Sport Club Dnipro-1
- **FC Vorskla Poltava** : (3) Vorskla · Vorskla Poltava · Vorskla Poltawa [de]
- **FC Karpaty Lviv** : (4) Karpaty · FC Lviv · Karpaty Lviv · Karpaty Lemberg [de]
- **SC Tavriya Simferopol** : (4) Tavriya · Tavriia · Tavriya Simferopol · SK Tavriya Simferopol
- **FC Zorya Luhansk** : (5) Zorya · Zorya Luhansk · Zorya Lugansk [de] · Zorya Voroshilovgrad · FC Zorya Lugansk [de]
- **FC Mariupol** : (3) Mariupol · FK Mariupol · FK Mariupol Illichivets'
- **FC Olexandriya** : (5) Olexandriya · Oleksandriya · FC Oleksandriya · Oleksandria [de] · FC Oleksandria [de]
- **FC Chornomorets Odesa** : (4) Chornomorets Odesa · Chernomorets Odesa · Chernomorets Odessa · Chernom. Odessa [de]
- **Desna** : (3) SFC Desna Tscherni · FC Desna Chernihiv · FK Desna Chernihiv
- **Kolos Kovalivka** : (1) FC Kolos Kovalivka
- **FC Volyn Lutsk** : (2) Volyn · Volyn Lutsk
- **FC Metalurh Zaporizhya** : (5) Metalurh Zaporizhya · Metalurg Zaporizhya · Metalurg Zaporizhia · MFC Metalurh Zaporizhya · Municipal Football Club Metalurh Zaporizhya
- **FC Kryvbas Kryvyi Rih** : (3) Kryvbas · FK Krivbas · Futbolniy Klub Krivbas Kriviy Rig
- **NK Veres Rivne** : (2) Veres Rivne · Narodnyy Klub Veres Rivne
- **FC Zirka Kropyvnytskyi** : (2) Zirka Kropyvnytskyi · FK Zirka Kirovohrad
- **FC Stal Kamianske (1926-2018)** : (3) Stal Kamianske · FK Stal Kamjanske · FC Metalist Kamianske
- **FC Hoverla Uzhhorod (1946-2016)** : (1) Hoverla Uzhhorod
- **FC Sevastopol (2002-2014)** : (1) Sevastopol




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Donetsk** (3): 
  - FC Shakhtar Donetsk  (5) Shakhtar · Shakhtar Donetsk · Shakhtar Don. · Schachtjor Donezk · Schachtar Donezk
  - FC Metalurh Donetsk  (2) Metalurh Donetsk · Metalurg Donetsk
  - FC Olimpik Donetsk  (1) Olimpik Donetsk
- **Dnipropetrovsk** (2): 
  - FC Dnipro  (5) Dnipro · FC Dnipro Dnipropetrovsk · Dnipro Dnipropetrovsk · SC Dnipro · Dnepr Dnepropetrovsk
  - SC Dnipro-1  (2) Dnipro-1 · Sport Club Dnipro-1
- **Kyiv** (2): 
  - FC Dynamo Kyiv  (6) Dynamo Kyiv · Dynamo Kiev · FC Dynamo Kiev · Dinamo Kiev · Dynamo Kiew [de] · FC Dynamo Kiew [de]
  - FC Arsenal Kyiv  (4) Arsenal Kyiv · Arsenal Kiew [de] · Arsenal Kiev · FC Arsenal Kiev
- **Kamianske** (1): FC Stal Kamianske (1926-2018)  (3) Stal Kamianske · FC Metalist Kamianske · FK Stal Kamjanske
- **Kharkiv** (1): FC Metalist Kharkiv  (3) Metalist · Metalist Kharkiv · Metalist Kharkov
- **Kropyvnytskyi** (1): FC Zirka Kropyvnytskyi  (2) Zirka Kropyvnytskyi · FK Zirka Kirovohrad
- **Kryvyi Rih** (1): FC Kryvbas Kryvyi Rih  (3) Kryvbas · FK Krivbas · Futbolniy Klub Krivbas Kriviy Rig
- **Lutsk** (1): FC Volyn Lutsk  (2) Volyn · Volyn Lutsk
- **Rivne** (1): NK Veres Rivne  (2) Veres Rivne · Narodnyy Klub Veres Rivne
- **Sevastopol** (1): FC Sevastopol (2002-2014)  (1) Sevastopol
- **Uzhhorod** (1): FC Hoverla Uzhhorod (1946-2016)  (1) Hoverla Uzhhorod
- **Zaporizhya** (1): FC Metalurh Zaporizhya  (5) Metalurh Zaporizhya · MFC Metalurh Zaporizhya · Municipal Football Club Metalurh Zaporizhya · Metalurg Zaporizhya · Metalurg Zaporizhia
- ? (10): 
  - FC Obolon Kyiv  (1) Obolon'
  - FC Vorskla Poltava  (3) Vorskla · Vorskla Poltava · Vorskla Poltawa [de]
  - FC Karpaty Lviv  (4) Karpaty · FC Lviv · Karpaty Lviv · Karpaty Lemberg [de]
  - SC Tavriya Simferopol  (4) Tavriya · Tavriya Simferopol · SK Tavriya Simferopol · Tavriia
  - FC Zorya Luhansk  (5) Zorya · Zorya Luhansk · Zorya Lugansk [de] · FC Zorya Lugansk [de] · Zorya Voroshilovgrad
  - FC Mariupol  (3) Mariupol · FK Mariupol · FK Mariupol Illichivets'
  - FC Olexandriya  (5) Olexandriya · Oleksandriya · FC Oleksandriya · Oleksandria [de] · FC Oleksandria [de]
  - FC Chornomorets Odesa  (4) Chornomorets Odesa · Chernomorets Odesa · Chernomorets Odessa · Chernom. Odessa [de]
  - Desna  (3) SFC Desna Tscherni · FC Desna Chernihiv · FK Desna Chernihiv
  - Kolos Kovalivka  (1) FC Kolos Kovalivka




By Region

- **Kyiv†** (2):   FC Dynamo Kyiv · FC Arsenal Kyiv
- **Donetsk†** (3):   FC Shakhtar Donetsk · FC Metalurh Donetsk · FC Olimpik Donetsk
- **Kharkiv†** (1):   FC Metalist Kharkiv
- **Dnipropetrovsk†** (2):   FC Dnipro · SC Dnipro-1
- **Lutsk†** (1):   FC Volyn Lutsk
- **Zaporizhya†** (1):   FC Metalurh Zaporizhya
- **Kryvyi Rih†** (1):   FC Kryvbas Kryvyi Rih
- **Rivne†** (1):   NK Veres Rivne
- **Kropyvnytskyi†** (1):   FC Zirka Kropyvnytskyi
- **Kamianske†** (1):   FC Stal Kamianske (1926-2018)
- **Uzhhorod†** (1):   FC Hoverla Uzhhorod (1946-2016)
- **Sevastopol†** (1):   FC Sevastopol (2002-2014)




By Year

- **1911** (1):   FC Zirka Kropyvnytskyi
- **1926** (1):   FC Stal Kamianske (1926-2018)
- **1935** (1):   FC Metalurh Zaporizhya
- **1946** (1):   FC Hoverla Uzhhorod (1946-2016)
- **1957** (1):   NK Veres Rivne
- **1959** (1):   FC Kryvbas Kryvyi Rih
- **2002** (1):   FC Sevastopol (2002-2014)
- **2017** (1):   SC Dnipro-1
- ? (18):   FC Dynamo Kyiv · FC Arsenal Kyiv · FC Obolon Kyiv · FC Shakhtar Donetsk · FC Metalurh Donetsk · FC Olimpik Donetsk · FC Metalist Kharkiv · FC Dnipro · FC Vorskla Poltava · FC Karpaty Lviv · SC Tavriya Simferopol · FC Zorya Luhansk · FC Mariupol · FC Olexandriya · FC Chornomorets Odesa · Desna · Kolos Kovalivka · FC Volyn Lutsk




Historic

- **2014** (1):   FC Sevastopol (2002-2014)
- **2016** (1):   FC Hoverla Uzhhorod (1946-2016)
- **2018** (1):   FC Stal Kamianske (1926-2018)






By A to Z

- **A** (3): Arsenal Kiev · Arsenal Kyiv · Arsenal Kiew [de]
- **C** (4): Chernomorets Odesa · Chornomorets Odesa · Chernomorets Odessa · Chernom. Odessa [de]
- **D** (9): Desna · Dnipro · Dnipro-1 · Dinamo Kiev · Dynamo Kiev · Dynamo Kyiv · Dynamo Kiew [de] · Dnepr Dnepropetrovsk · Dnipro Dnipropetrovsk
- **F** (39): FC Lviv · FC Dnipro · FK Krivbas · FC Mariupol · FK Mariupol · FC Dynamo Kiev · FC Dynamo Kyiv · FC Obolon Kyiv · FC Olexandriya · FC Volyn Lutsk · FC Arsenal Kiev · FC Arsenal Kyiv · FC Karpaty Lviv · FC Oleksandriya · FC Zorya Luhansk · FK Stal Kamjanske · FC Desna Chernihiv · FC Kolos Kovalivka · FC Olimpik Donetsk · FC Vorskla Poltava · FK Desna Chernihiv · FC Dynamo Kiew [de] · FC Metalist Kharkiv · FC Metalurh Donetsk · FC Oleksandria [de] · FC Shakhtar Donetsk · FK Zirka Kirovohrad · FC Chornomorets Odesa · FC Kryvbas Kryvyi Rih · FC Metalist Kamianske · FC Zorya Lugansk [de] · FC Metalurh Zaporizhya · FC Zirka Kropyvnytskyi · FC Dnipro Dnipropetrovsk · FK Mariupol Illichivets' · FC Sevastopol (2002-2014) · FC Stal Kamianske (1926-2018) · FC Hoverla Uzhhorod (1946-2016) · Futbolniy Klub Krivbas Kriviy Rig
- **H** (1): Hoverla Uzhhorod
- **K** (5): Karpaty · Kryvbas · Karpaty Lviv · Kolos Kovalivka · Karpaty Lemberg [de]
- **M** (11): Mariupol · Metalist · Metalist Kharkiv · Metalist Kharkov · Metalurg Donetsk · Metalurh Donetsk · Metalurg Zaporizhia · Metalurg Zaporizhya · Metalurh Zaporizhya · MFC Metalurh Zaporizhya · Municipal Football Club Metalurh Zaporizhya
- **N** (2): NK Veres Rivne · Narodnyy Klub Veres Rivne
- **O** (5): Obolon' · Olexandriya · Oleksandriya · Olimpik Donetsk · Oleksandria [de]
- **S** (13): Shakhtar · SC Dnipro · Sevastopol · SC Dnipro-1 · Shakhtar Don. · Stal Kamianske · Schachtar Donezk · Shakhtar Donetsk · Schachtjor Donezk · SFC Desna Tscherni · Sport Club Dnipro-1 · SC Tavriya Simferopol · SK Tavriya Simferopol
- **T** (3): Tavriia · Tavriya · Tavriya Simferopol
- **V** (6): Volyn · Vorskla · Veres Rivne · Volyn Lutsk · Vorskla Poltava · Vorskla Poltawa [de]
- **Z** (5): Zorya · Zorya Luhansk · Zorya Lugansk [de] · Zirka Kropyvnytskyi · Zorya Voroshilovgrad




