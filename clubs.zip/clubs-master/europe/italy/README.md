97 clubs

- [**AS Roma**](https://en.wikipedia.org/wiki/A.S._Roma) : (3) Roma · AS Rom [de] · Associazione Sportiva Roma
- [**SS Lazio**](https://en.wikipedia.org/wiki/S.S._Lazio) : (4) Lazio · Lazio Roma · Lazio Rom [de] · Società Sportiva Lazio ⇒ (1) ≈Societa Sportiva Lazio≈
- [**AC Milan**](https://en.wikipedia.org/wiki/A.C._Milan) : (3) Milan · AC Mailand [de] · Associazione Calcio Milan
- [**FC Internazionale Milano**](https://en.wikipedia.org/wiki/Inter_Milan) : (4) Inter · Inter Milan · Internazionale · Inter Mailand [de]
- [**Torino FC**](https://en.wikipedia.org/wiki/Torino_F.C.) : (4) Torino · FC Torino · FC Turin [de] · Torino Football Club
- [**Juventus**](https://en.wikipedia.org/wiki/Juventus_F.C.) : (4) Juventus FC · Juventus Torino · Juventus Turin [de] · Juventus Football Club
- **Hellas Verona FC** : (3) Verona · Hellas Verona · Hellas Verona Football Club
- [**AC Chievo Verona**](https://en.wikipedia.org/wiki/A.C._ChievoVerona) : (3) Chievo · Chievo Verona · Associazione Calcio Chievo Verona
- [**Genoa CFC**](https://en.wikipedia.org/wiki/Genoa_C.F.C.) : (4) Genoa · FC Genua [de] · CFC Genua 1893 [de] · Genoa Cricket and Football Club
- [**UC Sampdoria**](https://en.wikipedia.org/wiki/U.C._Sampdoria) : (4) Sampdoria · Sampdoria Genoa · Sampdoria Genua [de] · Unione Calcio Sampdoria
- [**Atalanta BC**](https://en.wikipedia.org/wiki/Atalanta_B.C.) : (3) Atalanta · Atalanta Bergamo · Atalanta Bergamasca Calcio
- **Benevento** : (1) Benevento Calcio
- [**Bologna FC**](https://en.wikipedia.org/wiki/Bologna_F.C._1909) : (4) Bologna · FC Bologna · Bologna FC 1909 · Bologna Football Club 1909
- [**Cagliari Calcio**](https://en.wikipedia.org/wiki/Cagliari_Calcio) : (1) Cagliari
- **FC Crotone** : (3) Crotone · Crotone FC · Federazione Calcistica Crotone
- [**ACF Fiorentina**](https://en.wikipedia.org/wiki/ACF_Fiorentina) : (5) Fiorentina · AC Firenze · AC Fiorentina · AC Florenz [de] · Associazione Calcio Firenze Fiorentina
- [**SSC Napoli**](https://en.wikipedia.org/wiki/S.S.C._Napoli) : (3) Napoli · SSC Neapel [de] · Società Sportiva Calcio Napoli ⇒ (1) ≈Societa Sportiva Calcio Napoli≈
- [**US Sassuolo Calcio**](https://en.wikipedia.org/wiki/U.S._Sassuolo_Calcio) : (4) Sassuolo · US Sassuolo · Sassuolo Calcio · Unione Sportiva Sassuolo Calcio
- [**SPAL**](https://en.wikipedia.org/wiki/S.P.A.L.) : (3) SPAL 2013 · SPAL Ferrara · SPAL 2013 Ferrara
- [**Udinese Calcio**](https://en.wikipedia.org/wiki/Udinese_Calcio) : (1) Udinese
- **Ascoli** : (1) Ascoli FC
- **Avellino** : (4) AS Avellino · US Avellino 1912 · Unione Sportiva Avellino 1912 · Associazione Sportiva Avellino 1912
- **Bari** : (4) AS Bari · SSC Bari · FC Bari 1908 · Società Sportiva Calcio Bari ⇒ (1) ≈Societa Sportiva Calcio Bari≈
- **Brescia** : (1) Brescia Calcio
- **Carpi** : (3) Carpi FC · Carpi FC 1909 · Carpi Football Club 1909
- **AC Cesena (1940-2018)** : (3) Cesena · Cesena FC · Associazione Calcio Cesena
- **Cittadella** : (1) AS Cittadella
- **Cremonese** : (1) US Cremonese
- [**Empoli**](https://en.wikipedia.org/wiki/Empoli_F.C.) : (3) Empoli FC · FC Empoli · Empoli Football Club
- **Foggia**
- [**Frosinone**](https://en.wikipedia.org/wiki/Frosinone_Calcio) : (1) Frosinone Calcio
- **Novara** : (1) Novara Calcio
- **Palermo** : (3) US Palermo · US Città di Palermo · Unione Sportiva Città di Palermo ⇒ (2) ≈US Citta di Palermo≈ · ≈Unione Sportiva Citta di Palermo≈
- [**Parma**](https://en.wikipedia.org/wiki/Parma_Calcio_1913) : (6) Parma FC · FC Parma · AC Parma · Parma Calcio · Parma Calcio 1913 · Parma Football Club
- **AC Perugia** : (4) Perugia · Perugia Calcio · AC Perugia Calcio · Associazione Calcistica Perugia Calcio
- **Pescara** : (1) Pescara Calcio
- **Pro Vercelli**
- **Salernitana** : (1) Salernitana Calcio
- **Spezia** : (1) Spezia Calcio
- **Ternana** : (1) Ternana Calcio
- **Venezia** : (1) SSC Venezia
- **Virtus Entella**
- **Piacenza Calcio** : (2) Piacenza · Piacenza Calcio 1919
- **LR Vicenza Virtus** : (3) Vicenza · Vicenza Calcio · Vicenza Virtus
- **Calcio Padova** : (2) Padova · Padua Calcio [de]
- **Modena FC** : (2) Modena · FC Modena
- **SS Robur Siena** : (3) Siena · AC Siena · Associazione Calcio Siena
- **US Anconitana ASD** : (1) Ancona
- **Cosenza Calcio** : (1) Cosenza
- **SS Fidelis Andria** : (2) F. Andria · SS Fidelis Andria 1928
- **US Lecce** : (1) Lecce
- **AS Lucchese Libertas** : (2) Lucchese · AS Lucchese Libertas 1905
- **SS Monza** : (2) Monza · SS Monza 1912
- **Ravenna FC** : (3) Ravenna · Ravenna Calcio · Ravenna FC 1913
- **AC Reggiana** : (5) Reggiana · Reggio Audace · AC Reggiana 1919 · Reggio Audace FC · Reggio Audace Football Club
- **Urbs Reggina** : (2) Reggina · Urbs Reggina 1914
- **ACD Treviso** : (1) Treviso
- **ASD Castel di Sangro** : (1) C. Sangro
- **Unione Calcio Albinoleffe** : (2) Albinoleffe · UC Albinoleffe
- **Calcio Catania** : (2) Catania · Catania Calcio
- **Como 1907** : (2) Como · Como Calcio
- **AS Livorno Calcio** : (3) Livorno · AS Livorno · Associazione Sportiva Livorno Calcio
- **ACR Messina SSD** : (1) Messina
- **US Triestina Calcio** : (3) Triestina · Triestina Calcio · US Triestina Calcio 1918
- **SS Arezzo** : (4) Arezzo · AC Arezzo · Società Sportiva Arezzo · Associazione Calcio Arezzo ⇒ (1) ≈Societa Sportiva Arezzo≈
- **US Catanzaro** : (2) Catanzaro · US Catanzaro 1929
- **ASD Virtus Bergamo** : (4) Alzano · Virtus Bergamo · Alzano Virescit · ASD Virtus Bergamo 1909
- **MC Fermana FC** : (4) Fermana · Fermana FC · US Fermana · Fermana Football Club
- **Gallipoli Football SSD** : (2) Gallipoli · Gallipoli Football 1909 SSD
- **ASD US Grosseto** : (2) Grosseto · ASD US Grosseto 1912
- **AS Gubbio** : (2) Gubbio · AS Gubbio 1910
- **SS Juve Stabia** : (1) Juve Stabia
- **SSD Latina Calcio** : (2) Latina · SSD Latina Calcio 1932
- **Mantova SSD** : (2) Mantova · Mantova 1911 SSD
- **ASD Nocerina** : (2) Nocerina · ASD Nocerina 1910
- **AC Pisa** : (3) Pisa · AC Pisa 1909 · SC Pisa [de]
- **US Pistoiese** : (3) Pistoiese · AC Pistoiese · US Pistoiese 1921
- **Portogruaro Calcio ASD** : (1) Portogruaro
- **Rimini FC SSD** : (4) Rimini · Rimini Calcio · Rimini FC 1912 · Rimini FC 1912 SSD
- **ASD Savoia** : (2) Savoia · ASD Savoia 1908
- **Trapani Calcio** : (1) Trapani
- **Varese Calcio** : (1) Varese
- **Virtus Lanciano** : (1) ASD 1920 Lanciano Calcio
- **Pordenone Calcio** : (1) Pordenone
- **Vis Pesaro 1898**
- **Giana Erminio** : (1) AS Giana Erminio
- **Carrarese Calcio** : (2) Carrarese · Carrarese Calcio 1908
- **Pontedera** : (1) US Città di Pontedera ⇒ (1) ≈US Citta di Pontedera≈
- **Pro Patria** : (1) Aurora Pro Patria 1919
- **AC Renate** : (1) Associazione Calcio Renate
- **Calcio Lecco** : (1) Calcio Lecco 1912
- **FC Südtirol** : (2) Südtirol · Alto Adige ⇒ (4) ≈Sudtirol≈ · ≈Suedtirol≈ · ≈FC Sudtirol≈ · ≈FC Suedtirol≈
- **Feralpisalò** : (1) AC Feralpisalò ⇒ (2) ≈Feralpisalo≈ · ≈AC Feralpisalo≈
- **Sambenedettese** : (1) SS Sambenedettese Calcio
- **Potenza Calcio** : (3) Potenza · Potenza SC · Potenza FC
- **Paganese Calcio** : (2) Paganese · Paganese Calcio 1926
- **Vibonese Calcio** : (3) Vibonese · US Vibonese Calcio · Unione Sportiva Vibonese Calcio




Alphabet

- **Alphabet Specials** (3):  **à**  **ò**  **ü** 
  - **à**×7 U+00E0 (224) - LATIN SMALL LETTER A WITH GRAVE ⇒ a
  - **ò**×2 U+00F2 (242) - LATIN SMALL LETTER O WITH GRAVE ⇒ o
  - **ü**×2 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates





By City

- **Genova** (2): 
  - Genoa CFC  (4) Genoa · Genoa Cricket and Football Club · FC Genua [de] · CFC Genua 1893 [de]
  - UC Sampdoria  (4) Sampdoria · Sampdoria Genoa · Unione Calcio Sampdoria · Sampdoria Genua [de]
- **Milano** (2): 
  - AC Milan  (3) Milan · Associazione Calcio Milan · AC Mailand [de]
  - FC Internazionale Milano  (4) Inter · Internazionale · Inter Milan · Inter Mailand [de]
- **Roma** (2): 
  - AS Roma  (3) Roma · Associazione Sportiva Roma · AS Rom [de]
  - SS Lazio  (4) Lazio · Lazio Roma · Società Sportiva Lazio · Lazio Rom [de]
- **Torino** (2): 
  - Torino FC  (4) Torino · Torino Football Club · FC Torino · FC Turin [de]
  - Juventus  (4) Juventus Torino · Juventus FC · Juventus Football Club · Juventus Turin [de]
- **Verona** (2): 
  - Hellas Verona FC  (3) Verona · Hellas Verona · Hellas Verona Football Club
  - AC Chievo Verona  (3) Chievo · Chievo Verona · Associazione Calcio Chievo Verona
- **Albino e Leffe** (1): Unione Calcio Albinoleffe  (2) Albinoleffe · UC Albinoleffe
- **Alzano Lombardo** (1): ASD Virtus Bergamo  (4) Alzano · ASD Virtus Bergamo 1909 · Virtus Bergamo · Alzano Virescit
- **Ancona** (1): US Anconitana ASD  (1) Ancona
- **Andria** (1): SS Fidelis Andria  (2) F. Andria · SS Fidelis Andria 1928
- **Arezzo** (1): SS Arezzo  (4) Arezzo · Società Sportiva Arezzo · AC Arezzo · Associazione Calcio Arezzo
- **Ascoli Piceno** (1): Ascoli  (1) Ascoli FC
- **Avellino** (1): Avellino  (4) US Avellino 1912 · Unione Sportiva Avellino 1912 · AS Avellino · Associazione Sportiva Avellino 1912
- **Bari** (1): Bari  (4) AS Bari · SSC Bari · Società Sportiva Calcio Bari · FC Bari 1908
- **Benevento** (1): Benevento  (1) Benevento Calcio
- **Bergamo** (1): Atalanta BC  (3) Atalanta · Atalanta Bergamo · Atalanta Bergamasca Calcio
- **Bologna** (1): Bologna FC  (4) Bologna · FC Bologna · Bologna FC 1909 · Bologna Football Club 1909
- **Bolzano** (1): FC Südtirol  (2) Südtirol · Alto Adige
- **Brescia** (1): Brescia  (1) Brescia Calcio
- **Busto Arsizio** (1): Pro Patria  (1) Aurora Pro Patria 1919
- **Cagliari** (1): Cagliari Calcio  (1) Cagliari
- **Carpi** (1): Carpi  (3) Carpi FC · Carpi FC 1909 · Carpi Football Club 1909
- **Carrara** (1): Carrarese Calcio  (2) Carrarese · Carrarese Calcio 1908
- **Castel di Sangro** (1): ASD Castel di Sangro  (1) C. Sangro
- **Castellammare di Stabia** (1): SS Juve Stabia  (1) Juve Stabia
- **Catania** (1): Calcio Catania  (2) Catania · Catania Calcio
- **Catanzaro** (1): US Catanzaro  (2) Catanzaro · US Catanzaro 1929
- **Cesena** (1): AC Cesena (1940-2018)  (3) Cesena · Associazione Calcio Cesena · Cesena FC
- **Chiavari** (1): Virtus Entella 
- **Cittadella** (1): Cittadella  (1) AS Cittadella
- **Como** (1): Como 1907  (2) Como · Como Calcio
- **Cosenza** (1): Cosenza Calcio  (1) Cosenza
- **Cremona** (1): Cremonese  (1) US Cremonese
- **Crotone** (1): FC Crotone  (3) Crotone · Crotone FC · Federazione Calcistica Crotone
- **Empoli** (1): Empoli  (3) Empoli FC · Empoli Football Club · FC Empoli
- **Fermo** (1): MC Fermana FC  (4) Fermana · Fermana FC · Fermana Football Club · US Fermana
- **Ferrara** (1): SPAL  (3) SPAL 2013 · SPAL Ferrara · SPAL 2013 Ferrara
- **Firenze** (1): ACF Fiorentina  (5) Fiorentina · AC Firenze · Associazione Calcio Firenze Fiorentina · AC Fiorentina · AC Florenz [de]
- **Foggia** (1): Foggia 
- **Frosinone** (1): Frosinone  (1) Frosinone Calcio
- **Gallipoli** (1): Gallipoli Football SSD  (2) Gallipoli · Gallipoli Football 1909 SSD
- **Gorgonzola** (1): Giana Erminio  (1) AS Giana Erminio
- **Grosseto** (1): ASD US Grosseto  (2) Grosseto · ASD US Grosseto 1912
- **Gubbio** (1): AS Gubbio  (2) Gubbio · AS Gubbio 1910
- **La Spezia** (1): Spezia  (1) Spezia Calcio
- **Lanciano** (1): Virtus Lanciano  (1) ASD 1920 Lanciano Calcio
- **Latina** (1): SSD Latina Calcio  (2) Latina · SSD Latina Calcio 1932
- **Lecce** (1): US Lecce  (1) Lecce
- **Lecco** (1): Calcio Lecco  (1) Calcio Lecco 1912
- **Livorno** (1): AS Livorno Calcio  (3) Livorno · AS Livorno · Associazione Sportiva Livorno Calcio
- **Lucca** (1): AS Lucchese Libertas  (2) Lucchese · AS Lucchese Libertas 1905
- **Mantova** (1): Mantova SSD  (2) Mantova · Mantova 1911 SSD
- **Messina** (1): ACR Messina SSD  (1) Messina
- **Modena** (1): Modena FC  (2) Modena · FC Modena
- **Monza** (1): SS Monza  (2) Monza · SS Monza 1912
- **Napoli** (1): SSC Napoli  (3) Napoli · Società Sportiva Calcio Napoli · SSC Neapel [de]
- **Nocera Inferiore** (1): ASD Nocerina  (2) Nocerina · ASD Nocerina 1910
- **Novara** (1): Novara  (1) Novara Calcio
- **Padova** (1): Calcio Padova  (2) Padova · Padua Calcio [de]
- **Pagani** (1): Paganese Calcio  (2) Paganese · Paganese Calcio 1926
- **Palermo** (1): Palermo  (3) US Palermo · US Città di Palermo · Unione Sportiva Città di Palermo
- **Parma** (1): Parma  (6) Parma FC · FC Parma · Parma Football Club · Parma Calcio · Parma Calcio 1913 · AC Parma
- **Perugia** (1): AC Perugia  (4) Perugia · Perugia Calcio · AC Perugia Calcio · Associazione Calcistica Perugia Calcio
- **Pesaro** (1): Vis Pesaro 1898 
- **Pescara** (1): Pescara  (1) Pescara Calcio
- **Piacenza** (1): Piacenza Calcio  (2) Piacenza · Piacenza Calcio 1919
- **Pisa** (1): AC Pisa  (3) Pisa · AC Pisa 1909 · SC Pisa [de]
- **Pistoia** (1): US Pistoiese  (3) Pistoiese · US Pistoiese 1921 · AC Pistoiese
- **Pontedera** (1): Pontedera  (1) US Città di Pontedera
- **Pordenone** (1): Pordenone Calcio  (1) Pordenone
- **Portogruaro** (1): Portogruaro Calcio ASD  (1) Portogruaro
- **Potenza** (1): Potenza Calcio  (3) Potenza · Potenza SC · Potenza FC
- **Ravenna** (1): Ravenna FC  (3) Ravenna · Ravenna FC 1913 · Ravenna Calcio
- **Reggio Calabria** (1): Urbs Reggina  (2) Reggina · Urbs Reggina 1914
- **Reggio Emilia** (1): AC Reggiana  (5) Reggiana · AC Reggiana 1919 · Reggio Audace · Reggio Audace FC · Reggio Audace Football Club
- **Renate** (1): AC Renate  (1) Associazione Calcio Renate
- **Rimini** (1): Rimini FC SSD  (4) Rimini · Rimini FC 1912 · Rimini FC 1912 SSD · Rimini Calcio
- **Salerno** (1): Salernitana  (1) Salernitana Calcio
- **Salò** (1): Feralpisalò  (1) AC Feralpisalò
- **San Benedetto del Tronto** (1): Sambenedettese  (1) SS Sambenedettese Calcio
- **Sassuolo** (1): US Sassuolo Calcio  (4) Sassuolo · US Sassuolo · Sassuolo Calcio · Unione Sportiva Sassuolo Calcio
- **Siena** (1): SS Robur Siena  (3) Siena · AC Siena · Associazione Calcio Siena
- **Terni** (1): Ternana  (1) Ternana Calcio
- **Torre Annunziata** (1): ASD Savoia  (2) Savoia · ASD Savoia 1908
- **Trapani** (1): Trapani Calcio  (1) Trapani
- **Treviso** (1): ACD Treviso  (1) Treviso
- **Trieste** (1): US Triestina Calcio  (3) Triestina · Triestina Calcio · US Triestina Calcio 1918
- **Udine** (1): Udinese Calcio  (1) Udinese
- **Varese** (1): Varese Calcio  (1) Varese
- **Venezia** (1): Venezia  (1) SSC Venezia
- **Vercelli** (1): Pro Vercelli 
- **Vibo Valentia** (1): Vibonese Calcio  (3) Vibonese · US Vibonese Calcio · Unione Sportiva Vibonese Calcio
- **Vicenza** (1): LR Vicenza Virtus  (3) Vicenza · Vicenza Calcio · Vicenza Virtus




By Region

- **Roma†** (2):   AS Roma · SS Lazio
- **Milano†** (2):   AC Milan · FC Internazionale Milano
- **Torino†** (2):   Torino FC · Juventus
- **Verona†** (2):   Hellas Verona FC · AC Chievo Verona
- **Genova†** (2):   Genoa CFC · UC Sampdoria
- **Bergamo†** (1):   Atalanta BC
- **Benevento†** (1):   Benevento
- **Bologna†** (1):   Bologna FC
- **Cagliari†** (1):   Cagliari Calcio
- **Crotone†** (1):   FC Crotone
- **Firenze†** (1):   ACF Fiorentina
- **Napoli†** (1):   SSC Napoli
- **Sassuolo†** (1):   US Sassuolo Calcio
- **Ferrara†** (1):   SPAL
- **Udine†** (1):   Udinese Calcio
- **Ascoli Piceno†** (1):   Ascoli
- **Avellino†** (1):   Avellino
- **Bari†** (1):   Bari
- **Brescia†** (1):   Brescia
- **Carpi†** (1):   Carpi
- **Cesena†** (1):   AC Cesena (1940-2018)
- **Cittadella†** (1):   Cittadella
- **Cremona†** (1):   Cremonese
- **Empoli†** (1):   Empoli
- **Foggia†** (1):   Foggia
- **Frosinone†** (1):   Frosinone
- **Novara†** (1):   Novara
- **Palermo†** (1):   Palermo
- **Parma†** (1):   Parma
- **Perugia†** (1):   AC Perugia
- **Pescara†** (1):   Pescara
- **Vercelli†** (1):   Pro Vercelli
- **Salerno†** (1):   Salernitana
- **La Spezia†** (1):   Spezia
- **Terni†** (1):   Ternana
- **Venezia†** (1):   Venezia
- **Chiavari†** (1):   Virtus Entella
- **Piacenza†** (1):   Piacenza Calcio
- **Vicenza†** (1):   LR Vicenza Virtus
- **Padova†** (1):   Calcio Padova
- **Modena†** (1):   Modena FC
- **Siena†** (1):   SS Robur Siena
- **Ancona†** (1):   US Anconitana ASD
- **Cosenza†** (1):   Cosenza Calcio
- **Andria†** (1):   SS Fidelis Andria
- **Lecce†** (1):   US Lecce
- **Lucca†** (1):   AS Lucchese Libertas
- **Monza†** (1):   SS Monza
- **Ravenna†** (1):   Ravenna FC
- **Reggio Emilia†** (1):   AC Reggiana
- **Reggio Calabria†** (1):   Urbs Reggina
- **Treviso†** (1):   ACD Treviso
- **Castel di Sangro†** (1):   ASD Castel di Sangro
- **Albino e Leffe†** (1):   Unione Calcio Albinoleffe
- **Catania†** (1):   Calcio Catania
- **Como†** (1):   Como 1907
- **Livorno†** (1):   AS Livorno Calcio
- **Messina†** (1):   ACR Messina SSD
- **Trieste†** (1):   US Triestina Calcio
- **Arezzo†** (1):   SS Arezzo
- **Catanzaro†** (1):   US Catanzaro
- **Alzano Lombardo†** (1):   ASD Virtus Bergamo
- **Fermo†** (1):   MC Fermana FC
- **Gallipoli†** (1):   Gallipoli Football SSD
- **Grosseto†** (1):   ASD US Grosseto
- **Gubbio†** (1):   AS Gubbio
- **Castellammare di Stabia†** (1):   SS Juve Stabia
- **Latina†** (1):   SSD Latina Calcio
- **Mantova†** (1):   Mantova SSD
- **Nocera Inferiore†** (1):   ASD Nocerina
- **Pisa†** (1):   AC Pisa
- **Pistoia†** (1):   US Pistoiese
- **Portogruaro†** (1):   Portogruaro Calcio ASD
- **Rimini†** (1):   Rimini FC SSD
- **Torre Annunziata†** (1):   ASD Savoia
- **Trapani†** (1):   Trapani Calcio
- **Varese†** (1):   Varese Calcio
- **Lanciano†** (1):   Virtus Lanciano
- **Pordenone†** (1):   Pordenone Calcio
- **Pesaro†** (1):   Vis Pesaro 1898
- **Gorgonzola†** (1):   Giana Erminio
- **Carrara†** (1):   Carrarese Calcio
- **Pontedera†** (1):   Pontedera
- **Busto Arsizio†** (1):   Pro Patria
- **Renate†** (1):   AC Renate
- **Lecco†** (1):   Calcio Lecco
- **Bolzano†** (1):   FC Südtirol
- **Salò†** (1):   Feralpisalò
- **San Benedetto del Tronto†** (1):   Sambenedettese
- **Potenza†** (1):   Potenza Calcio
- **Pagani†** (1):   Paganese Calcio
- **Vibo Valentia†** (1):   Vibonese Calcio




By Year

- **1903** (1):   Hellas Verona FC
- **1905** (1):   AC Perugia
- **1915** (1):   AS Livorno Calcio
- **1920** (1):   Pordenone Calcio
- **1922** (1):   US Sassuolo Calcio
- **1929** (1):   Benevento
- **1940** (1):   AC Cesena (1940-2018)
- ? (90):   AS Roma · SS Lazio · AC Milan · FC Internazionale Milano · Torino FC · Juventus · AC Chievo Verona · Genoa CFC · UC Sampdoria · Atalanta BC · Bologna FC · Cagliari Calcio · FC Crotone · ACF Fiorentina · SSC Napoli · SPAL · Udinese Calcio · Ascoli · Avellino · Bari · Brescia · Carpi · Cittadella · Cremonese · Empoli · Foggia · Frosinone · Novara · Palermo · Parma · Pescara · Pro Vercelli · Salernitana · Spezia · Ternana · Venezia · Virtus Entella · Piacenza Calcio · LR Vicenza Virtus · Calcio Padova · Modena FC · SS Robur Siena · US Anconitana ASD · Cosenza Calcio · SS Fidelis Andria · US Lecce · AS Lucchese Libertas · SS Monza · Ravenna FC · AC Reggiana · Urbs Reggina · ACD Treviso · ASD Castel di Sangro · Unione Calcio Albinoleffe · Calcio Catania · Como 1907 · ACR Messina SSD · US Triestina Calcio · SS Arezzo · US Catanzaro · ASD Virtus Bergamo · MC Fermana FC · Gallipoli Football SSD · ASD US Grosseto · AS Gubbio · SS Juve Stabia · SSD Latina Calcio · Mantova SSD · ASD Nocerina · AC Pisa · US Pistoiese · Portogruaro Calcio ASD · Rimini FC SSD · ASD Savoia · Trapani Calcio · Varese Calcio · Virtus Lanciano · Vis Pesaro 1898 · Giana Erminio · Carrarese Calcio · Pontedera · Pro Patria · AC Renate · Calcio Lecco · FC Südtirol · Feralpisalò · Sambenedettese · Potenza Calcio · Paganese Calcio · Vibonese Calcio




Historic

- **2018** (1):   AC Cesena (1940-2018)






By A to Z

- **A** (69): Alzano · Ancona · Arezzo · Ascoli · AC Pisa · AS Bari · AS Roma · AC Milan · AC Parma · AC Siena · Atalanta · Avellino · AC Arezzo · AC Renate · AS Gubbio · Ascoli FC · AC Firenze · AC Perugia · AS Livorno · ASD Savoia · Alto Adige · AC Reggiana · ACD Treviso · AS Avellino · AS Rom [de] · Albinoleffe · Atalanta BC · AC Pisa 1909 · AC Pistoiese · ASD Nocerina · AC Fiorentina · AS Cittadella · AC Feralpisalò · ACF Fiorentina · AS Gubbio 1910 · AC Florenz [de] · AC Mailand [de] · ACR Messina SSD · ASD Savoia 1908 · ASD US Grosseto · Alzano Virescit · AC Chievo Verona · AC Reggiana 1919 · AS Giana Erminio · Atalanta Bergamo · AC Perugia Calcio · AS Livorno Calcio · ASD Nocerina 1910 · ASD Virtus Bergamo · AS Lucchese Libertas · ASD Castel di Sangro · ASD US Grosseto 1912 · AC Cesena (1940-2018) · Aurora Pro Patria 1919 · ASD Virtus Bergamo 1909 · ASD 1920 Lanciano Calcio · AS Lucchese Libertas 1905 · Associazione Calcio Milan · Associazione Calcio Siena · Associazione Calcio Arezzo · Associazione Calcio Cesena · Associazione Calcio Renate · Associazione Sportiva Roma · Atalanta Bergamasca Calcio · Associazione Calcio Chievo Verona · Associazione Sportiva Avellino 1912 · Associazione Sportiva Livorno Calcio · Associazione Calcio Firenze Fiorentina · Associazione Calcistica Perugia Calcio
- **B** (9): Bari · Bologna · Brescia · Benevento · Bologna FC · Brescia Calcio · Bologna FC 1909 · Benevento Calcio · Bologna Football Club 1909
- **C** (31): Como · Carpi · Cesena · Chievo · Catania · Cosenza · Crotone · Cagliari · Carpi FC · C. Sangro · Carrarese · Catanzaro · Cesena FC · Como 1907 · Cremonese · Cittadella · Crotone FC · Como Calcio · Calcio Lecco · Calcio Padova · Carpi FC 1909 · Chievo Verona · Calcio Catania · Catania Calcio · Cosenza Calcio · Cagliari Calcio · Carrarese Calcio · Calcio Lecco 1912 · CFC Genua 1893 [de] · Carrarese Calcio 1908 · Carpi Football Club 1909
- **E** (3): Empoli · Empoli FC · Empoli Football Club
- **F** (21): Foggia · Fermana · FC Parma · F. Andria · FC Empoli · FC Modena · FC Torino · Frosinone · FC Bologna · FC Crotone · Fermana FC · Fiorentina · FC Südtirol · Feralpisalò · FC Bari 1908 · FC Genua [de] · FC Turin [de] · Frosinone Calcio · Fermana Football Club · FC Internazionale Milano · Federazione Calcistica Crotone
- **G** (9): Genoa · Gubbio · Grosseto · Gallipoli · Genoa CFC · Giana Erminio · Gallipoli Football SSD · Gallipoli Football 1909 SSD · Genoa Cricket and Football Club
- **H** (3): Hellas Verona · Hellas Verona FC · Hellas Verona Football Club
- **I** (4): Inter · Inter Milan · Internazionale · Inter Mailand [de]
- **J** (6): Juventus · Juve Stabia · Juventus FC · Juventus Torino · Juventus Turin [de] · Juventus Football Club
- **L** (8): Lazio · Lecce · Latina · Livorno · Lucchese · Lazio Roma · Lazio Rom [de] · LR Vicenza Virtus
- **M** (9): Milan · Monza · Modena · Mantova · Messina · Modena FC · Mantova SSD · MC Fermana FC · Mantova 1911 SSD
- **N** (4): Napoli · Novara · Nocerina · Novara Calcio
- **P** (31): Pisa · Parma · Padova · Palermo · Perugia · Pescara · Potenza · Paganese · Parma FC · Piacenza · Pistoiese · Pontedera · Pordenone · Potenza FC · Potenza SC · Pro Patria · Portogruaro · Parma Calcio · Pro Vercelli · Perugia Calcio · Pescara Calcio · Potenza Calcio · Paganese Calcio · Piacenza Calcio · Pordenone Calcio · Padua Calcio [de] · Parma Calcio 1913 · Parma Football Club · Paganese Calcio 1926 · Piacenza Calcio 1919 · Portogruaro Calcio ASD
- **R** (15): Roma · Rimini · Ravenna · Reggina · Reggiana · Ravenna FC · Reggio Audace · Rimini Calcio · Rimini FC SSD · Ravenna Calcio · Rimini FC 1912 · Ravenna FC 1913 · Reggio Audace FC · Rimini FC 1912 SSD · Reggio Audace Football Club
- **S** (37): SPAL · Siena · Savoia · Spezia · SS Lazio · SS Monza · SSC Bari · Sassuolo · Südtirol · SPAL 2013 · SS Arezzo · Sampdoria · SSC Napoli · SSC Venezia · Salernitana · SC Pisa [de] · SPAL Ferrara · SS Monza 1912 · Spezia Calcio · SS Juve Stabia · SS Robur Siena · Sambenedettese · SSC Neapel [de] · Sampdoria Genoa · Sassuolo Calcio · SPAL 2013 Ferrara · SS Fidelis Andria · SSD Latina Calcio · Salernitana Calcio · Sampdoria Genua [de] · SS Fidelis Andria 1928 · SSD Latina Calcio 1932 · Società Sportiva Lazio · Società Sportiva Arezzo · SS Sambenedettese Calcio · Società Sportiva Calcio Bari · Società Sportiva Calcio Napoli
- **T** (10): Torino · Ternana · Trapani · Treviso · Torino FC · Triestina · Ternana Calcio · Trapani Calcio · Triestina Calcio · Torino Football Club
- **U** (29): Udinese · US Lecce · US Fermana · US Palermo · US Sassuolo · UC Sampdoria · US Catanzaro · US Cremonese · US Pistoiese · Urbs Reggina · UC Albinoleffe · Udinese Calcio · US Avellino 1912 · US Anconitana ASD · US Catanzaro 1929 · US Pistoiese 1921 · Urbs Reggina 1914 · US Sassuolo Calcio · US Vibonese Calcio · US Città di Palermo · US Triestina Calcio · US Città di Pontedera · Unione Calcio Sampdoria · US Triestina Calcio 1918 · Unione Calcio Albinoleffe · Unione Sportiva Avellino 1912 · Unione Sportiva Sassuolo Calcio · Unione Sportiva Vibonese Calcio · Unione Sportiva Città di Palermo
- **V** (13): Varese · Verona · Venezia · Vicenza · Vibonese · Varese Calcio · Vicenza Calcio · Vicenza Virtus · Virtus Bergamo · Virtus Entella · Vibonese Calcio · Virtus Lanciano · Vis Pesaro 1898




