44 clubs

- [**Ajax Amsterdam**](https://en.wikipedia.org/wiki/AFC_Ajax) : (4) Ajax · AFC Ajax · Ajax Amsterd. · Amsterdamsche Football Club Ajax
- **Jong Ajax**
- **DWS Amsterdam** : (2) AFC DWS · Amsterdamsche Football Club Door Wilskracht Sterk
- **FC Amsterdam**
- [**AZ Alkmaar**](https://en.wikipedia.org/wiki/AZ_Alkmaar) : (2) AZ · Alkmaar Zaanstreek
- **AZ Alkmaar II** : (1) Jong AZ
- **SC Telstar** : (2) Telstar · SC Stormvogels Telstar
- **HFC Haarlem (1889-2010)** : (3) FC Haarlem · Haarlem FC · Haarlemsche Football Club Haarlem
- [**Feyenoord Rotterdam**](https://en.wikipedia.org/wiki/Feyenoord) : (1) Feyenoord
- **Sparta Rotterdam** : (2) Sparta · Sparta R'dam
- [**SBV Excelsior Rotterdam**](https://en.wikipedia.org/wiki/SBV_Excelsior) : (4) Excelsior · SBV Excelsior · Excel. Rotterdam · Stichting Betaald Voetbal Excelsior
- [**ADO Den Haag**](https://en.wikipedia.org/wiki/ADO_Den_Haag) : (3) Den Haag · FC Den Haag · Alles Door Oefening Den Haag
- **FC Dordrecht** : (2) Dordrecht · Dordrecht '90
- [**SC Cambuur**](https://en.wikipedia.org/wiki/SC_Cambuur) : (1) Cambuur
- [**SC Heerenveen**](https://en.wikipedia.org/wiki/SC_Heerenveen) : (2) Heerenveen · Sportclub Heerenveen
- **FC Den Bosch** : (1) Den Bosch
- [**NAC Breda**](https://en.wikipedia.org/wiki/NAC_Breda) : (2) NAC · NOAD ADVENDO Combinatie Breda
- [**PSV Eindhoven**](https://en.wikipedia.org/wiki/PSV_Eindhoven) : (2) PSV · Philips Sport Vereniging
- **Jong PSV** : (1) Jong PSV Eindh.
- **FC Eindhoven**
- [**RKC Waalwijk**](https://en.wikipedia.org/wiki/RKC_Waalwijk) : (3) RKC · Waalwijk · Rooms Katholieke Combinatie Waalwijk
- [**Willem II Tilburg**](https://en.wikipedia.org/wiki/Willem_II_(football_club)) : (1) Willem II
- **FC Oss** : (2) TOP Oss · Tot Ons Plezier Oss
- **Helmond Sport**
- [**Fortuna Sittard**](https://en.wikipedia.org/wiki/Fortuna_Sittard) : (2) For Sittard · SC Fortuna Sittard
- [**Roda JC Kerkrade**](https://en.wikipedia.org/wiki/Roda_JC_Kerkrade) : (4) Roda · Roda JC · Roda Kerkrade · Sportvereniging Roda Juliana Combinatie Kerkrade
- [**VVV Venlo**](https://en.wikipedia.org/wiki/VVV-Venlo) : (4) VVV · Venlo · VVV-Venlo · Venlose Voetbal Vereniging Venlo
- **MVV Maastricht**
- **Rapid JC Heerlen (1954-1962)** : (2) Rapid JC · Rapid Juliana Combinatie
- **Go Ahead Eagles**
- [**Heracles Almelo**](https://en.wikipedia.org/wiki/Heracles_Almelo) : (2) Heracles · SC Heracles Almelo
- [**FC Twente**](https://en.wikipedia.org/wiki/FC_Twente) : (4) Twente · Twente Enschede · FC Twente Enschede · Football Club Twente
- [**PEC Zwolle**](https://en.wikipedia.org/wiki/PEC_Zwolle) : (3) Zwolle · FC Zwolle · Prins Hendrik Ende Desespereert Nimmer Combinatie Zwolle
- **Almere City FC** : (1) Almere City
- [**BV De Graafschap**](https://en.wikipedia.org/wiki/De_Graafschap) : (3) Graafschap · De Graafschap · Vereniging Betaald Voetbal De Graafschap
- [**FC Groningen**](https://en.wikipedia.org/wiki/FC_Groningen) : (2) Groningen · Football Club Groningen
- [**NEC Nijmegen**](https://en.wikipedia.org/wiki/N.E.C._(football_club)) : (3) NEC · Nijmegen · Nijmegen Eendracht Combinatie
- **RBC Roosendaal** : (1) Roosendaal
- [**FC Utrecht**](https://en.wikipedia.org/wiki/FC_Utrecht) : (2) Utrecht · Football Club Utrecht
- **Jong FC Utrecht**
- **DOS Utrecht** : (2) VV DOS · Voetbalvereniging Door Oefening Sterk
- [**Vitesse Arnhem**](https://en.wikipedia.org/wiki/SBV_Vitesse) : (4) Vitesse · SBV Vitesse · Vitesse Arnheim [de] · Stichting Betaald Voetbal Vitesse
- **FC Volendam** : (1) Volendam
- [**FC Emmen**](https://en.wikipedia.org/wiki/FC_Emmen) : (2) Emmen · FC Emmen VV




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **VVV Venlo**, Venlo (1):
  - `vvvvenlo` (2): VVV Venlo · VVV-Venlo




By City

- **Amsterdam, Noord-Holland** (4): 
  - Ajax Amsterdam  (4) Ajax · AFC Ajax · Amsterdamsche Football Club Ajax · Ajax Amsterd.
  - Jong Ajax 
  - DWS Amsterdam  (2) AFC DWS · Amsterdamsche Football Club Door Wilskracht Sterk
  - FC Amsterdam 
- **Eindhoven, Noord-Brabant** (3): 
  - PSV Eindhoven  (2) Philips Sport Vereniging · PSV
  - Jong PSV  (1) Jong PSV Eindh.
  - FC Eindhoven 
- **Rotterdam, Zuid-Holland** (3): 
  - Feyenoord Rotterdam  (1) Feyenoord
  - Sparta Rotterdam  (2) Sparta · Sparta R'dam
  - SBV Excelsior Rotterdam  (4) Excelsior · SBV Excelsior · Stichting Betaald Voetbal Excelsior · Excel. Rotterdam
- **Utrecht** (3): 
  - FC Utrecht  (2) Utrecht · Football Club Utrecht
  - Jong FC Utrecht 
  - DOS Utrecht  (2) VV DOS · Voetbalvereniging Door Oefening Sterk
- **Alkmaar, Noord-Holland** (2): 
  - AZ Alkmaar  (2) AZ · Alkmaar Zaanstreek
  - AZ Alkmaar II  (1) Jong AZ
- **'s-Hertogenbosch, Noord-Brabant** (1): FC Den Bosch  (1) Den Bosch
- **Almelo, Overijssel** (1): Heracles Almelo  (2) Heracles · SC Heracles Almelo
- **Almere, Flevoland** (1): Almere City FC  (1) Almere City
- **Arnhem** (1): Vitesse Arnhem  (4) Vitesse · SBV Vitesse · Stichting Betaald Voetbal Vitesse · Vitesse Arnheim [de]
- **Breda, Noord-Brabant** (1): NAC Breda  (2) NOAD ADVENDO Combinatie Breda · NAC
- **Den Haag, Zuid-Holland** (1): ADO Den Haag  (3) Den Haag · Alles Door Oefening Den Haag · FC Den Haag
- **Deventer, Overijssel** (1): Go Ahead Eagles 
- **Doetinchem** (1): BV De Graafschap  (3) Graafschap · De Graafschap · Vereniging Betaald Voetbal De Graafschap
- **Dordrecht, Zuid-Holland** (1): FC Dordrecht  (2) Dordrecht · Dordrecht '90
- **Emmen** (1): FC Emmen  (2) Emmen · FC Emmen VV
- **Enschede, Overijssel** (1): FC Twente  (4) Twente · Football Club Twente · Twente Enschede · FC Twente Enschede
- **Groningen** (1): FC Groningen  (2) Groningen · Football Club Groningen
- **Haarlem, Noord-Holland** (1): HFC Haarlem (1889-2010)  (3) Haarlemsche Football Club Haarlem · Haarlem FC · FC Haarlem
- **Heerenveen, Friesland** (1): SC Heerenveen  (2) Heerenveen · Sportclub Heerenveen
- **Heerlen, Limburg** (1): Rapid JC Heerlen (1954-1962)  (2) Rapid JC · Rapid Juliana Combinatie
- **Helmond, Noord-Brabant** (1): Helmond Sport 
- **Kerkrade, Limburg** (1): Roda JC Kerkrade  (4) Roda · Roda JC · Roda Kerkrade · Sportvereniging Roda Juliana Combinatie Kerkrade
- **Leeuwarden, Friesland** (1): SC Cambuur  (1) Cambuur
- **Maastricht, Limburg** (1): MVV Maastricht 
- **Nijmegen** (1): NEC Nijmegen  (3) Nijmegen · Nijmegen Eendracht Combinatie · NEC
- **Oss, Noord-Brabant** (1): FC Oss  (2) TOP Oss · Tot Ons Plezier Oss
- **Roosendaal** (1): RBC Roosendaal  (1) Roosendaal
- **Sittard, Limburg** (1): Fortuna Sittard  (2) For Sittard · SC Fortuna Sittard
- **Tilburg, Noord-Brabant** (1): Willem II Tilburg  (1) Willem II
- **Velsen, Noord-Holland** (1): SC Telstar  (2) Telstar · SC Stormvogels Telstar
- **Venlo, Limburg** (1): VVV Venlo  (4) VVV · VVV-Venlo · Venlo · Venlose Voetbal Vereniging Venlo
- **Volendam** (1): FC Volendam  (1) Volendam
- **Waalwijk, Noord-Brabant** (1): RKC Waalwijk  (3) RKC · Waalwijk · Rooms Katholieke Combinatie Waalwijk
- **Zwolle, Overijssel** (1): PEC Zwolle  (3) Zwolle · Prins Hendrik Ende Desespereert Nimmer Combinatie Zwolle · FC Zwolle




By Region

- **Noord-Holland** (8):   Ajax Amsterdam · Jong Ajax · DWS Amsterdam · FC Amsterdam · AZ Alkmaar · AZ Alkmaar II · SC Telstar · HFC Haarlem (1889-2010)
- **Zuid-Holland** (5):   Feyenoord Rotterdam · Sparta Rotterdam · SBV Excelsior Rotterdam · ADO Den Haag · FC Dordrecht
- **Friesland** (2):   SC Cambuur · SC Heerenveen
- **Noord-Brabant** (9):   FC Den Bosch · NAC Breda · PSV Eindhoven · Jong PSV · FC Eindhoven · RKC Waalwijk · Willem II Tilburg · FC Oss · Helmond Sport
- **Limburg** (5):   Fortuna Sittard · Roda JC Kerkrade · VVV Venlo · MVV Maastricht · Rapid JC Heerlen (1954-1962)
- **Overijssel** (4):   Go Ahead Eagles · Heracles Almelo · FC Twente · PEC Zwolle
- **Flevoland** (1):   Almere City FC
- **Doetinchem†** (1):   BV De Graafschap
- **Groningen†** (1):   FC Groningen
- **Nijmegen†** (1):   NEC Nijmegen
- **Roosendaal†** (1):   RBC Roosendaal
- **Utrecht†** (3):   FC Utrecht · Jong FC Utrecht · DOS Utrecht
- **Arnhem†** (1):   Vitesse Arnhem
- **Volendam†** (1):   FC Volendam
- **Emmen†** (1):   FC Emmen




By Year

- **1889** (1):   HFC Haarlem (1889-2010)
- **1892** (1):   Vitesse Arnhem
- **1896** (1):   Willem II Tilburg
- **1900** (2):   Ajax Amsterdam · NEC Nijmegen
- **1902** (1):   SBV Excelsior Rotterdam
- **1903** (2):   VVV Venlo · Heracles Almelo
- **1905** (1):   ADO Den Haag
- **1908** (1):   Feyenoord Rotterdam
- **1909** (1):   FC Eindhoven
- **1910** (1):   PEC Zwolle
- **1912** (1):   NAC Breda
- **1913** (1):   PSV Eindhoven
- **1920** (1):   SC Heerenveen
- **1928** (1):   FC Oss
- **1940** (1):   RKC Waalwijk
- **1954** (2):   Rapid JC Heerlen (1954-1962) · BV De Graafschap
- **1962** (1):   Roda JC Kerkrade
- **1964** (1):   SC Cambuur
- **1965** (1):   FC Twente
- **1967** (1):   AZ Alkmaar
- **1970** (1):   FC Utrecht
- **1971** (1):   FC Groningen
- **2001** (1):   Almere City FC
- ? (18):   Jong Ajax · DWS Amsterdam · FC Amsterdam · AZ Alkmaar II · SC Telstar · Sparta Rotterdam · FC Dordrecht · FC Den Bosch · Jong PSV · Helmond Sport · Fortuna Sittard · MVV Maastricht · Go Ahead Eagles · RBC Roosendaal · Jong FC Utrecht · DOS Utrecht · FC Volendam · FC Emmen




Historic

- **1962** (1):   Rapid JC Heerlen (1954-1962)
- **2010** (1):   HFC Haarlem (1889-2010)






By A to Z

- **A** (15): AZ · Ajax · AFC DWS · AFC Ajax · AZ Alkmaar · Almere City · ADO Den Haag · AZ Alkmaar II · Ajax Amsterd. · Ajax Amsterdam · Almere City FC · Alkmaar Zaanstreek · Alles Door Oefening Den Haag · Amsterdamsche Football Club Ajax · Amsterdamsche Football Club Door Wilskracht Sterk
- **B** (1): BV De Graafschap
- **C** (1): Cambuur
- **D** (7): Den Haag · Den Bosch · Dordrecht · DOS Utrecht · DWS Amsterdam · De Graafschap · Dordrecht '90
- **E** (3): Emmen · Excelsior · Excel. Rotterdam
- **F** (22): FC Oss · FC Emmen · FC Twente · FC Zwolle · Feyenoord · FC Haarlem · FC Utrecht · FC Den Haag · FC Emmen VV · FC Volendam · For Sittard · FC Amsterdam · FC Den Bosch · FC Dordrecht · FC Eindhoven · FC Groningen · Fortuna Sittard · FC Twente Enschede · Feyenoord Rotterdam · Football Club Twente · Football Club Utrecht · Football Club Groningen
- **G** (3): Groningen · Graafschap · Go Ahead Eagles
- **H** (7): Heracles · Haarlem FC · Heerenveen · Helmond Sport · Heracles Almelo · HFC Haarlem (1889-2010) · Haarlemsche Football Club Haarlem
- **J** (5): Jong AZ · Jong PSV · Jong Ajax · Jong FC Utrecht · Jong PSV Eindh.
- **M** (1): MVV Maastricht
- **N** (7): NAC · NEC · Nijmegen · NAC Breda · NEC Nijmegen · NOAD ADVENDO Combinatie Breda · Nijmegen Eendracht Combinatie
- **P** (5): PSV · PEC Zwolle · PSV Eindhoven · Philips Sport Vereniging · Prins Hendrik Ende Desespereert Nimmer Combinatie Zwolle
- **R** (12): RKC · Roda · Roda JC · Rapid JC · Roosendaal · RKC Waalwijk · Roda Kerkrade · RBC Roosendaal · Roda JC Kerkrade · Rapid Juliana Combinatie · Rapid JC Heerlen (1954-1962) · Rooms Katholieke Combinatie Waalwijk
- **S** (16): Sparta · SC Cambuur · SC Telstar · SBV Vitesse · Sparta R'dam · SBV Excelsior · SC Heerenveen · Sparta Rotterdam · SC Fortuna Sittard · SC Heracles Almelo · Sportclub Heerenveen · SC Stormvogels Telstar · SBV Excelsior Rotterdam · Stichting Betaald Voetbal Vitesse · Stichting Betaald Voetbal Excelsior · Sportvereniging Roda Juliana Combinatie Kerkrade
- **T** (5): Twente · TOP Oss · Telstar · Twente Enschede · Tot Ons Plezier Oss
- **U** (1): Utrecht
- **V** (12): VVV · Venlo · VV DOS · Vitesse · Volendam · VVV Venlo · VVV-Venlo · Vitesse Arnhem · Vitesse Arnheim [de] · Venlose Voetbal Vereniging Venlo · Voetbalvereniging Door Oefening Sterk · Vereniging Betaald Voetbal De Graafschap
- **W** (3): Waalwijk · Willem II · Willem II Tilburg
- **Z** (1): Zwolle




