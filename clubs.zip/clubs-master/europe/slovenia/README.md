19 clubs

- **NK Olimpija Ljubljana** : (1) Olimpija Ljubljana
- **NK IB Ljubljana** : (1) IB Ljubljana
- **NK Maribor** : (1) Maribor
- **ND Mura 05** : (2) Mura · NS Mura
- **FC Koper** : (2) Koper · NK Koper
- **ND Gorica** : (2) Gorica · Nova Gorica
- **NK Domžale** : (1) Domžale ⇒ (2) ≈Domzale≈ · ≈NK Domzale≈
- **NK Rudar Velenje** : (1) Rudar Velenje
- **NK Celje** : (1) Celje
- **NK Aluminij** : (1) Aluminij
- **ASK Bravo Publikum**
- **NK Tabor Sezana** : (1) Tabor
- **NK Triglav** : (1) Triglav
- **NK Radomlje**
- **NK Nafta 1903** : (4) Nafta 1903 · Nafta Lendava · NK Nafta Lendava · NK Nafta Lendava 1903
- **NK Krško** : (2) Krško · Nogometni Klub Krško ⇒ (3) ≈Krsko≈ · ≈NK Krsko≈ · ≈Nogometni Klub Krsko≈
- **NK Primorje (1924-2011)** : (2) Primorje · Nogometni Klub Primorje
- **MNK Izola** : (1) Mladinski Nogometni Klub Izola
- **NK Izola (1923-1996)** : (1) Nogometni Klub Izola




Alphabet

- **Alphabet Specials** (2):  **š**  **ž** 
  - **š**×3 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **ž**×2 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Izola** (2): 
  - MNK Izola  (1) Mladinski Nogometni Klub Izola
  - NK Izola (1923-1996)  (1) Nogometni Klub Izola
- **Ajdovščina** (1): NK Primorje (1924-2011)  (2) Primorje · Nogometni Klub Primorje
- **Krško** (1): NK Krško  (2) Krško · Nogometni Klub Krško
- **Lendava** (1): NK Nafta 1903  (4) Nafta 1903 · NK Nafta Lendava 1903 · NK Nafta Lendava · Nafta Lendava
- **Maribor** (1): NK Maribor  (1) Maribor
- ? (13): 
  - NK Olimpija Ljubljana  (1) Olimpija Ljubljana
  - NK IB Ljubljana  (1) IB Ljubljana
  - ND Mura 05  (2) Mura · NS Mura
  - FC Koper  (2) Koper · NK Koper
  - ND Gorica  (2) Gorica · Nova Gorica
  - NK Domžale  (1) Domžale
  - NK Rudar Velenje  (1) Rudar Velenje
  - NK Celje  (1) Celje
  - NK Aluminij  (1) Aluminij
  - ASK Bravo Publikum 
  - NK Tabor Sezana  (1) Tabor
  - NK Triglav  (1) Triglav
  - NK Radomlje 




By Region

- **Maribor†** (1):   NK Maribor
- **Lendava†** (1):   NK Nafta 1903
- **Krško†** (1):   NK Krško
- **Ajdovščina†** (1):   NK Primorje (1924-2011)
- **Izola†** (2):   MNK Izola · NK Izola (1923-1996)




By Year

- **1922** (1):   NK Krško
- **1923** (1):   NK Izola (1923-1996)
- **1924** (1):   NK Primorje (1924-2011)
- **1996** (1):   MNK Izola
- ? (15):   NK Olimpija Ljubljana · NK IB Ljubljana · NK Maribor · ND Mura 05 · FC Koper · ND Gorica · NK Domžale · NK Rudar Velenje · NK Celje · NK Aluminij · ASK Bravo Publikum · NK Tabor Sezana · NK Triglav · NK Radomlje · NK Nafta 1903




Historic

- **1996** (1):   NK Izola (1923-1996)
- **2011** (1):   NK Primorje (1924-2011)






By A to Z

- **A** (2): Aluminij · ASK Bravo Publikum
- **C** (1): Celje
- **D** (1): Domžale
- **F** (1): FC Koper
- **G** (1): Gorica
- **I** (1): IB Ljubljana
- **K** (2): Koper · Krško
- **M** (4): Mura · Maribor · MNK Izola · Mladinski Nogometni Klub Izola
- **N** (26): NS Mura · NK Celje · NK Koper · NK Krško · ND Gorica · ND Mura 05 · NK Domžale · NK Maribor · NK Triglav · Nafta 1903 · NK Aluminij · NK Radomlje · Nova Gorica · NK Nafta 1903 · Nafta Lendava · NK IB Ljubljana · NK Tabor Sezana · NK Nafta Lendava · NK Rudar Velenje · NK Izola (1923-1996) · Nogometni Klub Izola · Nogometni Klub Krško · NK Nafta Lendava 1903 · NK Olimpija Ljubljana · NK Primorje (1924-2011) · Nogometni Klub Primorje
- **O** (1): Olimpija Ljubljana
- **P** (1): Primorje
- **R** (1): Rudar Velenje
- **T** (2): Tabor · Triglav




