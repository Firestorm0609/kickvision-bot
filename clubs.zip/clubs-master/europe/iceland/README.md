16 clubs

- **KR Reykjavík** : (2) KR · Knattspyrnufélag Reykjavíkur ⇒ (2) ≈KR Reykjavik≈ · ≈Knattspyrnufelag Reykjavikur≈
- **Fram Reykjavík** : (1) Fram ⇒ (1) ≈Fram Reykjavik≈
- **Fylkir Reykjavik** : (1) Fylkir
- **Valur Reykjavík** : (2) Valur · Valur Reykj. ⇒ (1) ≈Valur Reykjavik≈
- **Víkingur Reykjavík** : (1) Víkingur R. ⇒ (2) ≈Vikingur R.≈ · ≈Vikingur Reykjavik≈
- **ÍA Akranes** : (2) ÍA · Íþróttabandalag Akraness ⇒ (3) ≈IA≈ · ≈IA Akranes≈ · ≈Iprottabandalag Akraness≈
- **FH Hafnarfjörður** : (3) FH · FH Hafnarfjördur · FH Hafnarfjardar ⇒ (4) ≈FH Hafnarfjordur≈ · ≈FH Hafnarfjordur≈ · ≈FH Hafnarfjoerður≈ · ≈FH Hafnarfjoerdur≈
- **Breiðablik** : (1) Breidablik ⇒ (1) ≈Breidablik≈
- **ÍBV Vestmannaeyjar** : (2) ÍBV · ÍB Vestmannaeyja ⇒ (3) ≈IBV≈ · ≈IB Vestmannaeyja≈ · ≈IBV Vestmannaeyjar≈
- **Stjarnan** : (6) Stjarnan FC · UMF Stjarnan · Stjarnan Garð. · Stjarnan Garðab. · Stjarnan Gardab. · Stjarnan Garðabær ⇒ (3) ≈Stjarnan Gard.≈ · ≈Stjarnan Gardab.≈ · ≈Stjarnan Gardabaer≈
- **Grindavík** : (1) UMF Grindavík ⇒ (2) ≈Grindavik≈ · ≈UMF Grindavik≈
- **HK Kópavogs** : (1) HK ⇒ (1) ≈HK Kopavogs≈
- **KA Akureyri** : (1) KA
- **Thór Akureyri** : (1) Þór Akureyri ⇒ (2) ≈Por Akureyri≈ · ≈Thor Akureyri≈
- **Keflavík ÍF** : (2) Keflavík · ÍB Keflavík ⇒ (3) ≈Keflavik≈ · ≈Keflavik IF≈ · ≈IB Keflavik≈
- **Knattspyrnufélag Fjallabyggðar** : (2) KF · Leiftur ⇒ (1) ≈Knattspyrnufelag Fjallabyggdar≈




Alphabet

- **Alphabet Specials** (9):  **Í**  **Þ**  **æ**  **é**  **í**  **ð**  **ó**  **ö**  **þ** 
  - **Í**×8 U+00CD (205) - LATIN CAPITAL LETTER I WITH ACUTE ⇒ I
  - **Þ**×1 U+00DE (222) - LATIN CAPITAL LETTER THORN ⇒ P
  - **æ**×1 U+00E6 (230) - LATIN SMALL LETTER AE ⇒ ae
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×12 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ð**×6 U+00F0 (240) - LATIN SMALL LETTER ETH ⇒ d
  - **ó**×4 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ö**×2 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **þ**×1 U+00FE (254) - LATIN SMALL LETTER THORN ⇒ p




Duplicates

- **FH Hafnarfjörður**, Hafnarfjörður (1):
  - `fhhafnarfjordur` (2): **FH Hafnarfjordur** · **FH Hafnarfjordur**
- **Breiðablik**, Kópavogur (1):
  - `breidablik` (2): **Breidablik** · **Breidablik**
- **Stjarnan**, Garðabær (1):
  - `stjarnangardab` (2): **Stjarnan Gardab.** · **Stjarnan Gardab.**




By City

- **Reykjavík** (5): 
  - KR Reykjavík  (2) KR · Knattspyrnufélag Reykjavíkur
  - Fram Reykjavík  (1) Fram
  - Fylkir Reykjavik  (1) Fylkir
  - Valur Reykjavík  (2) Valur · Valur Reykj.
  - Víkingur Reykjavík  (1) Víkingur R.
- **Akureyri** (2): 
  - KA Akureyri  (1) KA
  - Thór Akureyri  (1) Þór Akureyri
- **Kópavogur** (2): 
  - Breiðablik  (1) Breidablik
  - HK Kópavogs  (1) HK
- **Akranes** (1): ÍA Akranes  (2) ÍA · Íþróttabandalag Akraness
- **Fjallabyggð** (1): Knattspyrnufélag Fjallabyggðar  (2) KF · Leiftur
- **Garðabær** (1): Stjarnan  (6) Stjarnan Garð. · Stjarnan Garðab. · Stjarnan Gardab. · UMF Stjarnan · Stjarnan Garðabær · Stjarnan FC
- **Grindavík** (1): Grindavík  (1) UMF Grindavík
- **Hafnarfjörður** (1): FH Hafnarfjörður  (3) FH · FH Hafnarfjördur · FH Hafnarfjardar
- **Reykjanesbær** (1): Keflavík ÍF  (2) Keflavík · ÍB Keflavík
- **Vestmannaeyjar** (1): ÍBV Vestmannaeyjar  (2) ÍBV · ÍB Vestmannaeyja




By Region

- **Reykjavík†** (5):   KR Reykjavík · Fram Reykjavík · Fylkir Reykjavik · Valur Reykjavík · Víkingur Reykjavík
- **Akranes†** (1):   ÍA Akranes
- **Hafnarfjörður†** (1):   FH Hafnarfjörður
- **Kópavogur†** (2):   Breiðablik · HK Kópavogs
- **Vestmannaeyjar†** (1):   ÍBV Vestmannaeyjar
- **Garðabær†** (1):   Stjarnan
- **Grindavík†** (1):   Grindavík
- **Akureyri†** (2):   KA Akureyri · Thór Akureyri
- **Reykjanesbær†** (1):   Keflavík ÍF
- **Fjallabyggð†** (1):   Knattspyrnufélag Fjallabyggðar




By Year

- **1960** (1):   Stjarnan
- ? (15):   KR Reykjavík · Fram Reykjavík · Fylkir Reykjavik · Valur Reykjavík · Víkingur Reykjavík · ÍA Akranes · FH Hafnarfjörður · Breiðablik · ÍBV Vestmannaeyjar · Grindavík · HK Kópavogs · KA Akureyri · Thór Akureyri · Keflavík ÍF · Knattspyrnufélag Fjallabyggðar






By A to Z

- **B** (2): Breidablik · Breiðablik
- **F** (8): FH · Fram · Fylkir · Fram Reykjavík · FH Hafnarfjardar · FH Hafnarfjördur · FH Hafnarfjörður · Fylkir Reykjavik
- **G** (1): Grindavík
- **H** (2): HK · HK Kópavogs
- **K** (9): KA · KF · KR · Keflavík · KA Akureyri · Keflavík ÍF · KR Reykjavík · Knattspyrnufélag Reykjavíkur · Knattspyrnufélag Fjallabyggðar
- **L** (1): Leiftur
- **S** (6): Stjarnan · Stjarnan FC · Stjarnan Garð. · Stjarnan Gardab. · Stjarnan Garðab. · Stjarnan Garðabær
- **T** (1): Thór Akureyri
- **U** (2): UMF Stjarnan · UMF Grindavík
- **V** (5): Valur · Víkingur R. · Valur Reykj. · Valur Reykjavík · Víkingur Reykjavík
- **Í** (7): ÍA · ÍBV · ÍA Akranes · ÍB Keflavík · ÍB Vestmannaeyja · ÍBV Vestmannaeyjar · Íþróttabandalag Akraness
- **Þ** (1): Þór Akureyri




