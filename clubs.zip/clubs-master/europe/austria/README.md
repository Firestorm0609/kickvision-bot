157 clubs

- [**SK Rapid Wien**](https://en.wikipedia.org/wiki/SK_Rapid_Wien) : (3) Rapid · Rapid Wien · Rapid Vienna [en]
- **SK Rapid Wien II** : (2) Rapid Wien Am. · SK Rapid Amateure
- [**FK Austria Wien**](https://en.wikipedia.org/wiki/FK_Austria_Wien) : (3) Austria · Austria Wien · Austria Vienna [en]
- **Young Violets Austria Wien** : (6) Young Violets · Austria Wien A. · FK Austria Wien II · Austria Wien Amat. · Young Violets A. W. · Ausstria Wien Amateure
- **SC Team Wiener Linien** : (2) Team Wiener Linien · SC Team Wr. Linien
- **Wiener Sport-Club** : (4) Wiener SC · Wiener SK · Wr. Sportklub · Wiener Sportklub
- **First Vienna FC** : (3) Vienna · Vienna FC 1894 · First Vienna FC 1894
- **Floridsdorfer AC** : (1) FAC Team für Wien ⇒ (2) ≈FAC Team fur Wien≈ · ≈FAC Team fuer Wien≈
- **Wiener Viktoria** : (1) SC Wiener Viktoria
- **FC Mauerwerk**
- **SC Ostbahn XI**
- **Technopool Admira** : (1) Admira Technopool
- **SR Donaufeld** : (2) Donaufeld · SR Donaufeld Wien
- **FC Stadlau**
- **SC Red Star Penzing**
- [**SV Mattersburg**](https://en.wikipedia.org/wiki/SV_Mattersburg) : (2) Mattersburg · Sportvereinigung Mattersburg
- **SV Mattersburg II** : (2) SV Mattersburg Am. · SV Mattersburg Amateure
- **SC Neusiedl am See** : (3) SC Neusiedl · Neusiedl am See · SC Neusiedl am See 1919
- **ASV Draßburg** ⇒ (1) ≈ASV Drassburg≈
- **SC-ESV Parndorf** : (4) Parndorf · SC/ESV Parndorf · SC-ESV Parndorf 1919 · SC/ESV Parndorf 1919
- **SV Stegersbach**
- **SV Oberwart**
- **SV Heiligenkreuz**
- **SC Pinkafeld**
- **SV Wimpassing** : (1) Wimpassing
- **SC Ritzing** : (1) Ritzing
- **SC Trausdorf**
- [**FC Admira Wacker Mödling**](https://en.wikipedia.org/wiki/FC_Admira_Wacker_Mödling) : (8) Admira · FC Admira · Admira Wien · Admira Wacker · FC Admira Wacker · Admira Wacker Mödling · SK Admira Wacker Wien · SK Admira Vienna [en] ⇒ (4) ≈Admira Wacker Modling≈ · ≈Admira Wacker Moedling≈ · ≈FC Admira Wacker Modling≈ · ≈FC Admira Wacker Moedling≈
- **FC Admira Wacker Mödling II** : (3) Admira Juniors · Admira Amateure · FC Admira Wacker II ⇒ (2) ≈FC Admira Wacker Modling II≈ · ≈FC Admira Wacker Moedling II≈
- **SC Wiener Neustadt** : (4) Neustadt · Wr. Neustadt · SC Wr. Neustadt · Wiener Neustadt
- [**SKN St. Pölten**](https://en.wikipedia.org/wiki/SKN_St._Pölten) : (3) St. Pölten · SKN Sankt Pölten · Sportklub Niederösterreich St. Pölten ⇒ (8) ≈St. Polten≈ · ≈St. Poelten≈ · ≈SKN St. Polten≈ · ≈SKN St. Poelten≈ · ≈SKN Sankt Polten≈ · ≈SKN Sankt Poelten≈ · ≈Sportklub Niederosterreich St. Polten≈ · ≈Sportklub Niederoesterreich St. Poelten≈
- **SKN St. Pölten Juniors** ⇒ (2) ≈SKN St. Polten Juniors≈ · ≈SKN St. Poelten Juniors≈
- **SV Horn**
- **Horn Amateure**
- **SKU Amstetten** : (1) Amstetten SKU
- **ASK Ebreichsdorf**
- **FC Marchfeld Donauauen** : (2) SC Mannsdorf · Mannsdorf-Großenz. ⇒ (1) ≈Mannsdorf-Grossenz.≈
- **SV Leobendorf**
- **SV Stripfing**
- **FCM Traiskirchen**
- **ASK-BSC Bruck/Leitha** : (1) Bruck/Leitha
- **1. SC Sollenau** : (2) Sollenau · SC Sollenau
- **SV Schwechat** : (1) Schwechat SV
- **ASK Bad Vöslau** ⇒ (2) ≈ASK Bad Voslau≈ · ≈ASK Bad Voeslau≈
- **SC Retz**
- **SCU Ardagger** : (1) Ardagger SCU
- **SV Gaflenz**
- **FC Rohrendorf/Gedersdorf** : (1) SC Rohrendorf
- **SC Leopoldsdorf** : (1) SC Leopoldsdorf i. Mfd.
- **ATSV Ober-Grafendorf** : (1) Ober-Grafendorf
- **ASK Kottingbrunn**
- **ASV Spratzern**
- **SC Krems**
- **SC Guntersdorf** : (1) Guntersdorf
- **SC Echsenbach** : (2) Echsenbach · SC Hartl Haus
- **SC St. Martin** : (1) St. Martin
- **SC Weißenkirchen** : (1) Weißenkirchen ⇒ (2) ≈Weissenkirchen≈ · ≈SC Weissenkirchen≈
- **SV Rehberg** : (1) Rehberg
- **SV Sieghartskirchen** : (1) Sieghartskirchen
- **SV Zwentendorf** : (1) Zwentendorf
- **USC Altenwörth** : (1) Altenwörth ⇒ (4) ≈Altenworth≈ · ≈Altenwoerth≈ · ≈USC Altenworth≈ · ≈USC Altenwoerth≈
- **USC Grafenwörth** : (1) Grafenwörth ⇒ (4) ≈Grafenworth≈ · ≈Grafenwoerth≈ · ≈USC Grafenworth≈ · ≈USC Grafenwoerth≈
- **USC Kirchberg/W.** : (1) Kirchberg/W.
- **USC Schweiggers** : (1) Schweiggers
- **USV Groß Gerungs** : (1) Groß Gerungs ⇒ (2) ≈Gross Gerungs≈ · ≈USV Gross Gerungs≈
- **USV Langenlois** : (1) Langenlois
- [**LASK Linz**](https://en.wikipedia.org/wiki/LASK_Linz) : (2) LASK · Linzer ASK
- **FC Juniors OÖ** : (1) Juniors OÖ ⇒ (4) ≈Juniors OO≈ · ≈Juniors OOE≈ · ≈FC Juniors OO≈ · ≈FC Juniors OOE≈
- **FC Pasching** : (1) Pasching
- **FC Blau-Weiß Linz** : (2) BW Linz · Blau-Weiß Linz ⇒ (2) ≈Blau-Weiss Linz≈ · ≈FC Blau-Weiss Linz≈
- **FC Stahl Linz** : (2) FC Linz · SK VOEST Linz
- **SV Ried** : (3) Ried · SV Josko Ried · SV Josko Fenster Ried
- **SV Ried II**
- **SK Vorwärts Steyr** : (1) Vorwärts Steyr ⇒ (4) ≈Vorwarts Steyr≈ · ≈Vorwaerts Steyr≈ · ≈SK Vorwarts Steyr≈ · ≈SK Vorwaerts Steyr≈
- **FC Wels**
- **WSC Hertha Wels**
- **Union Vöcklamarkt** : (1) Vöcklamarkt ⇒ (4) ≈Vocklamarkt≈ · ≈Voecklamarkt≈ · ≈Union Vocklamarkt≈ · ≈Union Voecklamarkt≈
- **ATSV Stadl-Paura**
- **Union Gurten** : (1) Gurten
- **Union St. Florian** : (1) St. Florian
- **SV Wallern** : (1) Wallern
- **SV Grün-Weiß Micheldorf** : (2) Micheldorf · SV Micheldorf ⇒ (2) ≈SV Grun-Weiss Micheldorf≈ · ≈SV Gruen-Weiss Micheldorf≈
- [**SK Sturm Graz**](https://en.wikipedia.org/wiki/SK_Sturm_Graz) : (2) Sturm · Sturm Graz
- **SK Sturm Graz II** : (1) Sturm Graz Amat.
- **Grazer AK**
- [**TSV Hartberg**](https://en.wikipedia.org/wiki/TSV_Hartberg) : (4) TSV · Hartberg · TSV Sparkasse Hartberg · Turn- und Sportverein Hartberg
- **Kapfenberger SV** : (2) KSV 1919 · Kapfenberger SV 1919
- **SV Lafnitz** : (1) Lafnitz
- **USV Allerheiligen** : (2) Allerheiligen · SV Allerheiligen
- **TuS Bad Gleichenberg** : (1) Bad Gleichenberg
- **Deutschlandsberger SC** : (1) Deutschlandsberg
- **FC Gleisdorf 09** : (1) FC Gleisdorf
- **SC Kalsdorf** : (1) Kalsdorf
- **USV St. Anna** : (1) St Anna am Aigen
- **SC Weiz**
- **DSV Leoben**
- **FC Gratkorn**
- **FC Lankowitz** : (1) FC Piberstein Lankowitz
- [**Wolfsberger AC**](https://en.wikipedia.org/wiki/Wolfsberger_AC) : (5) Wolfsberg · Wolfsberger · AC Wolfsberger · RZ Pellets WAC · Wolfsberger Athletik Club
- **Wolfsberger AC II** : (1) WAC Amateure
- **ATSV Wolfsberg**
- **Austria Klagenfurt** : (4) FC Kärnten · A. Klagenfurt · SK Austria Klagenfurt · SG Austria Klagenfurt ⇒ (2) ≈FC Karnten≈ · ≈FC Kaernten≈
- **Austria Kärnten (2007-2010)** : (1) SK Austria Kärnten ⇒ (4) ≈Austria Karnten≈ · ≈Austria Kaernten≈ · ≈SK Austria Karnten≈ · ≈SK Austria Kaernten≈
- **SAK Klagenfurt** : (3) Slowenischer AK · SAK Celovec/Klagenfurt · Slovenski atletski klub
- **Villacher SV**
- **SV Spittal/Drau**
- **FC St. Veit**
- **FC Lendorf** : (1) Lendorf
- **ASV Annabichler SV 1923**
- **ASKÖ Köttmannsdorf** ⇒ (2) ≈ASKO Kottmannsdorf≈ · ≈ASKOE Koettmannsdorf≈
- **VST Völkermarkt** ⇒ (2) ≈VST Volkermarkt≈ · ≈VST Voelkermarkt≈
- [**FC RB Salzburg**](https://en.wikipedia.org/wiki/FC_Red_Bull_Salzburg) : (5) Salzburg · FC Salzburg · RB Salzburg · Red Bull Salzburg · FC Red Bull Salzburg
- **FC RB Salzburg II** : (3) RB Salzburg II · FC RB Juniors Salzburg · FC Red Bull Salzburg II
- **FC Liefering** : (1) Liefering
- **Austria Salzburg** : (2) A. Salzburg · SV Austria Salzburg
- **SAK 1914** : (2) SAK 1914 Salzburg · Salzburger AK 1914
- **SV Grödig** : (1) Grödig ⇒ (4) ≈Grodig≈ · ≈Groedig≈ · ≈SV Grodig≈ · ≈SV Groedig≈
- **SV Seekirchen** : (1) SV Seekirchen 1945
- **FC Pinzgau Saalfelden** : (1) Pinzgau Saalfelden
- **USK Anif**
- **TSV St. Johann** : (2) TSV St. Johann Pongau · TSV St. Johann im Pongau
- **SV Wals-Grünau** ⇒ (2) ≈SV Wals-Grunau≈ · ≈SV Wals-Gruenau≈
- **SV Kuchl**
- **Bischofshofen Sportklub 1933**
- **TSV Neumarkt** : (1) TSV Neumarkt am Wallersee
- **USC Eugendorf**
- **SC Golling**
- [**FC Wacker Innsbruck**](https://en.wikipedia.org/wiki/FC_Wacker_Innsbruck_(2002)) : (7) FC Tirol · Innsbruck · FC Wacker · SSW Innsbruck · Wacker Innsbruck · FC Tirol Innsbruck · Spielgemeinschaft Swarovski Wacker Innsbruck
- **FC Wacker Innsbruck II** : (1) Wacker Innsbruck II
- **SV Innsbruck**
- [**WSG Tirol**](https://en.wikipedia.org/wiki/WSG_Wattens) : (7) Tirol · Wattens · WSG Wattens · WSG Swarovs. Tirol · WSG Swarovski Tirol · WSG Swarovski Wattens · Wattener Sportgemeinschaft Tirol
- **SC Schwaz** : (1) Schwaz
- **FC Kitzbühel** : (1) Kitzbühel ⇒ (4) ≈Kitzbuhel≈ · ≈Kitzbuehel≈ · ≈FC Kitzbuhel≈ · ≈FC Kitzbuehel≈
- **FC Kufstein** : (1) Kufstein
- **SV Telfs**
- **SV Wörgl** ⇒ (2) ≈SV Worgl≈ · ≈SV Woergl≈
- **SC Imst**
- **SV Hall**
- **SVG Reichenau**
- **FC Zirl**
- **SV Reutte**
- [**SCR Altach**](https://en.wikipedia.org/wiki/SC_Rheindorf_Altach) : (4) Altach · Rheindorf Altach · SC Rheindorf Altach · Sportclub Rheindorf Altach
- **SCR Altach Juniors** : (1) Altach Amateure
- **Austria Lustenau** : (2) A. Lustenau · SC Austria Lustenau
- **Austria Lustenau Amateure** : (2) Austria Lustenau A · SC Austria Lustenau Amateure
- **FC Lustenau 07** : (2) FC Lustenau · FC Lustenau 1907
- **FC Dornbirn 1913** : (2) Dornbirn · FC Dornbirn
- **Dornbirner SV** : (1) Dornbirner Sportverein
- **FC Höchst** : (1) Höchst ⇒ (4) ≈Hochst≈ · ≈Hoechst≈ · ≈FC Hochst≈ · ≈FC Hoechst≈
- **VfB Hohenems** : (1) Hohenems
- **FC Wolfurt** : (1) Meusburger FC Wolfurt
- **SW Bregenz** : (2) SC Bregenz · SC Schwarz-Weiß Bregenz ⇒ (1) ≈SC Schwarz-Weiss Bregenz≈
- **FC Hard** : (1) Hard
- **FC Langenegg** : (1) SPG FC Langenegg
- **FC Lauterach**
- **RW Rankweil**
- **SC Röthis** : (1) SC Röfix Röthis ⇒ (4) ≈SC Rothis≈ · ≈SC Roethis≈ · ≈SC Rofix Rothis≈ · ≈SC Roefix Roethis≈




Alphabet

- **Alphabet Specials** (5):  **Ö**  **ß**  **ä**  **ö**  **ü** 
  - **Ö**×3 U+00D6 (214) - LATIN CAPITAL LETTER O WITH DIAERESIS ⇒ O•OE
  - **ß**×10 U+00DF (223) - LATIN SMALL LETTER SHARP S ⇒ ss
  - **ä**×5 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **ö**×26 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ü**×5 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates

- **SC-ESV Parndorf**, Parndorf (2):
  - `scesvparndorf` (2): SC-ESV Parndorf · SC/ESV Parndorf
  - `scesvparndorf1919` (2): SC-ESV Parndorf 1919 · SC/ESV Parndorf 1919




By City

- **Wien, Wien** (11): 
  - SK Rapid Wien  (3) Rapid · Rapid Wien · Rapid Vienna [en]
  - SK Rapid Wien II  (2) Rapid Wien Am. · SK Rapid Amateure
  - FK Austria Wien  (3) Austria · Austria Wien · Austria Vienna [en]
  - Young Violets Austria Wien  (6) Young Violets · Young Violets A. W. · FK Austria Wien II · Austria Wien Amat. · Austria Wien A. · Ausstria Wien Amateure
  - SC Team Wiener Linien  (2) Team Wiener Linien · SC Team Wr. Linien
  - Wiener Sport-Club  (4) Wiener Sportklub · Wiener SK · Wr. Sportklub · Wiener SC
  - First Vienna FC  (3) Vienna · Vienna FC 1894 · First Vienna FC 1894
  - Floridsdorfer AC  (1) FAC Team für Wien
  - Wiener Viktoria  (1) SC Wiener Viktoria
  - FC Mauerwerk 
  - SC Ostbahn XI 
- **Linz, Oberösterreich** (5): 
  - LASK Linz  (2) LASK · Linzer ASK
  - FC Juniors OÖ  (1) Juniors OÖ
  - FC Pasching  (1) Pasching
  - FC Blau-Weiß Linz  (2) BW Linz · Blau-Weiß Linz
  - FC Stahl Linz  (2) SK VOEST Linz · FC Linz
- **Salzburg, Salzburg** (4): 
  - FC RB Salzburg  (5) Salzburg · FC Salzburg · RB Salzburg · Red Bull Salzburg · FC Red Bull Salzburg
  - FC RB Salzburg II  (3) RB Salzburg II · FC Red Bull Salzburg II · FC RB Juniors Salzburg
  - Austria Salzburg  (2) A. Salzburg · SV Austria Salzburg
  - SAK 1914  (2) Salzburger AK 1914 · SAK 1914 Salzburg
- **Graz, Steiermark** (3): 
  - SK Sturm Graz  (2) Sturm · Sturm Graz
  - SK Sturm Graz II  (1) Sturm Graz Amat.
  - Grazer AK 
- **Innsbruck, Tirol** (3): 
  - FC Wacker Innsbruck  (7) Innsbruck · FC Wacker · Wacker Innsbruck · FC Tirol · FC Tirol Innsbruck · SSW Innsbruck · Spielgemeinschaft Swarovski Wacker Innsbruck
  - FC Wacker Innsbruck II  (1) Wacker Innsbruck II
  - SV Innsbruck 
- **Klagenfurt, Kärnten** (3): 
  - Austria Klagenfurt  (4) A. Klagenfurt · SK Austria Klagenfurt · SG Austria Klagenfurt · FC Kärnten
  - Austria Kärnten (2007-2010)  (1) SK Austria Kärnten
  - SAK Klagenfurt  (3) Slovenski atletski klub · Slowenischer AK · SAK Celovec/Klagenfurt
- **Lustenau, Vorarlberg** (3): 
  - Austria Lustenau  (2) A. Lustenau · SC Austria Lustenau
  - Austria Lustenau Amateure  (2) SC Austria Lustenau Amateure · Austria Lustenau A
  - FC Lustenau 07  (2) FC Lustenau · FC Lustenau 1907
- **Wolfsberg, Kärnten** (3): 
  - Wolfsberger AC  (5) Wolfsberg · Wolfsberger · AC Wolfsberger · Wolfsberger Athletik Club · RZ Pellets WAC
  - Wolfsberger AC II  (1) WAC Amateure
  - ATSV Wolfsberg 
- **Altach, Vorarlberg** (2): 
  - SCR Altach  (4) Altach · Rheindorf Altach · SC Rheindorf Altach · Sportclub Rheindorf Altach
  - SCR Altach Juniors  (1) Altach Amateure
- **Dornbirn, Vorarlberg** (2): 
  - FC Dornbirn 1913  (2) Dornbirn · FC Dornbirn
  - Dornbirner SV  (1) Dornbirner Sportverein
- **Horn, Niederösterreich** (2): 
  - SV Horn 
  - Horn Amateure 
- **Maria Enzersdorf, Niederösterreich** (2): 
  - FC Admira Wacker Mödling  (8) Admira · Admira Wacker · FC Admira · FC Admira Wacker · Admira Wacker Mödling · Admira Wien · SK Admira Wacker Wien · SK Admira Vienna [en]
  - FC Admira Wacker Mödling II  (3) FC Admira Wacker II · Admira Amateure · Admira Juniors
- **Mattersburg, Burgenland** (2): 
  - SV Mattersburg  (2) Mattersburg · Sportvereinigung Mattersburg
  - SV Mattersburg II  (2) SV Mattersburg Am. · SV Mattersburg Amateure
- **Ried i. Innkreis, Oberösterreich** (2): 
  - SV Ried  (3) Ried · SV Josko Ried · SV Josko Fenster Ried
  - SV Ried II 
- **St. Pölten, Niederösterreich** (2): 
  - SKN St. Pölten  (3) St. Pölten · Sportklub Niederösterreich St. Pölten · SKN Sankt Pölten
  - SKN St. Pölten Juniors 
- **Wels, Oberösterreich** (2): 
  - FC Wels 
  - WSC Hertha Wels 
- **Allerheiligen bei Wildon, Steiermark** (1): USV Allerheiligen  (2) SV Allerheiligen · Allerheiligen
- **Altenwörth, Niederösterreich** (1): USC Altenwörth  (1) Altenwörth
- **Amstetten, Niederösterreich** (1): SKU Amstetten  (1) Amstetten SKU
- **Bad Gleichenberg, Steiermark** (1): TuS Bad Gleichenberg  (1) Bad Gleichenberg
- **Bregenz, Vorarlberg** (1): SW Bregenz  (2) SC Schwarz-Weiß Bregenz · SC Bregenz
- **Bruck an der Leitha, Niederösterreich** (1): ASK-BSC Bruck/Leitha  (1) Bruck/Leitha
- **Deutschlandsberg, Steiermark** (1): Deutschlandsberger SC  (1) Deutschlandsberg
- **Draßburg, Burgenland** (1): ASV Draßburg 
- **Ebreichsdorf, Niederösterreich** (1): ASK Ebreichsdorf 
- **Gleisdorf, Steiermark** (1): FC Gleisdorf 09  (1) FC Gleisdorf
- **Grafenwörth, Niederösterreich** (1): USC Grafenwörth  (1) Grafenwörth
- **Gratkorn, Steiermark** (1): FC Gratkorn 
- **Grödig, Salzburg** (1): SV Grödig  (1) Grödig
- **Gurten, Oberösterreich** (1): Union Gurten  (1) Gurten
- **Hartberg, Steiermark** (1): TSV Hartberg  (4) TSV · Hartberg · TSV Sparkasse Hartberg · Turn- und Sportverein Hartberg
- **Kalsdorf, Steiermark** (1): SC Kalsdorf  (1) Kalsdorf
- **Kapfenberg, Steiermark** (1): Kapfenberger SV  (2) KSV 1919 · Kapfenberger SV 1919
- **Kirchberg/W., Niederösterreich** (1): USC Kirchberg/W.  (1) Kirchberg/W.
- **Kitzbühel, Tirol** (1): FC Kitzbühel  (1) Kitzbühel
- **Kufstein, Tirol** (1): FC Kufstein  (1) Kufstein
- **Lafnitz, Steiermark** (1): SV Lafnitz  (1) Lafnitz
- **Langenlois, Niederösterreich** (1): USV Langenlois  (1) Langenlois
- **Leoben, Steiermark** (1): DSV Leoben 
- **Leobendorf, Niederösterreich** (1): SV Leobendorf 
- **Mannsdorf an der Donau, Niederösterreich** (1): FC Marchfeld Donauauen  (2) Mannsdorf-Großenz. · SC Mannsdorf
- **Neusiedl am See, Burgenland** (1): SC Neusiedl am See  (3) SC Neusiedl · Neusiedl am See · SC Neusiedl am See 1919
- **Oberwart, Burgenland** (1): SV Oberwart 
- **Parndorf, Burgenland** (1): SC-ESV Parndorf  (4) Parndorf · SC-ESV Parndorf 1919 · SC/ESV Parndorf · SC/ESV Parndorf 1919
- **Schwaz, Tirol** (1): SC Schwaz  (1) Schwaz
- **Schwechat, Niederösterreich** (1): SV Schwechat  (1) Schwechat SV
- **Sollenau, Niederösterreich** (1): 1. SC Sollenau  (2) Sollenau · SC Sollenau
- **St. Anna am Aigen, Steiermark** (1): USV St. Anna  (1) St Anna am Aigen
- **St. Florian, Oberösterreich** (1): Union St. Florian  (1) St. Florian
- **St. Johann im Pongau, Salzburg** (1): TSV St. Johann  (2) TSV St. Johann Pongau · TSV St. Johann im Pongau
- **Stadl-Paura, Oberösterreich** (1): ATSV Stadl-Paura 
- **Stegersbach, Burgenland** (1): SV Stegersbach 
- **Steyr, Oberösterreich** (1): SK Vorwärts Steyr  (1) Vorwärts Steyr
- **Stripfing, Niederösterreich** (1): SV Stripfing 
- **Traiskirchen, Niederösterreich** (1): FCM Traiskirchen 
- **Villach, Kärnten** (1): Villacher SV 
- **Vöcklamarkt, Oberösterreich** (1): Union Vöcklamarkt  (1) Vöcklamarkt
- **Wattens, Tirol** (1): WSG Tirol  (7) Tirol · WSG Swarovski Tirol · WSG Swarovs. Tirol · Wattener Sportgemeinschaft Tirol · Wattens · WSG Wattens · WSG Swarovski Wattens
- **Weiz, Steiermark** (1): SC Weiz 
- **Wr. Neustadt, Niederösterreich** (1): SC Wiener Neustadt  (4) Neustadt · Wr. Neustadt · SC Wr. Neustadt · Wiener Neustadt
- **Zwentendorf, Niederösterreich** (1): SV Zwentendorf  (1) Zwentendorf
- ? (61): 
  - Technopool Admira  (1) Admira Technopool
  - SR Donaufeld  (2) Donaufeld · SR Donaufeld Wien
  - FC Stadlau 
  - SC Red Star Penzing 
  - SV Heiligenkreuz 
  - SC Pinkafeld 
  - SV Wimpassing  (1) Wimpassing
  - SC Ritzing  (1) Ritzing
  - SC Trausdorf 
  - ASK Bad Vöslau 
  - SC Retz 
  - SCU Ardagger  (1) Ardagger SCU
  - SV Gaflenz 
  - FC Rohrendorf/Gedersdorf  (1) SC Rohrendorf
  - SC Leopoldsdorf  (1) SC Leopoldsdorf i. Mfd.
  - ATSV Ober-Grafendorf  (1) Ober-Grafendorf
  - ASK Kottingbrunn 
  - ASV Spratzern 
  - SC Krems 
  - SC Guntersdorf  (1) Guntersdorf
  - SC Echsenbach  (2) Echsenbach · SC Hartl Haus
  - SC St. Martin  (1) St. Martin
  - SC Weißenkirchen  (1) Weißenkirchen
  - SV Rehberg  (1) Rehberg
  - SV Sieghartskirchen  (1) Sieghartskirchen
  - USC Schweiggers  (1) Schweiggers
  - USV Groß Gerungs  (1) Groß Gerungs
  - SV Wallern  (1) Wallern
  - SV Grün-Weiß Micheldorf  (2) Micheldorf · SV Micheldorf
  - FC Lankowitz  (1) FC Piberstein Lankowitz
  - SV Spittal/Drau 
  - FC St. Veit 
  - FC Lendorf  (1) Lendorf
  - ASV Annabichler SV 1923 
  - ASKÖ Köttmannsdorf 
  - VST Völkermarkt 
  - FC Liefering  (1) Liefering
  - SV Seekirchen  (1) SV Seekirchen 1945
  - FC Pinzgau Saalfelden  (1) Pinzgau Saalfelden
  - USK Anif 
  - SV Wals-Grünau 
  - SV Kuchl 
  - Bischofshofen Sportklub 1933 
  - TSV Neumarkt  (1) TSV Neumarkt am Wallersee
  - USC Eugendorf 
  - SC Golling 
  - SV Telfs 
  - SV Wörgl 
  - SC Imst 
  - SV Hall 
  - SVG Reichenau 
  - FC Zirl 
  - SV Reutte 
  - FC Höchst  (1) Höchst
  - VfB Hohenems  (1) Hohenems
  - FC Wolfurt  (1) Meusburger FC Wolfurt
  - FC Hard  (1) Hard
  - FC Langenegg  (1) SPG FC Langenegg
  - FC Lauterach 
  - RW Rankweil 
  - SC Röthis  (1) SC Röfix Röthis




By Region

- **Wien** (11):   SK Rapid Wien · SK Rapid Wien II · FK Austria Wien · Young Violets Austria Wien · SC Team Wiener Linien · Wiener Sport-Club · First Vienna FC · Floridsdorfer AC · Wiener Viktoria · FC Mauerwerk · SC Ostbahn XI
- **Burgenland** (7):   SV Mattersburg · SV Mattersburg II · SC Neusiedl am See · ASV Draßburg · SC-ESV Parndorf · SV Stegersbach · SV Oberwart
- **Niederösterreich** (21):   FC Admira Wacker Mödling · FC Admira Wacker Mödling II · SC Wiener Neustadt · SKN St. Pölten · SKN St. Pölten Juniors · SV Horn · Horn Amateure · SKU Amstetten · ASK Ebreichsdorf · FC Marchfeld Donauauen · SV Leobendorf · SV Stripfing · FCM Traiskirchen · ASK-BSC Bruck/Leitha · 1. SC Sollenau · SV Schwechat · SV Zwentendorf · USC Altenwörth · USC Grafenwörth · USC Kirchberg/W. · USV Langenlois
- **Oberösterreich** (14):   LASK Linz · FC Juniors OÖ · FC Pasching · FC Blau-Weiß Linz · FC Stahl Linz · SV Ried · SV Ried II · SK Vorwärts Steyr · FC Wels · WSC Hertha Wels · Union Vöcklamarkt · ATSV Stadl-Paura · Union Gurten · Union St. Florian
- **Steiermark** (15):   SK Sturm Graz · SK Sturm Graz II · Grazer AK · TSV Hartberg · Kapfenberger SV · SV Lafnitz · USV Allerheiligen · TuS Bad Gleichenberg · Deutschlandsberger SC · FC Gleisdorf 09 · SC Kalsdorf · USV St. Anna · SC Weiz · DSV Leoben · FC Gratkorn
- **Kärnten** (7):   Wolfsberger AC · Wolfsberger AC II · ATSV Wolfsberg · Austria Klagenfurt · Austria Kärnten (2007-2010) · SAK Klagenfurt · Villacher SV
- **Salzburg** (6):   FC RB Salzburg · FC RB Salzburg II · Austria Salzburg · SAK 1914 · SV Grödig · TSV St. Johann
- **Tirol** (7):   FC Wacker Innsbruck · FC Wacker Innsbruck II · SV Innsbruck · WSG Tirol · SC Schwaz · FC Kitzbühel · FC Kufstein
- **Vorarlberg** (8):   SCR Altach · SCR Altach Juniors · Austria Lustenau · Austria Lustenau Amateure · FC Lustenau 07 · FC Dornbirn 1913 · Dornbirner SV · SW Bregenz




By Year

- **1894** (1):   First Vienna FC
- **1899** (2):   SK Rapid Wien · LASK Linz
- **1904** (1):   Floridsdorfer AC
- **1905** (1):   FC Admira Wacker Mödling
- **1907** (1):   FC Lustenau 07
- **1908** (1):   SC Wiener Neustadt
- **1909** (1):   SK Sturm Graz
- **1911** (1):   FK Austria Wien
- **1912** (1):   SV Ried
- **1913** (1):   FC Wacker Innsbruck
- **1914** (2):   SAK 1914 · Austria Lustenau
- **1922** (2):   SV Mattersburg · SV Horn
- **1929** (1):   SCR Altach
- **1930** (1):   WSG Tirol
- **1931** (1):   Wolfsberger AC
- **1933** (1):   FC RB Salzburg
- **1946** (1):   TSV Hartberg
- **1947** (1):   FC Liefering
- **1948** (1):   SV Grödig
- **2000** (1):   SKN St. Pölten
- **2007** (1):   Austria Kärnten (2007-2010)
- ? (133):   SK Rapid Wien II · Young Violets Austria Wien · SC Team Wiener Linien · Wiener Sport-Club · Wiener Viktoria · FC Mauerwerk · SC Ostbahn XI · Technopool Admira · SR Donaufeld · FC Stadlau · SC Red Star Penzing · SV Mattersburg II · SC Neusiedl am See · ASV Draßburg · SC-ESV Parndorf · SV Stegersbach · SV Oberwart · SV Heiligenkreuz · SC Pinkafeld · SV Wimpassing · SC Ritzing · SC Trausdorf · FC Admira Wacker Mödling II · SKN St. Pölten Juniors · Horn Amateure · SKU Amstetten · ASK Ebreichsdorf · FC Marchfeld Donauauen · SV Leobendorf · SV Stripfing · FCM Traiskirchen · ASK-BSC Bruck/Leitha · 1. SC Sollenau · SV Schwechat · ASK Bad Vöslau · SC Retz · SCU Ardagger · SV Gaflenz · FC Rohrendorf/Gedersdorf · SC Leopoldsdorf · ATSV Ober-Grafendorf · ASK Kottingbrunn · ASV Spratzern · SC Krems · SC Guntersdorf · SC Echsenbach · SC St. Martin · SC Weißenkirchen · SV Rehberg · SV Sieghartskirchen · SV Zwentendorf · USC Altenwörth · USC Grafenwörth · USC Kirchberg/W. · USC Schweiggers · USV Groß Gerungs · USV Langenlois · FC Juniors OÖ · FC Pasching · FC Blau-Weiß Linz · FC Stahl Linz · SV Ried II · SK Vorwärts Steyr · FC Wels · WSC Hertha Wels · Union Vöcklamarkt · ATSV Stadl-Paura · Union Gurten · Union St. Florian · SV Wallern · SV Grün-Weiß Micheldorf · SK Sturm Graz II · Grazer AK · Kapfenberger SV · SV Lafnitz · USV Allerheiligen · TuS Bad Gleichenberg · Deutschlandsberger SC · FC Gleisdorf 09 · SC Kalsdorf · USV St. Anna · SC Weiz · DSV Leoben · FC Gratkorn · FC Lankowitz · Wolfsberger AC II · ATSV Wolfsberg · Austria Klagenfurt · SAK Klagenfurt · Villacher SV · SV Spittal/Drau · FC St. Veit · FC Lendorf · ASV Annabichler SV 1923 · ASKÖ Köttmannsdorf · VST Völkermarkt · FC RB Salzburg II · Austria Salzburg · SV Seekirchen · FC Pinzgau Saalfelden · USK Anif · TSV St. Johann · SV Wals-Grünau · SV Kuchl · Bischofshofen Sportklub 1933 · TSV Neumarkt · USC Eugendorf · SC Golling · FC Wacker Innsbruck II · SV Innsbruck · SC Schwaz · FC Kitzbühel · FC Kufstein · SV Telfs · SV Wörgl · SC Imst · SV Hall · SVG Reichenau · FC Zirl · SV Reutte · SCR Altach Juniors · Austria Lustenau Amateure · FC Dornbirn 1913 · Dornbirner SV · FC Höchst · VfB Hohenems · FC Wolfurt · SW Bregenz · FC Hard · FC Langenegg · FC Lauterach · RW Rankweil · SC Röthis




Historic

- **2010** (1):   Austria Kärnten (2007-2010)






By A to Z

- **1** (1): 1. SC Sollenau
- **A** (40): Admira · Altach · Austria · Altenwörth · A. Lustenau · A. Salzburg · Admira Wien · ASV Draßburg · Ardagger SCU · Austria Wien · A. Klagenfurt · ASV Spratzern · Admira Wacker · Allerheiligen · Amstetten SKU · AC Wolfsberger · ASK Bad Vöslau · ATSV Wolfsberg · Admira Juniors · Admira Amateure · Altach Amateure · Austria Wien A. · ASK Ebreichsdorf · ASK Kottingbrunn · ATSV Stadl-Paura · Austria Lustenau · Austria Salzburg · Admira Technopool · ASKÖ Köttmannsdorf · Austria Klagenfurt · Austria Lustenau A · Austria Wien Amat. · Austria Vienna [en] · ASK-BSC Bruck/Leitha · ATSV Ober-Grafendorf · Admira Wacker Mödling · Ausstria Wien Amateure · ASV Annabichler SV 1923 · Austria Lustenau Amateure · Austria Kärnten (2007-2010)
- **B** (5): BW Linz · Bruck/Leitha · Blau-Weiß Linz · Bad Gleichenberg · Bischofshofen Sportklub 1933
- **D** (7): Dornbirn · Donaufeld · DSV Leoben · Dornbirner SV · Deutschlandsberg · Deutschlandsberger SC · Dornbirner Sportverein
- **E** (1): Echsenbach
- **F** (56): FC Hard · FC Linz · FC Wels · FC Zirl · FC Tirol · FC Admira · FC Höchst · FC Wacker · FC Kärnten · FC Lendorf · FC Stadlau · FC Wolfurt · FC Dornbirn · FC Gratkorn · FC Kufstein · FC Lustenau · FC Pasching · FC Salzburg · FC St. Veit · FC Gleisdorf · FC Kitzbühel · FC Langenegg · FC Lankowitz · FC Lauterach · FC Liefering · FC Mauerwerk · FC Juniors OÖ · FC Stahl Linz · FC Lustenau 07 · FC RB Salzburg · FC Gleisdorf 09 · FK Austria Wien · First Vienna FC · FC Admira Wacker · FC Dornbirn 1913 · FC Lustenau 1907 · FCM Traiskirchen · Floridsdorfer AC · FAC Team für Wien · FC Blau-Weiß Linz · FC RB Salzburg II · FC Tirol Innsbruck · FK Austria Wien II · FC Admira Wacker II · FC Wacker Innsbruck · FC Red Bull Salzburg · First Vienna FC 1894 · FC Pinzgau Saalfelden · FC Marchfeld Donauauen · FC RB Juniors Salzburg · FC Wacker Innsbruck II · FC Piberstein Lankowitz · FC Red Bull Salzburg II · FC Admira Wacker Mödling · FC Rohrendorf/Gedersdorf · FC Admira Wacker Mödling II
- **G** (6): Grödig · Gurten · Grazer AK · Grafenwörth · Guntersdorf · Groß Gerungs
- **H** (5): Hard · Höchst · Hartberg · Hohenems · Horn Amateure
- **I** (1): Innsbruck
- **J** (1): Juniors OÖ
- **K** (7): KSV 1919 · Kalsdorf · Kufstein · Kitzbühel · Kirchberg/W. · Kapfenberger SV · Kapfenberger SV 1919
- **L** (7): LASK · Lafnitz · Lendorf · LASK Linz · Liefering · Langenlois · Linzer ASK
- **M** (4): Micheldorf · Mattersburg · Mannsdorf-Großenz. · Meusburger FC Wolfurt
- **N** (2): Neustadt · Neusiedl am See
- **O** (1): Ober-Grafendorf
- **P** (3): Parndorf · Pasching · Pinzgau Saalfelden
- **R** (13): Ried · Rapid · Rehberg · Ritzing · Rapid Wien · RB Salzburg · RW Rankweil · RB Salzburg II · RZ Pellets WAC · Rapid Wien Am. · Rheindorf Altach · Rapid Vienna [en] · Red Bull Salzburg
- **S** (127): Sturm · Schwaz · SC Imst · SC Retz · SC Weiz · SV Hall · SV Horn · SV Ried · SAK 1914 · SC Krems · SV Kuchl · SV Telfs · SV Wörgl · Salzburg · Sollenau · SC Röthis · SC Schwaz · SV Grödig · SV Reutte · SC Bregenz · SC Golling · SC Ritzing · SCR Altach · SV Gaflenz · SV Lafnitz · SV Rehberg · SV Ried II · SV Wallern · SW Bregenz · St. Martin · St. Pölten · Sturm Graz · SC Kalsdorf · SC Neusiedl · SC Sollenau · SV Oberwart · Schweiggers · St. Florian · SC Mannsdorf · SC Pinkafeld · SC Trausdorf · SCU Ardagger · SR Donaufeld · SV Innsbruck · SV Schwechat · SV Stripfing · Schwechat SV · SC Echsenbach · SC Hartl Haus · SC Ostbahn XI · SC Rohrendorf · SC St. Martin · SK Rapid Wien · SK Sturm Graz · SK VOEST Linz · SKU Amstetten · SSW Innsbruck · SV Josko Ried · SV Leobendorf · SV Micheldorf · SV Seekirchen · SV Wimpassing · SVG Reichenau · SAK Klagenfurt · SC Guntersdorf · SKN St. Pölten · SV Mattersburg · SV Stegersbach · SV Wals-Grünau · SV Zwentendorf · SC Leopoldsdorf · SC Röfix Röthis · SC Wr. Neustadt · SC-ESV Parndorf · SC/ESV Parndorf · SV Spittal/Drau · Slowenischer AK · SC Weißenkirchen · SK Rapid Wien II · SK Sturm Graz II · SKN Sankt Pölten · SPG FC Langenegg · SV Allerheiligen · SV Heiligenkreuz · Sieghartskirchen · St Anna am Aigen · Sturm Graz Amat. · SAK 1914 Salzburg · SK Rapid Amateure · SK Vorwärts Steyr · SR Donaufeld Wien · SV Mattersburg II · SC Neusiedl am See · SC Team Wr. Linien · SC Wiener Neustadt · SC Wiener Viktoria · SCR Altach Juniors · SK Austria Kärnten · SV Mattersburg Am. · SV Seekirchen 1945 · Salzburger AK 1914 · SC Austria Lustenau · SC Red Star Penzing · SC Rheindorf Altach · SV Austria Salzburg · SV Sieghartskirchen · SC-ESV Parndorf 1919 · SC/ESV Parndorf 1919 · SC Team Wiener Linien · SG Austria Klagenfurt · SK Admira Vienna [en] · SK Admira Wacker Wien · SK Austria Klagenfurt · SV Josko Fenster Ried · SAK Celovec/Klagenfurt · SKN St. Pölten Juniors · SC Leopoldsdorf i. Mfd. · SC Neusiedl am See 1919 · SC Schwarz-Weiß Bregenz · SV Grün-Weiß Micheldorf · SV Mattersburg Amateure · Slovenski atletski klub · Sportclub Rheindorf Altach · SC Austria Lustenau Amateure · Sportvereinigung Mattersburg · Sportklub Niederösterreich St. Pölten · Spielgemeinschaft Swarovski Wacker Innsbruck
- **T** (13): TSV · Tirol · TSV Hartberg · TSV Neumarkt · TSV St. Johann · Technopool Admira · Team Wiener Linien · TuS Bad Gleichenberg · TSV St. Johann Pongau · TSV Sparkasse Hartberg · TSV St. Johann im Pongau · TSV Neumarkt am Wallersee · Turn- und Sportverein Hartberg
- **U** (13): USK Anif · USV St. Anna · Union Gurten · USC Eugendorf · USC Altenwörth · USV Langenlois · USC Grafenwörth · USC Schweiggers · USC Kirchberg/W. · USV Groß Gerungs · USV Allerheiligen · Union St. Florian · Union Vöcklamarkt
- **V** (7): Vienna · Vöcklamarkt · VfB Hohenems · Villacher SV · Vienna FC 1894 · Vorwärts Steyr · VST Völkermarkt
- **W** (27): Wallern · Wattens · WSG Tirol · Wiener SC · Wiener SK · Wolfsberg · Wimpassing · WSG Wattens · Wolfsberger · WAC Amateure · Wr. Neustadt · Weißenkirchen · Wr. Sportklub · Wolfsberger AC · WSC Hertha Wels · Wiener Neustadt · Wiener Viktoria · Wacker Innsbruck · Wiener Sportklub · Wiener Sport-Club · Wolfsberger AC II · WSG Swarovs. Tirol · WSG Swarovski Tirol · Wacker Innsbruck II · WSG Swarovski Wattens · Wolfsberger Athletik Club · Wattener Sportgemeinschaft Tirol
- **Y** (3): Young Violets · Young Violets A. W. · Young Violets Austria Wien
- **Z** (1): Zwentendorf




