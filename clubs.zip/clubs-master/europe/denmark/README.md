50 clubs

- [**FC København**](https://en.wikipedia.org/wiki/F.C._Copenhagen) : (4) København · FC Copenhagen [en] · FC Kopenhagen [de] · Football Club København ⇒ (3) ≈Kobenhavn≈ · ≈FC Kobenhavn≈ · ≈Football Club Kobenhavn≈
- **B 1903 København (1903-1992)** : (2) B 1903 · Boldklubben 1903 ⇒ (1) ≈B 1903 Kobenhavn≈
- **KB København (1876-1992)** : (4) KB · Kjøbenhavns BK · Kjøbenhavns Boldklub · Kjöbenhavns Boldklub ⇒ (5) ≈KB Kobenhavn≈ · ≈Kjobenhavns BK≈ · ≈Kjobenhavns Boldklub≈ · ≈Kjobenhavns Boldklub≈ · ≈Kjoebenhavns Boldklub≈
- **B93 København** : (2) B.93 · Boldklubben 1893 ⇒ (1) ≈B93 Kobenhavn≈
- **BK Fremad Amager** : (1) Fremad Amager
- **Brønshøj BK** : (2) Brönshöj BK [de] · Brønshøj Boldklub ⇒ (4) ≈Bronshoj BK≈ · ≈Bronshoj BK≈ · ≈Broenshoej BK≈ · ≈Bronshoj Boldklub≈
- **B 1908 Amager** : (2) B.1908 · Boldklubben 1908
- **Vanløse IF** : (1) Vanlöse IF [de] ⇒ (3) ≈Vanlose IF≈ · ≈Vanlose IF≈ · ≈Vanloese IF≈
- **BK Frem** : (4) Frem København · Boldklubben Frem · BK Frem København · BK Frem Copenhagen ⇒ (2) ≈Frem Kobenhavn≈ · ≈BK Frem Kobenhavn≈
- **Akademisk Boldklub** : (4) AB Gladsaxe · Akademisk BK · AB København · Akademisk Boldklub Gladsaxe ⇒ (1) ≈AB Kobenhavn≈
- [**Brøndby IF**](https://en.wikipedia.org/wiki/Brøndby_IF) : (2) Brøndby · Brøndbyernes Idrætsforening ⇒ (3) ≈Brondby≈ · ≈Brondby IF≈ · ≈Brondbyernes Idraetsforening≈
- [**FC Nordsjælland**](https://en.wikipedia.org/wiki/FC_Nordsjælland) : (2) Nordsjælland · Football Club Nordsjælland ⇒ (3) ≈Nordsjaelland≈ · ≈FC Nordsjaelland≈ · ≈Football Club Nordsjaelland≈
- **FC Helsingør** : (1) Helsingør ⇒ (2) ≈Helsingor≈ · ≈FC Helsingor≈
- **Lyngby BK** : (2) Lyngby · Lyngby Boldklub
- [**Aalborg BK**](https://en.wikipedia.org/wiki/Aalborg_Boldspilklub) : (4) AaB · Aalborg · AaB Aalborg · Aalborg Boldspilklub
- [**Hobro IK**](https://en.wikipedia.org/wiki/Hobro_IK) : (2) Hobro · Hobro Idræts Klub ⇒ (1) ≈Hobro Idraets Klub≈
- **Vendsyssel FF** : (1) Vendsyssel
- [**FC Midtjylland**](https://en.wikipedia.org/wiki/FC_Midtjylland) : (2) Midtjylland · Football Club Midtjylland
- **Ikast FS (1935-1999)** : (2) IFS · Ikast Forenede Sportsklubber
- [**AGF Aarhus**](https://en.wikipedia.org/wiki/Aarhus_Gymnastikforening) : (4) AGF · Aarhus · Aarhus GF · Aarhus Gymnastikforening
- [**Viborg FF**](https://en.wikipedia.org/wiki/Viborg_FF) : (2) Viborg · Viborg Fodsports Forening
- **AC Horsens** : (1) Horsens
- **Silkeborg IF** : (3) SIF · Silkeborg · Silkeborg Idrætsforening ⇒ (1) ≈Silkeborg Idraetsforening≈
- [**Randers FC**](https://en.wikipedia.org/wiki/Randers_FC) : (2) Randers · Randers Football Club
- **Randers Freja** : (1) Randers Sportsklub Freja
- [**Sønderjysk Elitesport**](https://en.wikipedia.org/wiki/SønderjyskE_Fodbold) : (2) SønderjyskE · SønderjyskE Fodbold ⇒ (3) ≈SonderjyskE≈ · ≈SonderjyskE Fodbold≈ · ≈Sonderjysk Elitesport≈
- [**Odense BK**](https://en.wikipedia.org/wiki/Odense_Boldklub) : (4) OB · Odense · OB Odense · Odense Boldklub
- **B 1909 Odense** : (2) B 1909 · Boldklubben 1909
- **B 1913 Odense** : (2) B 1913 · Boldklubben 1913
- [**Esbjerg fB**](https://en.wikipedia.org/wiki/Esbjerg_fB) : (2) Esbjerg · Esbjerg forenede Boldklubber
- **Vejle** : (2) Vejle BK · Vejle Boldklub
- **FC Vestsjælland** : (1) Vestsjælland ⇒ (2) ≈Vestsjaelland≈ · ≈FC Vestsjaelland≈
- **HB Køge** : (1) HB Köge [de] ⇒ (3) ≈HB Koge≈ · ≈HB Koge≈ · ≈HB Koege≈
- **Herfølge BK (1921-2009)** : (1) Herfølge Boldklub ⇒ (2) ≈Herfolge BK≈ · ≈Herfolge Boldklub≈
- **Køge BK (1927-2009)** : (1) Køge Boldklub ⇒ (2) ≈Koge BK≈ · ≈Koge Boldklub≈
- **Holbæk B&I** : (1) Holbæk Bold- & Idrætsforening ⇒ (2) ≈Holbaek B&I≈ · ≈Holbaek Bold- & Idraetsforening≈
- **FC Fredericia**
- **Skive IK**
- **Kolding IF**
- **FC Roskilde**
- **Hvidovre IF**
- **Nykøbing FC** : (1) Nyköbing FC [de] ⇒ (3) ≈Nykobing FC≈ · ≈Nykobing FC≈ · ≈Nykoebing FC≈
- **Næstved BK** : (1) Næstved IF ⇒ (2) ≈Naestved BK≈ · ≈Naestved IF≈
- **Hillerød Fodbold** : (1) Hilleröd Fodbold [de] ⇒ (3) ≈Hillerod Fodbold≈ · ≈Hillerod Fodbold≈ · ≈Hilleroed Fodbold≈
- **Middelfart BK** : (1) Middelfart G&BK
- **Varde IF**
- **Thisted FC**
- **Viby IF**
- **Hellerup IK** : (2) HIK · HIK Hellerup
- **B 1901 Nykøbing (1901-1994)** : (1) B1901 Nyköbing ⇒ (3) ≈B1901 Nykobing≈ · ≈B 1901 Nykobing≈ · ≈B1901 Nykoebing≈




Alphabet

- **Alphabet Specials** (3):  **æ**  **ö**  **ø** 
  - **æ**×13 U+00E6 (230) - LATIN SMALL LETTER AE ⇒ ae
  - **ö**×8 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ø**×32 U+00F8 (248) - LATIN SMALL LETTER O WITH STROKE ⇒ o




Duplicates

- **KB København (1876-1992)**, København (1):
  - `kjobenhavnsboldklub` (2): **Kjobenhavns Boldklub** · **Kjobenhavns Boldklub**
- **Brønshøj BK**, København (1):
  - `bronshojbk` (2): **Bronshoj BK** · **Bronshoj BK**
- **Vanløse IF**, København (1):
  - `vanloseif` (2): **Vanlose IF** · **Vanlose IF**
- **HB Køge**, Køge (1):
  - `hbkoge` (2): **HB Koge** · **HB Koge**
- **Nykøbing FC**, Nykøbing Falster (1):
  - `nykobingfc` (2): **Nykobing FC** · **Nykobing FC**
- **Hillerød Fodbold**, Hillerød (1):
  - `hillerodfodbold` (2): **Hillerod Fodbold** · **Hillerod Fodbold**
- **B 1901 Nykøbing (1901-1994)**, Nykøbing Falster (1):
  - `b1901nykobing` (2): B 1901 Nykobing · B1901 Nykobing




By City

- **København, Hovedstaden** (8): 
  - FC København  (4) København · Football Club København · FC Copenhagen [en] · FC Kopenhagen [de]
  - B 1903 København (1903-1992)  (2) B 1903 · Boldklubben 1903
  - KB København (1876-1992)  (4) KB · Kjøbenhavns BK · Kjøbenhavns Boldklub · Kjöbenhavns Boldklub
  - B93 København  (2) B.93 · Boldklubben 1893
  - BK Fremad Amager  (1) Fremad Amager
  - Brønshøj BK  (2) Brønshøj Boldklub · Brönshöj BK [de]
  - B 1908 Amager  (2) B.1908 · Boldklubben 1908
  - Vanløse IF  (1) Vanlöse IF [de]
- **Køge** (3): 
  - HB Køge  (1) HB Köge [de]
  - Herfølge BK (1921-2009)  (1) Herfølge Boldklub
  - Køge BK (1927-2009)  (1) Køge Boldklub
- **Odense, Syddanmark** (3): 
  - Odense BK  (4) OB · Odense · Odense Boldklub · OB Odense
  - B 1909 Odense  (2) B 1909 · Boldklubben 1909
  - B 1913 Odense  (2) B 1913 · Boldklubben 1913
- **Nykøbing Falster** (2): 
  - Nykøbing FC  (1) Nyköbing FC [de]
  - B 1901 Nykøbing (1901-1994)  (1) B1901 Nyköbing
- **Randers, Østjylland** (2): 
  - Randers FC  (2) Randers · Randers Football Club
  - Randers Freja  (1) Randers Sportsklub Freja
- **1886 København, Hovedstaden** (1): BK Frem  (4) Boldklubben Frem · Frem København · BK Frem København · BK Frem Copenhagen
- **Aalborg, Nordjylland** (1): Aalborg BK  (4) AaB · Aalborg · AaB Aalborg · Aalborg Boldspilklub
- **Aarhus, Midtjylland** (1): AGF Aarhus  (4) AGF · Aarhus · Aarhus GF · Aarhus Gymnastikforening
- **Brøndbyvester, Hovedstaden** (1): Brøndby IF  (2) Brøndby · Brøndbyernes Idrætsforening
- **Esbjerg, Syddanmark** (1): Esbjerg fB  (2) Esbjerg · Esbjerg forenede Boldklubber
- **Farum, Hovedstaden** (1): FC Nordsjælland  (2) Nordsjælland · Football Club Nordsjælland
- **Fredericia** (1): FC Fredericia 
- **Gladsaxe, Hovedstaden** (1): Akademisk Boldklub  (4) AB Gladsaxe · Akademisk Boldklub Gladsaxe · Akademisk BK · AB København
- **Haderslev, Syddanmark** (1): Sønderjysk Elitesport  (2) SønderjyskE · SønderjyskE Fodbold
- **Hellerup** (1): Hellerup IK  (2) HIK · HIK Hellerup
- **Helsingør, Hovedstaden** (1): FC Helsingør  (1) Helsingør
- **Herning, Midtjylland** (1): FC Midtjylland  (2) Midtjylland · Football Club Midtjylland
- **Hillerød** (1): Hillerød Fodbold  (1) Hilleröd Fodbold [de]
- **Hjørring, Nordjylland** (1): Vendsyssel FF  (1) Vendsyssel
- **Hobro, Nordjylland** (1): Hobro IK  (2) Hobro · Hobro Idræts Klub
- **Holbæk** (1): Holbæk B&I  (1) Holbæk Bold- & Idrætsforening
- **Horsens, Midtjylland** (1): AC Horsens  (1) Horsens
- **Hvidovre** (1): Hvidovre IF 
- **Ikast, Midtjylland** (1): Ikast FS (1935-1999)  (2) IFS · Ikast Forenede Sportsklubber
- **Kolding** (1): Kolding IF 
- **Lyngby, Hovedstaden** (1): Lyngby BK  (2) Lyngby · Lyngby Boldklub
- **Middelfart** (1): Middelfart BK  (1) Middelfart G&BK
- **Næstved** (1): Næstved BK  (1) Næstved IF
- **Roskilde** (1): FC Roskilde 
- **Silkeborg, Midtjylland** (1): Silkeborg IF  (3) Silkeborg · SIF · Silkeborg Idrætsforening
- **Skive** (1): Skive IK 
- **Slagelse, Sjælland** (1): FC Vestsjælland  (1) Vestsjælland
- **Thisted** (1): Thisted FC 
- **Varde** (1): Varde IF 
- **Vejle, Syddanmark** (1): Vejle  (2) Vejle BK · Vejle Boldklub
- **Viborg, Midtjylland** (1): Viborg FF  (2) Viborg · Viborg Fodsports Forening
- **Viby** (1): Viby IF 




By Region

- **Hovedstaden** (14):   FC København · B 1903 København (1903-1992) · KB København (1876-1992) · B93 København · BK Fremad Amager · Brønshøj BK · B 1908 Amager · Vanløse IF · BK Frem · Akademisk Boldklub · Brøndby IF · FC Nordsjælland · FC Helsingør · Lyngby BK
- **Nordjylland** (3):   Aalborg BK · Hobro IK · Vendsyssel FF
- **Midtjylland** (6):   FC Midtjylland · Ikast FS (1935-1999) · AGF Aarhus · Viborg FF · AC Horsens · Silkeborg IF
- **Østjylland** (2):   Randers FC · Randers Freja
- **Syddanmark** (6):   Sønderjysk Elitesport · Odense BK · B 1909 Odense · B 1913 Odense · Esbjerg fB · Vejle
- **Sjælland** (1):   FC Vestsjælland
- **Køge†** (3):   HB Køge · Herfølge BK (1921-2009) · Køge BK (1927-2009)
- **Holbæk†** (1):   Holbæk B&I
- **Fredericia†** (1):   FC Fredericia
- **Skive†** (1):   Skive IK
- **Kolding†** (1):   Kolding IF
- **Roskilde†** (1):   FC Roskilde
- **Hvidovre†** (1):   Hvidovre IF
- **Nykøbing Falster†** (2):   Nykøbing FC · B 1901 Nykøbing (1901-1994)
- **Næstved†** (1):   Næstved BK
- **Hillerød†** (1):   Hillerød Fodbold
- **Middelfart†** (1):   Middelfart BK
- **Varde†** (1):   Varde IF
- **Thisted†** (1):   Thisted FC
- **Viby†** (1):   Viby IF
- **Hellerup†** (1):   Hellerup IK




By Year

- **1876** (1):   KB København (1876-1992)
- **1880** (1):   AGF Aarhus
- **1885** (1):   Aalborg BK
- **1887** (1):   Odense BK
- **1891** (1):   Vejle
- **1893** (1):   B93 København
- **1896** (1):   Viborg FF
- **1901** (1):   B 1901 Nykøbing (1901-1994)
- **1903** (1):   B 1903 København (1903-1992)
- **1913** (1):   Hobro IK
- **1917** (1):   Silkeborg IF
- **1921** (2):   Lyngby BK · Herfølge BK (1921-2009)
- **1924** (1):   Esbjerg fB
- **1927** (1):   Køge BK (1927-2009)
- **1931** (1):   Holbæk B&I
- **1935** (1):   Ikast FS (1935-1999)
- **1964** (1):   Brøndby IF
- **1991** (1):   FC Nordsjælland
- **1992** (1):   FC København
- **1999** (1):   FC Midtjylland
- **2003** (1):   Randers FC
- **2004** (1):   Sønderjysk Elitesport
- **2005** (1):   FC Helsingør
- **2009** (1):   HB Køge
- ? (25):   BK Fremad Amager · Brønshøj BK · B 1908 Amager · Vanløse IF · BK Frem · Akademisk Boldklub · Vendsyssel FF · AC Horsens · Randers Freja · B 1909 Odense · B 1913 Odense · FC Vestsjælland · FC Fredericia · Skive IK · Kolding IF · FC Roskilde · Hvidovre IF · Nykøbing FC · Næstved BK · Hillerød Fodbold · Middelfart BK · Varde IF · Thisted FC · Viby IF · Hellerup IK




Historic

- **1992** (2):   B 1903 København (1903-1992) · KB København (1876-1992)
- **1994** (1):   B 1901 Nykøbing (1901-1994)
- **1999** (1):   Ikast FS (1935-1999)
- **2009** (2):   Herfølge BK (1921-2009) · Køge BK (1927-2009)






By A to Z

- **A** (16): AGF · AaB · Aarhus · Aalborg · Aarhus GF · AC Horsens · AGF Aarhus · Aalborg BK · AB Gladsaxe · AaB Aalborg · AB København · Akademisk BK · Akademisk Boldklub · Aalborg Boldspilklub · Aarhus Gymnastikforening · Akademisk Boldklub Gladsaxe
- **B** (28): B.93 · B 1903 · B 1909 · B 1913 · B.1908 · BK Frem · Brøndby · Brøndby IF · Brønshøj BK · B 1908 Amager · B 1909 Odense · B 1913 Odense · B93 København · B1901 Nyköbing · BK Fremad Amager · Boldklubben 1893 · Boldklubben 1903 · Boldklubben 1908 · Boldklubben 1909 · Boldklubben 1913 · Boldklubben Frem · Brönshöj BK [de] · BK Frem København · Brønshøj Boldklub · BK Frem Copenhagen · B 1901 Nykøbing (1901-1994) · Brøndbyernes Idrætsforening · B 1903 København (1903-1992)
- **E** (3): Esbjerg · Esbjerg fB · Esbjerg forenede Boldklubber
- **F** (14): FC Roskilde · FC Helsingør · FC København · FC Fredericia · Fremad Amager · FC Midtjylland · Frem København · FC Nordsjælland · FC Vestsjælland · FC Copenhagen [en] · FC Kopenhagen [de] · Football Club København · Football Club Midtjylland · Football Club Nordsjælland
- **H** (17): HIK · Hobro · HB Køge · Horsens · Hobro IK · Helsingør · Holbæk B&I · Hellerup IK · Hvidovre IF · HB Köge [de] · HIK Hellerup · Hillerød Fodbold · Herfølge Boldklub · Hobro Idræts Klub · Hilleröd Fodbold [de] · Herfølge BK (1921-2009) · Holbæk Bold- & Idrætsforening
- **I** (3): IFS · Ikast FS (1935-1999) · Ikast Forenede Sportsklubber
- **K** (9): KB · København · Kolding IF · Køge Boldklub · Kjøbenhavns BK · Køge BK (1927-2009) · Kjöbenhavns Boldklub · Kjøbenhavns Boldklub · KB København (1876-1992)
- **L** (3): Lyngby · Lyngby BK · Lyngby Boldklub
- **M** (3): Midtjylland · Middelfart BK · Middelfart G&BK
- **N** (5): Næstved BK · Næstved IF · Nykøbing FC · Nordsjælland · Nyköbing FC [de]
- **O** (5): OB · Odense · OB Odense · Odense BK · Odense Boldklub
- **R** (5): Randers · Randers FC · Randers Freja · Randers Football Club · Randers Sportsklub Freja
- **S** (8): SIF · Skive IK · Silkeborg · SønderjyskE · Silkeborg IF · SønderjyskE Fodbold · Sønderjysk Elitesport · Silkeborg Idrætsforening
- **T** (1): Thisted FC
- **V** (13): Vejle · Viborg · Viby IF · Varde IF · Vejle BK · Viborg FF · Vanløse IF · Vendsyssel · Vestsjælland · Vendsyssel FF · Vejle Boldklub · Vanlöse IF [de] · Viborg Fodsports Forening




