63 clubs

- [**Fenerbahçe İstanbul SK**](https://en.wikipedia.org/wiki/Fenerbahçe_S.K._(football)) : (5) Fenerbahçe · Fenerbahçe SK · Fenerbahçe İstanbul · Fenerbahçe Sports Club · Fenerbahçe Spor Kulübü ⇒ (7) ≈Fenerbahce≈ · ≈Fenerbahce SK≈ · ≈Fenerbahce Istanbul≈ · ≈Fenerbahce Spor Kulubu≈ · ≈Fenerbahce Istanbul SK≈ · ≈Fenerbahce Sports Club≈ · ≈Fenerbahçe Spor Kuluebue≈
- [**Galatasaray İstanbul AŞ**](https://en.wikipedia.org/wiki/Galatasaray_S.K._(football)) : (5) Galatasaray · Galatasaray AŞ · Galatasaray SK · Galatasar. İstanbul · Galatasaray İstanbul ⇒ (4) ≈Galatasaray AS≈ · ≈Galatasar. Istanbul≈ · ≈Galatasaray Istanbul≈ · ≈Galatasaray Istanbul AS≈
- [**Beşiktaş İstanbul JK**](https://en.wikipedia.org/wiki/Beşiktaş_J.K.) : (4) Beşiktaş · Beşiktaş JK · Beşiktaş İst. · Beşiktaş İstanbul ⇒ (5) ≈Besiktas≈ · ≈Besiktas JK≈ · ≈Besiktas Ist.≈ · ≈Besiktas Istanbul≈ · ≈Besiktas Istanbul JK≈
- [**Kasımpaşa İstanbul SK**](https://en.wikipedia.org/wiki/Kasımpaşa_S.K.) : (3) Kasımpaşa · Kasımpaşa SK · Kasımpaşa İstanbul ⇒ (4) ≈Kasimpasa≈ · ≈Kasimpasa SK≈ · ≈Kasimpasa Istanbul≈ · ≈Kasimpasa Istanbul SK≈
- [**İstanbul Başakşehir**](https://en.wikipedia.org/wiki/İstanbul_Başakşehir_F.K.) : (8) Başakşehir · Büyükşehyr · İst. Başakş · İ. Başakşehir · İstanb. Başakşehir · İstanbul Başakşeh. · İstanbul Başakşehir FK · İstanbul Büyükşehir Belediyespor ⇒ (11) ≈Buyuksehyr≈ · ≈Basaksehir≈ · ≈Ist. Basaks≈ · ≈Bueyuekşehyr≈ · ≈I. Basaksehir≈ · ≈Istanb. Basaksehir≈ · ≈Istanbul Basakseh.≈ · ≈Istanbul Basaksehir≈ · ≈Istanbul Basaksehir FK≈ · ≈Istanbul Buyuksehir Belediyespor≈ · ≈İstanbul Bueyuekşehir Belediyespor≈
- **İstanbulspor** : (1) İstanbulspor AS ⇒ (2) ≈Istanbulspor≈ · ≈Istanbulspor AS≈
- **Sarıyer SK** : (2) Sarıyer · Sarıyer Spor Kulübü ⇒ (4) ≈Sariyer≈ · ≈Sariyer SK≈ · ≈Sariyer Spor Kulubu≈ · ≈Sarıyer Spor Kuluebue≈
- **Zeytinburnuspor** : (2) Zeytinburnu · Zeytinburnu SK
- **Fatih Karagümrük** : (1) Fatih Karagümrük SK ⇒ (4) ≈Fatih Karagumruk≈ · ≈Fatih Karaguemruek≈ · ≈Fatih Karagumruk SK≈ · ≈Fatih Karaguemruek SK≈
- **Tuzlaspor**
- **Ümraniyespor** : (2) CG Ümraniyespor · Ümraniyespor Kulubu ⇒ (6) ≈Umraniyespor≈ · ≈UEmraniyespor≈ · ≈CG Umraniyespor≈ · ≈CG UEmraniyespor≈ · ≈Umraniyespor Kulubu≈ · ≈UEmraniyespor Kulubu≈
- **Gençlerbirliği Ankara SK** : (4) Gençlerbirliği · Gençlerbirliği SK · Gençlerbirliği Ankara · Gençlerbirliği Spor Kulübü ⇒ (6) ≈Genclerbirligi≈ · ≈Genclerbirligi SK≈ · ≈Genclerbirligi Ankara≈ · ≈Genclerbirligi Ankara SK≈ · ≈Genclerbirligi Spor Kulubu≈ · ≈Gençlerbirliği Spor Kuluebue≈
- **Osmanlıspor Ankara** : (4) Ankaraspor · Osmanlıspor · Ankaraspor AŞ · Osmanlıspor FK ⇒ (4) ≈Osmanlispor≈ · ≈Ankaraspor AS≈ · ≈Osmanlispor FK≈ · ≈Osmanlispor Ankara≈
- [**MKE Ankaragücü**](https://en.wikipedia.org/wiki/MKE_Ankaragücü) : (1) Ankaragücü ⇒ (4) ≈Ankaragucu≈ · ≈Ankaraguecue≈ · ≈MKE Ankaragucu≈ · ≈MKE Ankaraguecue≈
- **Hacettepespor** : (5) OFTAŞ · Oftasspor · Hacettepe · Hacettepe SK · Hacettepe Spor Kulübü ⇒ (3) ≈OFTAS≈ · ≈Hacettepe Spor Kulubu≈ · ≈Hacettepe Spor Kuluebue≈
- **Turanspor** : (2) Şekerspor · Beypazarı Şekerspor ⇒ (2) ≈Sekerspor≈ · ≈Beypazari Sekerspor≈
- **Petrol Ofisi SK (1954-2010)** : (2) P. Ofisi · Petrol Ofisi
- **Keçiörengücü** : (2) Keçiörengücü SK · Keciöerengücü [de] ⇒ (6) ≈Keciorengucu≈ · ≈Kecioerengucu≈ · ≈Keçioerenguecue≈ · ≈Keciorengucu SK≈ · ≈Kecioeerenguecue≈ · ≈Keçioerenguecue SK≈
- **Kardemir Karabükspor** : (1) Karabükspor ⇒ (4) ≈Karabukspor≈ · ≈Karabuekspor≈ · ≈Kardemir Karabukspor≈ · ≈Kardemir Karabuekspor≈
- **Elazığspor** ⇒ (1) ≈Elazigspor≈
- **Eskişehirspor** ⇒ (1) ≈Eskisehirspor≈
- [**Akhisarspor**](https://en.wikipedia.org/wiki/Akhisar_Belediyespor) : (5) Akhisar · Akhisar Bld.spor · Akhisar Belediye · Akhisar Belediyespor · Akhisar Belediye Gençlik ve Spor Kulübü ⇒ (2) ≈Akhisar Belediye Genclik ve Spor Kulubu≈ · ≈Akhisar Belediye Gençlik ve Spor Kuluebue≈
- [**Alanyaspor**](https://en.wikipedia.org/wiki/Alanyaspor)
- [**Antalyaspor**](https://en.wikipedia.org/wiki/Antalyaspor) : (4) Antalya · Antalyaspor AS · MP Antalyaspor · Antalyaspor Kulübü ⇒ (2) ≈Antalyaspor Kulubu≈ · ≈Antalyaspor Kuluebue≈
- [**Bursaspor**](https://en.wikipedia.org/wiki/Bursaspor) : (1) Bursaspor SK
- [**Göztepe İzmir**](https://en.wikipedia.org/wiki/Göztepe_S.K.) : (5) Göztep · Göztepe · Göztepe SK · Göztepe AŞ · Göztepespor ⇒ (12) ≈Goztep≈ · ≈Goztepe≈ · ≈Goeztep≈ · ≈Goeztepe≈ · ≈Goztepe AS≈ · ≈Goztepe SK≈ · ≈Goztepespor≈ · ≈Goeztepe SK≈ · ≈Goeztepe AŞ≈ · ≈Goeztepespor≈ · ≈Goztepe Izmir≈ · ≈Goeztepe İzmir≈
- **Bucaspor** : (1) Bucaspor Kulübü ⇒ (2) ≈Bucaspor Kulubu≈ · ≈Bucaspor Kuluebue≈
- **Altay SK** : (4) Altay · Altay GK · Altay İzmir · Altay Spor Kulübü ⇒ (3) ≈Altay Izmir≈ · ≈Altay Spor Kulubu≈ · ≈Altay Spor Kuluebue≈
- **Karşıyaka SK** : (2) Karşıyaka · Karşıyaka Spor Kulübü ⇒ (4) ≈Karsiyaka≈ · ≈Karsiyaka SK≈ · ≈Karsiyaka Spor Kulubu≈ · ≈Karşıyaka Spor Kuluebue≈
- **Altınordu** : (2) Altınordu FK · Altınordu Futbol Kulübü ⇒ (4) ≈Altinordu≈ · ≈Altinordu FK≈ · ≈Altinordu Futbol Kulubu≈ · ≈Altınordu Futbol Kuluebue≈
- **Menemenspor** : (4) EG Menemenspor · Menemen Belediye · Menemen Spor Kulübü · Menemen Belediyespor ⇒ (2) ≈Menemen Spor Kulubu≈ · ≈Menemen Spor Kuluebue≈
- [**Kayserispor**](https://en.wikipedia.org/wiki/Kayserispor) : (2) Kayseri · Kayseri Spor Kulübü ⇒ (2) ≈Kayseri Spor Kulubu≈ · ≈Kayseri Spor Kuluebue≈
- **Kayseri Erciyesspor** : (1) Erciyesspor
- [**Konyaspor**](https://en.wikipedia.org/wiki/Konyaspor) : (1) Atiker Konyaspor
- [**Sivasspor**](https://en.wikipedia.org/wiki/Sivasspor)
- [**Trabzonspor AŞ**](https://en.wikipedia.org/wiki/Trabzonspor) : (1) Trabzonspor ⇒ (1) ≈Trabzonspor AS≈
- [**Yeni Malatyaspor**](https://en.wikipedia.org/wiki/Yeni_Malatyaspor) : (2) Y. Malatyaspor · Yeni Malatya Spor Kulübü ⇒ (2) ≈Yeni Malatya Spor Kulubu≈ · ≈Yeni Malatya Spor Kuluebue≈
- **Malatyaspor** : (2) Malatya SK · Malatya Spor Kulübü ⇒ (2) ≈Malatya Spor Kulubu≈ · ≈Malatya Spor Kuluebue≈
- **Adanaspor** : (1) Adanaspor AŞ ⇒ (1) ≈Adanaspor AS≈
- **Adana Demirspor** : (2) Ad. Demirspor · Adana Demir Spor Kulübü ⇒ (2) ≈Adana Demir Spor Kulubu≈ · ≈Adana Demir Spor Kuluebue≈
- **Gaziantepspor**
- **Gazişehir Gaziantep FK** : (5) Gaziantep · Gaziantep FK · Gaziş. Gaziantep · Gazişehir Gaziantep · Gazişehir Gaziantep Futbol Kulübü ⇒ (5) ≈Gazis. Gaziantep≈ · ≈Gazisehir Gaziantep≈ · ≈Gazisehir Gaziantep FK≈ · ≈Gazisehir Gaziantep Futbol Kulubu≈ · ≈Gazişehir Gaziantep Futbol Kuluebue≈
- [**Çaykur Rizespor**](https://en.wikipedia.org/wiki/Çaykur_Rizespor) : (1) Rizespor ⇒ (1) ≈Caykur Rizespor≈
- **Balıkesirspor** ⇒ (1) ≈Balikesirspor≈
- **Mersin İdmanyurdu** : (1) Mersin İdman Yurdu ⇒ (2) ≈Mersin Idmanyurdu≈ · ≈Mersin Idman Yurdu≈
- [**BB Erzurumspor**](https://en.wikipedia.org/wiki/Büyükşehir_Belediye_Erzurumspor) : (2) Erzurum BB · Büyükşehir Belediye Erzurumspor ⇒ (2) ≈Buyuksehir Belediye Erzurumspor≈ · ≈Bueyuekşehir Belediye Erzurumspor≈
- **Denizlispor** : (1) Denizlispor Kulübü ⇒ (2) ≈Denizlispor Kulubu≈ · ≈Denizlispor Kuluebue≈
- **Orduspor**
- **Manisaspor**
- **Samsunspor** : (1) Samsunspor Kulübü Derneği ⇒ (2) ≈Samsunspor Kulubu Dernegi≈ · ≈Samsunspor Kuluebue Derneği≈
- **Diyarbakırspor** : (1) Diyarbekirspor AŞ ⇒ (2) ≈Diyarbakirspor≈ · ≈Diyarbekirspor AS≈
- **Kocaelispor** : (1) Kocaelispor Kulübü ⇒ (2) ≈Kocaelispor Kulubu≈ · ≈Kocaelispor Kuluebue≈
- **Sakaryaspor** : (1) Sakaryaspor Kulübü Derneği ⇒ (2) ≈Sakaryaspor Kulubu Dernegi≈ · ≈Sakaryaspor Kuluebue Derneği≈
- **Akçaabat Sebatspor** : (1) A. Sebatspor ⇒ (1) ≈Akcaabat Sebatspor≈
- **Yozgatspor** : (1) Yozgatspor Kulübü ⇒ (2) ≈Yozgatspor Kulubu≈ · ≈Yozgatspor Kuluebue≈
- **Erzurumspor (1968-2015)** : (1) Erzurum
- **Siirtspor** : (2) Siirt SK · Siirt Jet-PA
- **Vanspor FK** : (2) Vanspor · Van Büyükşehir Belediyespor ⇒ (2) ≈Van Buyuksehir Belediyespor≈ · ≈Van Bueyuekşehir Belediyespor≈
- **Çanakkale Dardanelspor** : (2) Dardanelspor · Çanakkale Dardanel SK ⇒ (2) ≈Canakkale Dardanel SK≈ · ≈Canakkale Dardanelspor≈
- **Boluspor**
- **Giresunspor**
- **Erzincanspor** : (3) 24 Erzincan · An. Erzincanspor · 24 Erzincan Spor Kulübü ⇒ (2) ≈24 Erzincan Spor Kulubu≈ · ≈24 Erzincan Spor Kuluebue≈
- **Hatayspor**




Alphabet

- **Alphabet Specials** (10):  **Ç**  **Ü**  **ç**  **ö**  **ü**  **ğ**  **İ**  **ı**  **Ş**  **ş** 
  - **Ç**×3 U+00C7 (199) - LATIN CAPITAL LETTER C WITH CEDILLA ⇒ C
  - **Ü**×3 U+00DC (220) - LATIN CAPITAL LETTER U WITH DIAERESIS ⇒ U•UE
  - **ç**×15 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **ö**×9 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ü**×68 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue
  - **ğ**×8 U+011F (287) - LATIN SMALL LETTER G WITH BREVE ⇒ g
  - **İ**×23 U+0130 (304) - LATIN CAPITAL LETTER I WITH DOT ABOVE ⇒ I
  - **ı**×20 U+0131 (305) - LATIN SMALL LETTER DOTLESS I ⇒ i
  - **Ş**×10 U+015E (350) - LATIN CAPITAL LETTER S WITH CEDILLA ⇒ S
  - **ş**×40 U+015F (351) - LATIN SMALL LETTER S WITH CEDILLA ⇒ s




Duplicates

- **Galatasaray İstanbul AŞ**, İstanbul (2):
  - `galatasaristanbul` (2): Galatasar. İstanbul · Galatasar. Istanbul
  - `galatasarayistanbul` (2): Galatasaray İstanbul · Galatasaray Istanbul
- **İstanbulspor**, İstanbul (2):
  - `istanbulspor` (2): İstanbulspor · Istanbulspor
  - `istanbulsporas` (2): İstanbulspor AS · Istanbulspor AS
- **Altay SK**, İzmir (1):
  - `altayizmir` (2): Altay İzmir · Altay Izmir
- **Mersin İdmanyurdu**, Mersin (1):
  - `mersinidmanyurdu` (4): Mersin İdmanyurdu · Mersin İdman Yurdu · Mersin Idmanyurdu · Mersin Idman Yurdu




By City

- **İstanbul** (11): 
  - Fenerbahçe İstanbul SK  (5) Fenerbahçe · Fenerbahçe SK · Fenerbahçe Spor Kulübü · Fenerbahçe Sports Club · Fenerbahçe İstanbul
  - Galatasaray İstanbul AŞ  (5) Galatasaray · Galatasar. İstanbul · Galatasaray İstanbul · Galatasaray AŞ · Galatasaray SK
  - Beşiktaş İstanbul JK  (4) Beşiktaş · Beşiktaş JK · Beşiktaş İst. · Beşiktaş İstanbul
  - Kasımpaşa İstanbul SK  (3) Kasımpaşa · Kasımpaşa SK · Kasımpaşa İstanbul
  - İstanbul Başakşehir  (8) Başakşehir · İ. Başakşehir · İst. Başakş · İstanb. Başakşehir · İstanbul Başakşeh. · İstanbul Başakşehir FK · Büyükşehyr · İstanbul Büyükşehir Belediyespor
  - İstanbulspor  (1) İstanbulspor AS
  - Sarıyer SK  (2) Sarıyer · Sarıyer Spor Kulübü
  - Zeytinburnuspor  (2) Zeytinburnu · Zeytinburnu SK
  - Fatih Karagümrük  (1) Fatih Karagümrük SK
  - Tuzlaspor 
  - Ümraniyespor  (2) CG Ümraniyespor · Ümraniyespor Kulubu
- **Ankara** (7): 
  - Gençlerbirliği Ankara SK  (4) Gençlerbirliği · Gençlerbirliği Ankara · Gençlerbirliği SK · Gençlerbirliği Spor Kulübü
  - Osmanlıspor Ankara  (4) Osmanlıspor · Osmanlıspor FK · Ankaraspor · Ankaraspor AŞ
  - MKE Ankaragücü  (1) Ankaragücü
  - Hacettepespor  (5) Hacettepe · Hacettepe SK · Hacettepe Spor Kulübü · Oftasspor · OFTAŞ
  - Turanspor  (2) Şekerspor · Beypazarı Şekerspor
  - Petrol Ofisi SK (1954-2010)  (2) P. Ofisi · Petrol Ofisi
  - Keçiörengücü  (2) Keçiörengücü SK · Keciöerengücü [de]
- **İzmir** (5): 
  - Göztepe İzmir  (5) Göztepe · Göztepe SK · Göztep · Göztepespor · Göztepe AŞ
  - Bucaspor  (1) Bucaspor Kulübü
  - Altay SK  (4) Altay · Altay Spor Kulübü · Altay İzmir · Altay GK
  - Karşıyaka SK  (2) Karşıyaka · Karşıyaka Spor Kulübü
  - Altınordu  (2) Altınordu FK · Altınordu Futbol Kulübü
- **Adana** (2): 
  - Adanaspor  (1) Adanaspor AŞ
  - Adana Demirspor  (2) Ad. Demirspor · Adana Demir Spor Kulübü
- **Erzurum** (2): 
  - BB Erzurumspor  (2) Erzurum BB · Büyükşehir Belediye Erzurumspor
  - Erzurumspor (1968-2015)  (1) Erzurum
- **Gaziantep** (2): 
  - Gaziantepspor 
  - Gazişehir Gaziantep FK  (5) Gaziantep · Gaziantep FK · Gazişehir Gaziantep · Gaziş. Gaziantep · Gazişehir Gaziantep Futbol Kulübü
- **Kayseri** (2): 
  - Kayserispor  (2) Kayseri · Kayseri Spor Kulübü
  - Kayseri Erciyesspor  (1) Erciyesspor
- **Malatya** (2): 
  - Yeni Malatyaspor  (2) Y. Malatyaspor · Yeni Malatya Spor Kulübü
  - Malatyaspor  (2) Malatya SK · Malatya Spor Kulübü
- **Adapazarı** (1): Sakaryaspor  (1) Sakaryaspor Kulübü Derneği
- **Akhisar** (1): Akhisarspor  (5) Akhisar · Akhisar Bld.spor · Akhisar Belediyespor · Akhisar Belediye Gençlik ve Spor Kulübü · Akhisar Belediye
- **Akçaabat** (1): Akçaabat Sebatspor  (1) A. Sebatspor
- **Alanya** (1): Alanyaspor 
- **Antakya** (1): Hatayspor 
- **Antalya** (1): Antalyaspor  (4) Antalya · Antalyaspor Kulübü · Antalyaspor AS · MP Antalyaspor
- **Balıkesir** (1): Balıkesirspor 
- **Bolu** (1): Boluspor 
- **Bursa** (1): Bursaspor  (1) Bursaspor SK
- **Denizli** (1): Denizlispor  (1) Denizlispor Kulübü
- **Diyarbakır** (1): Diyarbakırspor  (1) Diyarbekirspor AŞ
- **Elazığ** (1): Elazığspor 
- **Erzincan** (1): Erzincanspor  (3) An. Erzincanspor · 24 Erzincan · 24 Erzincan Spor Kulübü
- **Eskişehir** (1): Eskişehirspor 
- **Giresun** (1): Giresunspor 
- **Karabük** (1): Kardemir Karabükspor  (1) Karabükspor
- **Konya** (1): Konyaspor  (1) Atiker Konyaspor
- **Manisa** (1): Manisaspor 
- **Menemen** (1): Menemenspor  (4) Menemen Spor Kulübü · Menemen Belediye · Menemen Belediyespor · EG Menemenspor
- **Mersin** (1): Mersin İdmanyurdu  (1) Mersin İdman Yurdu
- **Ordu** (1): Orduspor 
- **Rize** (1): Çaykur Rizespor  (1) Rizespor
- **Samsun** (1): Samsunspor  (1) Samsunspor Kulübü Derneği
- **Siirt** (1): Siirtspor  (2) Siirt SK · Siirt Jet-PA
- **Sivas** (1): Sivasspor 
- **Trabzon** (1): Trabzonspor AŞ  (1) Trabzonspor
- **Van** (1): Vanspor FK  (2) Vanspor · Van Büyükşehir Belediyespor
- **Yozgat** (1): Yozgatspor  (1) Yozgatspor Kulübü
- **Çanakkale** (1): Çanakkale Dardanelspor  (2) Dardanelspor · Çanakkale Dardanel SK
- **İzmit** (1): Kocaelispor  (1) Kocaelispor Kulübü




By Region

- **İstanbul†** (11):   Fenerbahçe İstanbul SK · Galatasaray İstanbul AŞ · Beşiktaş İstanbul JK · Kasımpaşa İstanbul SK · İstanbul Başakşehir · İstanbulspor · Sarıyer SK · Zeytinburnuspor · Fatih Karagümrük · Tuzlaspor · Ümraniyespor
- **Ankara†** (7):   Gençlerbirliği Ankara SK · Osmanlıspor Ankara · MKE Ankaragücü · Hacettepespor · Turanspor · Petrol Ofisi SK (1954-2010) · Keçiörengücü
- **Karabük†** (1):   Kardemir Karabükspor
- **Elazığ†** (1):   Elazığspor
- **Eskişehir†** (1):   Eskişehirspor
- **Akhisar†** (1):   Akhisarspor
- **Alanya†** (1):   Alanyaspor
- **Antalya†** (1):   Antalyaspor
- **Bursa†** (1):   Bursaspor
- **İzmir†** (5):   Göztepe İzmir · Bucaspor · Altay SK · Karşıyaka SK · Altınordu
- **Menemen†** (1):   Menemenspor
- **Kayseri†** (2):   Kayserispor · Kayseri Erciyesspor
- **Konya†** (1):   Konyaspor
- **Sivas†** (1):   Sivasspor
- **Trabzon†** (1):   Trabzonspor AŞ
- **Malatya†** (2):   Yeni Malatyaspor · Malatyaspor
- **Adana†** (2):   Adanaspor · Adana Demirspor
- **Gaziantep†** (2):   Gaziantepspor · Gazişehir Gaziantep FK
- **Rize†** (1):   Çaykur Rizespor
- **Balıkesir†** (1):   Balıkesirspor
- **Mersin†** (1):   Mersin İdmanyurdu
- **Erzurum†** (2):   BB Erzurumspor · Erzurumspor (1968-2015)
- **Denizli†** (1):   Denizlispor
- **Ordu†** (1):   Orduspor
- **Manisa†** (1):   Manisaspor
- **Samsun†** (1):   Samsunspor
- **Diyarbakır†** (1):   Diyarbakırspor
- **İzmit†** (1):   Kocaelispor
- **Adapazarı†** (1):   Sakaryaspor
- **Akçaabat†** (1):   Akçaabat Sebatspor
- **Yozgat†** (1):   Yozgatspor
- **Siirt†** (1):   Siirtspor
- **Van†** (1):   Vanspor FK
- **Çanakkale†** (1):   Çanakkale Dardanelspor
- **Bolu†** (1):   Boluspor
- **Giresun†** (1):   Giresunspor
- **Erzincan†** (1):   Erzincanspor
- **Antakya†** (1):   Hatayspor




By Year

- **1912** (1):   Karşıyaka SK
- **1913** (1):   İstanbulspor
- **1914** (1):   Altay SK
- **1923** (2):   Gençlerbirliği Ankara SK · Akçaabat Sebatspor
- **1928** (1):   Bucaspor
- **1940** (2):   Sarıyer SK · Adana Demirspor
- **1947** (1):   Turanspor
- **1953** (1):   Zeytinburnuspor
- **1954** (2):   Petrol Ofisi SK (1954-2010) · Adanaspor
- **1959** (1):   Yozgatspor
- **1965** (3):   Manisaspor · Samsunspor · Sakaryaspor
- **1966** (6):   Antalyaspor · Kayserispor · Malatyaspor · Denizlispor · Kocaelispor · Çanakkale Dardanelspor
- **1967** (2):   Orduspor · Hatayspor
- **1968** (2):   Diyarbakırspor · Erzurumspor (1968-2015)
- **1969** (1):   Gaziantepspor
- **1982** (1):   Vanspor FK
- **1986** (1):   Yeni Malatyaspor
- **1988** (1):   Gazişehir Gaziantep FK
- **2001** (1):   Hacettepespor
- ? (32):   Fenerbahçe İstanbul SK · Galatasaray İstanbul AŞ · Beşiktaş İstanbul JK · Kasımpaşa İstanbul SK · İstanbul Başakşehir · Fatih Karagümrük · Tuzlaspor · Ümraniyespor · Osmanlıspor Ankara · MKE Ankaragücü · Keçiörengücü · Kardemir Karabükspor · Elazığspor · Eskişehirspor · Akhisarspor · Alanyaspor · Bursaspor · Göztepe İzmir · Altınordu · Menemenspor · Kayseri Erciyesspor · Konyaspor · Sivasspor · Trabzonspor AŞ · Çaykur Rizespor · Balıkesirspor · Mersin İdmanyurdu · BB Erzurumspor · Siirtspor · Boluspor · Giresunspor · Erzincanspor




Historic

- **2010** (1):   Petrol Ofisi SK (1954-2010)
- **2015** (1):   Erzurumspor (1968-2015)






By A to Z

- **2** (2): 24 Erzincan · 24 Erzincan Spor Kulübü
- **A** (31): Altay · Akhisar · Antalya · Altay GK · Altay SK · Adanaspor · Altınordu · Alanyaspor · Ankaragücü · Ankaraspor · Akhisarspor · Altay İzmir · Antalyaspor · A. Sebatspor · Adanaspor AŞ · Altınordu FK · Ad. Demirspor · Ankaraspor AŞ · Antalyaspor AS · Adana Demirspor · Akhisar Belediye · Akhisar Bld.spor · An. Erzincanspor · Atiker Konyaspor · Altay Spor Kulübü · Akçaabat Sebatspor · Antalyaspor Kulübü · Akhisar Belediyespor · Adana Demir Spor Kulübü · Altınordu Futbol Kulübü · Akhisar Belediye Gençlik ve Spor Kulübü
- **B** (16): Beşiktaş · Boluspor · Bucaspor · Bursaspor · Başakşehir · Büyükşehyr · Beşiktaş JK · Bursaspor SK · Balıkesirspor · Beşiktaş İst. · BB Erzurumspor · Bucaspor Kulübü · Beşiktaş İstanbul · Beypazarı Şekerspor · Beşiktaş İstanbul JK · Büyükşehir Belediye Erzurumspor
- **C** (1): CG Ümraniyespor
- **D** (5): Denizlispor · Dardanelspor · Diyarbakırspor · Diyarbekirspor AŞ · Denizlispor Kulübü
- **E** (8): Erzurum · Elazığspor · Erzurum BB · Erciyesspor · Erzincanspor · Eskişehirspor · EG Menemenspor · Erzurumspor (1968-2015)
- **F** (8): Fenerbahçe · Fenerbahçe SK · Fatih Karagümrük · Fatih Karagümrük SK · Fenerbahçe İstanbul · Fenerbahçe Spor Kulübü · Fenerbahçe Sports Club · Fenerbahçe İstanbul SK
- **G** (25): Göztep · Göztepe · Gaziantep · Göztepe AŞ · Göztepe SK · Galatasaray · Giresunspor · Göztepespor · Gaziantep FK · Gaziantepspor · Göztepe İzmir · Galatasaray AŞ · Galatasaray SK · Gençlerbirliği · Gaziş. Gaziantep · Gençlerbirliği SK · Galatasar. İstanbul · Gazişehir Gaziantep · Galatasaray İstanbul · Gençlerbirliği Ankara · Gazişehir Gaziantep FK · Galatasaray İstanbul AŞ · Gençlerbirliği Ankara SK · Gençlerbirliği Spor Kulübü · Gazişehir Gaziantep Futbol Kulübü
- **H** (5): Hacettepe · Hatayspor · Hacettepe SK · Hacettepespor · Hacettepe Spor Kulübü
- **K** (19): Kayseri · Karşıyaka · Kasımpaşa · Konyaspor · Karabükspor · Kayserispor · Kocaelispor · Karşıyaka SK · Kasımpaşa SK · Keçiörengücü · Keçiörengücü SK · Kasımpaşa İstanbul · Keciöerengücü [de] · Kocaelispor Kulübü · Kayseri Erciyesspor · Kayseri Spor Kulübü · Kardemir Karabükspor · Karşıyaka Spor Kulübü · Kasımpaşa İstanbul SK
- **M** (12): Malatya SK · Manisaspor · Malatyaspor · Menemenspor · MKE Ankaragücü · MP Antalyaspor · Menemen Belediye · Mersin İdmanyurdu · Mersin İdman Yurdu · Malatya Spor Kulübü · Menemen Spor Kulübü · Menemen Belediyespor
- **O** (6): OFTAŞ · Orduspor · Oftasspor · Osmanlıspor · Osmanlıspor FK · Osmanlıspor Ankara
- **P** (3): P. Ofisi · Petrol Ofisi · Petrol Ofisi SK (1954-2010)
- **R** (1): Rizespor
- **S** (11): Sarıyer · Siirt SK · Siirtspor · Sivasspor · Samsunspor · Sarıyer SK · Sakaryaspor · Siirt Jet-PA · Sarıyer Spor Kulübü · Samsunspor Kulübü Derneği · Sakaryaspor Kulübü Derneği
- **T** (4): Turanspor · Tuzlaspor · Trabzonspor · Trabzonspor AŞ
- **V** (3): Vanspor · Vanspor FK · Van Büyükşehir Belediyespor
- **Y** (5): Yozgatspor · Y. Malatyaspor · Yeni Malatyaspor · Yozgatspor Kulübü · Yeni Malatya Spor Kulübü
- **Z** (3): Zeytinburnu · Zeytinburnu SK · Zeytinburnuspor
- **Ç** (3): Çaykur Rizespor · Çanakkale Dardanel SK · Çanakkale Dardanelspor
- **Ü** (2): Ümraniyespor · Ümraniyespor Kulubu
- **İ** (9): İst. Başakş · İstanbulspor · İ. Başakşehir · İstanbulspor AS · İstanb. Başakşehir · İstanbul Başakşeh. · İstanbul Başakşehir · İstanbul Başakşehir FK · İstanbul Büyükşehir Belediyespor
- **Ş** (1): Şekerspor




