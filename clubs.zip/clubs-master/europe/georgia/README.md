17 clubs

- **FC Dinamo Tbilisi** : (1) Dinamo Tbilisi
- **FC Locomotive Tbilisi** : (3) Lokomotiv Tbilisi · Locomotive Tbilisi · FC Lokomotive Tbilisi
- **FC Ameri Tbilisi (2002-2009)** : (1) Ameri
- **FC Zestafoni** : (1) Zestafoni
- **FC Margveti Zestafoni (1990-2000)** : (1) Margveti Zestafoni
- **FC Metalurgi Rustavi** : (1) Metalurgi Rustavi
- **FC Dila Gori** : (2) Dila · Dila Gori
- **FC WIT Georgia** : (1) WIT Georgia
- **FC Gagra**
- **FC Torpedo Kutaisi** : (1) Torpedo Kutaisi
- **FC Chikhura Sachkhere** : (2) Chikhura · Chikhura Sachkhere
- **FC Samtredia** : (1) Samtredia
- **FC Dinamo Batumi** : (1) Dinamo Batumi
- **FC Tskhinvali** : (2) Spartak Tskhinvali · Spartaki Tskhinvali
- **FC Sioni Bolnisi** : (2) Sioni · Sioni Bolnisi
- **FC Saburtalo** : (1) Saburtalo
- **FC Kolkheti Poti** : (1) FC Kolkheti-1913 Poti




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Tbilisi** (3): 
  - FC Dinamo Tbilisi  (1) Dinamo Tbilisi
  - FC Locomotive Tbilisi  (3) Locomotive Tbilisi · FC Lokomotive Tbilisi · Lokomotiv Tbilisi
  - FC Ameri Tbilisi (2002-2009)  (1) Ameri
- **Zestafoni** (2): 
  - FC Zestafoni  (1) Zestafoni
  - FC Margveti Zestafoni (1990-2000)  (1) Margveti Zestafoni
- **Poti** (1): FC Kolkheti Poti  (1) FC Kolkheti-1913 Poti
- ? (11): 
  - FC Metalurgi Rustavi  (1) Metalurgi Rustavi
  - FC Dila Gori  (2) Dila · Dila Gori
  - FC WIT Georgia  (1) WIT Georgia
  - FC Gagra 
  - FC Torpedo Kutaisi  (1) Torpedo Kutaisi
  - FC Chikhura Sachkhere  (2) Chikhura · Chikhura Sachkhere
  - FC Samtredia  (1) Samtredia
  - FC Dinamo Batumi  (1) Dinamo Batumi
  - FC Tskhinvali  (2) Spartak Tskhinvali · Spartaki Tskhinvali
  - FC Sioni Bolnisi  (2) Sioni · Sioni Bolnisi
  - FC Saburtalo  (1) Saburtalo




By Region

- **Tbilisi†** (3):   FC Dinamo Tbilisi · FC Locomotive Tbilisi · FC Ameri Tbilisi (2002-2009)
- **Zestafoni†** (2):   FC Zestafoni · FC Margveti Zestafoni (1990-2000)
- **Poti†** (1):   FC Kolkheti Poti




By Year

- **1913** (1):   FC Kolkheti Poti
- **1990** (1):   FC Margveti Zestafoni (1990-2000)
- **2002** (1):   FC Ameri Tbilisi (2002-2009)
- **2014** (1):   FC Zestafoni
- ? (13):   FC Dinamo Tbilisi · FC Locomotive Tbilisi · FC Metalurgi Rustavi · FC Dila Gori · FC WIT Georgia · FC Gagra · FC Torpedo Kutaisi · FC Chikhura Sachkhere · FC Samtredia · FC Dinamo Batumi · FC Tskhinvali · FC Sioni Bolnisi · FC Saburtalo




Historic

- **2000** (1):   FC Margveti Zestafoni (1990-2000)
- **2009** (1):   FC Ameri Tbilisi (2002-2009)






By A to Z

- **A** (1): Ameri
- **C** (2): Chikhura · Chikhura Sachkhere
- **D** (4): Dila · Dila Gori · Dinamo Batumi · Dinamo Tbilisi
- **F** (19): FC Gagra · FC Dila Gori · FC Saburtalo · FC Samtredia · FC Zestafoni · FC Tskhinvali · FC WIT Georgia · FC Dinamo Batumi · FC Kolkheti Poti · FC Sioni Bolnisi · FC Dinamo Tbilisi · FC Torpedo Kutaisi · FC Metalurgi Rustavi · FC Chikhura Sachkhere · FC Kolkheti-1913 Poti · FC Locomotive Tbilisi · FC Lokomotive Tbilisi · FC Ameri Tbilisi (2002-2009) · FC Margveti Zestafoni (1990-2000)
- **L** (2): Lokomotiv Tbilisi · Locomotive Tbilisi
- **M** (2): Metalurgi Rustavi · Margveti Zestafoni
- **S** (6): Sioni · Saburtalo · Samtredia · Sioni Bolnisi · Spartak Tskhinvali · Spartaki Tskhinvali
- **T** (1): Torpedo Kutaisi
- **W** (1): WIT Georgia
- **Z** (1): Zestafoni




