16 clubs

- **FC Levadia Tallinn** : (5) Levadia · FCI Levadia · Levadia Tallinn · FC Levadia Maardu · FCI Levadia Tallinn
- **FC Flora Tallinn** : (3) Flora · FC Flora · Flora Tallinn
- **FC TVMK Tallinn** : (2) TVMK · FC TVMK
- **FCI Tallinn**
- **JK Tallinna Kalev** : (2) Talinna Kalev · Tallinna Kalev
- **FC Norma Tallinn (1959-1997)** : (1) Norma Tallinn
- **FC Lantana Tallinn (1994-1999)** : (2) FC Lantana · Lantana Tallinn
- **JK Trans Narva** : (4) Trans · Trans Narva · Narva Trans · JK Narva Trans
- **JK Nõmme Kalju** : (5) Kalju · Nõmme Kalju · Kalju Nõmme · Nõmme Kalju FC · Nõmme JK Kalju ⇒ (5) ≈Nomme Kalju≈ · ≈Kalju Nomme≈ · ≈Nomme Kalju FC≈ · ≈JK Nomme Kalju≈ · ≈Nomme JK Kalju≈
- **JK Sillamäe Kalev** : (2) Sillamäe Kalev · Kalev Sillamäe ⇒ (6) ≈Sillamae Kalev≈ · ≈Kalev Sillamae≈ · ≈Kalev Sillamaee≈ · ≈Sillamaee Kalev≈ · ≈JK Sillamae Kalev≈ · ≈JK Sillamaee Kalev≈
- **FC Santos Tartu** : (1) Santos Tartu
- **JK Tammeka Tartu** : (2) Tammeka · Tammeka Tartu
- **Paide Linnameeskond** : (1) Paide
- **JK Tulevik Viljandi** : (4) Tulevik · Viljandi Tulevik · Tulevik Viljandi · Viljandi JK Tulevik
- **FC Kuressaare** : (1) Kuressaare
- **Maardu Esteve** : (1) Maardu




Alphabet

- **Alphabet Specials** (2):  **ä**  **õ** 
  - **ä**×3 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **õ**×5 U+00F5 (245) - LATIN SMALL LETTER O WITH TILDE ⇒ o




Duplicates





By City

- **Tallinn** (2): 
  - FC Norma Tallinn (1959-1997)  (1) Norma Tallinn
  - FC Lantana Tallinn (1994-1999)  (2) FC Lantana · Lantana Tallinn
- **Viljandi** (1): JK Tulevik Viljandi  (4) Tulevik · Viljandi Tulevik · Viljandi JK Tulevik · Tulevik Viljandi
- ? (13): 
  - FC Levadia Tallinn  (5) Levadia · Levadia Tallinn · FC Levadia Maardu · FCI Levadia · FCI Levadia Tallinn
  - FC Flora Tallinn  (3) Flora · FC Flora · Flora Tallinn
  - FC TVMK Tallinn  (2) TVMK · FC TVMK
  - FCI Tallinn 
  - JK Tallinna Kalev  (2) Tallinna Kalev · Talinna Kalev
  - JK Trans Narva  (4) Trans · Trans Narva · Narva Trans · JK Narva Trans
  - JK Nõmme Kalju  (5) Kalju · Nõmme Kalju · Nõmme Kalju FC · Kalju Nõmme · Nõmme JK Kalju
  - JK Sillamäe Kalev  (2) Sillamäe Kalev · Kalev Sillamäe
  - FC Santos Tartu  (1) Santos Tartu
  - JK Tammeka Tartu  (2) Tammeka · Tammeka Tartu
  - Paide Linnameeskond  (1) Paide
  - FC Kuressaare  (1) Kuressaare
  - Maardu Esteve  (1) Maardu




By Region

- **Tallinn†** (2):   FC Norma Tallinn (1959-1997) · FC Lantana Tallinn (1994-1999)
- **Viljandi†** (1):   JK Tulevik Viljandi




By Year

- **1959** (1):   FC Norma Tallinn (1959-1997)
- **1994** (1):   FC Lantana Tallinn (1994-1999)
- ? (14):   FC Levadia Tallinn · FC Flora Tallinn · FC TVMK Tallinn · FCI Tallinn · JK Tallinna Kalev · JK Trans Narva · JK Nõmme Kalju · JK Sillamäe Kalev · FC Santos Tartu · JK Tammeka Tartu · Paide Linnameeskond · JK Tulevik Viljandi · FC Kuressaare · Maardu Esteve




Historic

- **1997** (1):   FC Norma Tallinn (1959-1997)
- **1999** (1):   FC Lantana Tallinn (1994-1999)






By A to Z

- **F** (16): Flora · FC TVMK · FC Flora · FC Lantana · FCI Levadia · FCI Tallinn · FC Kuressaare · Flora Tallinn · FC Santos Tartu · FC TVMK Tallinn · FC Flora Tallinn · FC Levadia Maardu · FC Levadia Tallinn · FCI Levadia Tallinn · FC Norma Tallinn (1959-1997) · FC Lantana Tallinn (1994-1999)
- **J** (7): JK Narva Trans · JK Nõmme Kalju · JK Trans Narva · JK Tammeka Tartu · JK Sillamäe Kalev · JK Tallinna Kalev · JK Tulevik Viljandi
- **K** (4): Kalju · Kuressaare · Kalju Nõmme · Kalev Sillamäe
- **L** (3): Levadia · Lantana Tallinn · Levadia Tallinn
- **M** (2): Maardu · Maardu Esteve
- **N** (5): Narva Trans · Nõmme Kalju · Norma Tallinn · Nõmme JK Kalju · Nõmme Kalju FC
- **P** (2): Paide · Paide Linnameeskond
- **S** (2): Santos Tartu · Sillamäe Kalev
- **T** (9): TVMK · Trans · Tammeka · Tulevik · Trans Narva · Talinna Kalev · Tammeka Tartu · Tallinna Kalev · Tulevik Viljandi
- **V** (2): Viljandi Tulevik · Viljandi JK Tulevik




