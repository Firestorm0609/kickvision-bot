17 clubs

- [**KF Tirana**](https://en.wikipedia.org/wiki/KF_Tirana) : (5) Tirana · SK Tirana · KF Tiranë · 17 Nëntori Tirana · Klubi i Futbollit Tirana ⇒ (2) ≈KF Tirane≈ · ≈17 Nentori Tirana≈
- [**FK Partizani Tirana**](https://en.wikipedia.org/wiki/FK_Partizani_Tirana) : (3) Partizani · FK Partizani · Partizani Tirana
- **FK Dinamo Tirana** : (1) Dinamo Tirana
- [**KS Skënderbeu**](https://en.wikipedia.org/wiki/KF_Skënderbeu_Korçë) : (4) Skënderbeu · KF Skënderbeu · Skënderbeu Korçë · KF Skënderbeu Korçë ⇒ (5) ≈Skenderbeu≈ · ≈KS Skenderbeu≈ · ≈KF Skenderbeu≈ · ≈Skenderbeu Korce≈ · ≈KF Skenderbeu Korce≈
- [**KS Flamurtari**](https://en.wikipedia.org/wiki/Flamurtari_Vlorë) : (4) Flamurtari · Flamurtari FC · Flamurtari Vlorë · KS Flamurtari Vlorë ⇒ (2) ≈Flamurtari Vlore≈ · ≈KS Flamurtari Vlore≈
- **KF Vllaznia** : (4) Vllaznia · FK Vllaznia · Vllaznia Shkodër · KF Vllaznia Shkodër ⇒ (2) ≈Vllaznia Shkoder≈ · ≈KF Vllaznia Shkoder≈
- **KS Besa** : (1) Besa Kavajë ⇒ (1) ≈Besa Kavaje≈
- [**KS Teuta**](https://en.wikipedia.org/wiki/KF_Teuta_Durrës) : (4) Teuta · KF Teuta · Teuta Durrës · KF Teuta Durrës ⇒ (2) ≈Teuta Durres≈ · ≈KF Teuta Durres≈
- [**KF Laçi**](https://en.wikipedia.org/wiki/KF_Laçi) : (2) Laç · Laçi ⇒ (3) ≈Lac≈ · ≈Laci≈ · ≈KF Laci≈
- [**FK Kukësi**](https://en.wikipedia.org/wiki/FK_Kukësi) : (2) Kukës · Kukësi ⇒ (3) ≈Kukes≈ · ≈Kukesi≈ · ≈FK Kukesi≈
- [**KS Luftëtari**](https://en.wikipedia.org/wiki/Luftëtari_Gjirokastër_FC) : (3) Luftëtari · Luftëtari Gjirokastër · Luftëtari Gjirokastër FC ⇒ (4) ≈Luftetari≈ · ≈KS Luftetari≈ · ≈Luftetari Gjirokaster≈ · ≈Luftetari Gjirokaster FC≈
- [**FC Kamza**](https://en.wikipedia.org/wiki/FC_Kamza) : (1) Kamza
- [**KS Kastrioti**](https://en.wikipedia.org/wiki/KS_Kastrioti) : (1) Kastrioti
- **FK Bylis** : (3) Bylis · KF Bylis · KS Bylis
- **KF Elbasani** : (3) KS Elbasani · Klubi Sportiv Elbasani · Klubi i Futbollit Elbasani
- **KF Tomori** : (1) FK Tomori
- **KF Apolonia** : (1) KF Apolonia Fier




Alphabet

- **Alphabet Specials** (2):  **ç**  **ë** 
  - **ç**×5 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **ë**×25 U+00EB (235) - LATIN SMALL LETTER E WITH DIAERESIS ⇒ e




Duplicates





By City

- **Tirana** (3): 
  - KF Tirana  (5) Tirana · Klubi i Futbollit Tirana · KF Tiranë · SK Tirana · 17 Nëntori Tirana
  - FK Partizani Tirana  (3) Partizani · FK Partizani · Partizani Tirana
  - FK Dinamo Tirana  (1) Dinamo Tirana
- **Ballsh** (1): FK Bylis  (3) Bylis · KF Bylis · KS Bylis
- **Berat** (1): KF Tomori  (1) FK Tomori
- **Elbasan** (1): KF Elbasani  (3) Klubi i Futbollit Elbasani · KS Elbasani · Klubi Sportiv Elbasani
- **Fier** (1): KF Apolonia  (1) KF Apolonia Fier
- **Shkodër** (1): KF Vllaznia  (4) Vllaznia · Vllaznia Shkodër · KF Vllaznia Shkodër · FK Vllaznia
- **Vlorë** (1): KS Flamurtari  (4) Flamurtari · Flamurtari Vlorë · KS Flamurtari Vlorë · Flamurtari FC
- ? (8): 
  - KS Skënderbeu  (4) Skënderbeu · Skënderbeu Korçë · KF Skënderbeu · KF Skënderbeu Korçë
  - KS Besa  (1) Besa Kavajë
  - KS Teuta  (4) Teuta · Teuta Durrës · KF Teuta · KF Teuta Durrës
  - KF Laçi  (2) Laç · Laçi
  - FK Kukësi  (2) Kukës · Kukësi
  - KS Luftëtari  (3) Luftëtari · Luftëtari Gjirokastër · Luftëtari Gjirokastër FC
  - FC Kamza  (1) Kamza
  - KS Kastrioti  (1) Kastrioti




By Region

- **Tirana†** (3):   KF Tirana · FK Partizani Tirana · FK Dinamo Tirana
- **Vlorë†** (1):   KS Flamurtari
- **Shkodër†** (1):   KF Vllaznia
- **Ballsh†** (1):   FK Bylis
- **Elbasan†** (1):   KF Elbasani
- **Berat†** (1):   KF Tomori
- **Fier†** (1):   KF Apolonia




By Year

- **1919** (1):   KF Vllaznia
- **1923** (3):   KS Flamurtari · KF Elbasani · KF Tomori
- **1925** (1):   KF Apolonia
- **1972** (1):   FK Bylis
- ? (11):   KF Tirana · FK Partizani Tirana · FK Dinamo Tirana · KS Skënderbeu · KS Besa · KS Teuta · KF Laçi · FK Kukësi · KS Luftëtari · FC Kamza · KS Kastrioti






By A to Z

- **1** (1): 17 Nëntori Tirana
- **B** (2): Bylis · Besa Kavajë
- **D** (1): Dinamo Tirana
- **F** (11): FC Kamza · FK Bylis · FK Kukësi · FK Tomori · Flamurtari · FK Vllaznia · FK Partizani · Flamurtari FC · FK Dinamo Tirana · Flamurtari Vlorë · FK Partizani Tirana
- **K** (30): Kamza · Kukës · Kukësi · KF Laçi · KS Besa · KF Bylis · KF Teuta · KS Bylis · KS Teuta · KF Tirana · KF Tiranë · KF Tomori · Kastrioti · KF Apolonia · KF Elbasani · KF Vllaznia · KS Elbasani · KS Kastrioti · KS Luftëtari · KF Skënderbeu · KS Flamurtari · KS Skënderbeu · KF Teuta Durrës · KF Apolonia Fier · KF Skënderbeu Korçë · KF Vllaznia Shkodër · KS Flamurtari Vlorë · Klubi Sportiv Elbasani · Klubi i Futbollit Tirana · Klubi i Futbollit Elbasani
- **L** (5): Laç · Laçi · Luftëtari · Luftëtari Gjirokastër · Luftëtari Gjirokastër FC
- **P** (2): Partizani · Partizani Tirana
- **S** (3): SK Tirana · Skënderbeu · Skënderbeu Korçë
- **T** (3): Teuta · Tirana · Teuta Durrës
- **V** (2): Vllaznia · Vllaznia Shkodër




