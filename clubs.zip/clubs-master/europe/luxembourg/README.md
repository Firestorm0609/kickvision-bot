25 clubs

- **Racing FC Union Lëtzebuerg** : (4) Racing Union · RFCU Luxemburg · Racing Union Luxembourg · Racing FC Union Luxembourg ⇒ (1) ≈Racing FC Union Letzebuerg≈
- **FC Aris Bonnevoie (-2001)** : (2) Aris Bonneweg · Aris Bonnevoie
- **FC Avenir Beggen** : (1) Avenir Beggen
- **Spora Luxemburg (1923-2005)** : (1) CA Spora Luxembourg
- **Union Luxembourg (1925-2005)** : (3) US Luxembourg · Union Luxemburg · Union Sportive Luxembourg
- **F91 Dudelange** : (1) Dudelange
- **Stade Dudelange (1913-1991)** : (1) CS Stade Dudelange
- **FC Differdange 03** : (2) Differdange · Differdange 03
- **Red Boys Differdange (1907-2003)** : (1) FA Red Boys Differdange
- **Jeunesse d'Esch** : (2) Jeunesse Esch · AS Jeunesse Esch
- **CS Grevenmacher** : (1) Grevenmacher
- **UN Käerjéng 97** ⇒ (2) ≈UN Kaerjeng 97≈ · ≈UN Kaeerjéng 97≈
- **CS Fola Esch** : (2) Fola · Fola Esch
- **FC Progrès Niederkorn** : (4) Progrès · P. Niederkorn · Progrès Niederkorn · Progrès Niedercorn ⇒ (4) ≈Progres≈ · ≈Progres Niedercorn≈ · ≈Progres Niederkorn≈ · ≈FC Progres Niederkorn≈
- **US Mondorf-les-Bains** : (1) Mondorf-les-Bains
- **FC Union Titus Pétange** : (1) Union Titus ⇒ (1) ≈FC Union Titus Petange≈
- **FC UNA Strassen** : (1) UNA Strassen
- **FC Victoria Rosport** : (1) Rosport
- **FC Muhlenbach Sandzak** : (1) Muhlenbach
- **FC Etzella Ettelbruck** : (1) Etzella
- **FC Rodange 91** : (1) Rodange
- **US Hostert** : (1) Hostert
- **FC Mondercange**
- **US Rumelange** : (1) Union Sportive Rumelange
- **CS Pétange (1910-2015)** : (1) Club Sportif Pétange ⇒ (2) ≈CS Petange≈ · ≈Club Sportif Petange≈




Alphabet

- **Alphabet Specials** (4):  **ä**  **è**  **é**  **ë** 
  - **ä**×1 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **è**×4 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **é**×4 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ë**×1 U+00EB (235) - LATIN SMALL LETTER E WITH DIAERESIS ⇒ e




Duplicates





By City

- **Lëtzebuerg** (5): 
  - Racing FC Union Lëtzebuerg  (4) Racing Union · Racing Union Luxembourg · Racing FC Union Luxembourg · RFCU Luxemburg
  - FC Aris Bonnevoie (-2001)  (2) Aris Bonnevoie · Aris Bonneweg
  - FC Avenir Beggen  (1) Avenir Beggen
  - Spora Luxemburg (1923-2005)  (1) CA Spora Luxembourg
  - Union Luxembourg (1925-2005)  (3) US Luxembourg · Union Sportive Luxembourg · Union Luxemburg
- **Differdange** (2): 
  - FC Differdange 03  (2) Differdange · Differdange 03
  - Red Boys Differdange (1907-2003)  (1) FA Red Boys Differdange
- **Dudelange** (2): 
  - F91 Dudelange  (1) Dudelange
  - Stade Dudelange (1913-1991)  (1) CS Stade Dudelange
- **Esch-sur-Alzette** (1): Jeunesse d'Esch  (2) Jeunesse Esch · AS Jeunesse Esch
- **Mondercange** (1): FC Mondercange 
- **Pétange** (1): CS Pétange (1910-2015)  (1) Club Sportif Pétange
- **Rumelange** (1): US Rumelange  (1) Union Sportive Rumelange
- ? (12): 
  - CS Grevenmacher  (1) Grevenmacher
  - UN Käerjéng 97 
  - CS Fola Esch  (2) Fola · Fola Esch
  - FC Progrès Niederkorn  (4) Progrès · P. Niederkorn · Progrès Niederkorn · Progrès Niedercorn
  - US Mondorf-les-Bains  (1) Mondorf-les-Bains
  - FC Union Titus Pétange  (1) Union Titus
  - FC UNA Strassen  (1) UNA Strassen
  - FC Victoria Rosport  (1) Rosport
  - FC Muhlenbach Sandzak  (1) Muhlenbach
  - FC Etzella Ettelbruck  (1) Etzella
  - FC Rodange 91  (1) Rodange
  - US Hostert  (1) Hostert




By Region

- **Lëtzebuerg†** (5):   Racing FC Union Lëtzebuerg · FC Aris Bonnevoie (-2001) · FC Avenir Beggen · Spora Luxemburg (1923-2005) · Union Luxembourg (1925-2005)
- **Dudelange†** (2):   F91 Dudelange · Stade Dudelange (1913-1991)
- **Differdange†** (2):   FC Differdange 03 · Red Boys Differdange (1907-2003)
- **Esch-sur-Alzette†** (1):   Jeunesse d'Esch
- **Mondercange†** (1):   FC Mondercange
- **Rumelange†** (1):   US Rumelange
- **Pétange†** (1):   CS Pétange (1910-2015)




By Year

- **1907** (1):   Red Boys Differdange (1907-2003)
- **1908** (1):   US Rumelange
- **1910** (1):   CS Pétange (1910-2015)
- **1913** (1):   Stade Dudelange (1913-1991)
- **1923** (1):   Spora Luxemburg (1923-2005)
- **1925** (1):   Union Luxembourg (1925-2005)
- **1933** (1):   FC Mondercange
- **2003** (1):   FC Differdange 03
- ? (17):   Racing FC Union Lëtzebuerg · FC Aris Bonnevoie (-2001) · FC Avenir Beggen · F91 Dudelange · Jeunesse d'Esch · CS Grevenmacher · UN Käerjéng 97 · CS Fola Esch · FC Progrès Niederkorn · US Mondorf-les-Bains · FC Union Titus Pétange · FC UNA Strassen · FC Victoria Rosport · FC Muhlenbach Sandzak · FC Etzella Ettelbruck · FC Rodange 91 · US Hostert




Historic

- **1991** (1):   Stade Dudelange (1913-1991)
- **2001** (1):   FC Aris Bonnevoie (-2001)
- **2003** (1):   Red Boys Differdange (1907-2003)
- **2005** (2):   Spora Luxemburg (1923-2005) · Union Luxembourg (1925-2005)
- **2015** (1):   CS Pétange (1910-2015)






By A to Z

- **A** (4): Aris Bonneweg · Avenir Beggen · Aris Bonnevoie · AS Jeunesse Esch
- **C** (6): CS Fola Esch · CS Grevenmacher · CS Stade Dudelange · CA Spora Luxembourg · Club Sportif Pétange · CS Pétange (1910-2015)
- **D** (3): Dudelange · Differdange · Differdange 03
- **E** (1): Etzella
- **F** (15): Fola · Fola Esch · F91 Dudelange · FC Rodange 91 · FC Mondercange · FC UNA Strassen · FC Avenir Beggen · FC Differdange 03 · FC Victoria Rosport · FC Etzella Ettelbruck · FC Muhlenbach Sandzak · FC Progrès Niederkorn · FC Union Titus Pétange · FA Red Boys Differdange · FC Aris Bonnevoie (-2001)
- **G** (1): Grevenmacher
- **H** (1): Hostert
- **J** (2): Jeunesse Esch · Jeunesse d'Esch
- **M** (2): Muhlenbach · Mondorf-les-Bains
- **P** (4): Progrès · P. Niederkorn · Progrès Niedercorn · Progrès Niederkorn
- **R** (8): Rodange · Rosport · Racing Union · RFCU Luxemburg · Racing Union Luxembourg · Racing FC Union Luxembourg · Racing FC Union Lëtzebuerg · Red Boys Differdange (1907-2003)
- **S** (2): Spora Luxemburg (1923-2005) · Stade Dudelange (1913-1991)
- **U** (11): US Hostert · Union Titus · UNA Strassen · US Rumelange · US Luxembourg · UN Käerjéng 97 · Union Luxemburg · US Mondorf-les-Bains · Union Sportive Rumelange · Union Sportive Luxembourg · Union Luxembourg (1925-2005)




