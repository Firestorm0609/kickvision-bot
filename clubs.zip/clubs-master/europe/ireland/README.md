26 clubs

- **Shamrock Rovers FC** : (3) Shamrock · Shamrock Rovers · FC Shamrock Rovers
- **Bohemian FC** : (4) Bohemians · Boh. Dublin · Bohemians Dublin · Bohemian Football Club Dublin
- **St Patrick's Athletic FC** : (5) St Patrick's · St. Patricks · Saint Patrick's · St Patrick's Athletic · Saint Patrick's Athletic FC
- **University College Dublin AFC** : (4) UCD · UC Dublin · Uni College Dublin · University College Dublin
- **Shelbourne FC** : (1) Shelbourne
- **Drumcondra FC** : (1) Drumcondra Dublin
- **Dublin City FC (1999-2006)** : (1) Dublin City
- **Athlone Town AFC** : (3) Athlone · Athlone Town · Athlone Town FC
- **Bray Wanderers FC** : (2) Bray · Bray Wanderers
- **Cobh Ramblers FC** : (1) Cobh Ramblers
- **Cork City FC** : (2) Cork · Cork City
- **Cork Celtic FC (1951-1979)** : (1) Cork Celtic
- **Cork Hibernians FC (1957-1976)** : (1) Cork Hibernians
- **Drogheda United FC** : (2) Drogheda · Drogheda United
- **Dundalk FC** : (2) Dundalk · FC Dundalk
- **Finn Harps FC** : (2) Finn Harps · FC Finn Harps
- **Galway United FC** : (2) Galway · Galway United
- **Limerick FC** : (1) Limerick
- **Longford Town FC** : (2) Longford · Longford Town
- **Mervue**
- **Monaghan** : (1) Monaghan United
- **Sligo Rovers FC** : (3) Sligo · Sligo Rovers · FC Sligo Rovers
- **Waterford FC** : (4) Waterford · Waterford AFC · Waterford United (1982-2016) · Waterford United FC (1982-2016)
- **Wexford FC** : (2) Wexford · Wexford Youths
- **Sporting Fingal FC** : (1) Sporting Fingal
- **Cabinteely FC** : (1) Cabinteely




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **St Patrick's Athletic FC**, Dublin (1):
  - `stpatricks` (2): St Patrick's · St. Patricks




By City

- **Dublin** (7): 
  - Shamrock Rovers FC  (3) Shamrock · Shamrock Rovers · FC Shamrock Rovers
  - Bohemian FC  (4) Bohemians · Boh. Dublin · Bohemians Dublin · Bohemian Football Club Dublin
  - St Patrick's Athletic FC  (5) St Patrick's · St Patrick's Athletic · St. Patricks · Saint Patrick's Athletic FC · Saint Patrick's
  - University College Dublin AFC  (4) UCD · UC Dublin · Uni College Dublin · University College Dublin
  - Shelbourne FC  (1) Shelbourne
  - Drumcondra FC  (1) Drumcondra Dublin
  - Dublin City FC (1999-2006)  (1) Dublin City
- **Cork** (3): 
  - Cork City FC  (2) Cork · Cork City
  - Cork Celtic FC (1951-1979)  (1) Cork Celtic
  - Cork Hibernians FC (1957-1976)  (1) Cork Hibernians
- **Athlone** (1): Athlone Town AFC  (3) Athlone · Athlone Town · Athlone Town FC
- **Ballybofey** (1): Finn Harps FC  (2) Finn Harps · FC Finn Harps
- **Bray** (1): Bray Wanderers FC  (2) Bray · Bray Wanderers
- **Cabinteely** (1): Cabinteely FC  (1) Cabinteely
- **Cobh** (1): Cobh Ramblers FC  (1) Cobh Ramblers
- **Crossabeg** (1): Wexford FC  (2) Wexford · Wexford Youths
- **Drogheda** (1): Drogheda United FC  (2) Drogheda · Drogheda United
- **Dundalk** (1): Dundalk FC  (2) Dundalk · FC Dundalk
- **Galway** (1): Galway United FC  (2) Galway · Galway United
- **Limerick** (1): Limerick FC  (1) Limerick
- **Longford** (1): Longford Town FC  (2) Longford · Longford Town
- **Sligo** (1): Sligo Rovers FC  (3) Sligo · Sligo Rovers · FC Sligo Rovers
- **Waterford** (1): Waterford FC  (4) Waterford · Waterford United (1982-2016) · Waterford United FC (1982-2016) · Waterford AFC
- ? (3): 
  - Mervue 
  - Monaghan  (1) Monaghan United
  - Sporting Fingal FC  (1) Sporting Fingal




By Region

- **Dublin†** (7):   Shamrock Rovers FC · Bohemian FC · St Patrick's Athletic FC · University College Dublin AFC · Shelbourne FC · Drumcondra FC · Dublin City FC (1999-2006)
- **Athlone†** (1):   Athlone Town AFC
- **Bray†** (1):   Bray Wanderers FC
- **Cobh†** (1):   Cobh Ramblers FC
- **Cork†** (3):   Cork City FC · Cork Celtic FC (1951-1979) · Cork Hibernians FC (1957-1976)
- **Drogheda†** (1):   Drogheda United FC
- **Dundalk†** (1):   Dundalk FC
- **Ballybofey†** (1):   Finn Harps FC
- **Galway†** (1):   Galway United FC
- **Limerick†** (1):   Limerick FC
- **Longford†** (1):   Longford Town FC
- **Sligo†** (1):   Sligo Rovers FC
- **Waterford†** (1):   Waterford FC
- **Crossabeg†** (1):   Wexford FC
- **Cabinteely†** (1):   Cabinteely FC




By Year

- **1951** (1):   Cork Celtic FC (1951-1979)
- **1957** (1):   Cork Hibernians FC (1957-1976)
- **1999** (1):   Dublin City FC (1999-2006)
- ? (23):   Shamrock Rovers FC · Bohemian FC · St Patrick's Athletic FC · University College Dublin AFC · Shelbourne FC · Drumcondra FC · Athlone Town AFC · Bray Wanderers FC · Cobh Ramblers FC · Cork City FC · Drogheda United FC · Dundalk FC · Finn Harps FC · Galway United FC · Limerick FC · Longford Town FC · Mervue · Monaghan · Sligo Rovers FC · Waterford FC · Wexford FC · Sporting Fingal FC · Cabinteely FC




Historic

- **1976** (1):   Cork Hibernians FC (1957-1976)
- **1979** (1):   Cork Celtic FC (1951-1979)
- **2006** (1):   Dublin City FC (1999-2006)






By A to Z

- **A** (4): Athlone · Athlone Town · Athlone Town FC · Athlone Town AFC
- **B** (8): Bray · Bohemians · Boh. Dublin · Bohemian FC · Bray Wanderers · Bohemians Dublin · Bray Wanderers FC · Bohemian Football Club Dublin
- **C** (11): Cork · Cork City · Cabinteely · Cork Celtic · Cork City FC · Cabinteely FC · Cobh Ramblers · Cork Hibernians · Cobh Ramblers FC · Cork Celtic FC (1951-1979) · Cork Hibernians FC (1957-1976)
- **D** (9): Dundalk · Drogheda · Dundalk FC · Dublin City · Drumcondra FC · Drogheda United · Drumcondra Dublin · Drogheda United FC · Dublin City FC (1999-2006)
- **F** (6): FC Dundalk · Finn Harps · FC Finn Harps · Finn Harps FC · FC Sligo Rovers · FC Shamrock Rovers
- **G** (3): Galway · Galway United · Galway United FC
- **L** (5): Limerick · Longford · Limerick FC · Longford Town · Longford Town FC
- **M** (3): Mervue · Monaghan · Monaghan United
- **S** (16): Sligo · Shamrock · Shelbourne · Sligo Rovers · St Patrick's · St. Patricks · Shelbourne FC · Saint Patrick's · Shamrock Rovers · Sligo Rovers FC · Sporting Fingal · Shamrock Rovers FC · Sporting Fingal FC · St Patrick's Athletic · St Patrick's Athletic FC · Saint Patrick's Athletic FC
- **U** (5): UCD · UC Dublin · Uni College Dublin · University College Dublin · University College Dublin AFC
- **W** (8): Wexford · Waterford · Wexford FC · Waterford FC · Waterford AFC · Wexford Youths · Waterford United (1982-2016) · Waterford United FC (1982-2016)




