29 clubs

- [**PFC CSKA Sofia**](https://en.wikipedia.org/wiki/PFC_CSKA_Sofia) : (5) CSKA Sofia · CDNA Sofia · CSKA-Sofia · PFC CSKA-Sofia · ZSKA Sofia [de]
- [**PFC Levski Sofia**](https://en.wikipedia.org/wiki/PFC_Levski_Sofia) : (5) Levski · Levski Sofia · Vitosha Sofia · Levski-Spartak Sofia · Professional Football Club Levski Sofia
- [**PFC Slavia Sofia**](https://en.wikipedia.org/wiki/PFC_Slavia_Sofia) : (2) Slavia Sofia · Professional Football Club Slavia Sofia
- [**PFC Lokomotiv Sofia**](https://en.wikipedia.org/wiki/PFC_Lokomotiv_Sofia) : (1) Lokomotiv Sofia
- **Tsarsko Selo Sofia** : (1) FC Tsarsko Selo Sofia
- **PFC Akademik Sofia** : (2) Akademik · Akademik Sofia
- **Tsarsko Selo** : (1) FC Tsarsko Selo Sofia 2015
- [**PFC Botev Plovdiv**](https://en.wikipedia.org/wiki/PFC_Botev_Plovdiv) : (2) Botev Plovdiv · Trakia Plovdiv
- [**PFC Lokomotiv Plovdiv**](https://en.wikipedia.org/wiki/PFC_Lokomotiv_Plovdiv) : (3) Lokomotiv Plovdiv · PFC Lokomotiv Plovdiv 1926 · PFC Lokomotiv Plovdiv 1936
- **Spartak Plovdiv** : (1) FC Spartak Plovdiv
- [**PFC Litex Lovech**](https://en.wikipedia.org/wiki/PFC_Litex_Lovech) : (3) Litex · Litex Lovech · Professional Football Club Litex Lovech
- [**PFC Cherno More Varna**](https://en.wikipedia.org/wiki/PFC_Cherno_More_Varna) : (2) Cherno More · Cherno More Varna
- **FC Spartak Varna** : (1) Spartak Varna
- [**PFC Ludogorets Razgrad**](https://en.wikipedia.org/wiki/PFC_Ludogorets_Razgrad) : (7) Ludogorets · Ludog. Razgrad · Ludogorets Razgrad · PFC Ludogorets 1945 · PFK Ludogorets Razgrad · PFC Ludogorets 1945 Razgrad · Professional Football Club Ludogorets Razgrad
- [**PFC Beroe Stara Zagora**](https://en.wikipedia.org/wiki/PFC_Beroe_Stara_Zagora) : (5) Beroe · PFC Beroe · Beroe Stara Zag. · FC Beroe Stara Zagora · Professional Football Club Beroe
- **PFC Lokomotiv Stara Zagora (1934-2009)** : (1) FC Beroe 2000 Kazanlak
- [**PFC Montana**](https://en.wikipedia.org/wiki/PFC_Montana) : (3) Montana · PFC Montana 1921 · Professional Football Club Montana
- [**FC Pirin Blagoevgrad**](https://en.wikipedia.org/wiki/FC_Pirin_Blagoevgrad) : (3) Blagoevgrad · Pirin Blagoevgrad · PFC Pirin Blagoevgrad
- **FC Dunav Ruse** : (5) Dunav · FC Dunav · Dunav Ruse · FC Dunav 2010 · PFC Dunav Ruse
- **POFC Botev Vratsa** : (4) Botev Vratsa · FK Botev Vratsa · OFC Botev Vratsa · PFC Botev Vratsa
- **SFC Etar Veliko Tarnovo** : (3) Etar Tarnovo · Et. Veliko Tarnovo · Etar Veliko Tarnovo
- **Arda** : (1) FC Arda Kardzhali
- **FC Etar Veliko Tarnovo** : (1) Etar
- **Vitosha Bistritsa** : (3) FC Vitosha · Vitosha Bistrica · FC Vitosha Bistritsa
- **OFC Sliven 2000** : (2) Sliven · OFC Sliven
- **FC Sliven (-2000)**
- **PFC Marek Dupnitsa** : (4) FC Marek · Marek Dupnitza · Marek Dupnitsa · FC Marek Dupnitsa
- **Neftochimik Burgas** : (5) FK Neftochimik · PFC Naftex Burgas · PFC Neftochimic Burgas · Neftochimic Burgas 1962 · Profesionalen Futbolen Klub Neftochimik 1962 Burgas
- **FC Shumen 1929 (-2016)** : (1) FC Shumen




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **PFC CSKA Sofia**, Sofia (2):
  - `pfccskasofia` (2): PFC CSKA Sofia · PFC CSKA-Sofia
  - `cskasofia` (2): CSKA Sofia · CSKA-Sofia




By City

- **Sofia** (6): 
  - PFC CSKA Sofia  (5) CSKA Sofia · CDNA Sofia · PFC CSKA-Sofia · CSKA-Sofia · ZSKA Sofia [de]
  - PFC Levski Sofia  (5) Levski Sofia · Levski · Professional Football Club Levski Sofia · Levski-Spartak Sofia · Vitosha Sofia
  - PFC Slavia Sofia  (2) Slavia Sofia · Professional Football Club Slavia Sofia
  - PFC Lokomotiv Sofia  (1) Lokomotiv Sofia
  - Tsarsko Selo Sofia  (1) FC Tsarsko Selo Sofia
  - PFC Akademik Sofia  (2) Akademik · Akademik Sofia
- **Plovdiv** (3): 
  - PFC Botev Plovdiv  (2) Botev Plovdiv · Trakia Plovdiv
  - PFC Lokomotiv Plovdiv  (3) Lokomotiv Plovdiv · PFC Lokomotiv Plovdiv 1926 · PFC Lokomotiv Plovdiv 1936
  - Spartak Plovdiv  (1) FC Spartak Plovdiv
- **Sliven** (2): 
  - OFC Sliven 2000  (2) Sliven · OFC Sliven
  - FC Sliven (-2000) 
- **Stara Zagora** (2): 
  - PFC Beroe Stara Zagora  (5) Beroe · Professional Football Club Beroe · Beroe Stara Zag. · PFC Beroe · FC Beroe Stara Zagora
  - PFC Lokomotiv Stara Zagora (1934-2009)  (1) FC Beroe 2000 Kazanlak
- **Varna** (2): 
  - PFC Cherno More Varna  (2) Cherno More · Cherno More Varna
  - FC Spartak Varna  (1) Spartak Varna
- **Bistritsa** (1): Vitosha Bistritsa  (3) FC Vitosha · FC Vitosha Bistritsa · Vitosha Bistrica
- **Blagoevgrad** (1): FC Pirin Blagoevgrad  (3) Blagoevgrad · PFC Pirin Blagoevgrad · Pirin Blagoevgrad
- **Burgas** (1): Neftochimik Burgas  (5) Neftochimic Burgas 1962 · PFC Neftochimic Burgas · Profesionalen Futbolen Klub Neftochimik 1962 Burgas · FK Neftochimik · PFC Naftex Burgas
- **Dupnitsa** (1): PFC Marek Dupnitsa  (4) FC Marek · FC Marek Dupnitsa · Marek Dupnitza · Marek Dupnitsa
- **Lovech** (1): PFC Litex Lovech  (3) Litex · Litex Lovech · Professional Football Club Litex Lovech
- **Montana** (1): PFC Montana  (3) Montana · PFC Montana 1921 · Professional Football Club Montana
- **Razgrad** (1): PFC Ludogorets Razgrad  (7) Ludogorets · Ludog. Razgrad · Ludogorets Razgrad · Professional Football Club Ludogorets Razgrad · PFC Ludogorets 1945 · PFK Ludogorets Razgrad · PFC Ludogorets 1945 Razgrad
- **Ruse** (1): FC Dunav Ruse  (5) Dunav · Dunav Ruse · FC Dunav · FC Dunav 2010 · PFC Dunav Ruse
- **Shumen** (1): FC Shumen 1929 (-2016)  (1) FC Shumen
- **Veliko Tarnovo** (1): SFC Etar Veliko Tarnovo  (3) Et. Veliko Tarnovo · Etar Veliko Tarnovo · Etar Tarnovo
- **Vratsa** (1): POFC Botev Vratsa  (4) Botev Vratsa · OFC Botev Vratsa · PFC Botev Vratsa · FK Botev Vratsa
- ? (3): 
  - Tsarsko Selo  (1) FC Tsarsko Selo Sofia 2015
  - Arda  (1) FC Arda Kardzhali
  - FC Etar Veliko Tarnovo  (1) Etar




By Region

- **Sofia†** (6):   PFC CSKA Sofia · PFC Levski Sofia · PFC Slavia Sofia · PFC Lokomotiv Sofia · Tsarsko Selo Sofia · PFC Akademik Sofia
- **Plovdiv†** (3):   PFC Botev Plovdiv · PFC Lokomotiv Plovdiv · Spartak Plovdiv
- **Lovech†** (1):   PFC Litex Lovech
- **Varna†** (2):   PFC Cherno More Varna · FC Spartak Varna
- **Razgrad†** (1):   PFC Ludogorets Razgrad
- **Stara Zagora†** (2):   PFC Beroe Stara Zagora · PFC Lokomotiv Stara Zagora (1934-2009)
- **Montana†** (1):   PFC Montana
- **Blagoevgrad†** (1):   FC Pirin Blagoevgrad
- **Ruse†** (1):   FC Dunav Ruse
- **Vratsa†** (1):   POFC Botev Vratsa
- **Veliko Tarnovo†** (1):   SFC Etar Veliko Tarnovo
- **Bistritsa†** (1):   Vitosha Bistritsa
- **Sliven†** (2):   OFC Sliven 2000 · FC Sliven (-2000)
- **Dupnitsa†** (1):   PFC Marek Dupnitsa
- **Burgas†** (1):   Neftochimik Burgas
- **Shumen†** (1):   FC Shumen 1929 (-2016)




By Year

- **1912** (1):   PFC Botev Plovdiv
- **1913** (2):   PFC Slavia Sofia · PFC Cherno More Varna
- **1914** (1):   PFC Levski Sofia
- **1916** (1):   PFC Beroe Stara Zagora
- **1918** (1):   FC Spartak Varna
- **1919** (1):   PFC Marek Dupnitsa
- **1921** (3):   PFC Litex Lovech · PFC Montana · POFC Botev Vratsa
- **1922** (1):   FC Pirin Blagoevgrad
- **1926** (1):   PFC Lokomotiv Plovdiv
- **1929** (1):   PFC Lokomotiv Sofia
- **1934** (1):   PFC Lokomotiv Stara Zagora (1934-2009)
- **1945** (1):   PFC Ludogorets Razgrad
- **1947** (2):   PFC Akademik Sofia · Spartak Plovdiv
- **1948** (1):   PFC CSKA Sofia
- **1949** (1):   FC Dunav Ruse
- **1962** (1):   Neftochimik Burgas
- **2000** (1):   OFC Sliven 2000
- **2015** (1):   Tsarsko Selo Sofia
- ? (7):   Tsarsko Selo · SFC Etar Veliko Tarnovo · Arda · FC Etar Veliko Tarnovo · Vitosha Bistritsa · FC Sliven (-2000) · FC Shumen 1929 (-2016)




Historic

- **2000** (1):   FC Sliven (-2000)
- **2009** (1):   PFC Lokomotiv Stara Zagora (1934-2009)
- **2016** (1):   FC Shumen 1929 (-2016)






By A to Z

- **A** (3): Arda · Akademik · Akademik Sofia
- **B** (5): Beroe · Blagoevgrad · Botev Vratsa · Botev Plovdiv · Beroe Stara Zag.
- **C** (5): CDNA Sofia · CSKA Sofia · CSKA-Sofia · Cherno More · Cherno More Varna
- **D** (2): Dunav · Dunav Ruse
- **E** (4): Etar · Etar Tarnovo · Et. Veliko Tarnovo · Etar Veliko Tarnovo
- **F** (21): FC Dunav · FC Marek · FC Shumen · FC Vitosha · FC Dunav 2010 · FC Dunav Ruse · FK Neftochimik · FK Botev Vratsa · FC Spartak Varna · FC Arda Kardzhali · FC Marek Dupnitsa · FC Sliven (-2000) · FC Spartak Plovdiv · FC Pirin Blagoevgrad · FC Vitosha Bistritsa · FC Beroe Stara Zagora · FC Tsarsko Selo Sofia · FC Beroe 2000 Kazanlak · FC Etar Veliko Tarnovo · FC Shumen 1929 (-2016) · FC Tsarsko Selo Sofia 2015
- **L** (10): Litex · Levski · Ludogorets · Levski Sofia · Litex Lovech · Ludog. Razgrad · Lokomotiv Sofia · Lokomotiv Plovdiv · Ludogorets Razgrad · Levski-Spartak Sofia
- **M** (3): Montana · Marek Dupnitsa · Marek Dupnitza
- **N** (2): Neftochimik Burgas · Neftochimic Burgas 1962
- **O** (3): OFC Sliven · OFC Sliven 2000 · OFC Botev Vratsa
- **P** (36): PFC Beroe · PFC Montana · PFC CSKA Sofia · PFC CSKA-Sofia · PFC Dunav Ruse · PFC Botev Vratsa · PFC Levski Sofia · PFC Litex Lovech · PFC Montana 1921 · PFC Slavia Sofia · PFC Botev Plovdiv · PFC Naftex Burgas · POFC Botev Vratsa · Pirin Blagoevgrad · PFC Akademik Sofia · PFC Marek Dupnitsa · PFC Lokomotiv Sofia · PFC Ludogorets 1945 · PFC Cherno More Varna · PFC Lokomotiv Plovdiv · PFC Pirin Blagoevgrad · PFC Beroe Stara Zagora · PFC Ludogorets Razgrad · PFC Neftochimic Burgas · PFK Ludogorets Razgrad · PFC Lokomotiv Plovdiv 1926 · PFC Lokomotiv Plovdiv 1936 · PFC Ludogorets 1945 Razgrad · Professional Football Club Beroe · Professional Football Club Montana · PFC Lokomotiv Stara Zagora (1934-2009) · Professional Football Club Levski Sofia · Professional Football Club Litex Lovech · Professional Football Club Slavia Sofia · Professional Football Club Ludogorets Razgrad · Profesionalen Futbolen Klub Neftochimik 1962 Burgas
- **S** (5): Sliven · Slavia Sofia · Spartak Varna · Spartak Plovdiv · SFC Etar Veliko Tarnovo
- **T** (3): Tsarsko Selo · Trakia Plovdiv · Tsarsko Selo Sofia
- **V** (3): Vitosha Sofia · Vitosha Bistrica · Vitosha Bistritsa
- **Z** (1): ZSKA Sofia [de]




