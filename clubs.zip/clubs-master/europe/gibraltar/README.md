14 clubs

- **Lincoln FC** : (3) Lincoln · Lincoln Red Imps · Lincoln Red Imps FC
- **Manchester 62 FC** : (1) Manchester 62
- **Lynx FC** : (1) Lynx
- **College Europa FC** : (2) Europa · Europa FC
- **Europa Point FC** : (1) Europa Point
- **College 1975 FC** : (1) College
- **Glacis United FC** : (1) Glacis
- **Lions Gibraltar FC** : (1) Lions Gibraltar
- **St Joseph's FRAC** : (2) St Joseph's · St Joseph's FC
- **Gibraltar Phoenix FC**
- **FC Magpies** : (1) Magpies
- **Mons Calpe SC** : (1) Mons Calpe
- **Boca Juniors Gibraltar FC** : (1) Boca Juniors
- **FC Olympique** : (1) Olympique




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- ? (14): 
  - Lincoln FC  (3) Lincoln · Lincoln Red Imps FC · Lincoln Red Imps
  - Manchester 62 FC  (1) Manchester 62
  - Lynx FC  (1) Lynx
  - College Europa FC  (2) Europa · Europa FC
  - Europa Point FC  (1) Europa Point
  - College 1975 FC  (1) College
  - Glacis United FC  (1) Glacis
  - Lions Gibraltar FC  (1) Lions Gibraltar
  - St Joseph's FRAC  (2) St Joseph's · St Joseph's FC
  - Gibraltar Phoenix FC 
  - FC Magpies  (1) Magpies
  - Mons Calpe SC  (1) Mons Calpe
  - Boca Juniors Gibraltar FC  (1) Boca Juniors
  - FC Olympique  (1) Olympique




By Region





By Year

- ? (14):   Lincoln FC · Manchester 62 FC · Lynx FC · College Europa FC · Europa Point FC · College 1975 FC · Glacis United FC · Lions Gibraltar FC · St Joseph's FRAC · Gibraltar Phoenix FC · FC Magpies · Mons Calpe SC · Boca Juniors Gibraltar FC · FC Olympique






By A to Z

- **B** (2): Boca Juniors · Boca Juniors Gibraltar FC
- **C** (3): College · College 1975 FC · College Europa FC
- **E** (4): Europa · Europa FC · Europa Point · Europa Point FC
- **F** (2): FC Magpies · FC Olympique
- **G** (3): Glacis · Glacis United FC · Gibraltar Phoenix FC
- **L** (8): Lynx · Lincoln · Lynx FC · Lincoln FC · Lions Gibraltar · Lincoln Red Imps · Lions Gibraltar FC · Lincoln Red Imps FC
- **M** (5): Magpies · Mons Calpe · Manchester 62 · Mons Calpe SC · Manchester 62 FC
- **O** (1): Olympique
- **S** (3): St Joseph's · St Joseph's FC · St Joseph's FRAC




