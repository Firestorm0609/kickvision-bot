47 clubs

- **Steaua București** : (7) FCSB · Steaua · CCA București · Steaua Bucuresti · FCS Bukarest [de] · FC Steaua Bucuresti · FC Steaua București ⇒ (3) ≈CCA Bucuresti≈ · ≈Steaua Bucuresti≈ · ≈FC Steaua Bucuresti≈
- **Dinamo București** : (7) Din. Bucuresti · FC Dinamo 1948 · Dinamo Bucuresti · Dinamo Bucureşti · FC Dinamo București · FC Dinamo Bucureşti · Dinamo Bukarest [de] ⇒ (4) ≈Dinamo Bucuresti≈ · ≈Dinamo Bucuresti≈ · ≈FC Dinamo Bucuresti≈ · ≈FC Dinamo Bucuresti≈
- **Rapid București** : (6) FC Rapid 1923 · Rapid Bucureşti · FC Rapid București · FC Rapid Bucuresti · Rapid Bukarest [de] · Fotbal Club Rapid 1923 ⇒ (3) ≈Rapid Bucuresti≈ · ≈Rapid Bucuresti≈ · ≈FC Rapid Bucuresti≈
- **Daco-Getica București** : (2) Daco-Getica Bucuresti · Asociația Sport Club Daco-Getica București ⇒ (2) ≈Daco-Getica Bucuresti≈ · ≈Asociatia Sport Club Daco-Getica Bucuresti≈
- **Sportul Studenţesc Bucureşti** : (4) Sportul · Sportul Studenţesc · FC Sportul Studenţesc · FC Sportul Studenţesc Bucureşti ⇒ (4) ≈Sportul Studentesc≈ · ≈FC Sportul Studentesc≈ · ≈Sportul Studentesc Bucuresti≈ · ≈FC Sportul Studentesc Bucuresti≈
- **AS Progresul București** : (6) Progresul · Naţional Bucureşti · Progresul București · FC Naţional Bucureşti · FC Progresul București · Fotbal Club Progresul București ⇒ (6) ≈National Bucuresti≈ · ≈Progresul Bucuresti≈ · ≈FC National Bucuresti≈ · ≈FC Progresul Bucuresti≈ · ≈AS Progresul Bucuresti≈ · ≈Fotbal Club Progresul Bucuresti≈
- **Victoria București (1949-1990)** ⇒ (1) ≈Victoria Bucuresti≈
- **CFR Cluj** : (3) FC CFR Cluj · CFR 1907 Cluj · FC CFR 1907 Cluj
- **U Cluj** : (4) U. Cluj · FC Univ. Cluj · Universitatea Cluj · FC Universitatea Cluj
- **Astra Giurgiu** : (3) Astra · FC Astra Giurgiu · AFC Astra Giurgiu
- **Ceahlăul Piatra Neamț** : (3) Ceahlaul · Ceahlaul Piatra Neamt · CSM Ceahlăul Piatra Neamț ⇒ (2) ≈Ceahlaul Piatra Neamt≈ · ≈CSM Ceahlaul Piatra Neamt≈
- **Concordia Chiajna** : (2) Concordia · CS Concordia Chiajna
- **FC Vaslui** : (1) Vaslui
- **Gaz Metan Mediaș** : (4) Gaz Metan · Gaz Metan Medias · CS Gaz Metan Mediaș · CS Gaz Metan Mediaş ⇒ (3) ≈Gaz Metan Medias≈ · ≈CS Gaz Metan Medias≈ · ≈CS Gaz Metan Medias≈
- **Gloria Bistrița** : (3) Bistrita · Gloria Bistrita · ACF Gloria 1922 Bistriţa ⇒ (2) ≈Gloria Bistrita≈ · ≈ACF Gloria 1922 Bistrita≈
- **FC Petrolul Ploiești** : (4) Petrolul · Petrolul Ploiesti · Petrolul Ploiești · FC Petrolul Ploieşti ⇒ (3) ≈Petrolul Ploiesti≈ · ≈FC Petrolul Ploiesti≈ · ≈FC Petrolul Ploiesti≈
- **FC Viitorul Constanța** : (3) Viitorul · FC Viitorul · Viitorul Constanța ⇒ (2) ≈Viitorul Constanta≈ · ≈FC Viitorul Constanta≈
- **Corona Brașov (2010-2014)** : (2) ASC Corona 2010 Brașov · Asociatia Sport Club Corona Brașov ⇒ (3) ≈Corona Brasov≈ · ≈ASC Corona 2010 Brasov≈ · ≈Asociatia Sport Club Corona Brasov≈
- **FC Brașov** : (4) SR Brașov · AS SR Brașov · Steagul Rosu Brașov · Asociația Sportivă SR Brașov ⇒ (5) ≈FC Brasov≈ · ≈SR Brasov≈ · ≈AS SR Brasov≈ · ≈Steagul Rosu Brasov≈ · ≈Asociatia Sportiva SR Brasov≈
- **Dunărea Călărași** : (4) Călărași · AFC Dunărea 2005 · FC Dunărea Călărași · Asociația Fotbal Club Dunărea 2005 Călărași ⇒ (5) ≈Calarasi≈ · ≈Dunarea Calarasi≈ · ≈AFC Dunarea 2005≈ · ≈FC Dunarea Calarasi≈ · ≈Asociatia Fotbal Club Dunarea 2005 Calarasi≈
- **Chindia Târgoviște** : (1) AFC Chindia Târgoviște ⇒ (2) ≈Chindia Targoviste≈ · ≈AFC Chindia Targoviste≈
- **CS Turnu Severin** : (1) Clubul Sportiv Turnu Severin
- **FC Severin** : (1) FC Drobeta-Turnu Severin
- **AFC Turris-Oltul** : (3) Turris Turnu Măgurele · Turris-Oltul Turnu Măgurele · AFC Turris-Oltul Turnu Măgurele ⇒ (3) ≈Turris Turnu Magurele≈ · ≈Turris-Oltul Turnu Magurele≈ · ≈AFC Turris-Oltul Turnu Magurele≈
- **FC Botoșani** : (3) Botoşani · FC Botoşani · Fotbal Club Botoșani ⇒ (4) ≈Botosani≈ · ≈FC Botosani≈ · ≈FC Botosani≈ · ≈Fotbal Club Botosani≈
- **FC Hermannstadt** : (2) Hermannstadt · AFC Hermannstadt
- **Săgeata Năvodari** : (2) Năvodari · AFC Săgeata Năvodari ⇒ (3) ≈Navodari≈ · ≈Sageata Navodari≈ · ≈AFC Sageata Navodari≈
- **Oțelul Galați** : (4) Oţelul · Oțelul · FC Oțelul Galați · ASC Oțelul Galați ⇒ (5) ≈Otelul≈ · ≈Otelul≈ · ≈Otelul Galati≈ · ≈FC Otelul Galati≈ · ≈ASC Otelul Galati≈
- **Pandurii Târgu Jiu** : (3) Pandurii · Pandurii Tg Jiu · CS Pandurii Târgu Jiu ⇒ (2) ≈Pandurii Targu Jiu≈ · ≈CS Pandurii Targu Jiu≈
- **FC Politehnica Iași** : (7) Poli Iasi · Poli Iași · CSMS Iasi · Politehnica Iași · Politehnica Iaşi · CSM Politehnica Iași · CSM Politehnica Iaşi ⇒ (6) ≈Poli Iasi≈ · ≈Politehnica Iasi≈ · ≈Politehnica Iasi≈ · ≈FC Politehnica Iasi≈ · ≈CSM Politehnica Iasi≈ · ≈CSM Politehnica Iasi≈
- **Poli Timișoara** : (5) Timişoara · FC Timișoara · ACS Poli Timișoara · Politehnica Timișoara · FC Politehnica Timișoara ⇒ (6) ≈Timisoara≈ · ≈FC Timisoara≈ · ≈Poli Timisoara≈ · ≈ACS Poli Timisoara≈ · ≈Politehnica Timisoara≈ · ≈FC Politehnica Timisoara≈
- **Sepsi Sfântu Gheorghe** : (3) Sepsi · Sepsi OSK · Sepsi Sf. Gheorghe ⇒ (1) ≈Sepsi Sfantu Gheorghe≈
- **ASA Târgu Mureș (2008-2018)** : (5) Târgu Mureș · Târgu Mureş · ASA Târgu Mureş · ASA Tîrgu Mureş · FCM Târgu Mureş ⇒ (6) ≈Targu Mures≈ · ≈Targu Mures≈ · ≈ASA Targu Mures≈ · ≈ASA Targu Mures≈ · ≈ASA Tirgu Mures≈ · ≈FCM Targu Mures≈
- **Universitatea Craiova** : (8) U Craiova · CS U Craiova · Univ. Craiova · CS Uni Craiova · U Craiova 1948 CS · CS Universitatea Craiova · FC Universitatea Craiova · U Craiova 1948 Club Sportiv
- **UTA Arad** : (4) UT Arad · FC UTA Arad · FCM UTA Arad · Fotbal Club UTA Arad
- **FC Voluntari** : (3) Voluntari · CS Voluntari · FC FC Voluntari
- **FC Academica Clinceni** : (3) Academica Clinceni · FC Academica Clinc · Fotbal Club Academica Clinceni
- **CS Mioveni** : (1) Mioveni
- **CSM Flacăra Moreni** : (4) Flacăra · Flacăra Moreni · CS Flacăra Moreni · Club Sportiv Municipal Flacăra Moreni ⇒ (5) ≈Flacara≈ · ≈Flacara Moreni≈ · ≈CS Flacara Moreni≈ · ≈CSM Flacara Moreni≈ · ≈Club Sportiv Municipal Flacara Moreni≈
- **FC Argeș Pitești** : (2) Argeș · Argeș Pitești ⇒ (3) ≈Arges≈ · ≈Arges Pitesti≈ · ≈FC Arges Pitesti≈
- **CS Minaur Baia Mare** : (3) Baia Mare · FC Baia Mare · Minaur Baia Mare
- **CSM Jiul Petroșani** : (3) Jiul Petroșani · CS Jiul Petroșani · Clubul Sportiv Municipal Jiul Petroșani ⇒ (4) ≈Jiul Petrosani≈ · ≈CS Jiul Petrosani≈ · ≈CSM Jiul Petrosani≈ · ≈Clubul Sportiv Municipal Jiul Petrosani≈
- **FCM Bacău** : (2) FCM 1950 Bacău · ASS FCM 1950 Bacău ⇒ (3) ≈FCM Bacau≈ · ≈FCM 1950 Bacau≈ · ≈ASS FCM 1950 Bacau≈
- **Chimia Râmnicu Vâlcea (1946-2004)** : (3) FC Râmnicu Vâlcea · Chimia Rimnicu Vilcea · CS Chimia Râmnicu Vâlcea ⇒ (3) ≈FC Ramnicu Valcea≈ · ≈Chimia Ramnicu Valcea≈ · ≈CS Chimia Ramnicu Valcea≈
- **Unirea Urziceni (1954-2017)** : (2) FC Unirea · FC Unirea Urziceni
- **FC Corvinul Hunedoara (1921-2004)** : (1) Corvinul Hunedoara
- **FC Extensiv Craiova (1949-2013)** : (2) FC Caracal · Fotbal Club Extensiv Craiova




Alphabet

- **Alphabet Specials** (7):  **â**  **î**  **ă**  **ş**  **ţ**  **ș**  **ț** 
  - **â**×16 U+00E2 (226) - LATIN SMALL LETTER A WITH CIRCUMFLEX ⇒ a
  - **î**×1 U+00EE (238) - LATIN SMALL LETTER I WITH CIRCUMFLEX ⇒ i
  - **ă**×31 U+0103 (259) - LATIN SMALL LETTER A WITH BREVE ⇒ a
  - **ş**×18 U+015F (351) - LATIN SMALL LETTER S WITH CEDILLA ⇒ s
  - **ţ**×8 U+0163 (355) - LATIN SMALL LETTER T WITH CEDILLA ⇒ t
  - **ș**×54 U+0219 (537) - LATIN SMALL LETTER S WITH COMMA BELOW ⇒ s
  - **ț**×15 U+021B (539) - LATIN SMALL LETTER T WITH COMMA BELOW ⇒ t




Duplicates

- **Steaua București**, București (2):
  - `steauabucuresti` (2): **Steaua Bucuresti** · **Steaua Bucuresti**
  - `fcsteauabucuresti` (2): **FC Steaua Bucuresti** · **FC Steaua Bucuresti**
- **Dinamo București**, București (2):
  - `dinamobucuresti` (3): **Dinamo Bucuresti** · **Dinamo Bucuresti** · **Dinamo Bucuresti**
  - `fcdinamobucuresti` (2): **FC Dinamo Bucuresti** · **FC Dinamo Bucuresti**
- **Rapid București**, București (2):
  - `fcrapidbucuresti` (2): **FC Rapid Bucuresti** · **FC Rapid Bucuresti**
  - `rapidbucuresti` (2): **Rapid Bucuresti** · **Rapid Bucuresti**
- **Daco-Getica București**, București (1):
  - `dacogeticabucuresti` (2): **Daco-Getica Bucuresti** · **Daco-Getica Bucuresti**
- **U Cluj**, Cluj (1):
  - `ucluj` (2): U Cluj · U. Cluj
- **Ceahlăul Piatra Neamț**, Piatra Neamț (1):
  - `ceahlaulpiatraneamt` (2): **Ceahlaul Piatra Neamt** · **Ceahlaul Piatra Neamt**
- **Gaz Metan Mediaș**, Mediaș (2):
  - `gazmetanmedias` (2): **Gaz Metan Medias** · **Gaz Metan Medias**
  - `csgazmetanmedias` (2): **CS Gaz Metan Medias** · **CS Gaz Metan Medias**
- **Gloria Bistrița**, Bistrița (1):
  - `gloriabistrita` (2): **Gloria Bistrita** · **Gloria Bistrita**
- **FC Petrolul Ploiești**, Ploiești (2):
  - `petrolulploiesti` (2): **Petrolul Ploiesti** · **Petrolul Ploiesti**
  - `fcpetrolulploiesti` (2): **FC Petrolul Ploiesti** · **FC Petrolul Ploiesti**
- **FC Botoșani**, Botoșani (1):
  - `fcbotosani` (2): **FC Botosani** · **FC Botosani**
- **Oțelul Galați**, Galați (1):
  - `otelul` (2): **Otelul** · **Otelul**
- **FC Politehnica Iași**, Iași (3):
  - `poliiasi` (2): **Poli Iasi** · **Poli Iasi**
  - `politehnicaiasi` (2): **Politehnica Iasi** · **Politehnica Iasi**
  - `csmpolitehnicaiasi` (2): **CSM Politehnica Iasi** · **CSM Politehnica Iasi**
- **ASA Târgu Mureș (2008-2018)**, Târgu Mureș (2):
  - `asatargumures` (2): **ASA Targu Mures** · **ASA Targu Mures**
  - `targumures` (2): **Targu Mures** · **Targu Mures**




By City

- **București** (7): 
  - Steaua București  (7) Steaua · Steaua Bucuresti · FC Steaua Bucuresti · FC Steaua București · FCSB · FCS Bukarest [de] · CCA București
  - Dinamo București  (7) Din. Bucuresti · Dinamo Bucuresti · FC Dinamo București · FC Dinamo Bucureşti · Dinamo Bucureşti · FC Dinamo 1948 · Dinamo Bukarest [de]
  - Rapid București  (6) FC Rapid Bucuresti · FC Rapid București · Rapid Bucureşti · Fotbal Club Rapid 1923 · FC Rapid 1923 · Rapid Bukarest [de]
  - Daco-Getica București  (2) Daco-Getica Bucuresti · Asociația Sport Club Daco-Getica București
  - Sportul Studenţesc Bucureşti  (4) Sportul · Sportul Studenţesc · FC Sportul Studenţesc · FC Sportul Studenţesc Bucureşti
  - AS Progresul București  (6) Progresul · Progresul București · FC Progresul București · Fotbal Club Progresul București · Naţional Bucureşti · FC Naţional Bucureşti
  - Victoria București (1949-1990) 
- **Brașov** (2): 
  - Corona Brașov (2010-2014)  (2) ASC Corona 2010 Brașov · Asociatia Sport Club Corona Brașov
  - FC Brașov  (4) SR Brașov · Steagul Rosu Brașov · AS SR Brașov · Asociația Sportivă SR Brașov
- **Cluj** (2): 
  - CFR Cluj  (3) CFR 1907 Cluj · FC CFR Cluj · FC CFR 1907 Cluj
  - U Cluj  (4) U. Cluj · Universitatea Cluj · FC Univ. Cluj · FC Universitatea Cluj
- **Drobeta-Turnu Severin** (2): 
  - CS Turnu Severin  (1) Clubul Sportiv Turnu Severin
  - FC Severin  (1) FC Drobeta-Turnu Severin
- **Arad** (1): UTA Arad  (4) FC UTA Arad · Fotbal Club UTA Arad · FCM UTA Arad · UT Arad
- **Bacău** (1): FCM Bacău  (2) FCM 1950 Bacău · ASS FCM 1950 Bacău
- **Baia Mare** (1): CS Minaur Baia Mare  (3) Baia Mare · Minaur Baia Mare · FC Baia Mare
- **Bistrița** (1): Gloria Bistrița  (3) Bistrita · Gloria Bistrita · ACF Gloria 1922 Bistriţa
- **Botoșani** (1): FC Botoșani  (3) Botoşani · FC Botoşani · Fotbal Club Botoșani
- **Caracal** (1): FC Extensiv Craiova (1949-2013)  (2) Fotbal Club Extensiv Craiova · FC Caracal
- **Chiajna** (1): Concordia Chiajna  (2) Concordia · CS Concordia Chiajna
- **Clinceni** (1): FC Academica Clinceni  (3) Academica Clinceni · Fotbal Club Academica Clinceni · FC Academica Clinc
- **Craiova** (1): Universitatea Craiova  (8) U Craiova · CS U Craiova · CS Uni Craiova · U Craiova 1948 CS · CS Universitatea Craiova · U Craiova 1948 Club Sportiv · Univ. Craiova · FC Universitatea Craiova
- **Călărași** (1): Dunărea Călărași  (4) Călărași · AFC Dunărea 2005 · Asociația Fotbal Club Dunărea 2005 Călărași · FC Dunărea Călărași
- **Galați** (1): Oțelul Galați  (4) Oţelul · Oțelul · ASC Oțelul Galați · FC Oțelul Galați
- **Giurgiu** (1): Astra Giurgiu  (3) Astra · FC Astra Giurgiu · AFC Astra Giurgiu
- **Hermannstadt** (1): FC Hermannstadt  (2) Hermannstadt · AFC Hermannstadt
- **Hunedoara** (1): FC Corvinul Hunedoara (1921-2004)  (1) Corvinul Hunedoara
- **Iași** (1): FC Politehnica Iași  (7) Poli Iasi · Poli Iași · Politehnica Iași · CSMS Iasi · CSM Politehnica Iași · CSM Politehnica Iaşi · Politehnica Iaşi
- **Mediaș** (1): Gaz Metan Mediaș  (4) Gaz Metan · Gaz Metan Medias · CS Gaz Metan Mediaș · CS Gaz Metan Mediaş
- **Mioveni** (1): CS Mioveni  (1) Mioveni
- **Moreni** (1): CSM Flacăra Moreni  (4) Flacăra · Flacăra Moreni · CS Flacăra Moreni · Club Sportiv Municipal Flacăra Moreni
- **Năvodari** (1): Săgeata Năvodari  (2) Năvodari · AFC Săgeata Năvodari
- **Ovidiu** (1): FC Viitorul Constanța  (3) Viitorul · FC Viitorul · Viitorul Constanța
- **Petroșani** (1): CSM Jiul Petroșani  (3) Jiul Petroșani · CS Jiul Petroșani · Clubul Sportiv Municipal Jiul Petroșani
- **Piatra Neamț** (1): Ceahlăul Piatra Neamț  (3) Ceahlaul · Ceahlaul Piatra Neamt · CSM Ceahlăul Piatra Neamț
- **Pitești** (1): FC Argeș Pitești  (2) Argeș · Argeș Pitești
- **Ploiești** (1): FC Petrolul Ploiești  (4) Petrolul · Petrolul Ploiesti · Petrolul Ploiești · FC Petrolul Ploieşti
- **Râmnicu Vâlcea** (1): Chimia Râmnicu Vâlcea (1946-2004)  (3) Chimia Rimnicu Vilcea · CS Chimia Râmnicu Vâlcea · FC Râmnicu Vâlcea
- **Sfântu Gheorghe** (1): Sepsi Sfântu Gheorghe  (3) Sepsi · Sepsi Sf. Gheorghe · Sepsi OSK
- **Timișoara** (1): Poli Timișoara  (5) Timişoara · ACS Poli Timișoara · FC Politehnica Timișoara · Politehnica Timișoara · FC Timișoara
- **Turnu Măgurele** (1): AFC Turris-Oltul  (3) AFC Turris-Oltul Turnu Măgurele · Turris Turnu Măgurele · Turris-Oltul Turnu Măgurele
- **Târgoviște** (1): Chindia Târgoviște  (1) AFC Chindia Târgoviște
- **Târgu Jiu** (1): Pandurii Târgu Jiu  (3) Pandurii · Pandurii Tg Jiu · CS Pandurii Târgu Jiu
- **Târgu Mureș** (1): ASA Târgu Mureș (2008-2018)  (5) Târgu Mureș · ASA Târgu Mureş · Târgu Mureş · ASA Tîrgu Mureş · FCM Târgu Mureş
- **Urziceni** (1): Unirea Urziceni (1954-2017)  (2) FC Unirea · FC Unirea Urziceni
- **Vaslui** (1): FC Vaslui  (1) Vaslui
- **Voluntari** (1): FC Voluntari  (3) Voluntari · CS Voluntari · FC FC Voluntari




By Region

- **București†** (7):   Steaua București · Dinamo București · Rapid București · Daco-Getica București · Sportul Studenţesc Bucureşti · AS Progresul București · Victoria București (1949-1990)
- **Cluj†** (2):   CFR Cluj · U Cluj
- **Giurgiu†** (1):   Astra Giurgiu
- **Piatra Neamț†** (1):   Ceahlăul Piatra Neamț
- **Chiajna†** (1):   Concordia Chiajna
- **Vaslui†** (1):   FC Vaslui
- **Mediaș†** (1):   Gaz Metan Mediaș
- **Bistrița†** (1):   Gloria Bistrița
- **Ploiești†** (1):   FC Petrolul Ploiești
- **Ovidiu†** (1):   FC Viitorul Constanța
- **Brașov†** (2):   Corona Brașov (2010-2014) · FC Brașov
- **Călărași†** (1):   Dunărea Călărași
- **Târgoviște†** (1):   Chindia Târgoviște
- **Drobeta-Turnu Severin†** (2):   CS Turnu Severin · FC Severin
- **Turnu Măgurele†** (1):   AFC Turris-Oltul
- **Botoșani†** (1):   FC Botoșani
- **Hermannstadt†** (1):   FC Hermannstadt
- **Năvodari†** (1):   Săgeata Năvodari
- **Galați†** (1):   Oțelul Galați
- **Târgu Jiu†** (1):   Pandurii Târgu Jiu
- **Iași†** (1):   FC Politehnica Iași
- **Timișoara†** (1):   Poli Timișoara
- **Sfântu Gheorghe†** (1):   Sepsi Sfântu Gheorghe
- **Târgu Mureș†** (1):   ASA Târgu Mureș (2008-2018)
- **Craiova†** (1):   Universitatea Craiova
- **Arad†** (1):   UTA Arad
- **Voluntari†** (1):   FC Voluntari
- **Clinceni†** (1):   FC Academica Clinceni
- **Mioveni†** (1):   CS Mioveni
- **Moreni†** (1):   CSM Flacăra Moreni
- **Pitești†** (1):   FC Argeș Pitești
- **Baia Mare†** (1):   CS Minaur Baia Mare
- **Petroșani†** (1):   CSM Jiul Petroșani
- **Bacău†** (1):   FCM Bacău
- **Râmnicu Vâlcea†** (1):   Chimia Râmnicu Vâlcea (1946-2004)
- **Urziceni†** (1):   Unirea Urziceni (1954-2017)
- **Hunedoara†** (1):   FC Corvinul Hunedoara (1921-2004)
- **Caracal†** (1):   FC Extensiv Craiova (1949-2013)




By Year

- **1916** (1):   Sportul Studenţesc Bucureşti
- **1919** (1):   CSM Jiul Petroșani
- **1921** (1):   FC Corvinul Hunedoara (1921-2004)
- **1922** (1):   CSM Flacăra Moreni
- **1923** (1):   Rapid București
- **1936** (1):   FC Brașov
- **1944** (1):   AS Progresul București
- **1946** (1):   Chimia Râmnicu Vâlcea (1946-2004)
- **1948** (2):   Dinamo București · CS Minaur Baia Mare
- **1949** (2):   Victoria București (1949-1990) · FC Extensiv Craiova (1949-2013)
- **1950** (1):   FCM Bacău
- **1954** (1):   Unirea Urziceni (1954-2017)
- **1965** (1):   AFC Turris-Oltul
- **2000** (1):   CS Mioveni
- **2005** (1):   FC Academica Clinceni
- **2008** (1):   ASA Târgu Mureș (2008-2018)
- **2010** (2):   Corona Brașov (2010-2014) · Chindia Târgoviște
- ? (27):   Steaua București · Daco-Getica București · CFR Cluj · U Cluj · Astra Giurgiu · Ceahlăul Piatra Neamț · Concordia Chiajna · FC Vaslui · Gaz Metan Mediaș · Gloria Bistrița · FC Petrolul Ploiești · FC Viitorul Constanța · Dunărea Călărași · CS Turnu Severin · FC Severin · FC Botoșani · FC Hermannstadt · Săgeata Năvodari · Oțelul Galați · Pandurii Târgu Jiu · FC Politehnica Iași · Poli Timișoara · Sepsi Sfântu Gheorghe · Universitatea Craiova · UTA Arad · FC Voluntari · FC Argeș Pitești




Historic

- **1990** (1):   Victoria București (1949-1990)
- **2004** (2):   Chimia Râmnicu Vâlcea (1946-2004) · FC Corvinul Hunedoara (1921-2004)
- **2013** (1):   FC Extensiv Craiova (1949-2013)
- **2014** (1):   Corona Brașov (2010-2014)
- **2017** (1):   Unirea Urziceni (1954-2017)
- **2018** (1):   ASA Târgu Mureș (2008-2018)






By A to Z

- **A** (26): Argeș · Astra · AS SR Brașov · Argeș Pitești · Astra Giurgiu · ASA Târgu Mureş · ASA Tîrgu Mureş · AFC Dunărea 2005 · AFC Hermannstadt · AFC Turris-Oltul · AFC Astra Giurgiu · ASC Oțelul Galați · ACS Poli Timișoara · ASS FCM 1950 Bacău · Academica Clinceni · AFC Săgeata Năvodari · AFC Chindia Târgoviște · AS Progresul București · ASC Corona 2010 Brașov · ACF Gloria 1922 Bistriţa · ASA Târgu Mureș (2008-2018) · Asociația Sportivă SR Brașov · AFC Turris-Oltul Turnu Măgurele · Asociatia Sport Club Corona Brașov · Asociația Sport Club Daco-Getica București · Asociația Fotbal Club Dunărea 2005 Călărași
- **B** (3): Bistrita · Botoşani · Baia Mare
- **C** (37): CFR Cluj · Ceahlaul · Călărași · CSMS Iasi · Concordia · CS Mioveni · CS U Craiova · CS Voluntari · CCA București · CFR 1907 Cluj · CS Uni Craiova · CS Turnu Severin · CS Flacăra Moreni · CS Jiul Petroșani · Concordia Chiajna · CSM Flacăra Moreni · CSM Jiul Petroșani · Chindia Târgoviște · Corvinul Hunedoara · CS Gaz Metan Mediaş · CS Gaz Metan Mediaș · CS Minaur Baia Mare · CS Concordia Chiajna · CSM Politehnica Iaşi · CSM Politehnica Iași · CS Pandurii Târgu Jiu · Ceahlaul Piatra Neamt · Ceahlăul Piatra Neamț · Chimia Rimnicu Vilcea · CS Chimia Râmnicu Vâlcea · CS Universitatea Craiova · CSM Ceahlăul Piatra Neamț · Corona Brașov (2010-2014) · Clubul Sportiv Turnu Severin · Chimia Râmnicu Vâlcea (1946-2004) · Club Sportiv Municipal Flacăra Moreni · Clubul Sportiv Municipal Jiul Petroșani
- **D** (8): Din. Bucuresti · Dinamo Bucuresti · Dinamo Bucureşti · Dinamo București · Dunărea Călărași · Dinamo Bukarest [de] · Daco-Getica Bucuresti · Daco-Getica București
- **F** (61): FCSB · Flacăra · FC Brașov · FC Unirea · FC Vaslui · FCM Bacău · FC Caracal · FC Severin · FC Botoşani · FC Botoșani · FC CFR Cluj · FC UTA Arad · FC Viitorul · FC Baia Mare · FC Timișoara · FC Voluntari · FCM UTA Arad · FC Rapid 1923 · FC Univ. Cluj · FC Dinamo 1948 · FCM 1950 Bacău · Flacăra Moreni · FC FC Voluntari · FC Hermannstadt · FCM Târgu Mureş · FC Argeș Pitești · FC Astra Giurgiu · FC CFR 1907 Cluj · FC Oțelul Galați · FC Râmnicu Vâlcea · FCS Bukarest [de] · FC Academica Clinc · FC Rapid Bucuresti · FC Rapid București · FC Unirea Urziceni · FC Dinamo Bucureşti · FC Dinamo București · FC Dunărea Călărași · FC Politehnica Iași · FC Steaua Bucuresti · FC Steaua București · FC Petrolul Ploieşti · FC Petrolul Ploiești · Fotbal Club Botoșani · Fotbal Club UTA Arad · FC Academica Clinceni · FC Naţional Bucureşti · FC Sportul Studenţesc · FC Universitatea Cluj · FC Viitorul Constanța · FC Progresul București · Fotbal Club Rapid 1923 · FC Drobeta-Turnu Severin · FC Politehnica Timișoara · FC Universitatea Craiova · Fotbal Club Extensiv Craiova · Fotbal Club Academica Clinceni · FC Extensiv Craiova (1949-2013) · FC Sportul Studenţesc Bucureşti · Fotbal Club Progresul București · FC Corvinul Hunedoara (1921-2004)
- **G** (5): Gaz Metan · Gloria Bistrita · Gloria Bistrița · Gaz Metan Medias · Gaz Metan Mediaș
- **H** (1): Hermannstadt
- **J** (1): Jiul Petroșani
- **M** (2): Mioveni · Minaur Baia Mare
- **N** (2): Năvodari · Naţional Bucureşti
- **O** (3): Oţelul · Oțelul · Oțelul Galați
- **P** (14): Pandurii · Petrolul · Poli Iasi · Poli Iași · Progresul · Poli Timișoara · Pandurii Tg Jiu · Politehnica Iaşi · Politehnica Iași · Petrolul Ploiesti · Petrolul Ploiești · Pandurii Târgu Jiu · Progresul București · Politehnica Timișoara
- **R** (3): Rapid Bucureşti · Rapid București · Rapid Bukarest [de]
- **S** (13): Sepsi · Steaua · Sportul · SR Brașov · Sepsi OSK · Steaua Bucuresti · Steaua București · Săgeata Năvodari · Sepsi Sf. Gheorghe · Sportul Studenţesc · Steagul Rosu Brașov · Sepsi Sfântu Gheorghe · Sportul Studenţesc Bucureşti
- **T** (5): Timişoara · Târgu Mureş · Târgu Mureș · Turris Turnu Măgurele · Turris-Oltul Turnu Măgurele
- **U** (11): U Cluj · U. Cluj · UT Arad · UTA Arad · U Craiova · Univ. Craiova · U Craiova 1948 CS · Universitatea Cluj · Universitatea Craiova · U Craiova 1948 Club Sportiv · Unirea Urziceni (1954-2017)
- **V** (5): Vaslui · Viitorul · Voluntari · Viitorul Constanța · Victoria București (1949-1990)




