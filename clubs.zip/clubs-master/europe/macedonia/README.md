20 clubs

- **FK Metalurg Skopje** : (1) Metalurg Skopje
- **FK Makedonija Skopje** : (4) Makedonija · Makedonija GP · FK Makedonija GP Skopje · FK Makedonija Gjorče Petrov ⇒ (1) ≈FK Makedonija Gjorce Petrov≈
- **FK Vardar** : (2) Vardar · Vardar Skopje
- **FK Cementarnica 55** : (1) Cementarnica Skopje
- **Sloga Jugomagnat Skopje (1927-2009)** : (1) FK Sloga Jugomagnat
- **FK Rabotnički** : (2) Rabotnički · Rabotnički Skopje ⇒ (3) ≈Rabotnicki≈ · ≈FK Rabotnicki≈ · ≈Rabotnicki Skopje≈
- **FK Renova** : (3) Renova · KF Renova · Renova Dzepciste
- **FK Shkëndija 79** : (4) Shkëndija · KF Shkëndija · KF Shkëndija 79 · Shkëndija Tetovo ⇒ (5) ≈Shkendija≈ · ≈KF Shkendija≈ · ≈FK Shkendija 79≈ · ≈KF Shkendija 79≈ · ≈Shkendija Tetovo≈
- **FK Teteks**
- **FK Milano**
- **FK Pelister** : (1) Pelister Bitola
- **KF Shkupi** : (3) Shkupi · FK Shkupi · FC Shkupi 1927
- **FK Sileks** : (2) Sileks · Sileks Kratovo
- **FK Turnovo**
- **Akademija Pandev**
- **FC Struga**
- **FK Borec Veles**
- **FK Pobeda** : (1) FK Pobeda Prilep
- **FK Bashkimi Kumanovo (1947-2008)** : (1) FK Baskimi
- **FK Belasica** : (1) FK Belasica GC




Alphabet

- **Alphabet Specials** (2):  **ë**  **č** 
  - **ë**×5 U+00EB (235) - LATIN SMALL LETTER E WITH DIAERESIS ⇒ e
  - **č**×4 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c




Duplicates





By City

- **Skopje** (6): 
  - FK Metalurg Skopje  (1) Metalurg Skopje
  - FK Makedonija Skopje  (4) Makedonija · FK Makedonija GP Skopje · Makedonija GP · FK Makedonija Gjorče Petrov
  - FK Vardar  (2) Vardar · Vardar Skopje
  - FK Cementarnica 55  (1) Cementarnica Skopje
  - Sloga Jugomagnat Skopje (1927-2009)  (1) FK Sloga Jugomagnat
  - FK Rabotnički  (2) Rabotnički · Rabotnički Skopje
- **Kratovo** (1): FK Sileks  (2) Sileks · Sileks Kratovo
- **Kumanovo** (1): FK Bashkimi Kumanovo (1947-2008)  (1) FK Baskimi
- **Prilep** (1): FK Pobeda  (1) FK Pobeda Prilep
- **Strumica** (1): FK Belasica  (1) FK Belasica GC
- **Čair** (1): KF Shkupi  (3) Shkupi · FC Shkupi 1927 · FK Shkupi
- ? (9): 
  - FK Renova  (3) Renova · KF Renova · Renova Dzepciste
  - FK Shkëndija 79  (4) Shkëndija · KF Shkëndija · KF Shkëndija 79 · Shkëndija Tetovo
  - FK Teteks 
  - FK Milano 
  - FK Pelister  (1) Pelister Bitola
  - FK Turnovo 
  - Akademija Pandev 
  - FC Struga 
  - FK Borec Veles 




By Region

- **Skopje†** (6):   FK Metalurg Skopje · FK Makedonija Skopje · FK Vardar · FK Cementarnica 55 · Sloga Jugomagnat Skopje (1927-2009) · FK Rabotnički
- **Čair†** (1):   KF Shkupi
- **Kratovo†** (1):   FK Sileks
- **Prilep†** (1):   FK Pobeda
- **Kumanovo†** (1):   FK Bashkimi Kumanovo (1947-2008)
- **Strumica†** (1):   FK Belasica




By Year

- **1922** (1):   FK Belasica
- **1927** (2):   Sloga Jugomagnat Skopje (1927-2009) · KF Shkupi
- **1932** (1):   FK Makedonija Skopje
- **1947** (1):   FK Bashkimi Kumanovo (1947-2008)
- **1965** (1):   FK Sileks
- **1995** (1):   FK Cementarnica 55
- ? (13):   FK Metalurg Skopje · FK Vardar · FK Rabotnički · FK Renova · FK Shkëndija 79 · FK Teteks · FK Milano · FK Pelister · FK Turnovo · Akademija Pandev · FC Struga · FK Borec Veles · FK Pobeda




Historic

- **2008** (1):   FK Bashkimi Kumanovo (1947-2008)
- **2009** (1):   Sloga Jugomagnat Skopje (1927-2009)






By A to Z

- **A** (1): Akademija Pandev
- **C** (1): Cementarnica Skopje
- **F** (25): FC Struga · FK Milano · FK Pobeda · FK Renova · FK Shkupi · FK Sileks · FK Teteks · FK Vardar · FK Baskimi · FK Turnovo · FK Belasica · FK Pelister · FK Rabotnički · FC Shkupi 1927 · FK Belasica GC · FK Borec Veles · FK Shkëndija 79 · FK Pobeda Prilep · FK Cementarnica 55 · FK Metalurg Skopje · FK Sloga Jugomagnat · FK Makedonija Skopje · FK Makedonija GP Skopje · FK Makedonija Gjorče Petrov · FK Bashkimi Kumanovo (1947-2008)
- **K** (4): KF Renova · KF Shkupi · KF Shkëndija · KF Shkëndija 79
- **M** (3): Makedonija · Makedonija GP · Metalurg Skopje
- **P** (1): Pelister Bitola
- **R** (4): Renova · Rabotnički · Renova Dzepciste · Rabotnički Skopje
- **S** (6): Shkupi · Sileks · Shkëndija · Sileks Kratovo · Shkëndija Tetovo · Sloga Jugomagnat Skopje (1927-2009)
- **V** (2): Vardar · Vardar Skopje




