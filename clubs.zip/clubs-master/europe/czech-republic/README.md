27 clubs

- [**AC Sparta Praha**](https://en.wikipedia.org/wiki/AC_Sparta_Prague) : (5) Sparta Praha · Sparta Prague · Sparta Prag [de] · AC Sparta Prague [en] · Athletic Club Sparta Praha
- [**FK Dukla Praha**](https://en.wikipedia.org/wiki/FK_Dukla_Prague) : (4) Dukla · Dukla Praha · FK Dukla Prag [de] · FK Dukla Prague [en]
- [**SK Slavia Praha**](https://en.wikipedia.org/wiki/SK_Slavia_Prague) : (6) Slavia Praha · Slavia Prag [de] · Slavia Prague [en] · SK Slavia Prag [de] · SK Slavia Prague [en] · Sportovní klub Slavia Praha ⇒ (1) ≈Sportovni klub Slavia Praha≈
- [**Bohemians Praha 1905**](https://en.wikipedia.org/wiki/Bohemians_1905) : (4) Bohemians 1905 · Bohemians EKD Praha · Bohem. Prag 1905 [de] · FC Bohemians Prag 1905
- **FK Viktoria Žižkov** : (1) Viktoria Žižkov ⇒ (2) ≈Viktoria Zizkov≈ · ≈FK Viktoria Zizkov≈
- [**FK Mladá Boleslav**](https://en.wikipedia.org/wiki/FK_Mladá_Boleslav) : (2) Mladá Boleslav · Fotbalový klub Mladá Boleslav ⇒ (3) ≈Mlada Boleslav≈ · ≈FK Mlada Boleslav≈ · ≈Fotbalovy klub Mlada Boleslav≈
- [**1. FK Příbram**](https://en.wikipedia.org/wiki/1._FK_Příbram) : (2) Příbram · FK Příbram ⇒ (3) ≈Pribram≈ · ≈FK Pribram≈ · ≈1. FK Pribram≈
- [**Viktoria Plzeň**](https://en.wikipedia.org/wiki/FC_Viktoria_Plzeň) : (5) Plzeň · FC Viktoria Plzeň · Vikt. Pilsen [de] · Viktoria Pilsen [de] · Football Club Viktoria Plzeň ⇒ (4) ≈Plzen≈ · ≈Viktoria Plzen≈ · ≈FC Viktoria Plzen≈ · ≈Football Club Viktoria Plzen≈
- [**FC Slovan Liberec**](https://en.wikipedia.org/wiki/FC_Slovan_Liberec) : (3) Liberec · Slovan Liberec · Football Club Slovan Liberec
- [**FK Jablonec**](https://en.wikipedia.org/wiki/FK_Jablonec) : (2) Jablonec · FK Baumit Jablonec
- [**FC Baník Ostrava**](https://en.wikipedia.org/wiki/FC_Baník_Ostrava) : (2) Baník · Baník Ostrava ⇒ (3) ≈Banik≈ · ≈Banik Ostrava≈ · ≈FC Banik Ostrava≈
- [**SK Sigma Olomouc**](https://en.wikipedia.org/wiki/SK_Sigma_Olomouc) : (3) Sigma · Sigma Olomouc · SK Sigma Olmütz [de] ⇒ (2) ≈SK Sigma Olmutz≈ · ≈SK Sigma Olmuetz≈
- [**FK Teplice**](https://en.wikipedia.org/wiki/FK_Teplice) : (1) Teplice
- [**1. FC Slovácko**](https://en.wikipedia.org/wiki/1._FC_Slovácko) : (1) Slovácko ⇒ (2) ≈Slovacko≈ · ≈1. FC Slovacko≈
- [**FC Zlín**](https://en.wikipedia.org/wiki/FC_Fastav_Zlín) : (3) Zlín · Fastav Zlín · FC Fastav Zlín ⇒ (4) ≈Zlin≈ · ≈FC Zlin≈ · ≈Fastav Zlin≈ · ≈FC Fastav Zlin≈
- [**FC Vysočina Jihlava**](https://en.wikipedia.org/wiki/FC_Vysočina_Jihlava) : (3) Jihlava · FC Jihlava · Vysočina Jihlava ⇒ (2) ≈Vysocina Jihlava≈ · ≈FC Vysocina Jihlava≈
- [**FC Zbrojovka Brno**](https://en.wikipedia.org/wiki/FC_Zbrojovka_Brno) : (2) Brno · Zbrojovka Brno
- **FC LeRK Brno (1910-1995)** : (1) Spartak Brno KPS
- [**MFK Karviná**](https://en.wikipedia.org/wiki/MFK_Karviná) : (1) Karviná ⇒ (2) ≈Karvina≈ · ≈MFK Karvina≈
- [**SFC Opava**](https://en.wikipedia.org/wiki/SFC_Opava) : (1) Opava
- **SK Dynamo České Budějovice** : (3) České Budĕjov. · České Budějovice · SK Dynamo Budweis [de] ⇒ (3) ≈Ceske Budĕjov.≈ · ≈Ceske Budejovice≈ · ≈SK Dynamo Ceske Budejovice≈
- **FK Ústí nad Labem** : (1) Ústí nad Labem ⇒ (2) ≈Usti nad Labem≈ · ≈FK Usti nad Labem≈
- **FC Hradec Králové** : (2) Hradec Králové · DSO Spartak Hradec Králové ⇒ (3) ≈Hradec Kralove≈ · ≈FC Hradec Kralove≈ · ≈DSO Spartak Hradec Kralove≈
- **MFK Vítkovice** : (2) TJ Vítkovice · Městský fotbalový klub Vítkovice ⇒ (3) ≈TJ Vitkovice≈ · ≈MFK Vitkovice≈ · ≈Mestsky fotbalovy klub Vitkovice≈
- **1. SC Znojmo FK** : (1) Znojmo
- **SK Kladno** : (2) Kladno · Sportovní Klub Kladno ⇒ (1) ≈Sportovni Klub Kladno≈
- **FK Drnovice (1932-2006)** : (2) 1. FK Drnovice · Petra Drnovice




Alphabet

- **Alphabet Specials** (14):  **Ú**  **á**  **é**  **í**  **ü**  **ý**  **Č**  **č**  **ĕ**  **ě**  **ň**  **ř**  **Ž**  **ž** 
  - **Ú**×2 U+00DA (218) - LATIN CAPITAL LETTER U WITH ACUTE ⇒ U
  - **á**×10 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×6 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×17 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ü**×1 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue
  - **ý**×3 U+00FD (253) - LATIN SMALL LETTER Y WITH ACUTE ⇒ y
  - **Č**×3 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **č**×2 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **ĕ**×1 U+0115 (277) - LATIN SMALL LETTER E WITH BREVE ⇒ **?**
  - **ě**×3 U+011B (283) - LATIN SMALL LETTER E WITH CARON ⇒ e
  - **ň**×4 U+0148 (328) - LATIN SMALL LETTER N WITH CARON ⇒ n
  - **ř**×3 U+0159 (345) - LATIN SMALL LETTER R WITH CARON ⇒ r
  - **Ž**×2 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z
  - **ž**×2 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Praha** (5): 
  - AC Sparta Praha  (5) Sparta Praha · Sparta Prague · Athletic Club Sparta Praha · AC Sparta Prague [en] · Sparta Prag [de]
  - FK Dukla Praha  (4) Dukla · FK Dukla Prague [en] · FK Dukla Prag [de] · Dukla Praha
  - SK Slavia Praha  (6) Slavia Praha · Sportovní klub Slavia Praha · SK Slavia Prague [en] · Slavia Prague [en] · Slavia Prag [de] · SK Slavia Prag [de]
  - Bohemians Praha 1905  (4) Bohemians 1905 · Bohem. Prag 1905 [de] · FC Bohemians Prag 1905 · Bohemians EKD Praha
  - FK Viktoria Žižkov  (1) Viktoria Žižkov
- **Brno** (2): 
  - FC Zbrojovka Brno  (2) Brno · Zbrojovka Brno
  - FC LeRK Brno (1910-1995)  (1) Spartak Brno KPS
- **Ostrava** (2): 
  - FC Baník Ostrava  (2) Baník · Baník Ostrava
  - MFK Vítkovice  (2) Městský fotbalový klub Vítkovice · TJ Vítkovice
- **Drnovice** (1): FK Drnovice (1932-2006)  (2) 1. FK Drnovice · Petra Drnovice
- **Hradec Králové** (1): FC Hradec Králové  (2) Hradec Králové · DSO Spartak Hradec Králové
- **Jablonec nad Nisou** (1): FK Jablonec  (2) Jablonec · FK Baumit Jablonec
- **Jihlava** (1): FC Vysočina Jihlava  (3) Jihlava · FC Jihlava · Vysočina Jihlava
- **Kladno** (1): SK Kladno  (2) Kladno · Sportovní Klub Kladno
- **Liberec** (1): FC Slovan Liberec  (3) Liberec · Slovan Liberec · Football Club Slovan Liberec
- **Mladá Boleslav** (1): FK Mladá Boleslav  (2) Mladá Boleslav · Fotbalový klub Mladá Boleslav
- **Olomouc** (1): SK Sigma Olomouc  (3) Sigma · Sigma Olomouc · SK Sigma Olmütz [de]
- **Plzeň** (1): Viktoria Plzeň  (5) Plzeň · FC Viktoria Plzeň · Football Club Viktoria Plzeň · Vikt. Pilsen [de] · Viktoria Pilsen [de]
- **Příbram** (1): 1. FK Příbram  (2) Příbram · FK Příbram
- **Teplice** (1): FK Teplice  (1) Teplice
- **Uherské Hradiště** (1): 1. FC Slovácko  (1) Slovácko
- **Zlín** (1): FC Zlín  (3) Zlín · FC Fastav Zlín · Fastav Zlín
- **Znojmo** (1): 1. SC Znojmo FK  (1) Znojmo
- **Ústí nad Labem** (1): FK Ústí nad Labem  (1) Ústí nad Labem
- ? (3): 
  - MFK Karviná  (1) Karviná
  - SFC Opava  (1) Opava
  - SK Dynamo České Budějovice  (3) České Budĕjov. · České Budějovice · SK Dynamo Budweis [de]




By Region

- **Praha†** (5):   AC Sparta Praha · FK Dukla Praha · SK Slavia Praha · Bohemians Praha 1905 · FK Viktoria Žižkov
- **Mladá Boleslav†** (1):   FK Mladá Boleslav
- **Příbram†** (1):   1. FK Příbram
- **Plzeň†** (1):   Viktoria Plzeň
- **Liberec†** (1):   FC Slovan Liberec
- **Jablonec nad Nisou†** (1):   FK Jablonec
- **Ostrava†** (2):   FC Baník Ostrava · MFK Vítkovice
- **Olomouc†** (1):   SK Sigma Olomouc
- **Teplice†** (1):   FK Teplice
- **Uherské Hradiště†** (1):   1. FC Slovácko
- **Zlín†** (1):   FC Zlín
- **Jihlava†** (1):   FC Vysočina Jihlava
- **Brno†** (2):   FC Zbrojovka Brno · FC LeRK Brno (1910-1995)
- **Ústí nad Labem†** (1):   FK Ústí nad Labem
- **Hradec Králové†** (1):   FC Hradec Králové
- **Znojmo†** (1):   1. SC Znojmo FK
- **Kladno†** (1):   SK Kladno
- **Drnovice†** (1):   FK Drnovice (1932-2006)




By Year

- **1892** (1):   SK Slavia Praha
- **1893** (1):   AC Sparta Praha
- **1902** (1):   FK Mladá Boleslav
- **1903** (1):   FK Viktoria Žižkov
- **1905** (1):   Bohemians Praha 1905
- **1910** (1):   FC LeRK Brno (1910-1995)
- **1911** (1):   Viktoria Plzeň
- **1913** (1):   FC Zbrojovka Brno
- **1919** (3):   SK Sigma Olomouc · FC Zlín · MFK Vítkovice
- **1922** (1):   FC Baník Ostrava
- **1927** (1):   1. FC Slovácko
- **1928** (1):   1. FK Příbram
- **1932** (1):   FK Drnovice (1932-2006)
- **1945** (2):   FK Jablonec · FK Teplice
- **1948** (1):   FC Vysočina Jihlava
- **1958** (2):   FK Dukla Praha · FC Slovan Liberec
- ? (7):   MFK Karviná · SFC Opava · SK Dynamo České Budějovice · FK Ústí nad Labem · FC Hradec Králové · 1. SC Znojmo FK · SK Kladno




Historic

- **1995** (1):   FC LeRK Brno (1910-1995)
- **2006** (1):   FK Drnovice (1932-2006)






By A to Z

- **1** (4): 1. FK Příbram · 1. FC Slovácko · 1. FK Drnovice · 1. SC Znojmo FK
- **A** (3): AC Sparta Praha · AC Sparta Prague [en] · Athletic Club Sparta Praha
- **B** (7): Brno · Baník · Baník Ostrava · Bohemians 1905 · Bohemians EKD Praha · Bohemians Praha 1905 · Bohem. Prag 1905 [de]
- **D** (3): Dukla · Dukla Praha · DSO Spartak Hradec Králové
- **F** (26): FC Zlín · FC Jihlava · FK Příbram · FK Teplice · FK Jablonec · Fastav Zlín · FC Fastav Zlín · FK Dukla Praha · FC Baník Ostrava · FC Hradec Králové · FC Slovan Liberec · FC Viktoria Plzeň · FC Zbrojovka Brno · FK Mladá Boleslav · FK Ústí nad Labem · FK Baumit Jablonec · FK Dukla Prag [de] · FK Viktoria Žižkov · FC Vysočina Jihlava · FK Dukla Prague [en] · FC Bohemians Prag 1905 · FK Drnovice (1932-2006) · FC LeRK Brno (1910-1995) · Football Club Slovan Liberec · Football Club Viktoria Plzeň · Fotbalový klub Mladá Boleslav
- **H** (1): Hradec Králové
- **J** (2): Jihlava · Jablonec
- **K** (2): Kladno · Karviná
- **L** (1): Liberec
- **M** (4): MFK Karviná · MFK Vítkovice · Mladá Boleslav · Městský fotbalový klub Vítkovice
- **O** (1): Opava
- **P** (3): Plzeň · Příbram · Petra Drnovice
- **S** (22): Sigma · Slovácko · SFC Opava · SK Kladno · Slavia Praha · Sparta Praha · Sigma Olomouc · Sparta Prague · Slovan Liberec · SK Slavia Praha · SK Sigma Olomouc · Slavia Prag [de] · Sparta Prag [de] · Spartak Brno KPS · Slavia Prague [en] · SK Slavia Prag [de] · SK Sigma Olmütz [de] · SK Slavia Prague [en] · Sportovní Klub Kladno · SK Dynamo Budweis [de] · SK Dynamo České Budějovice · Sportovní klub Slavia Praha
- **T** (2): Teplice · TJ Vítkovice
- **V** (5): Viktoria Plzeň · Viktoria Žižkov · Vysočina Jihlava · Vikt. Pilsen [de] · Viktoria Pilsen [de]
- **Z** (3): Zlín · Znojmo · Zbrojovka Brno
- **Ú** (1): Ústí nad Labem
- **Č** (2): České Budĕjov. · České Budějovice




