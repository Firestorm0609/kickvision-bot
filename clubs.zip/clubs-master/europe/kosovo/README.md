12 clubs

- **KF Drita** : (3) Drita · FC Drita · Drita Gjilan
- **FC Prishtina** : (2) Prishtina · Prishtina KF
- **Flamurtari Prishtina**
- **KF Trepça'89** : (3) Trepça · KF Trepça · Trepça 89 ⇒ (4) ≈Trepca≈ · ≈KF Trepca≈ · ≈Trepca 89≈ · ≈KF Trepca'89≈
- **Ballkani**
- **KF Feronikeli** : (1) Feronikeli
- **KF Gjilani** : (1) Gjilani
- **KF Drenica** : (1) Drenica
- **KF Llapi** : (1) Llapi
- **KF Ferizaj** : (1) Ferizaj
- **Dukagjini**
- **Vushtrria**




Alphabet

- **Alphabet Specials** (1):  **ç** 
  - **ç**×4 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c




Duplicates





By City

- **Prishtina** (2): 
  - FC Prishtina  (2) Prishtina · Prishtina KF
  - Flamurtari Prishtina 
- **Mitrovica** (1): KF Trepça'89  (3) KF Trepça · Trepça · Trepça 89
- ? (9): 
  - KF Drita  (3) Drita · Drita Gjilan · FC Drita
  - Ballkani 
  - KF Feronikeli  (1) Feronikeli
  - KF Gjilani  (1) Gjilani
  - KF Drenica  (1) Drenica
  - KF Llapi  (1) Llapi
  - KF Ferizaj  (1) Ferizaj
  - Dukagjini 
  - Vushtrria 




By Region

- **Prishtina†** (2):   FC Prishtina · Flamurtari Prishtina
- **Mitrovica†** (1):   KF Trepça'89




By Year

- ? (12):   KF Drita · FC Prishtina · Flamurtari Prishtina · KF Trepça'89 · Ballkani · KF Feronikeli · KF Gjilani · KF Drenica · KF Llapi · KF Ferizaj · Dukagjini · Vushtrria






By A to Z

- **B** (1): Ballkani
- **D** (4): Drita · Drenica · Dukagjini · Drita Gjilan
- **F** (5): Ferizaj · FC Drita · Feronikeli · FC Prishtina · Flamurtari Prishtina
- **G** (1): Gjilani
- **K** (8): KF Drita · KF Llapi · KF Trepça · KF Drenica · KF Ferizaj · KF Gjilani · KF Trepça'89 · KF Feronikeli
- **L** (1): Llapi
- **P** (2): Prishtina · Prishtina KF
- **T** (2): Trepça · Trepça 89
- **V** (1): Vushtrria




