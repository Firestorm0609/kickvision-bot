42 clubs

- **Legia Warszawa** : (3) Legia · Legia Warsaw [en] · Legia Warschau [de]
- **KSP Polonia Warszawa** : (2) Polonia Warsaw · Polonia Warszawa
- **Gwardia Warszawa** : (1) Gwardia Warsaw
- [**Górnik Zabrze**](https://en.wikipedia.org/wiki/Górnik_Zabrze) : (1) Górnik Z. ⇒ (2) ≈Gornik Z.≈ · ≈Gornik Zabrze≈
- **KKS Lech Poznań** : (3) Lech · Lech Poznań · Lech Posen [de] ⇒ (2) ≈Lech Poznan≈ · ≈KKS Lech Poznan≈
- **Warta Poznań** : (1) KS Warta Posen [de] ⇒ (1) ≈Warta Poznan≈
- **Wisła Kraków** : (2) Wisła · Wisła Krakau [de] ⇒ (3) ≈Wisla≈ · ≈Wisla Krakow≈ · ≈Wisla Krakau≈
- [**KS Cracovia**](https://en.wikipedia.org/wiki/KS_Cracovia_(football)) : (4) Cracovia · Cracovia Kraków · MKS Cracovia Kraków · Cracovia Krakau [de] ⇒ (2) ≈Cracovia Krakow≈ · ≈MKS Cracovia Krakow≈
- **Hutnik Kraków** : (2) KS Hutnik Kraków · KS Hutnik Nowa Huta ⇒ (2) ≈Hutnik Krakow≈ · ≈KS Hutnik Krakow≈
- **WKS Śląsk Wrocław** : (2) Śląsk · Śląsk Wrocław ⇒ (3) ≈Slask≈ · ≈Slask Wroclaw≈ · ≈WKS Slask Wroclaw≈
- **Jagiellonia Białystok** : (2) Jagiellonia · Jagiellonia Biał. ⇒ (2) ≈Jagiellonia Bial.≈ · ≈Jagiellonia Bialystok≈
- [**Arka Gdynia**](https://en.wikipedia.org/wiki/Arka_Gdynia) : (3) Arka · Arka Gdynia 1929 · MZKS Arka Gdynia
- **GKS Bełchatów** : (1) Bełchatów ⇒ (2) ≈Belchatow≈ · ≈GKS Belchatow≈
- **Korona Kielce** : (1) Korona
- **Lechia Gdańsk** : (2) Lechia · KS Lechia Gdańsk ⇒ (2) ≈Lechia Gdansk≈ · ≈KS Lechia Gdansk≈
- **Górnik Łęczna** : (2) Łęczna · GKS Górnik Łęczna ⇒ (3) ≈Leczna≈ · ≈Gornik Leczna≈ · ≈GKS Gornik Leczna≈
- **Miedź Legnica** : (2) Legnica · ASPN Miedź Legnica ⇒ (2) ≈Miedz Legnica≈ · ≈ASPN Miedz Legnica≈
- **Piast Gliwice** : (2) Piast · GKS Piast Gliwice
- **Wisła Płock** : (1) Płock ⇒ (2) ≈Plock≈ · ≈Wisla Plock≈
- **Podbeskidzie Bielsko-Biała** : (2) Podbeskidzie · Podbeskidzie Biała ⇒ (2) ≈Podbeskidzie Biala≈ · ≈Podbeskidzie Bielsko-Biala≈
- **Pogoń Szczecin** : (2) Pogoń · MKS Pogoń Szczecin ⇒ (3) ≈Pogon≈ · ≈Pogon Szczecin≈ · ≈MKS Pogon Szczecin≈
- **Ruch Chorzów** : (1) Ruch ⇒ (1) ≈Ruch Chorzow≈
- **Sandecja Nowy Sącz** : (1) Sandecja Nowy S. ⇒ (1) ≈Sandecja Nowy Sacz≈
- [**Bruk-Bet Termalica Nieciecza**](https://en.wikipedia.org/wiki/Bruk-Bet_Termalica_Nieciecza) : (2) Termalica B-B. · Termalica Nieciecza
- **Widzew Łódź** : (1) RTS Widzew Łódź ⇒ (2) ≈Widzew Lodz≈ · ≈RTS Widzew Lodz≈
- **ŁKS Łódź** : (3) ŁKS · Łódzki KS · ŁKS Łódź PSS ⇒ (4) ≈LKS≈ · ≈LKS Lodz≈ · ≈Lodzki KS≈ · ≈LKS Lodz PSS≈
- **Zagłębie Lubin** : (1) Zagłębie ⇒ (2) ≈Zaglebie≈ · ≈Zaglebie Lubin≈
- **Zagłębie Sosnowiec** : (2) KS Zagłębie Sosnowiec · Zagłębie Sosnowiec Spółka Akcyjna ⇒ (3) ≈Zaglebie Sosnowiec≈ · ≈KS Zaglebie Sosnowiec≈ · ≈Zaglebie Sosnowiec Spolka Akcyjna≈
- **Zawisza Bydgoszcz** : (1) Zawisza
- **Raków Częstochowa** : (5) Raków · RKS Raków · Raków Czestochowa · KS Raków Częstochowa · RKS Raków Częstochowa ⇒ (6) ≈Rakow≈ · ≈RKS Rakow≈ · ≈Rakow Czestochowa≈ · ≈Rakow Czestochowa≈ · ≈KS Rakow Czestochowa≈ · ≈RKS Rakow Czestochowa≈
- **Odra Opole** : (1) OKS Odra Opole
- **GKS Tychy** : (1) GKS Tychy 71
- **Chrobry Głogów** ⇒ (1) ≈Chrobry Glogow≈
- **OKS Stomil Olsztyn** : (2) Stomil Olsztyn · OKS 1945 Olsztyn
- **Polonia Bytom** : (1) KS Polonia Bytom
- **Szombierki Bytom**
- **Stal Mielec** : (2) KS Stal Mielec · FKS Stal Mielec
- **Dyskobolia Grodzisk Wielkopolski** : (4) Groclin Dyskobolia · Groclin Grodzisk Wielkopolski · KS Dyskobolia Grodzisk Wielkopolski · Klub Sportowy Dyskobolia Grodzisk Wielkopolski
- **Amica Wrońki (1992-2007)** ⇒ (1) ≈Amica Wronki≈
- **GKS Katowice** : (1) Górniczy Klub Sportowy Katowice ⇒ (1) ≈Gorniczy Klub Sportowy Katowice≈
- **Zagłębie Wałbrzych** : (1) GKS Zaglebie Wałbrzych ⇒ (2) ≈Zaglebie Walbrzych≈ · ≈GKS Zaglebie Walbrzych≈
- **Odra Wodzisław** : (3) Odra Wodzisław Śląski · MKS Odra Wodzisław Śląski · APN Odra Wodzisław Śląski ⇒ (4) ≈Odra Wodzislaw≈ · ≈Odra Wodzislaw Slaski≈ · ≈MKS Odra Wodzislaw Slaski≈ · ≈APN Odra Wodzislaw Slaski≈




Alphabet

- **Alphabet Specials** (8):  **ó**  **ą**  **ę**  **Ł**  **ł**  **ń**  **Ś**  **ź** 
  - **ó**×26 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ą**×7 U+0105 (261) - LATIN SMALL LETTER A WITH OGONEK ⇒ a
  - **ę**×12 U+0119 (281) - LATIN SMALL LETTER E WITH OGONEK ⇒ e
  - **Ł**×11 U+0141 (321) - LATIN CAPITAL LETTER L WITH STROKE ⇒ L
  - **ł**×28 U+0142 (322) - LATIN SMALL LETTER L WITH STROKE ⇒ l
  - **ń**×9 U+0144 (324) - LATIN SMALL LETTER N WITH ACUTE ⇒ n
  - **Ś**×6 U+015A (346) - LATIN CAPITAL LETTER S WITH ACUTE ⇒ S
  - **ź**×6 U+017A (378) - LATIN SMALL LETTER Z WITH ACUTE ⇒ z




Duplicates

- **Raków Częstochowa**, Częstochowa (1):
  - `rakowczestochowa` (2): **Rakow Czestochowa** · **Rakow Czestochowa**




By City

- **Kraków** (3): 
  - Wisła Kraków  (2) Wisła · Wisła Krakau [de]
  - KS Cracovia  (4) Cracovia · MKS Cracovia Kraków · Cracovia Kraków · Cracovia Krakau [de]
  - Hutnik Kraków  (2) KS Hutnik Nowa Huta · KS Hutnik Kraków
- **Warszawa** (3): 
  - Legia Warszawa  (3) Legia · Legia Warsaw [en] · Legia Warschau [de]
  - KSP Polonia Warszawa  (2) Polonia Warszawa · Polonia Warsaw
  - Gwardia Warszawa  (1) Gwardia Warsaw
- **Bytom** (2): 
  - Polonia Bytom  (1) KS Polonia Bytom
  - Szombierki Bytom 
- **Nieciecza** (2): 
  - Sandecja Nowy Sącz  (1) Sandecja Nowy S.
  - Bruk-Bet Termalica Nieciecza  (2) Termalica B-B. · Termalica Nieciecza
- **Poznań** (2): 
  - KKS Lech Poznań  (3) Lech · Lech Poznań · Lech Posen [de]
  - Warta Poznań  (1) KS Warta Posen [de]
- **Łódź** (2): 
  - Widzew Łódź  (1) RTS Widzew Łódź
  - ŁKS Łódź  (3) ŁKS · Łódzki KS · ŁKS Łódź PSS
- **Bełchatów** (1): GKS Bełchatów  (1) Bełchatów
- **Białystok** (1): Jagiellonia Białystok  (2) Jagiellonia · Jagiellonia Biał.
- **Bielsko-Biała** (1): Podbeskidzie Bielsko-Biała  (2) Podbeskidzie · Podbeskidzie Biała
- **Bydgoszcz** (1): Zawisza Bydgoszcz  (1) Zawisza
- **Chorzów** (1): Ruch Chorzów  (1) Ruch
- **Częstochowa** (1): Raków Częstochowa  (5) Raków · RKS Raków · RKS Raków Częstochowa · Raków Czestochowa · KS Raków Częstochowa
- **Gdańsk** (1): Lechia Gdańsk  (2) Lechia · KS Lechia Gdańsk
- **Gdynia** (1): Arka Gdynia  (3) Arka · Arka Gdynia 1929 · MZKS Arka Gdynia
- **Gliwice** (1): Piast Gliwice  (2) Piast · GKS Piast Gliwice
- **Grodzisk Wielkopolski** (1): Dyskobolia Grodzisk Wielkopolski  (4) KS Dyskobolia Grodzisk Wielkopolski · Klub Sportowy Dyskobolia Grodzisk Wielkopolski · Groclin Grodzisk Wielkopolski · Groclin Dyskobolia
- **Głogów** (1): Chrobry Głogów 
- **Katowice** (1): GKS Katowice  (1) Górniczy Klub Sportowy Katowice
- **Kielce** (1): Korona Kielce  (1) Korona
- **Legnica** (1): Miedź Legnica  (2) Legnica · ASPN Miedź Legnica
- **Lubin** (1): Zagłębie Lubin  (1) Zagłębie
- **Mielec** (1): Stal Mielec  (2) KS Stal Mielec · FKS Stal Mielec
- **Olsztyn** (1): OKS Stomil Olsztyn  (2) Stomil Olsztyn · OKS 1945 Olsztyn
- **Opole** (1): Odra Opole  (1) OKS Odra Opole
- **Płock** (1): Wisła Płock  (1) Płock
- **Sosnowiec** (1): Zagłębie Sosnowiec  (2) KS Zagłębie Sosnowiec · Zagłębie Sosnowiec Spółka Akcyjna
- **Szczecin** (1): Pogoń Szczecin  (2) Pogoń · MKS Pogoń Szczecin
- **Tychy** (1): GKS Tychy  (1) GKS Tychy 71
- **Walbrzych** (1): Zagłębie Wałbrzych  (1) GKS Zaglebie Wałbrzych
- **Wodzisław Śląski** (1): Odra Wodzisław  (3) Odra Wodzisław Śląski · MKS Odra Wodzisław Śląski · APN Odra Wodzisław Śląski
- **Wrocław** (1): WKS Śląsk Wrocław  (2) Śląsk · Śląsk Wrocław
- **Wrońki** (1): Amica Wrońki (1992-2007) 
- **Zabrze** (1): Górnik Zabrze  (1) Górnik Z.
- **Łęczna** (1): Górnik Łęczna  (2) Łęczna · GKS Górnik Łęczna




By Region

- **Warszawa†** (3):   Legia Warszawa · KSP Polonia Warszawa · Gwardia Warszawa
- **Zabrze†** (1):   Górnik Zabrze
- **Poznań†** (2):   KKS Lech Poznań · Warta Poznań
- **Kraków†** (3):   Wisła Kraków · KS Cracovia · Hutnik Kraków
- **Wrocław†** (1):   WKS Śląsk Wrocław
- **Białystok†** (1):   Jagiellonia Białystok
- **Gdynia†** (1):   Arka Gdynia
- **Bełchatów†** (1):   GKS Bełchatów
- **Kielce†** (1):   Korona Kielce
- **Gdańsk†** (1):   Lechia Gdańsk
- **Łęczna†** (1):   Górnik Łęczna
- **Legnica†** (1):   Miedź Legnica
- **Gliwice†** (1):   Piast Gliwice
- **Płock†** (1):   Wisła Płock
- **Bielsko-Biała†** (1):   Podbeskidzie Bielsko-Biała
- **Szczecin†** (1):   Pogoń Szczecin
- **Chorzów†** (1):   Ruch Chorzów
- **Nieciecza†** (2):   Sandecja Nowy Sącz · Bruk-Bet Termalica Nieciecza
- **Łódź†** (2):   Widzew Łódź · ŁKS Łódź
- **Lubin†** (1):   Zagłębie Lubin
- **Sosnowiec†** (1):   Zagłębie Sosnowiec
- **Bydgoszcz†** (1):   Zawisza Bydgoszcz
- **Częstochowa†** (1):   Raków Częstochowa
- **Opole†** (1):   Odra Opole
- **Tychy†** (1):   GKS Tychy
- **Głogów†** (1):   Chrobry Głogów
- **Olsztyn†** (1):   OKS Stomil Olsztyn
- **Bytom†** (2):   Polonia Bytom · Szombierki Bytom
- **Mielec†** (1):   Stal Mielec
- **Grodzisk Wielkopolski†** (1):   Dyskobolia Grodzisk Wielkopolski
- **Wrońki†** (1):   Amica Wrońki (1992-2007)
- **Katowice†** (1):   GKS Katowice
- **Walbrzych†** (1):   Zagłębie Wałbrzych
- **Wodzisław Śląski†** (1):   Odra Wodzisław




By Year

- **1906** (1):   Zagłębie Sosnowiec
- **1919** (1):   Szombierki Bytom
- **1920** (1):   Polonia Bytom
- **1921** (1):   Raków Częstochowa
- **1922** (3):   Bruk-Bet Termalica Nieciecza · Dyskobolia Grodzisk Wielkopolski · Odra Wodzisław
- **1939** (1):   Stal Mielec
- **1945** (1):   Zagłębie Wałbrzych
- **1948** (1):   Gwardia Warszawa
- **1950** (1):   Hutnik Kraków
- **1964** (1):   GKS Katowice
- **1992** (1):   Amica Wrońki (1992-2007)
- ? (29):   Legia Warszawa · KSP Polonia Warszawa · Górnik Zabrze · KKS Lech Poznań · Warta Poznań · Wisła Kraków · KS Cracovia · WKS Śląsk Wrocław · Jagiellonia Białystok · Arka Gdynia · GKS Bełchatów · Korona Kielce · Lechia Gdańsk · Górnik Łęczna · Miedź Legnica · Piast Gliwice · Wisła Płock · Podbeskidzie Bielsko-Biała · Pogoń Szczecin · Ruch Chorzów · Sandecja Nowy Sącz · Widzew Łódź · ŁKS Łódź · Zagłębie Lubin · Zawisza Bydgoszcz · Odra Opole · GKS Tychy · Chrobry Głogów · OKS Stomil Olsztyn




Historic

- **2007** (1):   Amica Wrońki (1992-2007)






By A to Z

- **A** (6): Arka · Arka Gdynia · Arka Gdynia 1929 · ASPN Miedź Legnica · Amica Wrońki (1992-2007) · APN Odra Wodzisław Śląski
- **B** (2): Bełchatów · Bruk-Bet Termalica Nieciecza
- **C** (4): Cracovia · Chrobry Głogów · Cracovia Kraków · Cracovia Krakau [de]
- **D** (1): Dyskobolia Grodzisk Wielkopolski
- **F** (1): FKS Stal Mielec
- **G** (15): GKS Tychy · Górnik Z. · GKS Katowice · GKS Tychy 71 · GKS Bełchatów · Górnik Zabrze · Górnik Łęczna · Gwardia Warsaw · Gwardia Warszawa · GKS Górnik Łęczna · GKS Piast Gliwice · Groclin Dyskobolia · GKS Zaglebie Wałbrzych · Groclin Grodzisk Wielkopolski · Górniczy Klub Sportowy Katowice
- **H** (1): Hutnik Kraków
- **J** (3): Jagiellonia · Jagiellonia Biał. · Jagiellonia Białystok
- **K** (15): Korona · KS Cracovia · Korona Kielce · KS Stal Mielec · KKS Lech Poznań · KS Hutnik Kraków · KS Lechia Gdańsk · KS Polonia Bytom · KS Hutnik Nowa Huta · KS Warta Posen [de] · KS Raków Częstochowa · KSP Polonia Warszawa · KS Zagłębie Sosnowiec · KS Dyskobolia Grodzisk Wielkopolski · Klub Sportowy Dyskobolia Grodzisk Wielkopolski
- **L** (10): Lech · Legia · Lechia · Legnica · Lech Poznań · Lechia Gdańsk · Legia Warszawa · Lech Posen [de] · Legia Warsaw [en] · Legia Warschau [de]
- **M** (5): Miedź Legnica · MZKS Arka Gdynia · MKS Pogoń Szczecin · MKS Cracovia Kraków · MKS Odra Wodzisław Śląski
- **O** (6): Odra Opole · OKS Odra Opole · Odra Wodzisław · OKS 1945 Olsztyn · OKS Stomil Olsztyn · Odra Wodzisław Śląski
- **P** (11): Piast · Pogoń · Płock · Podbeskidzie · Piast Gliwice · Polonia Bytom · Pogoń Szczecin · Polonia Warsaw · Polonia Warszawa · Podbeskidzie Biała · Podbeskidzie Bielsko-Biała
- **R** (8): Ruch · Raków · RKS Raków · Ruch Chorzów · RTS Widzew Łódź · Raków Czestochowa · Raków Częstochowa · RKS Raków Częstochowa
- **S** (5): Stal Mielec · Stomil Olsztyn · Sandecja Nowy S. · Szombierki Bytom · Sandecja Nowy Sącz
- **T** (2): Termalica B-B. · Termalica Nieciecza
- **W** (7): Wisła · Widzew Łódź · Wisła Płock · Warta Poznań · Wisła Kraków · WKS Śląsk Wrocław · Wisła Krakau [de]
- **Z** (7): Zawisza · Zagłębie · Zagłębie Lubin · Zawisza Bydgoszcz · Zagłębie Sosnowiec · Zagłębie Wałbrzych · Zagłębie Sosnowiec Spółka Akcyjna
- **Ł** (5): ŁKS · Łęczna · ŁKS Łódź · Łódzki KS · ŁKS Łódź PSS
- **Ś** (2): Śląsk · Śląsk Wrocław




