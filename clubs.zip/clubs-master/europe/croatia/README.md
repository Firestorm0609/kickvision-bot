23 clubs

- **GNK Dinamo Zagreb** : (2) Dinamo Zagreb · NK Dinamo Zagreb
- **NK Lokomotiva Zagreb** : (3) Lokomotiva · Lok Zagreb · Lokomotiva Zagreb
- **NK Zagreb**
- **NK Trešnjevka Zagreb** : (1) NK Trešnjevka ⇒ (2) ≈NK Tresnjevka≈ · ≈NK Tresnjevka Zagreb≈
- **NK Lučko Zagreb** : (2) Lučko · NK Lučko ⇒ (3) ≈Lucko≈ · ≈NK Lucko≈ · ≈NK Lucko Zagreb≈
- **NK Hrvatski Dragovoljac** : (1) Hrvatski Dragovoljac
- **NK Rudeš** ⇒ (1) ≈NK Rudes≈
- **NK Croatia Sesvete (1957-2012)** : (1) Croatia Sesvete
- **HNK Hajduk Split** : (1) Hajduk Split
- **RNK Split**
- **NK Slaven Belupo** : (5) Slaven · Slaven Belupo · Slaven Koprivnica · NK Slaven Koprivnica · Nogometni Klub Slaven
- **NK Varaždin** : (3) Varaždin · NK Varaždin ŠN · Varteks Varaždin ⇒ (4) ≈Varazdin≈ · ≈NK Varazdin≈ · ≈NK Varazdin SN≈ · ≈Varteks Varazdin≈
- **HNK Rijeka** : (2) Rijeka · NK Rijeka
- **NK Osijek** : (1) Osijek
- **HNK Cibalia** : (1) Cibalia
- **HNK Šibenik** : (1) Šibenik ⇒ (2) ≈Sibenik≈ · ≈HNK Sibenik≈
- **HNK Gorica**
- **NK Istra 1961** : (1) Istra 1961
- **NK Inter Zaprešić** : (2) Zaprešić · Inter Zaprešić ⇒ (3) ≈Zapresic≈ · ≈Inter Zapresic≈ · ≈NK Inter Zapresic≈
- **NK Karlovac** : (1) Karlovac
- **NK Zadar**
- **NK Međimurje Čakovec** : (3) Međimurje · Medimurje · NK Međimurje ⇒ (1) ≈NK Međimurje Cakovec≈
- **NK Kamen Ingrad (1929-2008)** : (1) Kamen Ingrad




Alphabet

- **Alphabet Specials** (7):  **ć**  **Č**  **č**  **đ**  **Š**  **š**  **ž** 
  - **ć**×3 U+0107 (263) - LATIN SMALL LETTER C WITH ACUTE ⇒ c
  - **Č**×1 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **č**×3 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **đ**×3 U+0111 (273) - LATIN SMALL LETTER D WITH STROKE ⇒ **?**
  - **Š**×3 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **š**×6 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **ž**×4 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Zagreb** (8): 
  - GNK Dinamo Zagreb  (2) Dinamo Zagreb · NK Dinamo Zagreb
  - NK Lokomotiva Zagreb  (3) Lokomotiva · Lok Zagreb · Lokomotiva Zagreb
  - NK Zagreb 
  - NK Trešnjevka Zagreb  (1) NK Trešnjevka
  - NK Lučko Zagreb  (2) Lučko · NK Lučko
  - NK Hrvatski Dragovoljac  (1) Hrvatski Dragovoljac
  - NK Rudeš 
  - NK Croatia Sesvete (1957-2012)  (1) Croatia Sesvete
- **Split** (2): 
  - HNK Hajduk Split  (1) Hajduk Split
  - RNK Split 
- **Karlovac** (1): NK Karlovac  (1) Karlovac
- **Koprivnica** (1): NK Slaven Belupo  (5) Slaven · Slaven Belupo · Slaven Koprivnica · NK Slaven Koprivnica · Nogometni Klub Slaven
- **Velika** (1): NK Kamen Ingrad (1929-2008)  (1) Kamen Ingrad
- **Zadar** (1): NK Zadar 
- **Čakovec** (1): NK Međimurje Čakovec  (3) Međimurje · NK Međimurje · Medimurje
- ? (8): 
  - NK Varaždin  (3) Varaždin · Varteks Varaždin · NK Varaždin ŠN
  - HNK Rijeka  (2) Rijeka · NK Rijeka
  - NK Osijek  (1) Osijek
  - HNK Cibalia  (1) Cibalia
  - HNK Šibenik  (1) Šibenik
  - HNK Gorica 
  - NK Istra 1961  (1) Istra 1961
  - NK Inter Zaprešić  (2) Zaprešić · Inter Zaprešić




By Region

- **Zagreb†** (8):   GNK Dinamo Zagreb · NK Lokomotiva Zagreb · NK Zagreb · NK Trešnjevka Zagreb · NK Lučko Zagreb · NK Hrvatski Dragovoljac · NK Rudeš · NK Croatia Sesvete (1957-2012)
- **Split†** (2):   HNK Hajduk Split · RNK Split
- **Koprivnica†** (1):   NK Slaven Belupo
- **Karlovac†** (1):   NK Karlovac
- **Zadar†** (1):   NK Zadar
- **Čakovec†** (1):   NK Međimurje Čakovec
- **Velika†** (1):   NK Kamen Ingrad (1929-2008)




By Year

- **1907** (1):   NK Slaven Belupo
- **1926** (1):   NK Trešnjevka Zagreb
- **1929** (1):   NK Kamen Ingrad (1929-2008)
- **1931** (1):   NK Lučko Zagreb
- **1957** (1):   NK Croatia Sesvete (1957-2012)
- **1975** (1):   NK Hrvatski Dragovoljac
- ? (17):   GNK Dinamo Zagreb · NK Lokomotiva Zagreb · NK Zagreb · NK Rudeš · HNK Hajduk Split · RNK Split · NK Varaždin · HNK Rijeka · NK Osijek · HNK Cibalia · HNK Šibenik · HNK Gorica · NK Istra 1961 · NK Inter Zaprešić · NK Karlovac · NK Zadar · NK Međimurje Čakovec




Historic

- **2008** (1):   NK Kamen Ingrad (1929-2008)
- **2012** (1):   NK Croatia Sesvete (1957-2012)






By A to Z

- **C** (2): Cibalia · Croatia Sesvete
- **D** (1): Dinamo Zagreb
- **G** (1): GNK Dinamo Zagreb
- **H** (7): HNK Gorica · HNK Rijeka · HNK Cibalia · HNK Šibenik · Hajduk Split · HNK Hajduk Split · Hrvatski Dragovoljac
- **I** (2): Istra 1961 · Inter Zaprešić
- **K** (2): Karlovac · Kamen Ingrad
- **L** (4): Lučko · Lok Zagreb · Lokomotiva · Lokomotiva Zagreb
- **M** (2): Medimurje · Međimurje
- **N** (24): NK Lučko · NK Rudeš · NK Zadar · NK Osijek · NK Rijeka · NK Zagreb · NK Karlovac · NK Varaždin · NK Međimurje · NK Istra 1961 · NK Trešnjevka · NK Varaždin ŠN · NK Lučko Zagreb · NK Dinamo Zagreb · NK Slaven Belupo · NK Inter Zaprešić · NK Lokomotiva Zagreb · NK Međimurje Čakovec · NK Slaven Koprivnica · NK Trešnjevka Zagreb · Nogometni Klub Slaven · NK Hrvatski Dragovoljac · NK Kamen Ingrad (1929-2008) · NK Croatia Sesvete (1957-2012)
- **O** (1): Osijek
- **R** (2): Rijeka · RNK Split
- **S** (3): Slaven · Slaven Belupo · Slaven Koprivnica
- **V** (2): Varaždin · Varteks Varaždin
- **Z** (1): Zaprešić
- **Š** (1): Šibenik




