13 clubs

- **UE Sant Julià** : (1) Sant Julià ⇒ (2) ≈Sant Julia≈ · ≈UE Sant Julia≈
- **FC Santa Coloma**
- **UE Santa Coloma**
- **FC Lusitans** : (3) Lusitans · Lusitanos · FC Lusitanos
- **UE Engordany** : (1) Engordany
- **Atlètic Club d'Escaldes** : (1) Atlètic Escaldes ⇒ (2) ≈Atletic Escaldes≈ · ≈Atletic Club d'Escaldes≈
- **CE Carroi**
- **FC Ordino** : (1) Ordino
- **Inter Club d'Escaldes** : (1) Inter Escaldes
- **FC Rànger's** : (1) Ranger's ⇒ (1) ≈FC Ranger's≈
- **FC Encamp**
- **Constellació Esportiva (1998-2000)** ⇒ (1) ≈Constellacio Esportiva≈
- **CE Principat (1989-2015)** : (1) Club Esportiu Principat




Alphabet

- **Alphabet Specials** (3):  **à**  **è**  **ó** 
  - **à**×3 U+00E0 (224) - LATIN SMALL LETTER A WITH GRAVE ⇒ a
  - **è**×2 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Andorra La Vella** (2): 
  - Constellació Esportiva (1998-2000) 
  - CE Principat (1989-2015)  (1) Club Esportiu Principat
- **Andorra la Vella** (1): FC Rànger's  (1) Ranger's
- **Encamp** (1): FC Encamp 
- ? (9): 
  - UE Sant Julià  (1) Sant Julià
  - FC Santa Coloma 
  - UE Santa Coloma 
  - FC Lusitans  (3) Lusitans · Lusitanos · FC Lusitanos
  - UE Engordany  (1) Engordany
  - Atlètic Club d'Escaldes  (1) Atlètic Escaldes
  - CE Carroi 
  - FC Ordino  (1) Ordino
  - Inter Club d'Escaldes  (1) Inter Escaldes




By Region

- **Andorra la Vella†** (1):   FC Rànger's
- **Encamp†** (1):   FC Encamp
- **Andorra La Vella†** (2):   Constellació Esportiva (1998-2000) · CE Principat (1989-2015)




By Year

- **1950** (1):   FC Encamp
- **1989** (1):   CE Principat (1989-2015)
- **1998** (1):   Constellació Esportiva (1998-2000)
- ? (10):   UE Sant Julià · FC Santa Coloma · UE Santa Coloma · FC Lusitans · UE Engordany · Atlètic Club d'Escaldes · CE Carroi · FC Ordino · Inter Club d'Escaldes · FC Rànger's




Historic

- **2000** (1):   Constellació Esportiva (1998-2000)
- **2015** (1):   CE Principat (1989-2015)






By A to Z

- **A** (2): Atlètic Escaldes · Atlètic Club d'Escaldes
- **C** (4): CE Carroi · Club Esportiu Principat · CE Principat (1989-2015) · Constellació Esportiva (1998-2000)
- **E** (1): Engordany
- **F** (6): FC Encamp · FC Ordino · FC Lusitans · FC Rànger's · FC Lusitanos · FC Santa Coloma
- **I** (2): Inter Escaldes · Inter Club d'Escaldes
- **L** (2): Lusitans · Lusitanos
- **O** (1): Ordino
- **R** (1): Ranger's
- **S** (1): Sant Julià
- **U** (3): UE Engordany · UE Sant Julià · UE Santa Coloma




