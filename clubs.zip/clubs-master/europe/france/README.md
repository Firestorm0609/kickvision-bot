73 clubs

- [**Paris Saint-Germain**](https://en.wikipedia.org/wiki/Paris_Saint-Germain_F.C.) : (7) Paris · Paris SG · Paris S. Germain · Paris St. Germain · Paris Saint Germain · Paris Saint-Germain FC · Paris-Saint-Germain Football Club
- **Paris FC** : (1) Paris FC 98
- **Red Star FC** : (2) Red Star · Red Star 93
- [**Amiens SC**](https://en.wikipedia.org/wiki/Amiens_SC) : (1) Amiens
- **FC Chambly** : (2) Chambly · Football Club Chambly Oise
- [**Angers SCO**](https://en.wikipedia.org/wiki/Angers_SCO) : (3) Angers · SCO Angers · Angers Sporting Club de l'Ouest
- [**Girondins de Bordeaux**](https://en.wikipedia.org/wiki/FC_Girondins_de_Bordeaux) : (5) Bordeaux · Girondins Bordeaux · FC Girondins Bordeaux · FC Girondins de Bordeaux · Football Club des Girondins de Bordeaux
- [**Stade Malherbe Caen**](https://en.wikipedia.org/wiki/Stade_Malherbe_Caen) : (3) Caen · SM Caen · Stade Malherbe de Caen
- [**Dijon FCO**](https://en.wikipedia.org/wiki/Dijon_FCO) : (4) Dijon · FCO Dijon · Dijon Football · Dijon Football Côte-d'Or ⇒ (1) ≈Dijon Football Cote-d'Or≈
- [**EA Guingamp**](https://en.wikipedia.org/wiki/En_Avant_de_Guingamp) : (3) Guingamp · En Avant Guingamp · En Avant de Guingamp
- [**Lille OSC**](https://en.wikipedia.org/wiki/Lille_OSC) : (4) LOSC · Lille · OSC Lille · LOSC Lille
- [**Olympique Lyonnais**](https://en.wikipedia.org/wiki/Olympique_Lyonnais) : (3) Lyon · Ol. Lyon · Olympique Lyon
- [**Olympique de Marseille**](https://en.wikipedia.org/wiki/Olympique_de_Marseille) : (3) Marseille · Olymp. Marseille · Olympique Marseille
- [**FC Metz**](https://en.wikipedia.org/wiki/FC_Metz) : (2) Metz · Football Club de Metz
- [**Montpellier HSC**](https://en.wikipedia.org/wiki/Montpellier_HSC) : (4) Montpellier · HSC Montpellier · Montpellier Hérault SC · Montpellier-Herault Sports Club ⇒ (1) ≈Montpellier Herault SC≈
- [**FC Nantes**](https://en.wikipedia.org/wiki/FC_Nantes) : (2) Nantes · Football Club de Nantes
- [**OGC Nice**](https://en.wikipedia.org/wiki/OGC_Nice) : (3) Nice · OGC Nizza [de] · Olympique Gymnaste Club Nice Côte d'Azur ⇒ (1) ≈Olympique Gymnaste Club Nice Cote d'Azur≈
- [**Stade Rennais FC**](https://en.wikipedia.org/wiki/Stade_Rennais_F.C.) : (4) Rennes · Stade Rennes · Stade Rennais · Stade Rennais Football Club
- [**AS Saint-Étienne**](https://en.wikipedia.org/wiki/AS_Saint-Étienne) : (3) St-Étienne · Saint-Étienne · Association Sportive de Saint-Étienne Loire ⇒ (4) ≈St-Etienne≈ · ≈Saint-Etienne≈ · ≈AS Saint-Etienne≈ · ≈Association Sportive de Saint-Etienne Loire≈
- [**RC Strasbourg**](https://en.wikipedia.org/wiki/RC_Strasbourg_Alsace) : (5) Strasbourg · Racing Strasbourg · RC Strasbourg Alsace · Racing Straßburg [de] · Racing Club de Strasbourg Alsace ⇒ (1) ≈Racing Strassburg≈
- [**Toulouse FC**](https://en.wikipedia.org/wiki/Toulouse_FC) : (3) Toulouse · FC Toulouse · Toulouse Football Club
- [**ES Troyes AC**](https://en.wikipedia.org/wiki/Troyes_AC) : (4) Troyes · Troyes AC · ESTAC Troyes · Espérance Sportive Troyes Aube Champagne ⇒ (1) ≈Esperance Sportive Troyes Aube Champagne≈
- [**Stade de Reims**](https://en.wikipedia.org/wiki/Stade_de_Reims) : (2) Reims · Stade Reims
- [**Nîmes Olympique**](https://en.wikipedia.org/wiki/Nîmes_Olympique) : (3) Nîmes · Olympique Nîmes · Nîmes Olympique SC ⇒ (4) ≈Nimes≈ · ≈Nimes Olympique≈ · ≈Olympique Nimes≈ · ≈Nimes Olympique SC≈
- [**AC Ajaccio**](https://en.wikipedia.org/wiki/AC_Ajaccio) : (2) Ajaccio · Athletic Club Ajaccien
- [**GFC Ajaccio**](https://en.wikipedia.org/wiki/Gazélec_Ajaccio) : (3) Ajaccio GFCO · Gazélec Ajaccio · Gazélec Football Club Ajaccio ⇒ (2) ≈Gazelec Ajaccio≈ · ≈Gazelec Football Club Ajaccio≈
- **AJ Auxerre** : (2) Auxerre · Association de la Jeunesse Auxerroise
- **Bourg-en-Bresse 01** : (2) Bourg Peronnas · FC Bourg Peronnas
- **Stade Brestois 29** : (3) Brest · Stade Brest · Stade Brestois
- **LB Châteauroux** : (2) Châteauroux · La Berrichonne de Châteauroux ⇒ (3) ≈Chateauroux≈ · ≈LB Chateauroux≈ · ≈La Berrichonne de Chateauroux≈
- **Clermont Foot 63** : (2) Clermont · Clermont Foot
- **Le Havre AC** : (3) Le Havre · Havre AC · Le Havre Athletic Club Football
- [**RC Lens**](https://en.wikipedia.org/wiki/RC_Lens) : (2) Lens · Racing Club de Lens
- [**FC Lorient**](https://en.wikipedia.org/wiki/FC_Lorient) : (2) Lorient · Football Club Lorient-Bretagne Sud
- **AS Nancy Lorraine** : (4) Nancy · AS Nancy · AS Nancy-Lorraine · Association Sportive Nancy-Lorraine
- **Chamois Niortais FC** : (4) Niort · Chamois Niortais · FC Chamois Niort · Chamois Niortais Football Club
- **US Orléans** : (3) Orléans · US Orléans 45 · Union sportive Orléans Loiret football ⇒ (4) ≈Orleans≈ · ≈US Orleans≈ · ≈US Orleans 45≈ · ≈Union sportive Orleans Loiret football≈
- **US Quevilly-Rouen Métropole** : (2) Quevilly Rouen · Quevilly-Rouen ⇒ (1) ≈US Quevilly-Rouen Metropole≈
- **FC Sochaux-Montbéliard** : (3) Sochaux · FC Sochaux · Football Club de Sochaux-Montbéliard ⇒ (2) ≈FC Sochaux-Montbeliard≈ · ≈Football Club de Sochaux-Montbeliard≈
- **Tours FC** : (3) Tours · FC Tours · Tours Football Club
- **Valenciennes FC** : (3) Valenciennes · FC Valenciennes · Valenciennes Football Club
- **AC Arles-Avignon** : (3) Arles · AC Arles Avignon · Athletic Club Arles-Avignon
- [**SC Bastia**](https://en.wikipedia.org/wiki/SC_Bastia) : (2) Bastia · Sporting Club de Bastia
- **CA Bastia**
- **AS Beauvais Oise** : (1) Beauvais
- **Racing Besançon** : (2) Besançon · Besançon RC ⇒ (3) ≈Besancon≈ · ≈Besancon RC≈ · ≈Racing Besancon≈
- **US Boulogne** : (1) Boulogne
- **AS Cannes** : (1) Cannes
- **FCO Charleville** : (1) Charleville
- **US Créteil** : (3) Créteil · US Créteil-Lusitanos · Union Sportive Créteil-Lusitanos ⇒ (4) ≈Creteil≈ · ≈US Creteil≈ · ≈US Creteil-Lusitanos≈ · ≈Union Sportive Creteil-Lusitanos≈
- **SAS Épinal** : (1) Épinal ⇒ (2) ≈Epinal≈ · ≈SAS Epinal≈
- **Évian TG FC** : (5) Évian TG · Évian Thonon Gaillard · Évian Thonon-Gaillard FC · Évian Thonon Gaillard FC · Évian Thonon Gaillard Football Club ⇒ (6) ≈Evian TG≈ · ≈Evian TG FC≈ · ≈Evian Thonon Gaillard≈ · ≈Evian Thonon-Gaillard FC≈ · ≈Evian Thonon Gaillard FC≈ · ≈Evian Thonon Gaillard Football Club≈
- **Grenoble Foot 38** : (2) Grenoble · Grenoble Foot
- **FC Gueugnon** : (1) Gueugnon
- **FC Istres** : (1) Istres
- **Stade Lavallois** : (4) Laval · Stade Laval · Stade Lavallois-Mayenne FC · Stade Lavallois Mayenne Football Club
- **Le Mans FC** : (3) Le Mans · Le Mans UC 72 · Le Mans Football Club
- **FC Libourne-Saint-Seurin** : (1) Libourne
- **CS Louhans-Cuiseaux** : (1) Louhans-Cuis.
- **FC Martigues** : (1) Martigues
- **FC Mulhouse** : (1) Mulhouse
- **Perpignan FC** : (1) Perpignan
- **FC Rouen** : (1) Rouen
- **CS Sedan-Ardennes** : (3) Sedan · CS Sedan · Club Sportif Sedan Ardennes
- **FC Sète** : (1) Sete ⇒ (1) ≈FC Sete≈
- **Stade Briochin** : (1) St Brieuc
- **Sporting Toulon Var** : (1) Toulon
- **ASOA Valence** : (1) Valence
- **Vannes OC** : (1) Vannes
- **Wasquehal Foot** : (1) Wasquehal
- **Rodez AF** : (3) Rodez · Rodez Aveyron · Rodez Aveyron Football
- **AS Béziers** : (2) Béziers · Avenir Sportif Béziers ⇒ (3) ≈Beziers≈ · ≈AS Beziers≈ · ≈Avenir Sportif Beziers≈
- **Angoulême-Soyaux Charente** : (4) Angoulême · AS Angoulême · Angoulême CFC · Angoulême Charente FC ⇒ (5) ≈Angouleme≈ · ≈AS Angouleme≈ · ≈Angouleme CFC≈ · ≈Angouleme Charente FC≈ · ≈Angouleme-Soyaux Charente≈




Alphabet

- **Alphabet Specials** (9):  **É**  **ß**  **â**  **ç**  **è**  **é**  **ê**  **î**  **ô** 
  - **É**×12 U+00C9 (201) - LATIN CAPITAL LETTER E WITH ACUTE ⇒ E
  - **ß**×1 U+00DF (223) - LATIN SMALL LETTER SHARP S ⇒ ss
  - **â**×3 U+00E2 (226) - LATIN SMALL LETTER A WITH CIRCUMFLEX ⇒ a
  - **ç**×3 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **è**×1 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **é**×18 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ê**×5 U+00EA (234) - LATIN SMALL LETTER E WITH CIRCUMFLEX ⇒ e
  - **î**×4 U+00EE (238) - LATIN SMALL LETTER I WITH CIRCUMFLEX ⇒ i
  - **ô**×2 U+00F4 (244) - LATIN SMALL LETTER O WITH CIRCUMFLEX ⇒ o




Duplicates

- **Paris Saint-Germain**, Paris (1):
  - `parissaintgermain` (2): Paris Saint-Germain · Paris Saint Germain
- **AS Nancy Lorraine**, Nancy (1):
  - `asnancylorraine` (2): AS Nancy Lorraine · AS Nancy-Lorraine
- **US Quevilly-Rouen Métropole**, Petit-Quevilly (1):
  - `quevillyrouen` (2): Quevilly Rouen · Quevilly-Rouen
- **AC Arles-Avignon**, Avignon (1):
  - `acarlesavignon` (2): AC Arles-Avignon · AC Arles Avignon
- **Évian TG FC**, Thonon-les-Bains (2):
  - `évianthonongaillardfc` (2): Évian Thonon Gaillard FC · Évian Thonon-Gaillard FC
  - `evianthonongaillardfc` (2): Evian Thonon Gaillard FC · Evian Thonon-Gaillard FC




By City

- **Ajaccio** (2): 
  - AC Ajaccio  (2) Ajaccio · Athletic Club Ajaccien
  - GFC Ajaccio  (3) Ajaccio GFCO · Gazélec Ajaccio · Gazélec Football Club Ajaccio
- **Bastia** (2): 
  - SC Bastia  (2) Bastia · Sporting Club de Bastia
  - CA Bastia 
- **Paris, Île-de-France** (2): 
  - Paris Saint-Germain  (7) Paris · Paris SG · Paris St. Germain · Paris S. Germain · Paris Saint Germain · Paris Saint-Germain FC · Paris-Saint-Germain Football Club
  - Paris FC  (1) Paris FC 98
- **Amiens, Hauts-de-France** (1): Amiens SC  (1) Amiens
- **Angers, Pays de la Loire** (1): Angers SCO  (3) Angers · Angers Sporting Club de l'Ouest · SCO Angers
- **Angoulême** (1): Angoulême-Soyaux Charente  (4) Angoulême · AS Angoulême · Angoulême CFC · Angoulême Charente FC
- **Auxerre** (1): AJ Auxerre  (2) Auxerre · Association de la Jeunesse Auxerroise
- **Avignon** (1): AC Arles-Avignon  (3) Arles · AC Arles Avignon · Athletic Club Arles-Avignon
- **Beauvais Oise** (1): AS Beauvais Oise  (1) Beauvais
- **Besançon** (1): Racing Besançon  (2) Besançon · Besançon RC
- **Bordeaux, Nouvelle-Aquitaine** (1): Girondins de Bordeaux  (5) Bordeaux · Girondins Bordeaux · FC Girondins Bordeaux · FC Girondins de Bordeaux · Football Club des Girondins de Bordeaux
- **Boulogne-sur-Mer** (1): US Boulogne  (1) Boulogne
- **Bourg-en-Bresse** (1): Bourg-en-Bresse 01  (2) Bourg Peronnas · FC Bourg Peronnas
- **Brest** (1): Stade Brestois 29  (3) Brest · Stade Brest · Stade Brestois
- **Béziers, Occitanie** (1): AS Béziers  (2) Béziers · Avenir Sportif Béziers
- **Caen** (1): Stade Malherbe Caen  (3) Caen · SM Caen · Stade Malherbe de Caen
- **Canet-en-Roussillon** (1): Perpignan FC  (1) Perpignan
- **Cannes** (1): AS Cannes  (1) Cannes
- **Chambly, Hauts-de-France** (1): FC Chambly  (2) Chambly · Football Club Chambly Oise
- **Charleville-Mézières** (1): FCO Charleville  (1) Charleville
- **Châteauroux** (1): LB Châteauroux  (2) Châteauroux · La Berrichonne de Châteauroux
- **Clermont** (1): Clermont Foot 63  (2) Clermont · Clermont Foot
- **Créteil** (1): US Créteil  (3) Créteil · US Créteil-Lusitanos · Union Sportive Créteil-Lusitanos
- **Dijon** (1): Dijon FCO  (4) Dijon · FCO Dijon · Dijon Football · Dijon Football Côte-d'Or
- **Grenoble** (1): Grenoble Foot 38  (2) Grenoble · Grenoble Foot
- **Gueugnon** (1): FC Gueugnon  (1) Gueugnon
- **Guingamp** (1): EA Guingamp  (3) Guingamp · En Avant Guingamp · En Avant de Guingamp
- **Istres** (1): FC Istres  (1) Istres
- **Laval** (1): Stade Lavallois  (4) Laval · Stade Lavallois Mayenne Football Club · Stade Lavallois-Mayenne FC · Stade Laval
- **Le Havre** (1): Le Havre AC  (3) Le Havre · Havre AC · Le Havre Athletic Club Football
- **Le Mans, Pays de la Loire** (1): Le Mans FC  (3) Le Mans · Le Mans Football Club · Le Mans UC 72
- **Lens** (1): RC Lens  (2) Lens · Racing Club de Lens
- **Libourne** (1): FC Libourne-Saint-Seurin  (1) Libourne
- **Lille** (1): Lille OSC  (4) Lille · LOSC · LOSC Lille · OSC Lille
- **Lorient** (1): FC Lorient  (2) Lorient · Football Club Lorient-Bretagne Sud
- **Louhans** (1): CS Louhans-Cuiseaux  (1) Louhans-Cuis.
- **Lyon** (1): Olympique Lyonnais  (3) Lyon · Ol. Lyon · Olympique Lyon
- **Marseille** (1): Olympique de Marseille  (3) Marseille · Olymp. Marseille · Olympique Marseille
- **Martigues** (1): FC Martigues  (1) Martigues
- **Metz** (1): FC Metz  (2) Metz · Football Club de Metz
- **Montbéliard** (1): FC Sochaux-Montbéliard  (3) Sochaux · FC Sochaux · Football Club de Sochaux-Montbéliard
- **Montpellier** (1): Montpellier HSC  (4) Montpellier · HSC Montpellier · Montpellier Hérault SC · Montpellier-Herault Sports Club
- **Mulhouse** (1): FC Mulhouse  (1) Mulhouse
- **Nancy** (1): AS Nancy Lorraine  (4) Nancy · AS Nancy · AS Nancy-Lorraine · Association Sportive Nancy-Lorraine
- **Nantes** (1): FC Nantes  (2) Nantes · Football Club de Nantes
- **Nice** (1): OGC Nice  (3) Nice · Olympique Gymnaste Club Nice Côte d'Azur · OGC Nizza [de]
- **Niort** (1): Chamois Niortais FC  (4) Niort · Chamois Niortais · Chamois Niortais Football Club · FC Chamois Niort
- **Nîmes** (1): Nîmes Olympique  (3) Nîmes · Olympique Nîmes · Nîmes Olympique SC
- **Orléans** (1): US Orléans  (3) Orléans · Union sportive Orléans Loiret football · US Orléans 45
- **Petit-Quevilly** (1): US Quevilly-Rouen Métropole  (2) Quevilly Rouen · Quevilly-Rouen
- **Reims** (1): Stade de Reims  (2) Reims · Stade Reims
- **Rennes** (1): Stade Rennais FC  (4) Rennes · Stade Rennes · Stade Rennais · Stade Rennais Football Club
- **Rodez, Occitanie** (1): Rodez AF  (3) Rodez · Rodez Aveyron · Rodez Aveyron Football
- **Rouen** (1): FC Rouen  (1) Rouen
- **Saint-Brieuc** (1): Stade Briochin  (1) St Brieuc
- **Saint-Ouen, Île-de-France** (1): Red Star FC  (2) Red Star · Red Star 93
- **Saint-Étienne** (1): AS Saint-Étienne  (3) St-Étienne · Saint-Étienne · Association Sportive de Saint-Étienne Loire
- **Sedan** (1): CS Sedan-Ardennes  (3) Sedan · CS Sedan · Club Sportif Sedan Ardennes
- **Strasbourg** (1): RC Strasbourg  (5) Strasbourg · Racing Strasbourg · RC Strasbourg Alsace · Racing Club de Strasbourg Alsace · Racing Straßburg [de]
- **Sète** (1): FC Sète  (1) Sete
- **Thonon-les-Bains** (1): Évian TG FC  (5) Évian TG · Évian Thonon Gaillard · Évian Thonon Gaillard FC · Évian Thonon-Gaillard FC · Évian Thonon Gaillard Football Club
- **Toulon** (1): Sporting Toulon Var  (1) Toulon
- **Toulouse** (1): Toulouse FC  (3) Toulouse · Toulouse Football Club · FC Toulouse
- **Tours** (1): Tours FC  (3) Tours · Tours Football Club · FC Tours
- **Troyes** (1): ES Troyes AC  (4) Troyes · ESTAC Troyes · Espérance Sportive Troyes Aube Champagne · Troyes AC
- **Valence** (1): ASOA Valence  (1) Valence
- **Valenciennes** (1): Valenciennes FC  (3) Valenciennes · Valenciennes Football Club · FC Valenciennes
- **Vannes** (1): Vannes OC  (1) Vannes
- **Wasquehal** (1): Wasquehal Foot  (1) Wasquehal
- **Épinal** (1): SAS Épinal  (1) Épinal




By Region

- **Île-de-France** (3):   Paris Saint-Germain · Paris FC · Red Star FC
- **Hauts-de-France** (2):   Amiens SC · FC Chambly
- **Pays de la Loire** (2):   Angers SCO · Le Mans FC
- **Nouvelle-Aquitaine** (1):   Girondins de Bordeaux
- **Caen†** (1):   Stade Malherbe Caen
- **Dijon†** (1):   Dijon FCO
- **Guingamp†** (1):   EA Guingamp
- **Lille†** (1):   Lille OSC
- **Lyon†** (1):   Olympique Lyonnais
- **Marseille†** (1):   Olympique de Marseille
- **Metz†** (1):   FC Metz
- **Montpellier†** (1):   Montpellier HSC
- **Nantes†** (1):   FC Nantes
- **Nice†** (1):   OGC Nice
- **Rennes†** (1):   Stade Rennais FC
- **Saint-Étienne†** (1):   AS Saint-Étienne
- **Strasbourg†** (1):   RC Strasbourg
- **Toulouse†** (1):   Toulouse FC
- **Troyes†** (1):   ES Troyes AC
- **Reims†** (1):   Stade de Reims
- **Nîmes†** (1):   Nîmes Olympique
- **Ajaccio†** (2):   AC Ajaccio · GFC Ajaccio
- **Auxerre†** (1):   AJ Auxerre
- **Bourg-en-Bresse†** (1):   Bourg-en-Bresse 01
- **Brest†** (1):   Stade Brestois 29
- **Châteauroux†** (1):   LB Châteauroux
- **Clermont†** (1):   Clermont Foot 63
- **Le Havre†** (1):   Le Havre AC
- **Lens†** (1):   RC Lens
- **Lorient†** (1):   FC Lorient
- **Nancy†** (1):   AS Nancy Lorraine
- **Niort†** (1):   Chamois Niortais FC
- **Orléans†** (1):   US Orléans
- **Petit-Quevilly†** (1):   US Quevilly-Rouen Métropole
- **Montbéliard†** (1):   FC Sochaux-Montbéliard
- **Tours†** (1):   Tours FC
- **Valenciennes†** (1):   Valenciennes FC
- **Avignon†** (1):   AC Arles-Avignon
- **Bastia†** (2):   SC Bastia · CA Bastia
- **Beauvais Oise†** (1):   AS Beauvais Oise
- **Besançon†** (1):   Racing Besançon
- **Boulogne-sur-Mer†** (1):   US Boulogne
- **Cannes†** (1):   AS Cannes
- **Charleville-Mézières†** (1):   FCO Charleville
- **Créteil†** (1):   US Créteil
- **Épinal†** (1):   SAS Épinal
- **Thonon-les-Bains†** (1):   Évian TG FC
- **Grenoble†** (1):   Grenoble Foot 38
- **Gueugnon†** (1):   FC Gueugnon
- **Istres†** (1):   FC Istres
- **Laval†** (1):   Stade Lavallois
- **Libourne†** (1):   FC Libourne-Saint-Seurin
- **Louhans†** (1):   CS Louhans-Cuiseaux
- **Martigues†** (1):   FC Martigues
- **Mulhouse†** (1):   FC Mulhouse
- **Canet-en-Roussillon†** (1):   Perpignan FC
- **Rouen†** (1):   FC Rouen
- **Sedan†** (1):   CS Sedan-Ardennes
- **Sète†** (1):   FC Sète
- **Saint-Brieuc†** (1):   Stade Briochin
- **Toulon†** (1):   Sporting Toulon Var
- **Valence†** (1):   ASOA Valence
- **Vannes†** (1):   Vannes OC
- **Wasquehal†** (1):   Wasquehal Foot
- **Occitanie** (2):   Rodez AF · AS Béziers
- **Angoulême†** (1):   Angoulême-Soyaux Charente




By Year

- **1881** (1):   Girondins de Bordeaux
- **1899** (2):   Olympique Lyonnais · Olympique de Marseille
- **1901** (1):   Stade Rennais FC
- **1904** (1):   OGC Nice
- **1905** (1):   SC Bastia
- **1906** (1):   RC Lens
- **1910** (2):   AC Ajaccio · GFC Ajaccio
- **1912** (1):   EA Guingamp
- **1913** (1):   Stade Malherbe Caen
- **1919** (3):   Angers SCO · AS Saint-Étienne · CS Sedan-Ardennes
- **1920** (1):   Angoulême-Soyaux Charente
- **1926** (1):   FC Lorient
- **1929** (1):   Rodez AF
- **1931** (1):   Stade de Reims
- **1932** (1):   FC Metz
- **1943** (1):   FC Nantes
- **1944** (1):   Lille OSC
- **1970** (2):   Paris Saint-Germain · Toulouse FC
- **1974** (1):   Montpellier HSC
- **1986** (1):   ES Troyes AC
- **1989** (1):   FC Chambly
- **2007** (2):   Évian TG FC · AS Béziers
- ? (45):   Paris FC · Red Star FC · Amiens SC · Dijon FCO · RC Strasbourg · Nîmes Olympique · AJ Auxerre · Bourg-en-Bresse 01 · Stade Brestois 29 · LB Châteauroux · Clermont Foot 63 · Le Havre AC · AS Nancy Lorraine · Chamois Niortais FC · US Orléans · US Quevilly-Rouen Métropole · FC Sochaux-Montbéliard · Tours FC · Valenciennes FC · AC Arles-Avignon · CA Bastia · AS Beauvais Oise · Racing Besançon · US Boulogne · AS Cannes · FCO Charleville · US Créteil · SAS Épinal · Grenoble Foot 38 · FC Gueugnon · FC Istres · Stade Lavallois · Le Mans FC · FC Libourne-Saint-Seurin · CS Louhans-Cuiseaux · FC Martigues · FC Mulhouse · Perpignan FC · FC Rouen · FC Sète · Stade Briochin · Sporting Toulon Var · ASOA Valence · Vannes OC · Wasquehal Foot






By A to Z

- **A** (32): Arles · Amiens · Angers · Ajaccio · Auxerre · AS Nancy · AS Cannes · Amiens SC · Angoulême · AC Ajaccio · AJ Auxerre · AS Béziers · Angers SCO · AS Angoulême · ASOA Valence · Ajaccio GFCO · Angoulême CFC · AC Arles Avignon · AC Arles-Avignon · AS Beauvais Oise · AS Saint-Étienne · AS Nancy Lorraine · AS Nancy-Lorraine · Angoulême Charente FC · Athletic Club Ajaccien · Avenir Sportif Béziers · Angoulême-Soyaux Charente · Athletic Club Arles-Avignon · Angers Sporting Club de l'Ouest · Association Sportive Nancy-Lorraine · Association de la Jeunesse Auxerroise · Association Sportive de Saint-Étienne Loire
- **B** (10): Brest · Bastia · Béziers · Beauvais · Besançon · Bordeaux · Boulogne · Besançon RC · Bourg Peronnas · Bourg-en-Bresse 01
- **C** (17): Caen · Cannes · Chambly · Créteil · CS Sedan · Clermont · CA Bastia · Charleville · Châteauroux · Clermont Foot · Chamois Niortais · Clermont Foot 63 · CS Sedan-Ardennes · CS Louhans-Cuiseaux · Chamois Niortais FC · Club Sportif Sedan Ardennes · Chamois Niortais Football Club
- **D** (4): Dijon · Dijon FCO · Dijon Football · Dijon Football Côte-d'Or
- **E** (6): EA Guingamp · ES Troyes AC · ESTAC Troyes · En Avant Guingamp · En Avant de Guingamp · Espérance Sportive Troyes Aube Champagne
- **F** (28): FC Metz · FC Sète · FC Rouen · FC Tours · FC Istres · FC Nantes · FCO Dijon · FC Chambly · FC Lorient · FC Sochaux · FC Gueugnon · FC Mulhouse · FC Toulouse · FC Martigues · FC Valenciennes · FCO Charleville · FC Chamois Niort · FC Bourg Peronnas · FC Girondins Bordeaux · Football Club de Metz · FC Sochaux-Montbéliard · Football Club de Nantes · FC Girondins de Bordeaux · FC Libourne-Saint-Seurin · Football Club Chambly Oise · Football Club Lorient-Bretagne Sud · Football Club de Sochaux-Montbéliard · Football Club des Girondins de Bordeaux
- **G** (10): Grenoble · Gueugnon · Guingamp · GFC Ajaccio · Grenoble Foot · Gazélec Ajaccio · Grenoble Foot 38 · Girondins Bordeaux · Girondins de Bordeaux · Gazélec Football Club Ajaccio
- **H** (2): Havre AC · HSC Montpellier
- **I** (1): Istres
- **L** (19): LOSC · Lens · Lyon · Laval · Lille · Le Mans · Lorient · Le Havre · Libourne · Lille OSC · LOSC Lille · Le Mans FC · Le Havre AC · Le Mans UC 72 · Louhans-Cuis. · LB Châteauroux · Le Mans Football Club · La Berrichonne de Châteauroux · Le Havre Athletic Club Football
- **M** (8): Metz · Mulhouse · Marseille · Martigues · Montpellier · Montpellier HSC · Montpellier Hérault SC · Montpellier-Herault Sports Club
- **N** (7): Nice · Nancy · Niort · Nîmes · Nantes · Nîmes Olympique · Nîmes Olympique SC
- **O** (12): Orléans · OGC Nice · Ol. Lyon · OSC Lille · OGC Nizza [de] · Olympique Lyon · Olympique Nîmes · Olymp. Marseille · Olympique Lyonnais · Olympique Marseille · Olympique de Marseille · Olympique Gymnaste Club Nice Côte d'Azur
- **P** (12): Paris · Paris FC · Paris SG · Perpignan · Paris FC 98 · Perpignan FC · Paris S. Germain · Paris St. Germain · Paris Saint Germain · Paris Saint-Germain · Paris Saint-Germain FC · Paris-Saint-Germain Football Club
- **Q** (2): Quevilly Rouen · Quevilly-Rouen
- **R** (18): Reims · Rodez · Rouen · Rennes · RC Lens · Red Star · Rodez AF · Red Star 93 · Red Star FC · RC Strasbourg · Rodez Aveyron · Racing Besançon · Racing Strasbourg · Racing Club de Lens · RC Strasbourg Alsace · Racing Straßburg [de] · Rodez Aveyron Football · Racing Club de Strasbourg Alsace
- **S** (29): Sete · Sedan · SM Caen · Sochaux · SC Bastia · St Brieuc · SAS Épinal · SCO Angers · St-Étienne · Strasbourg · Stade Brest · Stade Laval · Stade Reims · Stade Rennes · Saint-Étienne · Stade Rennais · Stade Brestois · Stade Briochin · Stade de Reims · Stade Lavallois · Stade Rennais FC · Stade Brestois 29 · Sporting Toulon Var · Stade Malherbe Caen · Stade Malherbe de Caen · Sporting Club de Bastia · Stade Lavallois-Mayenne FC · Stade Rennais Football Club · Stade Lavallois Mayenne Football Club
- **T** (9): Tours · Toulon · Troyes · Toulouse · Tours FC · Troyes AC · Toulouse FC · Tours Football Club · Toulouse Football Club
- **U** (8): US Créteil · US Orléans · US Boulogne · US Orléans 45 · US Créteil-Lusitanos · US Quevilly-Rouen Métropole · Union Sportive Créteil-Lusitanos · Union sportive Orléans Loiret football
- **V** (6): Vannes · Valence · Vannes OC · Valenciennes · Valenciennes FC · Valenciennes Football Club
- **W** (2): Wasquehal · Wasquehal Foot
- **É** (7): Épinal · Évian TG · Évian TG FC · Évian Thonon Gaillard · Évian Thonon Gaillard FC · Évian Thonon-Gaillard FC · Évian Thonon Gaillard Football Club




