45 clubs

- [**Celtic FC**](https://en.wikipedia.org/wiki/Celtic_F.C.) : (2) Celtic · Celtic Glasgow
- [**Rangers FC**](https://en.wikipedia.org/wiki/Rangers_F.C.) : (3) Rangers · Gl. Rangers · Glasgow Rangers
- [**Partick Thistle**](https://en.wikipedia.org/wiki/Partick_Thistle_F.C.) : (3) Jags · Partick · Partick Thistle FC
- **Queen's Park** : (1) Queens Park
- [**Heart of Midlothian FC**](https://en.wikipedia.org/wiki/Heart_of_Midlothian_F.C.) : (4) Hearts · Hearts FC · Heart of Midl. · Heart of Midlothian
- [**Hibernian FC**](https://en.wikipedia.org/wiki/Hibernian_F.C.) : (2) Hibernian · Hibernians
- **Edinburgh City**
- [**Aberdeen FC**](https://en.wikipedia.org/wiki/Aberdeen_F.C.) : (3) Aberdeen · Abderden · FC Aberdeen
- **Cove Rangers FC** : (2) Cove Rangers · Cove Rangers Football Club
- [**Dundee FC**](https://en.wikipedia.org/wiki/Dundee_F.C.) : (2) Dundee · FC Dundee
- [**Dundee United**](https://en.wikipedia.org/wiki/Dundee_United_F.C.) : (3) Dundee Utd · Dundee United FC · Dundee Hibernian
- [**Hamilton Academical FC**](https://en.wikipedia.org/wiki/Hamilton_Academical_F.C.) : (4) Hamilton · Hamilton FC · Hamilton Accies · Hamilton Academical
- [**Kilmarnock FC**](https://en.wikipedia.org/wiki/Kilmarnock_F.C.) : (3) Killie · Kilmarnock · FC Kilmarnock
- [**Motherwell FC**](https://en.wikipedia.org/wiki/Motherwell_F.C.) : (2) Motherwell · FC Motherwell
- [**Ross County FC**](https://en.wikipedia.org/wiki/Ross_County_F.C.) : (2) Ross County · FC Ross County
- [**St Johnstone FC**](https://en.wikipedia.org/wiki/St_Johnstone_F.C.) : (4) St Johnstone · St. Johnstone · FC St. Johnstone · Saint Johnstone FC
- **Brechin City** : (1) Brechin
- **Dumbarton** : (1) FC Dumbarton
- **Dunfermline Athletic** : (2) Dunfermline · Dunfermline Athletic FC
- **Falkirk** : (2) FC Falkirk · Falkirk FC
- **Greenock Morton** : (2) Morton · Greenock Morton FC
- [**Inverness Caledonian Thistle**](https://en.wikipedia.org/wiki/Inverness_Caledonian_Thistle_F.C.) : (7) ICT · Inverness · Inverness C · Inverness CT · Caley Thistle · The Caley Jags · Inverness Caledonian Thistle FC
- [**Livingston FC**](https://en.wikipedia.org/wiki/Livingston_F.C.) : (2) Livingston · FC Livingston
- **Queen of the South** : (3) Queen of Sth · Queen of South · Queen of the South FC
- [**Saint Mirren FC**](https://en.wikipedia.org/wiki/St_Mirren_F.C.) : (3) St Mirren · St Mirren FC · FC St. Mirren
- **Airdrieonians** : (2) Airdrie · Airdrie Utd
- **Albion Rovers** : (1) Albion Rvs
- **Alloa Athletic** : (2) Alloa · FC Alloa Athletic
- **Arbroath** : (1) FC Arbroath
- **Ayr United** : (1) Ayr
- **East Fife** : (1) FC East Fife
- **Forfar Athletic** : (1) Forfar
- **Raith Rovers** : (4) Raith · Raith Rvs · FC Raith Rovers · Raith Rovers FC
- **Stranraer** : (1) FC Stranraer
- **Annan Athletic**
- **Clyde** : (1) FC Clyde
- **Cowdenbeath**
- **Elgin City** : (1) Elgin
- **Montrose** : (1) FC Montrose
- **Peterhead** : (1) Peterhead FC
- **Stenhousemuir**
- **Stirling Albion** : (1) Stirling
- [**Clydebank FC**](https://en.wikipedia.org/wiki/Clydebank_F.C.) : (1) Clydebank
- [**East Stirlingshire FC**](https://en.wikipedia.org/wiki/East_Stirlingshire_F.C.) : (1) East Stirling
- [**Gretna FC**](https://en.wikipedia.org/wiki/Gretna_F.C.) : (1) Gretna




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **Queen's Park**, Glasgow (1):
  - `queenspark` (2): Queen's Park · Queens Park
- **St Johnstone FC**, Perth (1):
  - `stjohnstone` (2): St Johnstone · St. Johnstone




By City

- **Glasgow** (4): 
  - Celtic FC  (2) Celtic · Celtic Glasgow
  - Rangers FC  (3) Rangers · Gl. Rangers · Glasgow Rangers
  - Partick Thistle  (3) Partick · Partick Thistle FC · Jags
  - Queen's Park  (1) Queens Park
- **Edinburgh** (3): 
  - Heart of Midlothian FC  (4) Hearts · Heart of Midl. · Heart of Midlothian · Hearts FC
  - Hibernian FC  (2) Hibernian · Hibernians
  - Edinburgh City 
- **Aberdeen** (2): 
  - Aberdeen FC  (3) Aberdeen · FC Aberdeen · Abderden
  - Cove Rangers FC  (2) Cove Rangers · Cove Rangers Football Club
- **Dundee** (2): 
  - Dundee FC  (2) Dundee · FC Dundee
  - Dundee United  (3) Dundee Utd · Dundee United FC · Dundee Hibernian
- **Falkirk** (2): 
  - Falkirk  (2) FC Falkirk · Falkirk FC
  - East Stirlingshire FC  (1) East Stirling
- **Airdrie** (1): Airdrieonians  (2) Airdrie Utd · Airdrie
- **Alloa** (1): Alloa Athletic  (2) Alloa · FC Alloa Athletic
- **Annan** (1): Annan Athletic 
- **Arbroath** (1): Arbroath  (1) FC Arbroath
- **Ayr** (1): Ayr United  (1) Ayr
- **Brechin** (1): Brechin City  (1) Brechin
- **Clydebank** (1): Clydebank FC  (1) Clydebank
- **Coatbridge** (1): Albion Rovers  (1) Albion Rvs
- **Cowdenbeath** (1): Cowdenbeath 
- **Cumbernauld** (1): Clyde  (1) FC Clyde
- **Dingwall** (1): Ross County FC  (2) Ross County · FC Ross County
- **Dumbarton** (1): Dumbarton  (1) FC Dumbarton
- **Dumfries** (1): Queen of the South  (3) Queen of Sth · Queen of South · Queen of the South FC
- **Dunfermline** (1): Dunfermline Athletic  (2) Dunfermline · Dunfermline Athletic FC
- **Elgin** (1): Elgin City  (1) Elgin
- **Forfar** (1): Forfar Athletic  (1) Forfar
- **Greenock** (1): Greenock Morton  (2) Morton · Greenock Morton FC
- **Gretna** (1): Gretna FC  (1) Gretna
- **Hamilton** (1): Hamilton Academical FC  (4) Hamilton · Hamilton FC · Hamilton Accies · Hamilton Academical
- **Inverness** (1): Inverness Caledonian Thistle  (7) Inverness · Inverness C · Inverness CT · Inverness Caledonian Thistle FC · Caley Thistle · ICT · The Caley Jags
- **Kilmarnock** (1): Kilmarnock FC  (3) Killie · Kilmarnock · FC Kilmarnock
- **Kirkcaldy** (1): Raith Rovers  (4) Raith · Raith Rvs · FC Raith Rovers · Raith Rovers FC
- **Livingston** (1): Livingston FC  (2) Livingston · FC Livingston
- **Methil** (1): East Fife  (1) FC East Fife
- **Montrose** (1): Montrose  (1) FC Montrose
- **Motherwell** (1): Motherwell FC  (2) Motherwell · FC Motherwell
- **Paisley** (1): Saint Mirren FC  (3) St Mirren · St Mirren FC · FC St. Mirren
- **Perth** (1): St Johnstone FC  (4) St Johnstone · St. Johnstone · Saint Johnstone FC · FC St. Johnstone
- **Peterhead** (1): Peterhead  (1) Peterhead FC
- **Stenhousemuir** (1): Stenhousemuir 
- **Stirling** (1): Stirling Albion  (1) Stirling
- **Stranraer** (1): Stranraer  (1) FC Stranraer




By Region

- **Glasgow†** (4):   Celtic FC · Rangers FC · Partick Thistle · Queen's Park
- **Edinburgh†** (3):   Heart of Midlothian FC · Hibernian FC · Edinburgh City
- **Aberdeen†** (2):   Aberdeen FC · Cove Rangers FC
- **Dundee†** (2):   Dundee FC · Dundee United
- **Hamilton†** (1):   Hamilton Academical FC
- **Kilmarnock†** (1):   Kilmarnock FC
- **Motherwell†** (1):   Motherwell FC
- **Dingwall†** (1):   Ross County FC
- **Perth†** (1):   St Johnstone FC
- **Brechin†** (1):   Brechin City
- **Dumbarton†** (1):   Dumbarton
- **Dunfermline†** (1):   Dunfermline Athletic
- **Falkirk†** (2):   Falkirk · East Stirlingshire FC
- **Greenock†** (1):   Greenock Morton
- **Inverness†** (1):   Inverness Caledonian Thistle
- **Livingston†** (1):   Livingston FC
- **Dumfries†** (1):   Queen of the South
- **Paisley†** (1):   Saint Mirren FC
- **Airdrie†** (1):   Airdrieonians
- **Coatbridge†** (1):   Albion Rovers
- **Alloa†** (1):   Alloa Athletic
- **Arbroath†** (1):   Arbroath
- **Ayr†** (1):   Ayr United
- **Methil†** (1):   East Fife
- **Forfar†** (1):   Forfar Athletic
- **Kirkcaldy†** (1):   Raith Rovers
- **Stranraer†** (1):   Stranraer
- **Annan†** (1):   Annan Athletic
- **Cumbernauld†** (1):   Clyde
- **Cowdenbeath†** (1):   Cowdenbeath
- **Elgin†** (1):   Elgin City
- **Montrose†** (1):   Montrose
- **Peterhead†** (1):   Peterhead
- **Stenhousemuir†** (1):   Stenhousemuir
- **Stirling†** (1):   Stirling Albion
- **Clydebank†** (1):   Clydebank FC
- **Gretna†** (1):   Gretna FC




By Year

- **1869** (1):   Kilmarnock FC
- **1874** (1):   Hamilton Academical FC
- **1876** (1):   Partick Thistle
- **1877** (1):   Saint Mirren FC
- **1884** (1):   St Johnstone FC
- **1886** (1):   Motherwell FC
- **1887** (1):   Celtic FC
- **1893** (1):   Dundee FC
- **1903** (1):   Aberdeen FC
- **1909** (1):   Dundee United
- **1922** (1):   Cove Rangers FC
- **1929** (1):   Ross County FC
- **1994** (1):   Inverness Caledonian Thistle
- ? (32):   Rangers FC · Queen's Park · Heart of Midlothian FC · Hibernian FC · Edinburgh City · Brechin City · Dumbarton · Dunfermline Athletic · Falkirk · Greenock Morton · Livingston FC · Queen of the South · Airdrieonians · Albion Rovers · Alloa Athletic · Arbroath · Ayr United · East Fife · Forfar Athletic · Raith Rovers · Stranraer · Annan Athletic · Clyde · Cowdenbeath · Elgin City · Montrose · Peterhead · Stenhousemuir · Stirling Albion · Clydebank FC · East Stirlingshire FC · Gretna FC






By A to Z

- **A** (14): Ayr · Alloa · Airdrie · Abderden · Aberdeen · Arbroath · Albion Rvs · Ayr United · Aberdeen FC · Airdrie Utd · Airdrieonians · Albion Rovers · Alloa Athletic · Annan Athletic
- **B** (2): Brechin · Brechin City
- **C** (11): Clyde · Celtic · Celtic FC · Clydebank · Cowdenbeath · Clydebank FC · Cove Rangers · Caley Thistle · Celtic Glasgow · Cove Rangers FC · Cove Rangers Football Club
- **D** (10): Dundee · Dumbarton · Dundee FC · Dundee Utd · Dunfermline · Dundee United · Dundee Hibernian · Dundee United FC · Dunfermline Athletic · Dunfermline Athletic FC
- **E** (6): Elgin · East Fife · Elgin City · East Stirling · Edinburgh City · East Stirlingshire FC
- **F** (21): Forfar · Falkirk · FC Clyde · FC Dundee · FC Falkirk · Falkirk FC · FC Aberdeen · FC Arbroath · FC Montrose · FC Dumbarton · FC East Fife · FC Stranraer · FC Kilmarnock · FC Livingston · FC Motherwell · FC St. Mirren · FC Ross County · FC Raith Rovers · Forfar Athletic · FC St. Johnstone · FC Alloa Athletic
- **G** (6): Gretna · Gretna FC · Gl. Rangers · Glasgow Rangers · Greenock Morton · Greenock Morton FC
- **H** (13): Hearts · Hamilton · Hearts FC · Hibernian · Hibernians · Hamilton FC · Hibernian FC · Heart of Midl. · Hamilton Accies · Hamilton Academical · Heart of Midlothian · Hamilton Academical FC · Heart of Midlothian FC
- **I** (6): ICT · Inverness · Inverness C · Inverness CT · Inverness Caledonian Thistle · Inverness Caledonian Thistle FC
- **J** (1): Jags
- **K** (3): Killie · Kilmarnock · Kilmarnock FC
- **L** (2): Livingston · Livingston FC
- **M** (4): Morton · Montrose · Motherwell · Motherwell FC
- **P** (5): Partick · Peterhead · Peterhead FC · Partick Thistle · Partick Thistle FC
- **Q** (6): Queens Park · Queen of Sth · Queen's Park · Queen of South · Queen of the South · Queen of the South FC
- **R** (8): Raith · Rangers · Raith Rvs · Rangers FC · Ross County · Raith Rovers · Ross County FC · Raith Rovers FC
- **S** (11): Stirling · St Mirren · Stranraer · St Johnstone · St Mirren FC · St. Johnstone · Stenhousemuir · Saint Mirren FC · St Johnstone FC · Stirling Albion · Saint Johnstone FC
- **T** (1): The Caley Jags




