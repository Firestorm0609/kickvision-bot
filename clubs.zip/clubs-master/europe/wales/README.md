31 clubs

- **The New Saints FC** : (3) TNS · TN Saints · The New Saints
- **Bangor City FC** : (2) Bangor · Bangor City
- **Llanelli AFC** : (3) Llanelli · Llanelli Town · Llanelli Town AFC
- **Cefn Druids AFC** : (2) Cefn Druids · NEWI Cefn Druids
- **Neath FC** : (1) Neath Athletic
- **Port Talbot Town FC** : (1) Port Talbot
- **Connah's Quay Nomads FC** : (2) Connah's Quay · Connah's Quay Nomads
- **Bala Town FC** : (2) Bala · Bala Town
- **Llandudno FC** : (2) Llandudno Town · Llandudno Town FC
- **Newtown AFC** : (1) Newtown
- **AUK Broughton FC** : (5) Airbus · Airbus UK · Broughton · Airbus UK Broughton · Airbus UK Broughton FC
- **Aberystwyth Town FC** : (2) Aberystwyth · Aberystwyth Town
- **Barry Town AFC** : (5) Barry · Barry Town · FC Barry Town · Barry Town United · Barry Town United FC
- **Cardiff Metropolitan University FC** : (5) Cardiff Met · Cardiff M.U. · Cardiff Met Uni. · Cardiff Metropolitan · Cardiff Met University
- **Caernarfon Town FC** : (2) Caernarfon · Caernarfon Town
- **Carmarthen Town AFC** : (1) Carmarthen
- **Penybont FC**
- [**Swansea City FC**](https://en.wikipedia.org/wiki/Swansea_City_A.F.C.) : (3) Swansea · Swansea City · Swansea City AFC
- [**Cardiff City FC**](https://en.wikipedia.org/wiki/Cardiff_City_F.C.) : (2) Cardiff · Cardiff City
- [**Newport County AFC**](https://en.wikipedia.org/wiki/Newport_County_A.F.C.) : (2) Newport · Newport County
- **Wrexham AFC** : (2) Wrexham · Wrexham FC
- **Merthyr Town FC** : (2) Merthyr Town · Merthyr Tydfil FC
- **Aberdare Athletic FC (1893-1928)** : (1) Aberdare Athletic
- **Rhyl FC** : (2) Rhyl · Rhyl Football Club
- **Cwmbrân Town AFC** : (2) Cwmbrân Town · Cwmbrân Town FC ⇒ (3) ≈Cwmbran Town≈ · ≈Cwmbran Town FC≈ · ≈Cwmbran Town AFC≈
- **Prestatyn Town FC**
- **Afan Lido FC** : (1) Afan Lido
- **Haverfordwest County AFC** : (1) Haverfordwest County
- **Porthmadog FC** : (1) Porthmadog
- **Welshpool Town FC** : (2) Welshpool Town · Welshpool Football Club
- **Caersws FC** : (1) Caersws




Alphabet

- **Alphabet Specials** (1):  **â** 
  - **â**×3 U+00E2 (226) - LATIN SMALL LETTER A WITH CIRCUMFLEX ⇒ a




Duplicates





By City

- **Aberdare** (1): Aberdare Athletic FC (1893-1928)  (1) Aberdare Athletic
- **Caersws** (1): Caersws FC  (1) Caersws
- **Cardiff** (1): Cardiff City FC  (2) Cardiff · Cardiff City
- **Cwmbrân** (1): Cwmbrân Town AFC  (2) Cwmbrân Town · Cwmbrân Town FC
- **Haverfordwest** (1): Haverfordwest County AFC  (1) Haverfordwest County
- **Llandudno** (1): Llandudno FC  (2) Llandudno Town FC · Llandudno Town
- **Llanelli** (1): Llanelli AFC  (3) Llanelli · Llanelli Town · Llanelli Town AFC
- **Merthyr Tydfil** (1): Merthyr Town FC  (2) Merthyr Town · Merthyr Tydfil FC
- **Newport** (1): Newport County AFC  (2) Newport · Newport County
- **Oswestry** (1): The New Saints FC  (3) TNS · TN Saints · The New Saints
- **Port Talbot** (1): Afan Lido FC  (1) Afan Lido
- **Porthmadog** (1): Porthmadog FC  (1) Porthmadog
- **Prestatyn** (1): Prestatyn Town FC 
- **Rhyl** (1): Rhyl FC  (2) Rhyl · Rhyl Football Club
- **Swansea** (1): Swansea City FC  (3) Swansea · Swansea City · Swansea City AFC
- **Welshpool** (1): Welshpool Town FC  (2) Welshpool Football Club · Welshpool Town
- **Wrexham** (1): Wrexham AFC  (2) Wrexham · Wrexham FC
- ? (14): 
  - Bangor City FC  (2) Bangor · Bangor City
  - Cefn Druids AFC  (2) Cefn Druids · NEWI Cefn Druids
  - Neath FC  (1) Neath Athletic
  - Port Talbot Town FC  (1) Port Talbot
  - Connah's Quay Nomads FC  (2) Connah's Quay · Connah's Quay Nomads
  - Bala Town FC  (2) Bala · Bala Town
  - Newtown AFC  (1) Newtown
  - AUK Broughton FC  (5) Airbus · Airbus UK · Broughton · Airbus UK Broughton · Airbus UK Broughton FC
  - Aberystwyth Town FC  (2) Aberystwyth · Aberystwyth Town
  - Barry Town AFC  (5) Barry · FC Barry Town · Barry Town · Barry Town United · Barry Town United FC
  - Cardiff Metropolitan University FC  (5) Cardiff Met · Cardiff M.U. · Cardiff Met Uni. · Cardiff Metropolitan · Cardiff Met University
  - Caernarfon Town FC  (2) Caernarfon · Caernarfon Town
  - Carmarthen Town AFC  (1) Carmarthen
  - Penybont FC 




By Region

- **Oswestry†** (1):   The New Saints FC
- **Llanelli†** (1):   Llanelli AFC
- **Llandudno†** (1):   Llandudno FC
- **Swansea†** (1):   Swansea City FC
- **Cardiff†** (1):   Cardiff City FC
- **Newport†** (1):   Newport County AFC
- **Wrexham†** (1):   Wrexham AFC
- **Merthyr Tydfil†** (1):   Merthyr Town FC
- **Aberdare†** (1):   Aberdare Athletic FC (1893-1928)
- **Rhyl†** (1):   Rhyl FC
- **Cwmbrân†** (1):   Cwmbrân Town AFC
- **Prestatyn†** (1):   Prestatyn Town FC
- **Port Talbot†** (1):   Afan Lido FC
- **Haverfordwest†** (1):   Haverfordwest County AFC
- **Porthmadog†** (1):   Porthmadog FC
- **Welshpool†** (1):   Welshpool Town FC
- **Caersws†** (1):   Caersws FC




By Year

- **1893** (1):   Aberdare Athletic FC (1893-1928)
- **1896** (1):   Llanelli AFC
- **1899** (1):   Haverfordwest County AFC
- **1910** (1):   Prestatyn Town FC
- **1912** (2):   Swansea City FC · Newport County AFC
- **1967** (1):   Afan Lido FC
- **1988** (1):   Llandudno FC
- ? (23):   The New Saints FC · Bangor City FC · Cefn Druids AFC · Neath FC · Port Talbot Town FC · Connah's Quay Nomads FC · Bala Town FC · Newtown AFC · AUK Broughton FC · Aberystwyth Town FC · Barry Town AFC · Cardiff Metropolitan University FC · Caernarfon Town FC · Carmarthen Town AFC · Penybont FC · Cardiff City FC · Wrexham AFC · Merthyr Town FC · Rhyl FC · Cwmbrân Town AFC · Porthmadog FC · Welshpool Town FC · Caersws FC




Historic

- **1928** (1):   Aberdare Athletic FC (1893-1928)






By A to Z

- **A** (12): Airbus · Afan Lido · Airbus UK · Aberystwyth · Afan Lido FC · AUK Broughton FC · Aberystwyth Town · Aberdare Athletic · Aberystwyth Town FC · Airbus UK Broughton · Airbus UK Broughton FC · Aberdare Athletic FC (1893-1928)
- **B** (12): Bala · Barry · Bangor · Bala Town · Broughton · Barry Town · Bangor City · Bala Town FC · Bangor City FC · Barry Town AFC · Barry Town United · Barry Town United FC
- **C** (24): Caersws · Cardiff · Caernarfon · Caersws FC · Carmarthen · Cardiff Met · Cefn Druids · Cardiff City · Cardiff M.U. · Cwmbrân Town · Connah's Quay · Caernarfon Town · Cardiff City FC · Cefn Druids AFC · Cwmbrân Town FC · Cardiff Met Uni. · Cwmbrân Town AFC · Caernarfon Town FC · Carmarthen Town AFC · Cardiff Metropolitan · Connah's Quay Nomads · Cardiff Met University · Connah's Quay Nomads FC · Cardiff Metropolitan University FC
- **F** (1): FC Barry Town
- **H** (2): Haverfordwest County · Haverfordwest County AFC
- **L** (7): Llanelli · Llandudno FC · Llanelli AFC · Llanelli Town · Llandudno Town · Llandudno Town FC · Llanelli Town AFC
- **M** (3): Merthyr Town · Merthyr Town FC · Merthyr Tydfil FC
- **N** (8): Newport · Newtown · Neath FC · Newtown AFC · Neath Athletic · Newport County · NEWI Cefn Druids · Newport County AFC
- **P** (6): Porthmadog · Penybont FC · Port Talbot · Porthmadog FC · Prestatyn Town FC · Port Talbot Town FC
- **R** (3): Rhyl · Rhyl FC · Rhyl Football Club
- **S** (4): Swansea · Swansea City · Swansea City FC · Swansea City AFC
- **T** (4): TNS · TN Saints · The New Saints · The New Saints FC
- **W** (6): Wrexham · Wrexham FC · Wrexham AFC · Welshpool Town · Welshpool Town FC · Welshpool Football Club




