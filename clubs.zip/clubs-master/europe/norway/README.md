41 clubs

- **Vålerenga Fotball** : (3) Vålerenga · Vålerenga IF · Vålerengen IF ⇒ (4) ≈Valerenga≈ · ≈Valerenga IF≈ · ≈Valerengen IF≈ · ≈Valerenga Fotball≈
- **KFUM-Kameratene Oslo** : (1) KFUM Oslo
- **Skeid Fotball** : (3) Skeid · Skeid FK · Skeid Oslo
- **Lyn Oslo** : (6) Lyn · FK Lyn · Lyn Fotball · Lyn 1896 FK · FC Lyn Oslo · Lyn 1896 Fotballklubb
- **Frigg Oslo FK** : (1) Frigg Oslo Fotballklubb
- **Rosenborg BK** : (2) Rosenborg · Rosenborg Ballklub
- **Ranheim** : (2) Ranheim IL · Ranheim Fotball
- **Moss FK** : (1) Moss Fotballklubb
- **Molde FK** : (1) Molde
- **Tromsø IL** : (2) Tromsø · Tromsø Idrettslag ⇒ (3) ≈Tromso≈ · ≈Tromso IL≈ · ≈Tromso Idrettslag≈
- **Aalesunds FK** : (2) Aalesund · Aalesunds Fotballklubb
- **SK Brann** : (2) Brann · SK Brann Bergen
- **Strømsgodset IF** : (2) Strømsgodset · Strømsgodset Toppfotball ⇒ (3) ≈Stromsgodset≈ · ≈Stromsgodset IF≈ · ≈Stromsgodset Toppfotball≈
- **Fredrikstad FK** : (2) Fredrikstad · Fredrikstad Fotballklubb
- **Lillestrøm SK** : (2) Lillestrøm · Lilleström SK [de] ⇒ (4) ≈Lillestrom≈ · ≈Lillestrom SK≈ · ≈Lillestrom SK≈ · ≈Lillestroem SK≈
- **Viking FK** : (3) Viking · Viking Stavanger · Viking Fotballklubb
- **Odds BK** : (3) Odd · Odd Grenland · Odds Ballklubb
- **Sandefjord** : (1) Sandefjord Fotball
- **Sandnes Ulf** : (1) Sandnes
- **Sarpsborg 08** : (4) Sarpsborg · Sarpsborg FK · Sarpsborg 08 FF · Sarpsborg 08 Fotballforening
- **Sogndal** : (2) Sogndal IL · Sogndal Fotball
- **Stabæk** : (2) Stabæk IF · Stabæk Fotball ⇒ (3) ≈Stabaek≈ · ≈Stabaek IF≈ · ≈Stabaek Fotball≈
- **IK Start** : (2) Start · Idrettsklubben Start
- **Kristiansund BK** : (2) Kristiansund · Kristiansund Ballklubb
- **Mjøndalen IF** : (2) Mjøndalen · Mjöndalen [de] ⇒ (4) ≈Mjondalen≈ · ≈Mjondalen≈ · ≈Mjoendalen≈ · ≈Mjondalen IF≈
- **Bodø/Glimt** : (3) FK Bodø/Glimt · Bodö Glimt [de] · Fotballklubben Bodø/Glimt ⇒ (5) ≈Bodo/Glimt≈ · ≈Bodo Glimt≈ · ≈Bodoe Glimt≈ · ≈FK Bodo/Glimt≈ · ≈Fotballklubben Bodo/Glimt≈
- **FK Haugesund** : (2) Haugesund · Fotballklubben Haugesund
- **SK Haugar** : (2) Haugur Haugesund · Sportsklubben Haugar
- **Hønefoss BK** : (2) Hønefoss · Hønefoss Ballklubb ⇒ (3) ≈Honefoss≈ · ≈Honefoss BK≈ · ≈Honefoss Ballklubb≈
- **FK Jerv** : (1) Jerv
- **Ullensaker/Kisa IL** : (2) Ull/Kisa · Ullensaker/Kisa
- **IL Hødd** : (3) Hødd · IL Hødd Fotball · Idrettslaget Hødd ⇒ (4) ≈Hodd≈ · ≈IL Hodd≈ · ≈IL Hodd Fotball≈ · ≈Idrettslaget Hodd≈
- **Hamarkameratene** : (2) HamKam · Ham-Kam
- **Kongsvinger IL** : (3) Kongsvinger · Kongsvinger IL Fot · Kongsvinger IL Toppfotball
- **Nest-Sotra Fotball** : (1) Nest-Sotra
- **Notodden FK** : (1) Notodden
- **Raufoss IL** : (1) Raufoss
- **Strømmen IF** : (2) Strømmen · Strömmen IF [de] ⇒ (4) ≈Strommen≈ · ≈Strommen IF≈ · ≈Strommen IF≈ · ≈Stroemmen IF≈
- **Tromsdalen UIL** : (1) Tromsdalen
- **Åsane Fotball** : (1) Aasane Fotball [de] ⇒ (1) ≈Asane Fotball≈
- **Bryne FK** : (1) Bryne Fotballklubb




Alphabet

- **Alphabet Specials** (5):  **Å**  **å**  **æ**  **ö**  **ø** 
  - **Å**×1 U+00C5 (197) - LATIN CAPITAL LETTER A WITH RING ABOVE ⇒ A
  - **å**×4 U+00E5 (229) - LATIN SMALL LETTER A WITH RING ABOVE ⇒ a
  - **æ**×3 U+00E6 (230) - LATIN SMALL LETTER AE ⇒ ae
  - **ö**×4 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ø**×22 U+00F8 (248) - LATIN SMALL LETTER O WITH STROKE ⇒ o




Duplicates

- **Lillestrøm SK**, Lillestrøm (1):
  - `lillestromsk` (2): **Lillestrom SK** · **Lillestrom SK**
- **Mjøndalen IF**, Mjøndalen (1):
  - `mjondalen` (2): **Mjondalen** · **Mjondalen**
- **Bodø/Glimt**, Bodø (1):
  - `bodoglimt` (2): Bodo/Glimt · Bodo Glimt
- **Hamarkameratene**, Hamar (1):
  - `hamkam` (2): HamKam · Ham-Kam
- **Strømmen IF**, Strømmen (1):
  - `strommenif` (2): **Strommen IF** · **Strommen IF**




By City

- **Oslo** (5): 
  - Vålerenga Fotball  (3) Vålerenga · Vålerenga IF · Vålerengen IF
  - KFUM-Kameratene Oslo  (1) KFUM Oslo
  - Skeid Fotball  (3) Skeid · Skeid FK · Skeid Oslo
  - Lyn Oslo  (6) Lyn · Lyn 1896 FK · FK Lyn · Lyn Fotball · Lyn 1896 Fotballklubb · FC Lyn Oslo
  - Frigg Oslo FK  (1) Frigg Oslo Fotballklubb
- **Haugesund** (2): 
  - FK Haugesund  (2) Haugesund · Fotballklubben Haugesund
  - SK Haugar  (2) Haugur Haugesund · Sportsklubben Haugar
- **Trondheim** (2): 
  - Rosenborg BK  (2) Rosenborg · Rosenborg Ballklub
  - Ranheim  (2) Ranheim Fotball · Ranheim IL
- **Bergen** (1): SK Brann  (2) Brann · SK Brann Bergen
- **Bodø** (1): Bodø/Glimt  (3) FK Bodø/Glimt · Fotballklubben Bodø/Glimt · Bodö Glimt [de]
- **Bryne** (1): Bryne FK  (1) Bryne Fotballklubb
- **Bærum** (1): Stabæk  (2) Stabæk Fotball · Stabæk IF
- **Drammen** (1): Strømsgodset IF  (2) Strømsgodset · Strømsgodset Toppfotball
- **Fredrikstad** (1): Fredrikstad FK  (2) Fredrikstad · Fredrikstad Fotballklubb
- **Grimstad** (1): FK Jerv  (1) Jerv
- **Hamar** (1): Hamarkameratene  (2) HamKam · Ham-Kam
- **Hønefoss** (1): Hønefoss BK  (2) Hønefoss · Hønefoss Ballklubb
- **Kongsvinger** (1): Kongsvinger IL  (3) Kongsvinger · Kongsvinger IL Fot · Kongsvinger IL Toppfotball
- **Kristiansand** (1): IK Start  (2) Start · Idrettsklubben Start
- **Kristiansund** (1): Kristiansund BK  (2) Kristiansund · Kristiansund Ballklubb
- **Lillestrøm** (1): Lillestrøm SK  (2) Lillestrøm · Lilleström SK [de]
- **Mjøndalen** (1): Mjøndalen IF  (2) Mjøndalen · Mjöndalen [de]
- **Molde** (1): Molde FK  (1) Molde
- **Moss** (1): Moss FK  (1) Moss Fotballklubb
- **Notodden** (1): Notodden FK  (1) Notodden
- **Raufoss** (1): Raufoss IL  (1) Raufoss
- **Sandefjord** (1): Sandefjord  (1) Sandefjord Fotball
- **Sandnes** (1): Sandnes Ulf  (1) Sandnes
- **Sarpsborg** (1): Sarpsborg 08  (4) Sarpsborg · Sarpsborg 08 FF · Sarpsborg 08 Fotballforening · Sarpsborg FK
- **Skien** (1): Odds BK  (3) Odd · Odds Ballklubb · Odd Grenland
- **Sogndal** (1): Sogndal  (2) Sogndal Fotball · Sogndal IL
- **Sotra** (1): Nest-Sotra Fotball  (1) Nest-Sotra
- **Stavanger** (1): Viking FK  (3) Viking · Viking Fotballklubb · Viking Stavanger
- **Strømmen** (1): Strømmen IF  (2) Strømmen · Strömmen IF [de]
- **Tromsdalen** (1): Tromsdalen UIL  (1) Tromsdalen
- **Tromsø** (1): Tromsø IL  (2) Tromsø · Tromsø Idrettslag
- **Ullensaker** (1): Ullensaker/Kisa IL  (2) Ull/Kisa · Ullensaker/Kisa
- **Ulsteinvik** (1): IL Hødd  (3) Hødd · Idrettslaget Hødd · IL Hødd Fotball
- **Ålesund** (1): Aalesunds FK  (2) Aalesund · Aalesunds Fotballklubb
- **Åsane** (1): Åsane Fotball  (1) Aasane Fotball [de]




By Region

- **Oslo†** (5):   Vålerenga Fotball · KFUM-Kameratene Oslo · Skeid Fotball · Lyn Oslo · Frigg Oslo FK
- **Trondheim†** (2):   Rosenborg BK · Ranheim
- **Moss†** (1):   Moss FK
- **Molde†** (1):   Molde FK
- **Tromsø†** (1):   Tromsø IL
- **Ålesund†** (1):   Aalesunds FK
- **Bergen†** (1):   SK Brann
- **Drammen†** (1):   Strømsgodset IF
- **Fredrikstad†** (1):   Fredrikstad FK
- **Lillestrøm†** (1):   Lillestrøm SK
- **Stavanger†** (1):   Viking FK
- **Skien†** (1):   Odds BK
- **Sandefjord†** (1):   Sandefjord
- **Sandnes†** (1):   Sandnes Ulf
- **Sarpsborg†** (1):   Sarpsborg 08
- **Sogndal†** (1):   Sogndal
- **Bærum†** (1):   Stabæk
- **Kristiansand†** (1):   IK Start
- **Kristiansund†** (1):   Kristiansund BK
- **Mjøndalen†** (1):   Mjøndalen IF
- **Bodø†** (1):   Bodø/Glimt
- **Haugesund†** (2):   FK Haugesund · SK Haugar
- **Hønefoss†** (1):   Hønefoss BK
- **Grimstad†** (1):   FK Jerv
- **Ullensaker†** (1):   Ullensaker/Kisa IL
- **Ulsteinvik†** (1):   IL Hødd
- **Hamar†** (1):   Hamarkameratene
- **Kongsvinger†** (1):   Kongsvinger IL
- **Sotra†** (1):   Nest-Sotra Fotball
- **Notodden†** (1):   Notodden FK
- **Raufoss†** (1):   Raufoss IL
- **Strømmen†** (1):   Strømmen IF
- **Tromsdalen†** (1):   Tromsdalen UIL
- **Åsane†** (1):   Åsane Fotball
- **Bryne†** (1):   Bryne FK




By Year

- **1892** (1):   Kongsvinger IL
- **1894** (1):   Odds BK
- **1904** (1):   Frigg Oslo FK
- **1919** (1):   IL Hødd
- **1926** (1):   Bryne FK
- **1939** (1):   SK Haugar
- **1993** (1):   FK Haugesund
- ? (34):   Vålerenga Fotball · KFUM-Kameratene Oslo · Skeid Fotball · Lyn Oslo · Rosenborg BK · Ranheim · Moss FK · Molde FK · Tromsø IL · Aalesunds FK · SK Brann · Strømsgodset IF · Fredrikstad FK · Lillestrøm SK · Viking FK · Sandefjord · Sandnes Ulf · Sarpsborg 08 · Sogndal · Stabæk · IK Start · Kristiansund BK · Mjøndalen IF · Bodø/Glimt · Hønefoss BK · FK Jerv · Ullensaker/Kisa IL · Hamarkameratene · Nest-Sotra Fotball · Notodden FK · Raufoss IL · Strømmen IF · Tromsdalen UIL · Åsane Fotball






By A to Z

- **A** (4): Aalesund · Aalesunds FK · Aasane Fotball [de] · Aalesunds Fotballklubb
- **B** (5): Brann · Bryne FK · Bodø/Glimt · Bodö Glimt [de] · Bryne Fotballklubb
- **F** (12): FK Lyn · FK Jerv · FC Lyn Oslo · Fredrikstad · FK Haugesund · FK Bodø/Glimt · Frigg Oslo FK · Fredrikstad FK · Frigg Oslo Fotballklubb · Fotballklubben Haugesund · Fredrikstad Fotballklubb · Fotballklubben Bodø/Glimt
- **H** (9): Hødd · HamKam · Ham-Kam · Hønefoss · Haugesund · Hønefoss BK · Hamarkameratene · Haugur Haugesund · Hønefoss Ballklubb
- **I** (5): IL Hødd · IK Start · IL Hødd Fotball · Idrettslaget Hødd · Idrettsklubben Start
- **J** (1): Jerv
- **K** (9): KFUM Oslo · Kongsvinger · Kristiansund · Kongsvinger IL · Kristiansund BK · Kongsvinger IL Fot · KFUM-Kameratene Oslo · Kristiansund Ballklubb · Kongsvinger IL Toppfotball
- **L** (8): Lyn · Lyn Oslo · Lillestrøm · Lyn 1896 FK · Lyn Fotball · Lillestrøm SK · Lilleström SK [de] · Lyn 1896 Fotballklubb
- **M** (7): Molde · Moss FK · Molde FK · Mjøndalen · Mjøndalen IF · Mjöndalen [de] · Moss Fotballklubb
- **N** (4): Notodden · Nest-Sotra · Notodden FK · Nest-Sotra Fotball
- **O** (4): Odd · Odds BK · Odd Grenland · Odds Ballklubb
- **R** (8): Ranheim · Raufoss · Rosenborg · Ranheim IL · Raufoss IL · Rosenborg BK · Ranheim Fotball · Rosenborg Ballklub
- **S** (30): Skeid · Start · Stabæk · Sandnes · Sogndal · SK Brann · Skeid FK · Strømmen · SK Haugar · Sarpsborg · Stabæk IF · Sandefjord · Skeid Oslo · Sogndal IL · Sandnes Ulf · Strømmen IF · Sarpsborg 08 · Sarpsborg FK · Strømsgodset · Skeid Fotball · Stabæk Fotball · SK Brann Bergen · Sarpsborg 08 FF · Sogndal Fotball · Strømsgodset IF · Strömmen IF [de] · Sandefjord Fotball · Sportsklubben Haugar · Strømsgodset Toppfotball · Sarpsborg 08 Fotballforening
- **T** (5): Tromsø · Tromsø IL · Tromsdalen · Tromsdalen UIL · Tromsø Idrettslag
- **U** (3): Ull/Kisa · Ullensaker/Kisa · Ullensaker/Kisa IL
- **V** (8): Viking · Viking FK · Vålerenga · Vålerenga IF · Vålerengen IF · Viking Stavanger · Vålerenga Fotball · Viking Fotballklubb
- **Å** (1): Åsane Fotball




