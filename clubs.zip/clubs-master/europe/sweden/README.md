40 clubs

- **AIK** : (4) AIK Solna · AIK Fotboll · AIK Stockholm · Allmänna Idrottsklubben ⇒ (2) ≈Allmanna Idrottsklubben≈ · ≈Allmaenna Idrottsklubben≈
- **IF Brommapojkarna** : (1) Brommapojkarna
- **Djurgårdens IF** : (2) Djurgården · Djurgarden ⇒ (2) ≈Djurgarden≈ · ≈Djurgardens IF≈
- **Hammarby IF** : (2) Hammarby · Hammarby Fotboll
- **IFK Göteborg** : (4) Göteborg · Goteborg · IFK Goteborg · Idrottsföreningen Kamraterna Göteborg ⇒ (6) ≈Goteborg≈ · ≈Goeteborg≈ · ≈IFK Goteborg≈ · ≈IFK Goeteborg≈ · ≈Idrottsforeningen Kamraterna Goteborg≈ · ≈Idrottsfoereningen Kamraterna Goeteborg≈
- **GAIS** : (2) GAIS Göteborg · Göteborgs Atlet- och Idrottssällskap ⇒ (4) ≈GAIS Goteborg≈ · ≈GAIS Goeteborg≈ · ≈Goteborgs Atlet- och Idrottssallskap≈ · ≈Goeteborgs Atlet- och Idrottssaellskap≈
- **BK Häcken** : (3) Hacken · Häcken · Bollklubben Häcken ⇒ (6) ≈Hacken≈ · ≈Haecken≈ · ≈BK Hacken≈ · ≈BK Haecken≈ · ≈Bollklubben Hacken≈ · ≈Bollklubben Haecken≈
- **Qviding FIF**
- **Örgryte Göteborg** : (1) Örgryte IS ⇒ (4) ≈Orgryte IS≈ · ≈OErgryte IS≈ · ≈Orgryte Goteborg≈ · ≈OErgryte Goeteborg≈
- **Malmö FF** : (3) Malmö · Malmo FF · Malmö Fotbollförening ⇒ (6) ≈Malmo≈ · ≈Malmoe≈ · ≈Malmo FF≈ · ≈Malmoe FF≈ · ≈Malmo Fotbollforening≈ · ≈Malmoe Fotbollfoerening≈
- **IFK Malmö** : (2) IFK Malmö Fotboll · Idrottsföreningen Kamraterna Malmö ⇒ (6) ≈IFK Malmo≈ · ≈IFK Malmoe≈ · ≈IFK Malmo Fotboll≈ · ≈IFK Malmoe Fotboll≈ · ≈Idrottsforeningen Kamraterna Malmo≈ · ≈Idrottsfoereningen Kamraterna Malmoe≈
- **IF Elfsborg** : (1) Elfsborg
- **Norrby IF**
- **Helsingborgs IF** : (2) Helsingborg · Helsingborg IF
- **Kalmar FF** : (1) Kalmar
- **Örebro SK** : (3) Örebro · Orebro · Örebro Sportklubb ⇒ (6) ≈Orebro≈ · ≈OErebro≈ · ≈Orebro SK≈ · ≈OErebro SK≈ · ≈Orebro Sportklubb≈ · ≈OErebro Sportklubb≈
- **Gefle IF** : (1) Gefle
- **AFC Eskilstuna** : (1) Eskilstuna
- **Mjällby AIF** : (1) Mjallby ⇒ (2) ≈Mjallby AIF≈ · ≈Mjaellby AIF≈
- **Åtvidabergs FF** : (5) ÅFF · Åtvid · Åtvidaberg · Atvidabergs · Åtvidabergs Fotbollförening ⇒ (6) ≈AFF≈ · ≈Atvid≈ · ≈Atvidaberg≈ · ≈Atvidabergs FF≈ · ≈Atvidabergs Fotbollforening≈ · ≈Åtvidabergs Fotbollfoerening≈
- **Dalkurd FF** : (1) Dalkurd
- **IK Sirius** : (2) Sirius · IK Sirius FK
- **Falkenbergs FF** : (1) Falkenbergs
- **Halmstads BK** : (2) Halmstad · Halmstads Bollklubb
- **Jönköpings Södra IF** : (2) Jönköpings · Jönköpings Södra ⇒ (6) ≈Jonkopings≈ · ≈Joenkoepings≈ · ≈Jonkopings Sodra≈ · ≈Jonkopings Sodra IF≈ · ≈Joenkoepings Soedra≈ · ≈Joenkoepings Soedra IF≈
- **Ljungskile SK** : (1) Ljungskile
- **IFK Norrköping** : (3) Norrköping · Norrkoping · IFK Norrköping FK ⇒ (6) ≈Norrkoping≈ · ≈Norrkoeping≈ · ≈IFK Norrkoping≈ · ≈IFK Norrkoeping≈ · ≈IFK Norrkoping FK≈ · ≈IFK Norrkoeping FK≈
- **Östers IF** : (1) Osters ⇒ (2) ≈Osters IF≈ · ≈OEsters IF≈
- **Östersunds FK** : (2) Östersund · Ostersunds ⇒ (4) ≈Ostersund≈ · ≈OEstersund≈ · ≈Ostersunds FK≈ · ≈OEstersunds FK≈
- **GIF Sundsvall** : (1) Sundsvall
- **Syrianska FC** : (1) Syrianska
- **Trelleborgs FF** : (1) Trelleborgs
- **FC Trollhättan** ⇒ (2) ≈FC Trollhattan≈ · ≈FC Trollhaettan≈
- **Husqvarna FF**
- **Nyköping BIS** ⇒ (2) ≈Nykoping BIS≈ · ≈Nykoeping BIS≈
- **Västerås SK** : (1) Vasteraas SK ⇒ (2) ≈Vasteras SK≈ · ≈Vaesterås SK≈
- **Degerfors IF**
- **Varbergs BoIS**
- **IK Brage** : (1) Brage
- **Landskrona BoIS** : (1) Landskrona Boll och Idrottsällskap ⇒ (2) ≈Landskrona Boll och Idrottsallskap≈ · ≈Landskrona Boll och Idrottsaellskap≈




Alphabet

- **Alphabet Specials** (5):  **Å**  **Ö**  **ä**  **å**  **ö** 
  - **Å**×5 U+00C5 (197) - LATIN CAPITAL LETTER A WITH RING ABOVE ⇒ A
  - **Ö**×8 U+00D6 (214) - LATIN CAPITAL LETTER O WITH DIAERESIS ⇒ O•OE
  - **ä**×9 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **å**×3 U+00E5 (229) - LATIN SMALL LETTER A WITH RING ABOVE ⇒ a
  - **ö**×28 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe




Duplicates

- **Djurgårdens IF**, Stockholm (1):
  - `djurgarden` (2): **Djurgarden** · **Djurgarden**
- **IFK Göteborg**, Göteborg (2):
  - `goteborg` (2): **Goteborg** · **Goteborg**
  - `ifkgoteborg` (2): **IFK Goteborg** · **IFK Goteborg**
- **BK Häcken**, Göteborg (1):
  - `hacken` (2): **Hacken** · **Hacken**
- **Malmö FF**, Malmö (1):
  - `malmoff` (2): **Malmo FF** · **Malmo FF**
- **Örebro SK**, Örebro (1):
  - `orebro` (2): **Orebro** · **Orebro**
- **IFK Norrköping**, Norrköping (1):
  - `norrkoping` (2): **Norrkoping** · **Norrkoping**




By City

- **Göteborg** (5): 
  - IFK Göteborg  (4) Göteborg · Goteborg · IFK Goteborg · Idrottsföreningen Kamraterna Göteborg
  - GAIS  (2) GAIS Göteborg · Göteborgs Atlet- och Idrottssällskap
  - BK Häcken  (3) Hacken · Häcken · Bollklubben Häcken
  - Qviding FIF 
  - Örgryte Göteborg  (1) Örgryte IS
- **Stockholm** (4): 
  - AIK  (4) AIK Fotboll · Allmänna Idrottsklubben · AIK Stockholm · AIK Solna
  - IF Brommapojkarna  (1) Brommapojkarna
  - Djurgårdens IF  (2) Djurgården · Djurgarden
  - Hammarby IF  (2) Hammarby · Hammarby Fotboll
- **Borås** (2): 
  - IF Elfsborg  (1) Elfsborg
  - Norrby IF 
- **Malmö** (2): 
  - Malmö FF  (3) Malmö · Malmo FF · Malmö Fotbollförening
  - IFK Malmö  (2) IFK Malmö Fotboll · Idrottsföreningen Kamraterna Malmö
- **Uppsala** (2): 
  - Dalkurd FF  (1) Dalkurd
  - IK Sirius  (2) Sirius · IK Sirius FK
- **Borlänge** (1): IK Brage  (1) Brage
- **Degerfors** (1): Degerfors IF 
- **Eskilstuna** (1): AFC Eskilstuna  (1) Eskilstuna
- **Falkenberg** (1): Falkenbergs FF  (1) Falkenbergs
- **Gävle** (1): Gefle IF  (1) Gefle
- **Halmstad** (1): Halmstads BK  (2) Halmstad · Halmstads Bollklubb
- **Helsingborg** (1): Helsingborgs IF  (2) Helsingborg · Helsingborg IF
- **Huskvarna** (1): Husqvarna FF 
- **Jönköping** (1): Jönköpings Södra IF  (2) Jönköpings · Jönköpings Södra
- **Kalmar** (1): Kalmar FF  (1) Kalmar
- **Landskrona** (1): Landskrona BoIS  (1) Landskrona Boll och Idrottsällskap
- **Ljungskile** (1): Ljungskile SK  (1) Ljungskile
- **Mjällby** (1): Mjällby AIF  (1) Mjallby
- **Norrköping** (1): IFK Norrköping  (3) Norrköping · Norrkoping · IFK Norrköping FK
- **Nyköping** (1): Nyköping BIS 
- **Sundsvall** (1): GIF Sundsvall  (1) Sundsvall
- **Södertälje** (1): Syrianska FC  (1) Syrianska
- **Trelleborg** (1): Trelleborgs FF  (1) Trelleborgs
- **Trollhättan** (1): FC Trollhättan 
- **Varberg** (1): Varbergs BoIS 
- **Västerås** (1): Västerås SK  (1) Vasteraas SK
- **Växjö** (1): Östers IF  (1) Osters
- **Åtvidaberg** (1): Åtvidabergs FF  (5) Atvidabergs · Åtvidaberg · Åtvid · ÅFF · Åtvidabergs Fotbollförening
- **Örebro** (1): Örebro SK  (3) Örebro · Orebro · Örebro Sportklubb
- **Östersund** (1): Östersunds FK  (2) Östersund · Ostersunds




By Region

- **Stockholm†** (4):   AIK · IF Brommapojkarna · Djurgårdens IF · Hammarby IF
- **Göteborg†** (5):   IFK Göteborg · GAIS · BK Häcken · Qviding FIF · Örgryte Göteborg
- **Malmö†** (2):   Malmö FF · IFK Malmö
- **Borås†** (2):   IF Elfsborg · Norrby IF
- **Helsingborg†** (1):   Helsingborgs IF
- **Kalmar†** (1):   Kalmar FF
- **Örebro†** (1):   Örebro SK
- **Gävle†** (1):   Gefle IF
- **Eskilstuna†** (1):   AFC Eskilstuna
- **Mjällby†** (1):   Mjällby AIF
- **Åtvidaberg†** (1):   Åtvidabergs FF
- **Uppsala†** (2):   Dalkurd FF · IK Sirius
- **Falkenberg†** (1):   Falkenbergs FF
- **Halmstad†** (1):   Halmstads BK
- **Jönköping†** (1):   Jönköpings Södra IF
- **Ljungskile†** (1):   Ljungskile SK
- **Norrköping†** (1):   IFK Norrköping
- **Växjö†** (1):   Östers IF
- **Östersund†** (1):   Östersunds FK
- **Sundsvall†** (1):   GIF Sundsvall
- **Södertälje†** (1):   Syrianska FC
- **Trelleborg†** (1):   Trelleborgs FF
- **Trollhättan†** (1):   FC Trollhättan
- **Huskvarna†** (1):   Husqvarna FF
- **Nyköping†** (1):   Nyköping BIS
- **Västerås†** (1):   Västerås SK
- **Degerfors†** (1):   Degerfors IF
- **Varberg†** (1):   Varbergs BoIS
- **Borlänge†** (1):   IK Brage
- **Landskrona†** (1):   Landskrona BoIS




By Year

- **1915** (1):   Landskrona BoIS
- ? (39):   AIK · IF Brommapojkarna · Djurgårdens IF · Hammarby IF · IFK Göteborg · GAIS · BK Häcken · Qviding FIF · Örgryte Göteborg · Malmö FF · IFK Malmö · IF Elfsborg · Norrby IF · Helsingborgs IF · Kalmar FF · Örebro SK · Gefle IF · AFC Eskilstuna · Mjällby AIF · Åtvidabergs FF · Dalkurd FF · IK Sirius · Falkenbergs FF · Halmstads BK · Jönköpings Södra IF · Ljungskile SK · IFK Norrköping · Östers IF · Östersunds FK · GIF Sundsvall · Syrianska FC · Trelleborgs FF · FC Trollhättan · Husqvarna FF · Nyköping BIS · Västerås SK · Degerfors IF · Varbergs BoIS · IK Brage






By A to Z

- **A** (7): AIK · AIK Solna · AIK Fotboll · Atvidabergs · AIK Stockholm · AFC Eskilstuna · Allmänna Idrottsklubben
- **B** (4): Brage · BK Häcken · Brommapojkarna · Bollklubben Häcken
- **D** (6): Dalkurd · Dalkurd FF · Djurgarden · Djurgården · Degerfors IF · Djurgårdens IF
- **E** (2): Elfsborg · Eskilstuna
- **F** (3): Falkenbergs · FC Trollhättan · Falkenbergs FF
- **G** (8): GAIS · Gefle · Gefle IF · Goteborg · Göteborg · GAIS Göteborg · GIF Sundsvall · Göteborgs Atlet- och Idrottssällskap
- **H** (12): Hacken · Häcken · Halmstad · Hammarby · Hammarby IF · Helsingborg · Halmstads BK · Husqvarna FF · Helsingborg IF · Helsingborgs IF · Hammarby Fotboll · Halmstads Bollklubb
- **I** (13): IK Brage · IFK Malmö · IK Sirius · IF Elfsborg · IFK Goteborg · IFK Göteborg · IK Sirius FK · IFK Norrköping · IF Brommapojkarna · IFK Malmö Fotboll · IFK Norrköping FK · Idrottsföreningen Kamraterna Malmö · Idrottsföreningen Kamraterna Göteborg
- **J** (3): Jönköpings · Jönköpings Södra · Jönköpings Södra IF
- **K** (2): Kalmar · Kalmar FF
- **L** (4): Ljungskile · Ljungskile SK · Landskrona BoIS · Landskrona Boll och Idrottsällskap
- **M** (6): Malmö · Mjallby · Malmo FF · Malmö FF · Mjällby AIF · Malmö Fotbollförening
- **N** (4): Norrby IF · Norrkoping · Norrköping · Nyköping BIS
- **O** (3): Orebro · Osters · Ostersunds
- **Q** (1): Qviding FIF
- **S** (4): Sirius · Sundsvall · Syrianska · Syrianska FC
- **T** (2): Trelleborgs · Trelleborgs FF
- **V** (3): Västerås SK · Vasteraas SK · Varbergs BoIS
- **Å** (5): ÅFF · Åtvid · Åtvidaberg · Åtvidabergs FF · Åtvidabergs Fotbollförening
- **Ö** (8): Örebro · Örebro SK · Östers IF · Östersund · Örgryte IS · Östersunds FK · Örgryte Göteborg · Örebro Sportklubb




