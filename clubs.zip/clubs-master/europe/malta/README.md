18 clubs

- **Valletta FC** : (1) Valletta
- **Sliema Wanderers FC** : (2) Sliema · Sliema Wanderers
- **Birkirkara FC** : (1) Birkirkara
- **Floriana FC** : (1) Floriana
- **Hibernians FC** : (1) Hibernians
- **Marsaxlokk FC** : (1) Marsaxlokk
- **Balzan FC** : (1) Balzan
- **Gżira United FC** : (2) Gżira · Gżira United ⇒ (3) ≈Gzira≈ · ≈Gzira United≈ · ≈Gzira United FC≈
- **Gudja United**
- **Hamrun Spartans FC** : (2) Hamrun · Hamrun Spartans
- **FC Sirens** : (1) Sirens
- **Santa Lucia**
- **Senglea Athletic FC** : (1) Senglea
- **Mosta FC** : (1) Mosta
- **Tarxien Rainbows FC** : (1) Tarxien
- **Rabat Ajax** : (1) Rabat Ajax FC
- **Marsa FC**
- **Żurrieq FC** : (1) FC Zurrieq ⇒ (1) ≈Zurrieq FC≈




Alphabet

- **Alphabet Specials** (2):  **Ż**  **ż** 
  - **Ż**×1 U+017B (379) - LATIN CAPITAL LETTER Z WITH DOT ABOVE ⇒ Z
  - **ż**×3 U+017C (380) - LATIN SMALL LETTER Z WITH DOT ABOVE ⇒ z




Duplicates





By City

- **Marsa** (1): Marsa FC 
- **Marsaxlokk** (1): Marsaxlokk FC  (1) Marsaxlokk
- **Rabat** (1): Rabat Ajax  (1) Rabat Ajax FC
- **Sliema** (1): Sliema Wanderers FC  (2) Sliema · Sliema Wanderers
- **Valletta** (1): Valletta FC  (1) Valletta
- **Żurrieq** (1): Żurrieq FC  (1) FC Zurrieq
- ? (12): 
  - Birkirkara FC  (1) Birkirkara
  - Floriana FC  (1) Floriana
  - Hibernians FC  (1) Hibernians
  - Balzan FC  (1) Balzan
  - Gżira United FC  (2) Gżira · Gżira United
  - Gudja United 
  - Hamrun Spartans FC  (2) Hamrun · Hamrun Spartans
  - FC Sirens  (1) Sirens
  - Santa Lucia 
  - Senglea Athletic FC  (1) Senglea
  - Mosta FC  (1) Mosta
  - Tarxien Rainbows FC  (1) Tarxien




By Region

- **Valletta†** (1):   Valletta FC
- **Sliema†** (1):   Sliema Wanderers FC
- **Marsaxlokk†** (1):   Marsaxlokk FC
- **Rabat†** (1):   Rabat Ajax
- **Marsa†** (1):   Marsa FC
- **Żurrieq†** (1):   Żurrieq FC




By Year

- **1920** (1):   Marsa FC
- **1949** (2):   Marsaxlokk FC · Żurrieq FC
- ? (15):   Valletta FC · Sliema Wanderers FC · Birkirkara FC · Floriana FC · Hibernians FC · Balzan FC · Gżira United FC · Gudja United · Hamrun Spartans FC · FC Sirens · Santa Lucia · Senglea Athletic FC · Mosta FC · Tarxien Rainbows FC · Rabat Ajax






By A to Z

- **B** (4): Balzan · Balzan FC · Birkirkara · Birkirkara FC
- **F** (4): Floriana · FC Sirens · FC Zurrieq · Floriana FC
- **G** (4): Gżira · Gudja United · Gżira United · Gżira United FC
- **H** (5): Hamrun · Hibernians · Hibernians FC · Hamrun Spartans · Hamrun Spartans FC
- **M** (5): Mosta · Marsa FC · Mosta FC · Marsaxlokk · Marsaxlokk FC
- **R** (2): Rabat Ajax · Rabat Ajax FC
- **S** (7): Sirens · Sliema · Senglea · Santa Lucia · Sliema Wanderers · Senglea Athletic FC · Sliema Wanderers FC
- **T** (2): Tarxien · Tarxien Rainbows FC
- **V** (2): Valletta · Valletta FC
- **Ż** (1): Żurrieq FC




