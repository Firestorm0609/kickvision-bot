21 clubs

- **FK Sarajevo** : (1) Sarajevo
- **FK Slavija Sarajevo** : (1) Slavija
- **FK Olimpic Sarajevo** : (1) Olimpic Sarajevo
- **FK Željezničar** : (3) Željezničar · Željezničar Sarajevo · FK Željezničar Sarajevo ⇒ (4) ≈Zeljeznicar≈ · ≈FK Zeljeznicar≈ · ≈Zeljeznicar Sarajevo≈ · ≈FK Zeljeznicar Sarajevo≈
- **HŠK Zrinjski** : (4) Zrinjski · Zrinjs. Mostar · Zrinjski Mostar · HŠK Zrinjski Mostar ⇒ (2) ≈HSK Zrinjski≈ · ≈HSK Zrinjski Mostar≈
- **Velež Mostar** : (2) FK Velež Mostar · Fudbalski Klub Velež Mostar ⇒ (3) ≈Velez Mostar≈ · ≈FK Velez Mostar≈ · ≈Fudbalski Klub Velez Mostar≈
- **NK Široki Brijeg** : (1) Široki Brijeg ⇒ (2) ≈Siroki Brijeg≈ · ≈NK Siroki Brijeg≈
- **FK Borac Banja Luka** : (2) Borac · Borac Banja Luka
- **FK Modriča** ⇒ (1) ≈FK Modrica≈
- **FK Sloboda Tuzla** : (2) Sloboda · Sloboda Tuzla
- **FK Radnik Bijeljina** : (3) Radnik · Radnik Bijelji · Radnik Bijeljina
- **Sloga Simin Han**
- **NK Čelik Zenica** : (1) Čelik ⇒ (2) ≈Celik≈ · ≈NK Celik Zenica≈
- **FK Mladost Doboj Kakanj** : (1) Mladost Doboj Kakanj
- **FK Velež** : (1) Velež ⇒ (2) ≈Velez≈ · ≈FK Velez≈
- **Zvijezda 09**
- **NK Brotnjo** : (1) Nogometni Klub Brotnjo
- **FK Leotar** : (2) Leotar · Leotar Trebinje
- **FK Budućnost Banovići** ⇒ (1) ≈FK Buducnost Banovici≈
- **HNK Orašje** : (1) NK Orašje ⇒ (2) ≈NK Orasje≈ · ≈HNK Orasje≈
- **NK Žepče (1919-2010)** ⇒ (1) ≈NK Zepce≈




Alphabet

- **Alphabet Specials** (7):  **ć**  **Č**  **č**  **Š**  **š**  **Ž**  **ž** 
  - **ć**×2 U+0107 (263) - LATIN SMALL LETTER C WITH ACUTE ⇒ c
  - **Č**×2 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **č**×6 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **Š**×4 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **š**×2 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **Ž**×5 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z
  - **ž**×5 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Mostar** (2): 
  - HŠK Zrinjski  (4) Zrinjski · Zrinjs. Mostar · Zrinjski Mostar · HŠK Zrinjski Mostar
  - Velež Mostar  (2) FK Velež Mostar · Fudbalski Klub Velež Mostar
- **Banovići** (1): FK Budućnost Banovići 
- **Orašje** (1): HNK Orašje  (1) NK Orašje
- **Trebinje** (1): FK Leotar  (2) Leotar · Leotar Trebinje
- **Čitluk** (1): NK Brotnjo  (1) Nogometni Klub Brotnjo
- **Žepče** (1): NK Žepče (1919-2010) 
- ? (14): 
  - FK Sarajevo  (1) Sarajevo
  - FK Slavija Sarajevo  (1) Slavija
  - FK Olimpic Sarajevo  (1) Olimpic Sarajevo
  - FK Željezničar  (3) Željezničar · Željezničar Sarajevo · FK Željezničar Sarajevo
  - NK Široki Brijeg  (1) Široki Brijeg
  - FK Borac Banja Luka  (2) Borac · Borac Banja Luka
  - FK Modriča 
  - FK Sloboda Tuzla  (2) Sloboda · Sloboda Tuzla
  - FK Radnik Bijeljina  (3) Radnik · Radnik Bijelji · Radnik Bijeljina
  - Sloga Simin Han 
  - NK Čelik Zenica  (1) Čelik
  - FK Mladost Doboj Kakanj  (1) Mladost Doboj Kakanj
  - FK Velež  (1) Velež
  - Zvijezda 09 




By Region

- **Mostar†** (2):   HŠK Zrinjski · Velež Mostar
- **Čitluk†** (1):   NK Brotnjo
- **Trebinje†** (1):   FK Leotar
- **Banovići†** (1):   FK Budućnost Banovići
- **Orašje†** (1):   HNK Orašje
- **Žepče†** (1):   NK Žepče (1919-2010)




By Year

- **1919** (1):   NK Žepče (1919-2010)
- **1922** (1):   Velež Mostar
- **1925** (1):   FK Leotar
- **1947** (1):   FK Budućnost Banovići
- **1996** (1):   HNK Orašje
- ? (16):   FK Sarajevo · FK Slavija Sarajevo · FK Olimpic Sarajevo · FK Željezničar · HŠK Zrinjski · NK Široki Brijeg · FK Borac Banja Luka · FK Modriča · FK Sloboda Tuzla · FK Radnik Bijeljina · Sloga Simin Han · NK Čelik Zenica · FK Mladost Doboj Kakanj · FK Velež · Zvijezda 09 · NK Brotnjo




Historic

- **2010** (1):   NK Žepče (1919-2010)






By A to Z

- **B** (2): Borac · Borac Banja Luka
- **F** (15): FK Velež · FK Leotar · FK Modriča · FK Sarajevo · FK Željezničar · FK Velež Mostar · FK Sloboda Tuzla · FK Borac Banja Luka · FK Olimpic Sarajevo · FK Radnik Bijeljina · FK Slavija Sarajevo · FK Budućnost Banovići · FK Mladost Doboj Kakanj · FK Željezničar Sarajevo · Fudbalski Klub Velež Mostar
- **H** (3): HNK Orašje · HŠK Zrinjski · HŠK Zrinjski Mostar
- **L** (2): Leotar · Leotar Trebinje
- **M** (1): Mladost Doboj Kakanj
- **N** (6): NK Orašje · NK Brotnjo · NK Čelik Zenica · NK Široki Brijeg · NK Žepče (1919-2010) · Nogometni Klub Brotnjo
- **O** (1): Olimpic Sarajevo
- **R** (3): Radnik · Radnik Bijelji · Radnik Bijeljina
- **S** (5): Slavija · Sloboda · Sarajevo · Sloboda Tuzla · Sloga Simin Han
- **V** (2): Velež · Velež Mostar
- **Z** (4): Zrinjski · Zvijezda 09 · Zrinjs. Mostar · Zrinjski Mostar
- **Č** (1): Čelik
- **Š** (1): Široki Brijeg
- **Ž** (2): Željezničar · Željezničar Sarajevo




