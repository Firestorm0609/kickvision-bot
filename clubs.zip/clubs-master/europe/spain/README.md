110 clubs

- [**Atlético Madrid**](https://en.wikipedia.org/wiki/Atlético_Madrid) : (5) Atlético · Atl. Madrid · Ath Madrid [en] · Atlético de Madrid · Club Atlético de Madrid ⇒ (4) ≈Atletico≈ · ≈Atletico Madrid≈ · ≈Atletico de Madrid≈ · ≈Club Atletico de Madrid≈
- **Atlético Madrid B** : (1) Ath Madrid B [en] ⇒ (1) ≈Atletico Madrid B≈
- [**Real Madrid**](https://en.wikipedia.org/wiki/Real_Madrid_CF) : (3) R. Madrid · Real Madrid CF · Real Madrid Club de Fútbol ⇒ (1) ≈Real Madrid Club de Futbol≈
- **Real Madrid B** : (1) Real Madrid CF B
- [**Getafe CF**](https://en.wikipedia.org/wiki/Getafe_CF) : (3) Getafe · FC Getafe · Getafe Club de Fútbol ⇒ (1) ≈Getafe Club de Futbol≈
- [**Rayo Vallecano**](https://en.wikipedia.org/wiki/Rayo_Vallecano) : (3) Rayo · Vallecano · Rayo Vallecano de Madrid
- **AD Alcorcón** : (3) Alcorcón · Alcorcón AD · Agrupación Deportiva Alcorcón ⇒ (4) ≈Alcorcon≈ · ≈AD Alcorcon≈ · ≈Alcorcon AD≈ · ≈Agrupacion Deportiva Alcorcon≈
- **CF Fuenlabrada** : (2) Fuenlabrada · Club de Fútbol Fuenlabrada ⇒ (1) ≈Club de Futbol Fuenlabrada≈
- **CF Rayo Majadahonda** : (2) Rayo Majadahonda · Club de Fútbol Rayo Majadahonda ⇒ (1) ≈Club de Futbol Rayo Majadahonda≈
- **Málaga CF** : (3) Málaga · CF Málaga · FC Málaga ⇒ (4) ≈Malaga≈ · ≈CF Malaga≈ · ≈Malaga CF≈ · ≈FC Malaga≈
- **Málaga CF B** : (1) Málaga B ⇒ (2) ≈Malaga B≈ · ≈Malaga CF B≈
- [**Sevilla FC**](https://en.wikipedia.org/wiki/Sevilla_FC) : (3) Sevilla · FC Sevilla · Sevilla Fútbol Club ⇒ (1) ≈Sevilla Futbol Club≈
- **Sevilla FC B** : (1) Sevilla B
- [**Real Betis**](https://en.wikipedia.org/wiki/Real_Betis) : (4) Betis · Betis Sevilla · Real Betis Sevilla · Real Betis Balompié ⇒ (1) ≈Real Betis Balompie≈
- **Algeciras CF** : (1) Algeciras
- **UD Almería** : (2) Almería · Unión Deportiva Almería ⇒ (3) ≈Almeria≈ · ≈UD Almeria≈ · ≈Union Deportiva Almeria≈
- **Cádiz CF** : (2) Cádiz · FC Cádiz [de] ⇒ (3) ≈Cadiz≈ · ≈Cadiz CF≈ · ≈FC Cadiz≈
- **Córdoba CF** : (2) Córdoba · Córdoba Club de Fútbol ⇒ (3) ≈Cordoba≈ · ≈Cordoba CF≈ · ≈Cordoba Club de Futbol≈
- **Écija Balompié** : (1) Écija ⇒ (2) ≈Ecija≈ · ≈Ecija Balompie≈
- **Real Jaén CF** : (3) Jaén · Real Jaén · Real Jaén Club de Fútbol ⇒ (4) ≈Jaen≈ · ≈Real Jaen≈ · ≈Real Jaen CF≈ · ≈Real Jaen Club de Futbol≈
- **Granada CF** : (3) Granada · FC Granada · Granada Club de Fútbol ⇒ (1) ≈Granada Club de Futbol≈
- **Granada 74**
- [**FC Barcelona**](https://en.wikipedia.org/wiki/FC_Barcelona) : (2) Barcelona · Fútbol Club Barcelona ⇒ (1) ≈Futbol Club Barcelona≈
- **FC Barcelona B** : (2) Barcelona B · Fútbol Club Barcelona B ⇒ (1) ≈Futbol Club Barcelona B≈
- [**RCD Espanyol**](https://en.wikipedia.org/wiki/RCD_Espanyol) : (9) Español · Espanyol · Esp. Barcelona · Espanyol Barc. · Espan. Barcelona · Real CD Espanyol · Espanyol Barcelona · Real Club Deportivo Español · Real Club Deportivo Espanyol ⇒ (2) ≈Espanol≈ · ≈Real Club Deportivo Espanol≈
- **Gimnàstic Tarragona** : (1) Gimnàstic ⇒ (2) ≈Gimnastic≈ · ≈Gimnastic Tarragona≈
- [**Girona FC**](https://en.wikipedia.org/wiki/Girona_FC) : (3) Girona · FC Girona · Girona Futbol Club
- **CF Reus** : (3) Reus Deportiu · CF Reus Deportiu · Club de Futbol Reus Deportiu
- **RCD La Coruña** : (9) La Coruña · Deportivo · Dep. La Coruña · Deportivo da Coruña · Deportivo La Coruña · RC Deportivo La Coruña · Deportivo de La Coruña · RC Deportivo de La Coruña · Real Club Deportivo La Coruña ⇒ (9) ≈La Coruna≈ · ≈RCD La Coruna≈ · ≈Dep. La Coruna≈ · ≈Deportivo da Coruna≈ · ≈Deportivo La Coruna≈ · ≈RC Deportivo La Coruna≈ · ≈Deportivo de La Coruna≈ · ≈RC Deportivo de La Coruna≈ · ≈Real Club Deportivo La Coruna≈
- [**RC Celta Vigo**](https://en.wikipedia.org/wiki/RC_Celta_de_Vigo) : (7) Celta · Celta Vigo · R.C. Celta · Celta de Vigo · RC Celta de Vigo · Real Club Celta Vigo · Real Club Celta de Vigo
- **SD Compostela** : (1) Compostela
- **Racing Ferrol** : (1) Ferrol
- [**Valencia CF**](https://en.wikipedia.org/wiki/Valencia_CF) : (4) Valencia · FC Valencia · CF Valencia · Valencia Club de Fútbol ⇒ (1) ≈Valencia Club de Futbol≈
- [**Levante UD**](https://en.wikipedia.org/wiki/Levante_UD) : (3) Levante · UD Levante · Levante Unión Deportiva ⇒ (1) ≈Levante Union Deportiva≈
- **Alicante CF** : (1) Alicante
- **Hércules CF** : (2) Hércules · Hércules de Alicante Club de Fútbol ⇒ (3) ≈Hercules≈ · ≈Hercules CF≈ · ≈Hercules de Alicante Club de Futbol≈
- **CD Alcoyano** : (1) Alcoyano
- **Elche CF** : (2) Elche · FC Elche [de]
- **CD Castellón** : (1) Castellón ⇒ (2) ≈Castellon≈ · ≈CD Castellon≈
- [**Villarreal CF**](https://en.wikipedia.org/wiki/Villarreal_CF) : (3) Villareal · Villarreal · FC Villarreal
- **Villarreal CF B** : (1) Villarreal B
- [**Real Sociedad**](https://en.wikipedia.org/wiki/Real_Sociedad) : (5) Sociedad · R. Sociedad · R. S. San Sebastián · Real Sociedad de Fútbol · Real Sociedad San Sebastián ⇒ (3) ≈R. S. San Sebastian≈ · ≈Real Sociedad de Futbol≈ · ≈Real Sociedad San Sebastian≈
- [**Deportivo Alavés**](https://en.wikipedia.org/wiki/Deportivo_Alavés) : (2) Alavés · CD Alavés ⇒ (3) ≈Alaves≈ · ≈CD Alaves≈ · ≈Deportivo Alaves≈
- [**SD Eibar**](https://en.wikipedia.org/wiki/SD_Eibar) : (2) Eibar · Sociedad Deportiva Eibar
- [**Athletic Club Bilbao**](https://en.wikipedia.org/wiki/Athletic_Bilbao) : (4) Athletic · Ath Bilbao · Athletic Club · Athletic Bilbao
- **Athletic Club Bilbao B** : (1) Ath Bilbao B
- **Sporting Gijón** : (5) Sporting · Sp Gijón · Real Sporting · Sporting de Gijón · Real Sporting de Gijón ⇒ (4) ≈Sp Gijon≈ · ≈Sporting Gijon≈ · ≈Sporting de Gijon≈ · ≈Real Sporting de Gijon≈
- **Albacete Balompié** : (1) Albacete ⇒ (1) ≈Albacete Balompie≈
- **CD Guadalajara** : (1) Guadalajara
- **CD Badajoz** : (1) Badajoz
- **CF Extremadura (-2010)** : (1) Extremadura
- **Extremadura UD** : (2) UD Extremadura · Extremadura Unión Deportiva ⇒ (1) ≈Extremadura Union Deportiva≈
- **CP Mérida** : (1) Mérida ⇒ (2) ≈Merida≈ · ≈CP Merida≈
- **Burgos CF** : (1) Burgos
- **CD Mirandés** : (2) Mirandés · Club Deportivo Mirandés ⇒ (3) ≈Mirandes≈ · ≈CD Mirandes≈ · ≈Club Deportivo Mirandes≈
- **Real Murcia CF** : (2) Murcia · Real Murcia Club de Fútbol ⇒ (1) ≈Real Murcia Club de Futbol≈
- **UCAM Murcia**
- **CF Ciudad de Murcia** : (1) Ciudad de Murcia
- **FC Cartagena** : (1) Cartagena
- **Real Zaragoza** : (2) Zaragoza · Real Saragossa [de]
- [**SD Huesca**](https://en.wikipedia.org/wiki/SD_Huesca) : (1) Huesca
- **UD Las Palmas** : (3) Las Palmas · Las Palmas UD · Unión Deportiva Las Palmas ⇒ (1) ≈Union Deportiva Las Palmas≈
- **Universidad Las Palmas** : (1) U.Las Palmas
- **RCD Mallorca** : (4) Mallorca · Real Mallorca · Real CD Mallorca · Real Club Deportivo Mallorca
- **RCD Mallorca B** : (1) Mallorca B
- **CD Atlético Baleares** : (2) Atlético Baleares · Club Deportivo Atlético Baleares ⇒ (3) ≈Atletico Baleares≈ · ≈CD Atletico Baleares≈ · ≈Club Deportivo Atletico Baleares≈
- **CD Tenerife** : (4) Tenerife · Teneriffa CD [de] · CD Teneriffa [de] · Club Deportivo Tenerife
- **CA Osasuna** : (3) Osasuna · At. Osasuna · Club Atlético Osasuna ⇒ (1) ≈Club Atletico Osasuna≈
- [**CD Leganés**](https://en.wikipedia.org/wiki/CD_Leganés) : (2) Leganés · Club Deportivo Leganés ⇒ (3) ≈Leganes≈ · ≈CD Leganes≈ · ≈Club Deportivo Leganes≈
- **Cultural Leonesa** : (1) Leonesa
- **UE Lleida** : (2) Lleida · Lerida
- **UE Llagostera** : (1) Llagostera
- **CD Logroñés** : (1) Logroñés ⇒ (2) ≈Logrones≈ · ≈CD Logrones≈
- **UD Logroñés** : (1) Unión Deportiva Logroñés ⇒ (2) ≈UD Logrones≈ · ≈Union Deportiva Logrones≈
- **SD Logroñés** : (1) Sociedad Deportiva Logroñés ⇒ (2) ≈SD Logrones≈ · ≈Sociedad Deportiva Logrones≈
- **Lorca FC** : (1) Lorca
- **CD Lugo** : (2) Lugo · Club Deportivo Lugo
- **CD Numancia** : (3) Numancia · Numancia CD · Club Deportivo Numancia de Soria
- **CD Ourense** : (2) Orense · Ourense
- **Real Oviedo** : (1) Oviedo
- **Polideportivo Ejido** : (1) Poli Ejido
- **SD Ponferradina** : (3) Ponferradina · Ponferradina SD · Sociedad Deportiva Ponferradina
- **Pontevedra CF** : (1) Pontevedra
- **Real Unión** ⇒ (1) ≈Real Union≈
- **Recreativo Huelva** : (3) Recreativo · RC Recreativo de Huelva · Real Club Recreativo de Huelva
- **CE Sabadell** : (3) Sabadell · CE Sabadell FC · Centre d'Esports Sabadell Futbol Club
- **UD Salamanca** : (1) Salamanca
- **Real Racing Santander** : (4) Santander · Racing Santander · Real Racing Club · Real Racing Club de Santander
- **Terrassa FC** : (1) Terrassa
- **CD Toledo** : (1) Toledo
- [**Real Valladolid CF**](https://en.wikipedia.org/wiki/Real_Valladolid) : (4) Valladolid · Real Valladolid · R. Valladolid C.F. · Real Valladolid Club de Fútbol ⇒ (1) ≈Real Valladolid Club de Futbol≈
- **UD Vecindario** : (1) Vecindario
- **Xerez CD** : (2) Xerez · Deportivo Xerez
- **Real Madrid Castilla** : (2) Castilla · Real Madrid Castilla Club de Fútbol ⇒ (1) ≈Real Madrid Castilla Club de Futbol≈
- **Club Marino Luanco** : (1) Marino Luanco
- **CF Illueca** : (2) Illueca CF · Club de Fútbol Illueca ⇒ (1) ≈Club de Futbol Illueca≈
- **UD Socuéllamos** : (2) UD Socuéllamos CF · Unión Deportiva Socuéllamos ⇒ (3) ≈UD Socuellamos≈ · ≈UD Socuellamos CF≈ · ≈Union Deportiva Socuellamos≈
- **UM Escobedo** : (1) Unión Montañesa Escobedo ⇒ (1) ≈Union Montanesa Escobedo≈
- **Gimnástica Segoviana** : (3) Segoviana · Gimnástica Segoviana CF · Gimnástica Segoviana Club de Fútbol ⇒ (3) ≈Gimnastica Segoviana≈ · ≈Gimnastica Segoviana CF≈ · ≈Gimnastica Segoviana Club de Futbol≈
- **Zamora CF** : (1) Zamora Club de Fútbol ⇒ (1) ≈Zamora Club de Futbol≈
- **Comillas CF**
- **CD El Álamo** : (1) Club Deportivo El Álamo ⇒ (2) ≈CD El Alamo≈ · ≈Club Deportivo El Alamo≈
- **El Palmar CF** : (2) EG El Palmar CF · El Palmar Club de Fútbol-Estrella Grana ⇒ (1) ≈El Palmar Club de Futbol-Estrella Grana≈
- **Bergantiños FC** : (2) Bergantiños CF · Bergantiños Fútbol Club ⇒ (3) ≈Bergantinos FC≈ · ≈Bergantinos CF≈ · ≈Bergantinos Futbol Club≈
- **Tolosa CF** : (1) Tolosa Club de Fútbol ⇒ (1) ≈Tolosa Club de Futbol≈
- **CF Badalona** : (1) Club de Fútbol Badalona ⇒ (1) ≈Club de Futbol Badalona≈
- **CA Antoniano** : (2) Atlético Antoniano · Club Atlético Antoniano ⇒ (2) ≈Atletico Antoniano≈ · ≈Club Atletico Antoniano≈
- **CD Peña Azagresa** : (1) Club Deportivo Peña Azagresa ⇒ (2) ≈CD Pena Azagresa≈ · ≈Club Deportivo Pena Azagresa≈
- **CD Becerril** : (1) Club Deportivo Becerril
- **UD Melilla** : (2) Melilla UD · Union Deportiva Melilla




Alphabet

- **Alphabet Specials** (9):  **Á**  **É**  **à**  **á**  **é**  **í**  **ñ**  **ó**  **ú** 
  - **Á**×2 U+00C1 (193) - LATIN CAPITAL LETTER A WITH ACUTE ⇒ A
  - **É**×2 U+00C9 (201) - LATIN CAPITAL LETTER E WITH ACUTE ⇒ E
  - **à**×2 U+00E0 (224) - LATIN SMALL LETTER A WITH GRAVE ⇒ a
  - **á**×14 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×41 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×3 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ñ**×23 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×22 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×23 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Madrid, Comunidad de Madrid** (6): 
  - Atlético Madrid  (5) Atlético · Atl. Madrid · Atlético de Madrid · Club Atlético de Madrid · Ath Madrid [en]
  - Atlético Madrid B  (1) Ath Madrid B [en]
  - Real Madrid  (3) R. Madrid · Real Madrid CF · Real Madrid Club de Fútbol
  - Real Madrid B  (1) Real Madrid CF B
  - Getafe CF  (3) Getafe · FC Getafe · Getafe Club de Fútbol
  - Rayo Vallecano  (3) Rayo · Vallecano · Rayo Vallecano de Madrid
- **Barcelona, Cataluña** (3): 
  - FC Barcelona  (2) Barcelona · Fútbol Club Barcelona
  - FC Barcelona B  (2) Barcelona B · Fútbol Club Barcelona B
  - RCD Espanyol  (9) Espanyol · Esp. Barcelona · Espan. Barcelona · Espanyol Barc. · Espanyol Barcelona · Real CD Espanyol · Real Club Deportivo Espanyol · Español · Real Club Deportivo Español
- **Logroño** (3): 
  - CD Logroñés  (1) Logroñés
  - UD Logroñés  (1) Unión Deportiva Logroñés
  - SD Logroñés  (1) Sociedad Deportiva Logroñés
- **Murcia, Región de Murcia** (3): 
  - Real Murcia CF  (2) Murcia · Real Murcia Club de Fútbol
  - UCAM Murcia 
  - CF Ciudad de Murcia  (1) Ciudad de Murcia
- **Palma de Mallorca, Islas Baleares** (3): 
  - RCD Mallorca  (4) Mallorca · Real CD Mallorca · Real Club Deportivo Mallorca · Real Mallorca
  - RCD Mallorca B  (1) Mallorca B
  - CD Atlético Baleares  (2) Atlético Baleares · Club Deportivo Atlético Baleares
- **Sevilla, Andalucía** (3): 
  - Sevilla FC  (3) Sevilla · Sevilla Fútbol Club · FC Sevilla
  - Sevilla FC B  (1) Sevilla B
  - Real Betis  (4) Betis · Betis Sevilla · Real Betis Sevilla · Real Betis Balompié
- **Alicante, Comunidad Valenciana** (2): 
  - Alicante CF  (1) Alicante
  - Hércules CF  (2) Hércules · Hércules de Alicante Club de Fútbol
- **Almendralejo, Extremadura** (2): 
  - CF Extremadura (-2010)  (1) Extremadura
  - Extremadura UD  (2) Extremadura Unión Deportiva · UD Extremadura
- **Bilbao, País Vasco** (2): 
  - Athletic Club Bilbao  (4) Athletic · Athletic Club · Ath Bilbao · Athletic Bilbao
  - Athletic Club Bilbao B  (1) Ath Bilbao B
- **Granada, Andalucía** (2): 
  - Granada CF  (3) Granada · Granada Club de Fútbol · FC Granada
  - Granada 74 
- **Las Palmas, Islas Canarias** (2): 
  - UD Las Palmas  (3) Las Palmas · Unión Deportiva Las Palmas · Las Palmas UD
  - Universidad Las Palmas  (1) U.Las Palmas
- **Málaga, Andalucía** (2): 
  - Málaga CF  (3) Málaga · CF Málaga · FC Málaga
  - Málaga CF B  (1) Málaga B
- **Valencia, Comunidad Valenciana** (2): 
  - Valencia CF  (4) Valencia · Valencia Club de Fútbol · FC Valencia · CF Valencia
  - Levante UD  (3) Levante · UD Levante · Levante Unión Deportiva
- **Villarreal, Comunidad Valenciana** (2): 
  - Villarreal CF  (3) Villarreal · FC Villarreal · Villareal
  - Villarreal CF B  (1) Villarreal B
- **Albacete, Castilla-La Mancha** (1): Albacete Balompié  (1) Albacete
- **Alcorcón, Comunidad de Madrid** (1): AD Alcorcón  (3) Alcorcón · Agrupación Deportiva Alcorcón · Alcorcón AD
- **Alcoy, Comunidad Valenciana** (1): CD Alcoyano  (1) Alcoyano
- **Algeciras, Andalucía** (1): Algeciras CF  (1) Algeciras
- **Almería, Andalucía** (1): UD Almería  (2) Almería · Unión Deportiva Almería
- **Azagra** (1): CD Peña Azagresa  (1) Club Deportivo Peña Azagresa
- **Badajoz, Extremadura** (1): CD Badajoz  (1) Badajoz
- **Badalona** (1): CF Badalona  (1) Club de Fútbol Badalona
- **Becerril de Campos** (1): CD Becerril  (1) Club Deportivo Becerril
- **Burgos, Castilla y León** (1): Burgos CF  (1) Burgos
- **Carballo** (1): Bergantiños FC  (2) Bergantiños Fútbol Club · Bergantiños CF
- **Cartagena, Región de Murcia** (1): FC Cartagena  (1) Cartagena
- **Castellón de la Plana, Comunidad Valenciana** (1): CD Castellón  (1) Castellón
- **Comillas** (1): Comillas CF 
- **Cádiz, Andalucía** (1): Cádiz CF  (2) Cádiz · FC Cádiz [de]
- **Córdoba, Andalucía** (1): Córdoba CF  (2) Córdoba · Córdoba Club de Fútbol
- **Eibar, País Vasco** (1): SD Eibar  (2) Eibar · Sociedad Deportiva Eibar
- **El Palmar** (1): El Palmar CF  (2) El Palmar Club de Fútbol-Estrella Grana · EG El Palmar CF
- **El Álamo** (1): CD El Álamo  (1) Club Deportivo El Álamo
- **Elche, Comunidad Valenciana** (1): Elche CF  (2) Elche · FC Elche [de]
- **Escobedo** (1): UM Escobedo  (1) Unión Montañesa Escobedo
- **Ferrol, Galicia** (1): Racing Ferrol  (1) Ferrol
- **Fuenlabrada, Comunidad de Madrid** (1): CF Fuenlabrada  (2) Fuenlabrada · Club de Fútbol Fuenlabrada
- **Gerona, Cataluña** (1): Girona FC  (3) Girona · Girona Futbol Club · FC Girona
- **Gijón, Asturias** (1): Sporting Gijón  (5) Sporting · Sp Gijón · Real Sporting · Real Sporting de Gijón · Sporting de Gijón
- **Guadalajara, Castilla-La Mancha** (1): CD Guadalajara  (1) Guadalajara
- **Huesca, Aragón** (1): SD Huesca  (1) Huesca
- **Illueca** (1): CF Illueca  (2) Club de Fútbol Illueca · Illueca CF
- **Jaén, Andalucía** (1): Real Jaén CF  (3) Jaén · Real Jaén · Real Jaén Club de Fútbol
- **La Coruña, Galicia** (1): RCD La Coruña  (9) La Coruña · RC Deportivo La Coruña · RC Deportivo de La Coruña · Real Club Deportivo La Coruña · Deportivo · Deportivo La Coruña · Deportivo de La Coruña · Deportivo da Coruña · Dep. La Coruña
- **Lebrija** (1): CA Antoniano  (2) Atlético Antoniano · Club Atlético Antoniano
- **Luanco** (1): Club Marino Luanco  (1) Marino Luanco
- **Majadahonda, Comunidad de Madrid** (1): CF Rayo Majadahonda  (2) Rayo Majadahonda · Club de Fútbol Rayo Majadahonda
- **Melilla** (1): UD Melilla  (2) Union Deportiva Melilla · Melilla UD
- **Miranda de Ebro, Castilla y León** (1): CD Mirandés  (2) Mirandés · Club Deportivo Mirandés
- **Mérida, Extremadura** (1): CP Mérida  (1) Mérida
- **Reus, Cataluña** (1): CF Reus  (3) Reus Deportiu · CF Reus Deportiu · Club de Futbol Reus Deportiu
- **San Sebastián, País Vasco** (1): Real Sociedad  (5) Sociedad · R. Sociedad · R. S. San Sebastián · Real Sociedad San Sebastián · Real Sociedad de Fútbol
- **Santa Cruz de Tenerife, Canarias** (1): CD Tenerife  (4) Tenerife · Club Deportivo Tenerife · Teneriffa CD [de] · CD Teneriffa [de]
- **Santander** (1): Real Racing Santander  (4) Santander · Racing Santander · Real Racing Club de Santander · Real Racing Club
- **Santiago de Compostela, Galicia** (1): SD Compostela  (1) Compostela
- **Segoviana** (1): Gimnástica Segoviana  (3) Segoviana · Gimnástica Segoviana CF · Gimnástica Segoviana Club de Fútbol
- **Socuéllamos** (1): UD Socuéllamos  (2) UD Socuéllamos CF · Unión Deportiva Socuéllamos
- **Tarragona, Cataluña** (1): Gimnàstic Tarragona  (1) Gimnàstic
- **Tolosa** (1): Tolosa CF  (1) Tolosa Club de Fútbol
- **Vigo, Galicia** (1): RC Celta Vigo  (7) Celta · Celta Vigo · R.C. Celta · Real Club Celta Vigo · Real Club Celta de Vigo · Celta de Vigo · RC Celta de Vigo
- **Vitoria, País Vasco** (1): Deportivo Alavés  (2) Alavés · CD Alavés
- **Zamora** (1): Zamora CF  (1) Zamora Club de Fútbol
- **Zaragoza, Aragón** (1): Real Zaragoza  (2) Zaragoza · Real Saragossa [de]
- **Écija, Andalucía** (1): Écija Balompié  (1) Écija
- ? (23): 
  - CA Osasuna  (3) Osasuna · At. Osasuna · Club Atlético Osasuna
  - CD Leganés  (2) Leganés · Club Deportivo Leganés
  - Cultural Leonesa  (1) Leonesa
  - UE Lleida  (2) Lleida · Lerida
  - UE Llagostera  (1) Llagostera
  - Lorca FC  (1) Lorca
  - CD Lugo  (2) Lugo · Club Deportivo Lugo
  - CD Numancia  (3) Numancia · Club Deportivo Numancia de Soria · Numancia CD
  - CD Ourense  (2) Ourense · Orense
  - Real Oviedo  (1) Oviedo
  - Polideportivo Ejido  (1) Poli Ejido
  - SD Ponferradina  (3) Ponferradina · Sociedad Deportiva Ponferradina · Ponferradina SD
  - Pontevedra CF  (1) Pontevedra
  - Real Unión 
  - Recreativo Huelva  (3) Recreativo · RC Recreativo de Huelva · Real Club Recreativo de Huelva
  - CE Sabadell  (3) Sabadell · CE Sabadell FC · Centre d'Esports Sabadell Futbol Club
  - UD Salamanca  (1) Salamanca
  - Terrassa FC  (1) Terrassa
  - CD Toledo  (1) Toledo
  - Real Valladolid CF  (4) Valladolid · Real Valladolid · R. Valladolid C.F. · Real Valladolid Club de Fútbol
  - UD Vecindario  (1) Vecindario
  - Xerez CD  (2) Xerez · Deportivo Xerez
  - Real Madrid Castilla  (2) Castilla · Real Madrid Castilla Club de Fútbol




By Region

- **Comunidad de Madrid** (9):   Atlético Madrid · Atlético Madrid B · Real Madrid · Real Madrid B · Getafe CF · Rayo Vallecano · AD Alcorcón · CF Fuenlabrada · CF Rayo Majadahonda
- **Andalucía** (13):   Málaga CF · Málaga CF B · Sevilla FC · Sevilla FC B · Real Betis · Algeciras CF · UD Almería · Cádiz CF · Córdoba CF · Écija Balompié · Real Jaén CF · Granada CF · Granada 74
- **Cataluña** (6):   FC Barcelona · FC Barcelona B · RCD Espanyol · Gimnàstic Tarragona · Girona FC · CF Reus
- **Galicia** (4):   RCD La Coruña · RC Celta Vigo · SD Compostela · Racing Ferrol
- **Comunidad Valenciana** (9):   Valencia CF · Levante UD · Alicante CF · Hércules CF · CD Alcoyano · Elche CF · CD Castellón · Villarreal CF · Villarreal CF B
- **País Vasco** (5):   Real Sociedad · Deportivo Alavés · SD Eibar · Athletic Club Bilbao · Athletic Club Bilbao B
- **Asturias** (1):   Sporting Gijón
- **Castilla-La Mancha** (2):   Albacete Balompié · CD Guadalajara
- **Extremadura** (4):   CD Badajoz · CF Extremadura (-2010) · Extremadura UD · CP Mérida
- **Castilla y León** (2):   Burgos CF · CD Mirandés
- **Región de Murcia** (4):   Real Murcia CF · UCAM Murcia · CF Ciudad de Murcia · FC Cartagena
- **Aragón** (2):   Real Zaragoza · SD Huesca
- **Islas Canarias** (2):   UD Las Palmas · Universidad Las Palmas
- **Islas Baleares** (3):   RCD Mallorca · RCD Mallorca B · CD Atlético Baleares
- **Canarias** (1):   CD Tenerife
- **Logroño†** (3):   CD Logroñés · UD Logroñés · SD Logroñés
- **Santander†** (1):   Real Racing Santander
- **Luanco†** (1):   Club Marino Luanco
- **Illueca†** (1):   CF Illueca
- **Socuéllamos†** (1):   UD Socuéllamos
- **Escobedo†** (1):   UM Escobedo
- **Segoviana†** (1):   Gimnástica Segoviana
- **Zamora†** (1):   Zamora CF
- **Comillas†** (1):   Comillas CF
- **El Álamo†** (1):   CD El Álamo
- **El Palmar†** (1):   El Palmar CF
- **Carballo†** (1):   Bergantiños FC
- **Tolosa†** (1):   Tolosa CF
- **Badalona†** (1):   CF Badalona
- **Lebrija†** (1):   CA Antoniano
- **Azagra†** (1):   CD Peña Azagresa
- **Becerril de Campos†** (1):   CD Becerril
- **Melilla†** (1):   UD Melilla




By Year

- **1909** (1):   CF Reus
- **1913** (1):   Real Racing Santander
- **1976** (1):   CF Rayo Majadahonda
- ? (107):   Atlético Madrid · Atlético Madrid B · Real Madrid · Real Madrid B · Getafe CF · Rayo Vallecano · AD Alcorcón · CF Fuenlabrada · Málaga CF · Málaga CF B · Sevilla FC · Sevilla FC B · Real Betis · Algeciras CF · UD Almería · Cádiz CF · Córdoba CF · Écija Balompié · Real Jaén CF · Granada CF · Granada 74 · FC Barcelona · FC Barcelona B · RCD Espanyol · Gimnàstic Tarragona · Girona FC · RCD La Coruña · RC Celta Vigo · SD Compostela · Racing Ferrol · Valencia CF · Levante UD · Alicante CF · Hércules CF · CD Alcoyano · Elche CF · CD Castellón · Villarreal CF · Villarreal CF B · Real Sociedad · Deportivo Alavés · SD Eibar · Athletic Club Bilbao · Athletic Club Bilbao B · Sporting Gijón · Albacete Balompié · CD Guadalajara · CD Badajoz · CF Extremadura (-2010) · Extremadura UD · CP Mérida · Burgos CF · CD Mirandés · Real Murcia CF · UCAM Murcia · CF Ciudad de Murcia · FC Cartagena · Real Zaragoza · SD Huesca · UD Las Palmas · Universidad Las Palmas · RCD Mallorca · RCD Mallorca B · CD Atlético Baleares · CD Tenerife · CA Osasuna · CD Leganés · Cultural Leonesa · UE Lleida · UE Llagostera · CD Logroñés · UD Logroñés · SD Logroñés · Lorca FC · CD Lugo · CD Numancia · CD Ourense · Real Oviedo · Polideportivo Ejido · SD Ponferradina · Pontevedra CF · Real Unión · Recreativo Huelva · CE Sabadell · UD Salamanca · Terrassa FC · CD Toledo · Real Valladolid CF · UD Vecindario · Xerez CD · Real Madrid Castilla · Club Marino Luanco · CF Illueca · UD Socuéllamos · UM Escobedo · Gimnástica Segoviana · Zamora CF · Comillas CF · CD El Álamo · El Palmar CF · Bergantiños FC · Tolosa CF · CF Badalona · CA Antoniano · CD Peña Azagresa · CD Becerril · UD Melilla




Historic

- **2010** (1):   CF Extremadura (-2010)






By A to Z

- **A** (30): Alavés · Almería · Albacete · Alcorcón · Alcoyano · Alicante · Athletic · Atlético · Algeciras · Ath Bilbao · AD Alcorcón · Alcorcón AD · Alicante CF · At. Osasuna · Atl. Madrid · Algeciras CF · Ath Bilbao B · Athletic Club · Ath Madrid [en] · Athletic Bilbao · Atlético Madrid · Albacete Balompié · Ath Madrid B [en] · Atlético Baleares · Atlético Madrid B · Atlético Antoniano · Atlético de Madrid · Athletic Club Bilbao · Athletic Club Bilbao B · Agrupación Deportiva Alcorcón
- **B** (10): Betis · Burgos · Badajoz · Barcelona · Burgos CF · Barcelona B · Betis Sevilla · Bergantiños CF · Bergantiños FC · Bergantiños Fútbol Club
- **C** (67): Celta · Cádiz · CD Lugo · CF Reus · Córdoba · Castilla · Cádiz CF · CD Alavés · CD Toledo · CF Málaga · CP Mérida · Cartagena · Castellón · CA Osasuna · CD Badajoz · CD Leganés · CD Ourense · CF Illueca · Celta Vigo · Compostela · Córdoba CF · CD Alcoyano · CD Becerril · CD El Álamo · CD Logroñés · CD Mirandés · CD Numancia · CD Tenerife · CE Sabadell · CF Badalona · CF Valencia · Comillas CF · CA Antoniano · CD Castellón · Celta de Vigo · CD Guadalajara · CE Sabadell FC · CF Fuenlabrada · CD Peña Azagresa · CF Reus Deportiu · Ciudad de Murcia · Cultural Leonesa · CD Teneriffa [de] · Club Marino Luanco · CF Ciudad de Murcia · CF Rayo Majadahonda · Club Deportivo Lugo · CD Atlético Baleares · Club Atlético Osasuna · CF Extremadura (-2010) · Club Deportivo Leganés · Club de Fútbol Illueca · Córdoba Club de Fútbol · Club Atlético Antoniano · Club Atlético de Madrid · Club Deportivo Becerril · Club Deportivo El Álamo · Club Deportivo Mirandés · Club Deportivo Tenerife · Club de Fútbol Badalona · Club de Fútbol Fuenlabrada · Club Deportivo Peña Azagresa · Club de Futbol Reus Deportiu · Club de Fútbol Rayo Majadahonda · Club Deportivo Atlético Baleares · Club Deportivo Numancia de Soria · Centre d'Esports Sabadell Futbol Club
- **D** (7): Deportivo · Dep. La Coruña · Deportivo Xerez · Deportivo Alavés · Deportivo La Coruña · Deportivo da Coruña · Deportivo de La Coruña
- **E** (15): Eibar · Elche · Español · Elche CF · Espanyol · Extremadura · El Palmar CF · Esp. Barcelona · Espanyol Barc. · Extremadura UD · EG El Palmar CF · Espan. Barcelona · Espanyol Barcelona · Extremadura Unión Deportiva · El Palmar Club de Fútbol-Estrella Grana
- **F** (16): Ferrol · FC Getafe · FC Girona · FC Málaga · FC Granada · FC Sevilla · FC Valencia · Fuenlabrada · FC Barcelona · FC Cartagena · FC Cádiz [de] · FC Elche [de] · FC Villarreal · FC Barcelona B · Fútbol Club Barcelona · Fútbol Club Barcelona B
- **G** (16): Getafe · Girona · Granada · Getafe CF · Gimnàstic · Girona FC · Granada 74 · Granada CF · Guadalajara · Girona Futbol Club · Gimnàstic Tarragona · Gimnástica Segoviana · Getafe Club de Fútbol · Granada Club de Fútbol · Gimnástica Segoviana CF · Gimnástica Segoviana Club de Fútbol
- **H** (4): Huesca · Hércules · Hércules CF · Hércules de Alicante Club de Fútbol
- **I** (1): Illueca CF
- **J** (1): Jaén
- **L** (15): Lugo · Lorca · Lerida · Lleida · Leganés · Leonesa · Levante · Logroñés · Lorca FC · La Coruña · Las Palmas · Levante UD · Llagostera · Las Palmas UD · Levante Unión Deportiva
- **M** (11): Murcia · Málaga · Mérida · Mallorca · Mirandés · Málaga B · Málaga CF · Mallorca B · Melilla UD · Málaga CF B · Marino Luanco
- **N** (2): Numancia · Numancia CD
- **O** (4): Orense · Oviedo · Osasuna · Ourense
- **P** (6): Poli Ejido · Pontevedra · Ponferradina · Pontevedra CF · Ponferradina SD · Polideportivo Ejido
- **R** (63): Rayo · R. Madrid · Real Jaén · R.C. Celta · Real Betis · Real Unión · Recreativo · R. Sociedad · Real Madrid · Real Oviedo · RCD Espanyol · RCD Mallorca · Real Jaén CF · RC Celta Vigo · RCD La Coruña · Racing Ferrol · Real Madrid B · Real Mallorca · Real Sociedad · Real Sporting · Real Zaragoza · Reus Deportiu · RCD Mallorca B · Rayo Vallecano · Real Madrid CF · Real Murcia CF · Real Valladolid · RC Celta de Vigo · Racing Santander · Rayo Majadahonda · Real CD Espanyol · Real CD Mallorca · Real Madrid CF B · Real Racing Club · Recreativo Huelva · R. Valladolid C.F. · Real Betis Sevilla · Real Valladolid CF · R. S. San Sebastián · Real Betis Balompié · Real Saragossa [de] · Real Club Celta Vigo · Real Madrid Castilla · Real Racing Santander · RC Deportivo La Coruña · Real Sporting de Gijón · RC Recreativo de Huelva · Real Club Celta de Vigo · Real Sociedad de Fútbol · Rayo Vallecano de Madrid · Real Jaén Club de Fútbol · RC Deportivo de La Coruña · Real Madrid Club de Fútbol · Real Murcia Club de Fútbol · Real Club Deportivo Español · Real Sociedad San Sebastián · Real Club Deportivo Espanyol · Real Club Deportivo Mallorca · Real Club Deportivo La Coruña · Real Racing Club de Santander · Real Club Recreativo de Huelva · Real Valladolid Club de Fútbol · Real Madrid Castilla Club de Fútbol
- **S** (22): Sevilla · SD Eibar · Sabadell · Sociedad · Sp Gijón · Sporting · SD Huesca · Salamanca · Santander · Segoviana · Sevilla B · Sevilla FC · SD Logroñés · Sevilla FC B · SD Compostela · Sporting Gijón · SD Ponferradina · Sporting de Gijón · Sevilla Fútbol Club · Sociedad Deportiva Eibar · Sociedad Deportiva Logroñés · Sociedad Deportiva Ponferradina
- **T** (7): Toledo · Tenerife · Terrassa · Tolosa CF · Terrassa FC · Teneriffa CD [de] · Tolosa Club de Fútbol
- **U** (22): UE Lleida · UD Almería · UD Levante · UD Melilla · UCAM Murcia · UD Logroñés · UM Escobedo · U.Las Palmas · UD Salamanca · UD Las Palmas · UD Vecindario · UE Llagostera · UD Extremadura · UD Socuéllamos · UD Socuéllamos CF · Universidad Las Palmas · Union Deportiva Melilla · Unión Deportiva Almería · Unión Deportiva Logroñés · Unión Montañesa Escobedo · Unión Deportiva Las Palmas · Unión Deportiva Socuéllamos
- **V** (11): Valencia · Vallecano · Villareal · Valladolid · Vecindario · Villarreal · Valencia CF · Villarreal B · Villarreal CF · Villarreal CF B · Valencia Club de Fútbol
- **X** (2): Xerez · Xerez CD
- **Z** (3): Zaragoza · Zamora CF · Zamora Club de Fútbol
- **É** (2): Écija · Écija Balompié




