20 clubs

- **Bakı FK** : (2) Baku · FK Baku ⇒ (1) ≈Baki FK≈
- **İnter Bakı PİK** : (2) Inter Baku · Inter Baku PIK ⇒ (1) ≈Inter Baki PIK≈
- **FK Shafa Baku (1997-2005)** : (3) FK Şäfa · Safa Baku · Shafa Baku ⇒ (2) ≈FK Safa≈ · ≈FK Şaefa≈
- **Neftçi PFK** : (3) Neftçi · Neftchi Baku · Neftchi PFC Baku ⇒ (2) ≈Neftci≈ · ≈Neftci PFK≈
- **Zirä FK** : (2) Zira FK · PFC Zire ⇒ (2) ≈Zira FK≈ · ≈Zirae FK≈
- **FK Şämkir (1954-2017)** : (3) Shamkir · Shamkir FC · Shamkir FK ⇒ (2) ≈FK Samkir≈ · ≈FK Şaemkir≈
- **Qarabağ FK** : (3) Qarabağ · Qarabağ Ağdam · Garabag Agdam ⇒ (3) ≈Qarabag≈ · ≈Qarabag FK≈ · ≈Qarabag Agdam≈
- **Xäzär Länkäran FK** : (1) Khazar Lankaran ⇒ (2) ≈Xazar Lankaran FK≈ · ≈Xaezaer Laenkaeran FK≈
- **Olimpik-Şüvälan PFK** ⇒ (2) ≈Olimpik-Suvalan PFK≈ · ≈Olimpik-Şuevaelan PFK≈
- **Simurq PFK (2005-2015)** : (3) Simurq PFC · Simurq PIK · Simurq Zaqatala PFK
- **Gabala SC** : (3) Gabala · Qäbälä · Gabala FK ⇒ (2) ≈Qabala≈ · ≈Qaebaelae≈
- **Keşla FK** : (2) Keşla · Keşlə FK ⇒ (3) ≈Kesla≈ · ≈Kesla FK≈ · ≈Keslə FK≈
- **Käpäz PFK** : (4) Käpäz · FK Käpäz · Kapaz Ganja · Kapaz Professional Football Club ⇒ (6) ≈Kapaz≈ · ≈Kaepaez≈ · ≈FK Kapaz≈ · ≈Kapaz PFK≈ · ≈FK Kaepaez≈ · ≈Kaepaez PFK≈
- **Sabail** : (1) Səbail FK
- **Sumqayıt FK** : (1) Sumqayıt ⇒ (2) ≈Sumqayit≈ · ≈Sumqayit FK≈
- **Sabah**
- **PFK Turan Tovuz** : (5) Turan İK · Turan PFK · Turan-T İK · Turan-Tovuz İK · Turan İdman Klubu ⇒ (4) ≈Turan IK≈ · ≈Turan-T IK≈ · ≈Turan-Tovuz IK≈ · ≈Turan Idman Klubu≈
- **FK MKT Araz** : (2) MKT Araz · FK MKT Araz İmişli ⇒ (1) ≈FK MKT Araz Imisli≈
- **Karvan FK (2004-2014)** : (1) FK Karvan Evlakh
- **Khazri Buzovna (1994-1998)** : (1) FK Khazri Buzovna




Alphabet

- **Alphabet Specials** (9):  **ä**  **ç**  **ü**  **ğ**  **İ**  **ı**  **Ş**  **ş**  **ə** 
  - **ä**×17 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **ç**×2 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **ü**×1 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue
  - **ğ**×4 U+011F (287) - LATIN SMALL LETTER G WITH BREVE ⇒ g
  - **İ**×7 U+0130 (304) - LATIN CAPITAL LETTER I WITH DOT ABOVE ⇒ I
  - **ı**×4 U+0131 (305) - LATIN SMALL LETTER DOTLESS I ⇒ i
  - **Ş**×3 U+015E (350) - LATIN CAPITAL LETTER S WITH CEDILLA ⇒ S
  - **ş**×4 U+015F (351) - LATIN SMALL LETTER S WITH CEDILLA ⇒ s
  - **ə**×2 U+0259 (601) - LATIN SMALL LETTER SCHWA ⇒ **?**




Duplicates

- **Zirä FK**, Baku (1):
  - `zirafk` (2): **Zira FK** · **Zira FK**
- **PFK Turan Tovuz**, Tovuz (4):
  - `turantik` (2): Turan-T İK · Turan-T IK
  - `turantovuzik` (2): Turan-Tovuz İK · Turan-Tovuz IK
  - `turanik` (2): Turan İK · Turan IK
  - `turanidmanklubu` (2): Turan İdman Klubu · Turan Idman Klubu




By City

- **Baku** (5): 
  - Bakı FK  (2) Baku · FK Baku
  - İnter Bakı PİK  (2) Inter Baku PIK · Inter Baku
  - FK Shafa Baku (1997-2005)  (3) Shafa Baku · Safa Baku · FK Şäfa
  - Neftçi PFK  (3) Neftçi · Neftchi PFC Baku · Neftchi Baku
  - Zirä FK  (2) Zira FK · PFC Zire
- **Buzovna** (1): Khazri Buzovna (1994-1998)  (1) FK Khazri Buzovna
- **Ganja** (1): Käpäz PFK  (4) Käpäz · FK Käpäz · Kapaz Ganja · Kapaz Professional Football Club
- **Tovuz** (1): PFK Turan Tovuz  (5) Turan PFK · Turan-T İK · Turan-Tovuz İK · Turan İK · Turan İdman Klubu
- **Yevlakh** (1): Karvan FK (2004-2014)  (1) FK Karvan Evlakh
- **Zaqatala** (1): Simurq PFK (2005-2015)  (3) Simurq PFC · Simurq PIK · Simurq Zaqatala PFK
- **İmişli** (1): FK MKT Araz  (2) MKT Araz · FK MKT Araz İmişli
- **Şəmkir** (1): FK Şämkir (1954-2017)  (3) Shamkir · Shamkir FC · Shamkir FK
- ? (8): 
  - Qarabağ FK  (3) Qarabağ · Qarabağ Ağdam · Garabag Agdam
  - Xäzär Länkäran FK  (1) Khazar Lankaran
  - Olimpik-Şüvälan PFK 
  - Gabala SC  (3) Gabala · Gabala FK · Qäbälä
  - Keşla FK  (2) Keşla · Keşlə FK
  - Sabail  (1) Səbail FK
  - Sumqayıt FK  (1) Sumqayıt
  - Sabah 




By Region

- **Baku†** (5):   Bakı FK · İnter Bakı PİK · FK Shafa Baku (1997-2005) · Neftçi PFK · Zirä FK
- **Şəmkir†** (1):   FK Şämkir (1954-2017)
- **Zaqatala†** (1):   Simurq PFK (2005-2015)
- **Ganja†** (1):   Käpäz PFK
- **Tovuz†** (1):   PFK Turan Tovuz
- **İmişli†** (1):   FK MKT Araz
- **Yevlakh†** (1):   Karvan FK (2004-2014)
- **Buzovna†** (1):   Khazri Buzovna (1994-1998)




By Year

- **1954** (2):   FK Şämkir (1954-2017) · PFK Turan Tovuz
- **1959** (1):   Käpäz PFK
- **1994** (1):   Khazri Buzovna (1994-1998)
- **1997** (1):   FK Shafa Baku (1997-2005)
- **2004** (2):   FK MKT Araz · Karvan FK (2004-2014)
- **2005** (1):   Simurq PFK (2005-2015)
- ? (12):   Bakı FK · İnter Bakı PİK · Neftçi PFK · Zirä FK · Qarabağ FK · Xäzär Länkäran FK · Olimpik-Şüvälan PFK · Gabala SC · Keşla FK · Sabail · Sumqayıt FK · Sabah




Historic

- **1998** (1):   Khazri Buzovna (1994-1998)
- **2005** (1):   FK Shafa Baku (1997-2005)
- **2014** (1):   Karvan FK (2004-2014)
- **2015** (1):   Simurq PFK (2005-2015)
- **2017** (1):   FK Şämkir (1954-2017)






By A to Z

- **B** (2): Baku · Bakı FK
- **F** (9): FK Baku · FK Şäfa · FK Käpäz · FK MKT Araz · FK Karvan Evlakh · FK Khazri Buzovna · FK MKT Araz İmişli · FK Şämkir (1954-2017) · FK Shafa Baku (1997-2005)
- **G** (4): Gabala · Gabala FK · Gabala SC · Garabag Agdam
- **I** (2): Inter Baku · Inter Baku PIK
- **K** (10): Keşla · Käpäz · Keşla FK · Keşlə FK · Käpäz PFK · Kapaz Ganja · Khazar Lankaran · Karvan FK (2004-2014) · Khazri Buzovna (1994-1998) · Kapaz Professional Football Club
- **M** (1): MKT Araz
- **N** (4): Neftçi · Neftçi PFK · Neftchi Baku · Neftchi PFC Baku
- **O** (1): Olimpik-Şüvälan PFK
- **P** (2): PFC Zire · PFK Turan Tovuz
- **Q** (4): Qäbälä · Qarabağ · Qarabağ FK · Qarabağ Ağdam
- **S** (14): Sabah · Sabail · Shamkir · Sumqayıt · Safa Baku · Səbail FK · Shafa Baku · Shamkir FC · Shamkir FK · Simurq PFC · Simurq PIK · Sumqayıt FK · Simurq Zaqatala PFK · Simurq PFK (2005-2015)
- **T** (5): Turan İK · Turan PFK · Turan-T İK · Turan-Tovuz İK · Turan İdman Klubu
- **X** (1): Xäzär Länkäran FK
- **Z** (2): Zira FK · Zirä FK
- **İ** (1): İnter Bakı PİK




