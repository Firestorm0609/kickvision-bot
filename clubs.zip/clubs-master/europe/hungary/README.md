29 clubs

- **Ferencvárosi TC** : (2) Ferencváros · Ferencvaros ⇒ (2) ≈Ferencvaros≈ · ≈Ferencvarosi TC≈
- **Budapest Honvéd FC** : (5) Honvéd · Budapest Honvéd · Honvéd Budapest · Kispesti Honvéd · Budapest Honvéd SE ⇒ (6) ≈Honved≈ · ≈Kispesti Honved≈ · ≈Honved Budapest≈ · ≈Budapest Honved≈ · ≈Budapest Honved SE≈ · ≈Budapest Honved FC≈
- **Vasas FC** : (3) Vasas · Vasas Budapest · Budapesti Vasas
- **MTK Budapest** : (3) MTK · Budapesti Vörös Lobogó · Magyar Testgyakorlók Köre Budapest Futball Club ⇒ (4) ≈Budapesti Voros Lobogo≈ · ≈Budapesti Voeroes Lobogó≈ · ≈Magyar Testgyakorlok Kore Budapest Futball Club≈ · ≈Magyar Testgyakorlók Koere Budapest Futball Club≈
- **Újpest FC** : (6) Újpest · Újpest TE · Ú. Dózsa SC · Újpest Dózsa · Újpesti Dózsa SC · Újpesti Dózsa Sport Club ⇒ (7) ≈Ujpest≈ · ≈Ujpest FC≈ · ≈Ujpest TE≈ · ≈U. Dozsa SC≈ · ≈Ujpest Dozsa≈ · ≈Ujpesti Dozsa SC≈ · ≈Ujpesti Dozsa Sport Club≈
- **Csepel SC** : (1) Csepel FC
- **Budapesti VSC** : (1) Budapesti Vasutas Sport Club
- **Vác FC** : (3) Váci FC · Dunakanyar-Vác · Dunakanyar-Vác FC ⇒ (4) ≈Vac FC≈ · ≈Vaci FC≈ · ≈Dunakanyar-Vac≈ · ≈Dunakanyar-Vac FC≈
- **Dunaújváros FC (1952-2009)** : (2) Dunaújváros · Dunaferr SE ⇒ (2) ≈Dunaujvaros≈ · ≈Dunaujvaros FC≈
- **Videoton FC** : (6) Videoton · Fehérvár · MOL Vidi · Fehérvár FC · MOL Fehérvár FC · Videoton Fehérvár ⇒ (4) ≈Fehervar≈ · ≈Fehervar FC≈ · ≈MOL Fehervar FC≈ · ≈Videoton Fehervar≈
- **Debreceni VSC** : (2) Debrecen · DVSC Debrecen
- **Győri ETO FC** : (9) Győr · ETO Győr · ETO Györ · Gyori ETO · Győri ETO · ETO FC Győr · Rába ETO Győr · Raba ETO Gyor · Egyetértés Torna Osztály Futball Club Győr ⇒ (9) ≈Gyor≈ · ≈ETO Gyor≈ · ≈ETO Gyor≈ · ≈Gyori ETO≈ · ≈ETO Gyoer≈ · ≈ETO FC Gyor≈ · ≈Gyori ETO FC≈ · ≈Raba ETO Gyor≈ · ≈Egyetertes Torna Osztaly Futball Club Gyor≈
- **Paksi SE** : (2) Paks · Paksi FC
- **Kecskeméti TE** : (1) Kecskemét ⇒ (2) ≈Kecskemet≈ · ≈Kecskemeti TE≈
- **Szombathelyi Haladás** : (1) Haladás ⇒ (2) ≈Haladas≈ · ≈Szombathelyi Haladas≈
- **Zalaegerszegi TE** : (1) Zalaegerszeg
- **Diósgyőri VTK** : (5) Diósgyőr · Diósgyör · Diósgyöri VTK · Diósgyöri Miskolc · Diósgyőr-Vasgyári Testgyakorlók Köre ⇒ (10) ≈Diosgyor≈ · ≈Diosgyor≈ · ≈Diósgyoer≈ · ≈Diosgyori VTK≈ · ≈Diosgyori VTK≈ · ≈Diósgyoeri VTK≈ · ≈Diosgyori Miskolc≈ · ≈Diósgyoeri Miskolc≈ · ≈Diosgyor-Vasgyari Testgyakorlok Kore≈ · ≈Diósgyőr-Vasgyári Testgyakorlók Koere≈
- **Mezőkövesd Zsóry SE** : (2) Mezőkövesd · Mezőkövesd-Zsóry ⇒ (6) ≈Mezokovesd≈ · ≈Mezőkoevesd≈ · ≈Mezokovesd-Zsory≈ · ≈Mezőkoevesd-Zsóry≈ · ≈Mezokovesd Zsory SE≈ · ≈Mezőkoevesd Zsóry SE≈
- **Varda SE** : (1) Varda
- **Puskás Akadémia FC** : (1) Puskás FC ⇒ (2) ≈Puskas FC≈ · ≈Puskas Akademia FC≈
- **Kaposvári Rákóczi FC** : (2) Rákóczi · Kaposvári Rákóczi ⇒ (3) ≈Rakoczi≈ · ≈Kaposvari Rakoczi≈ · ≈Kaposvari Rakoczi FC≈
- **Salgótarjáni BTC** : (2) Salgótarján BTC · Salgótarjáni Barátok Torna Club ⇒ (3) ≈Salgotarjan BTC≈ · ≈Salgotarjani BTC≈ · ≈Salgotarjani Baratok Torna Club≈
- **Pécsi MFC** : (6) PMFC · MSC Pécs · Pécsi Dózsa · Pécsi Mecsek FC · Pécsi Dózsa Sport Club · Pécsi Mecsek Football Club ⇒ (6) ≈MSC Pecs≈ · ≈Pecsi MFC≈ · ≈Pecsi Dozsa≈ · ≈Pecsi Mecsek FC≈ · ≈Pecsi Dozsa Sport Club≈ · ≈Pecsi Mecsek Football Club≈
- **FC Sopron (1921-2008)**
- **Békéscsaba 1912 Előre** : (7) Békéscsaba · Békéscsabai EFC · Békéscsaba Előre · Békéscsabai Előre · Bekescsabai Elore · Békéscsabai Előre FC · Békéscsaba 1912 Előre SE ⇒ (7) ≈Bekescsaba≈ · ≈Bekescsabai EFC≈ · ≈Bekescsaba Elore≈ · ≈Bekescsabai Elore≈ · ≈Bekescsabai Elore FC≈ · ≈Bekescsaba 1912 Elore≈ · ≈Bekescsaba 1912 Elore SE≈
- **Pápai FC (1995-2015)** : (2) Pápa · Lombard Pápa TFC ⇒ (3) ≈Papa≈ · ≈Papai FC≈ · ≈Lombard Papa TFC≈
- **FC Tatabánya** : (2) Tatabánya · Tatabánya FC ⇒ (3) ≈Tatabanya≈ · ≈FC Tatabanya≈ · ≈Tatabanya FC≈
- **BFC Siófok** : (3) Siófok · Siófoki Bányász · Bodajk FC Siófok ⇒ (4) ≈Siofok≈ · ≈BFC Siofok≈ · ≈Siofoki Banyasz≈ · ≈Bodajk FC Siofok≈
- **Komlói Bányász SK** : (2) Komlói Bányász · Komlói Bányász Sport Klub ⇒ (3) ≈Komloi Banyasz≈ · ≈Komloi Banyasz SK≈ · ≈Komloi Banyasz Sport Klub≈




Alphabet

- **Alphabet Specials** (7):  **Ú**  **á**  **é**  **ó**  **ö**  **ú**  **ő** 
  - **Ú**×7 U+00DA (218) - LATIN CAPITAL LETTER U WITH ACUTE ⇒ U
  - **á**×42 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×35 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ó**×30 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ö**×11 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ú**×2 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u
  - **ő**×18 U+0151 (337) - LATIN SMALL LETTER O WITH DOUBLE ACUTE ⇒ o




Duplicates

- **Ferencvárosi TC**, Budapest (1):
  - `ferencvaros` (2): **Ferencvaros** · **Ferencvaros**
- **Győri ETO FC**, Győr (3):
  - `gyorieto` (2): **Gyori ETO** · **Gyori ETO**
  - `rabaetogyor` (2): **Raba ETO Gyor** · **Raba ETO Gyor**
  - `etogyor` (2): **ETO Gyor** · **ETO Gyor**
- **Diósgyőri VTK**, Miskolc (2):
  - `diosgyorivtk` (2): **Diosgyori VTK** · **Diosgyori VTK**
  - `diosgyor` (2): **Diosgyor** · **Diosgyor**
- **Békéscsaba 1912 Előre**, Békéscsaba (1):
  - `bekescsabaielore` (2): **Bekescsabai Elore** · **Bekescsabai Elore**




By City

- **Budapest** (7): 
  - Ferencvárosi TC  (2) Ferencváros · Ferencvaros
  - Budapest Honvéd FC  (5) Honvéd · Honvéd Budapest · Budapest Honvéd · Budapest Honvéd SE · Kispesti Honvéd
  - Vasas FC  (3) Vasas · Vasas Budapest · Budapesti Vasas
  - MTK Budapest  (3) MTK · Magyar Testgyakorlók Köre Budapest Futball Club · Budapesti Vörös Lobogó
  - Újpest FC  (6) Újpest · Újpest Dózsa · Ú. Dózsa SC · Újpesti Dózsa SC · Újpesti Dózsa Sport Club · Újpest TE
  - Csepel SC  (1) Csepel FC
  - Budapesti VSC  (1) Budapesti Vasutas Sport Club
- **Békéscsaba** (1): Békéscsaba 1912 Előre  (7) Békéscsaba · Békéscsaba Előre · Békéscsaba 1912 Előre SE · Békéscsabai Előre · Bekescsabai Elore · Békéscsabai Előre FC · Békéscsabai EFC
- **Dunaújváros** (1): Dunaújváros FC (1952-2009)  (2) Dunaújváros · Dunaferr SE
- **Győr** (1): Győri ETO FC  (9) Győr · Győri ETO · Rába ETO Győr · ETO Győr · ETO FC Győr · Egyetértés Torna Osztály Futball Club Győr · Gyori ETO · Raba ETO Gyor · ETO Györ
- **Komló** (1): Komlói Bányász SK  (2) Komlói Bányász · Komlói Bányász Sport Klub
- **Miskolc** (1): Diósgyőri VTK  (5) Diósgyőr · Diósgyöri VTK · Diósgyőr-Vasgyári Testgyakorlók Köre · Diósgyöri Miskolc · Diósgyör
- **Pápa** (1): Pápai FC (1995-2015)  (2) Pápa · Lombard Pápa TFC
- **Pécs** (1): Pécsi MFC  (6) PMFC · Pécsi Mecsek FC · Pécsi Mecsek Football Club · MSC Pécs · Pécsi Dózsa · Pécsi Dózsa Sport Club
- **Salgótarján** (1): Salgótarjáni BTC  (2) Salgótarjáni Barátok Torna Club · Salgótarján BTC
- **Siófok** (1): BFC Siófok  (3) Siófok · Bodajk FC Siófok · Siófoki Bányász
- **Sopron** (1): FC Sopron (1921-2008) 
- **Tatabánya** (1): FC Tatabánya  (2) Tatabánya · Tatabánya FC
- **Vác** (1): Vác FC  (3) Dunakanyar-Vác · Dunakanyar-Vác FC · Váci FC
- ? (10): 
  - Videoton FC  (6) Videoton · Videoton Fehérvár · Fehérvár · Fehérvár FC · MOL Fehérvár FC · MOL Vidi
  - Debreceni VSC  (2) Debrecen · DVSC Debrecen
  - Paksi SE  (2) Paks · Paksi FC
  - Kecskeméti TE  (1) Kecskemét
  - Szombathelyi Haladás  (1) Haladás
  - Zalaegerszegi TE  (1) Zalaegerszeg
  - Mezőkövesd Zsóry SE  (2) Mezőkövesd · Mezőkövesd-Zsóry
  - Varda SE  (1) Varda
  - Puskás Akadémia FC  (1) Puskás FC
  - Kaposvári Rákóczi FC  (2) Rákóczi · Kaposvári Rákóczi




By Region

- **Budapest†** (7):   Ferencvárosi TC · Budapest Honvéd FC · Vasas FC · MTK Budapest · Újpest FC · Csepel SC · Budapesti VSC
- **Vác†** (1):   Vác FC
- **Dunaújváros†** (1):   Dunaújváros FC (1952-2009)
- **Győr†** (1):   Győri ETO FC
- **Miskolc†** (1):   Diósgyőri VTK
- **Salgótarján†** (1):   Salgótarjáni BTC
- **Pécs†** (1):   Pécsi MFC
- **Sopron†** (1):   FC Sopron (1921-2008)
- **Békéscsaba†** (1):   Békéscsaba 1912 Előre
- **Pápa†** (1):   Pápai FC (1995-2015)
- **Tatabánya†** (1):   FC Tatabánya
- **Siófok†** (1):   BFC Siófok
- **Komló†** (1):   Komlói Bányász SK




By Year

- **1904** (1):   Győri ETO FC
- **1910** (2):   Diósgyőri VTK · FC Tatabánya
- **1911** (1):   Budapesti VSC
- **1912** (1):   Békéscsaba 1912 Előre
- **1920** (1):   Salgótarjáni BTC
- **1921** (2):   FC Sopron (1921-2008) · BFC Siófok
- **1922** (1):   Komlói Bányász SK
- **1950** (1):   Pécsi MFC
- **1952** (1):   Dunaújváros FC (1952-2009)
- **1995** (1):   Pápai FC (1995-2015)
- ? (17):   Ferencvárosi TC · Budapest Honvéd FC · Vasas FC · MTK Budapest · Újpest FC · Csepel SC · Vác FC · Videoton FC · Debreceni VSC · Paksi SE · Kecskeméti TE · Szombathelyi Haladás · Zalaegerszegi TE · Mezőkövesd Zsóry SE · Varda SE · Puskás Akadémia FC · Kaposvári Rákóczi FC




Historic

- **2008** (1):   FC Sopron (1921-2008)
- **2009** (1):   Dunaújváros FC (1952-2009)
- **2015** (1):   Pápai FC (1995-2015)






By A to Z

- **B** (17): BFC Siófok · Békéscsaba · Budapesti VSC · Budapest Honvéd · Budapesti Vasas · Békéscsabai EFC · Bodajk FC Siófok · Békéscsaba Előre · Bekescsabai Elore · Békéscsabai Előre · Budapest Honvéd FC · Budapest Honvéd SE · Békéscsabai Előre FC · Békéscsaba 1912 Előre · Budapesti Vörös Lobogó · Békéscsaba 1912 Előre SE · Budapesti Vasutas Sport Club
- **C** (2): Csepel FC · Csepel SC
- **D** (14): Debrecen · Diósgyör · Diósgyőr · Dunaferr SE · Dunaújváros · DVSC Debrecen · Debreceni VSC · Diósgyöri VTK · Diósgyőri VTK · Dunakanyar-Vác · Diósgyöri Miskolc · Dunakanyar-Vác FC · Dunaújváros FC (1952-2009) · Diósgyőr-Vasgyári Testgyakorlók Köre
- **E** (4): ETO Györ · ETO Győr · ETO FC Győr · Egyetértés Torna Osztály Futball Club Győr
- **F** (7): Fehérvár · Fehérvár FC · Ferencvaros · Ferencváros · FC Tatabánya · Ferencvárosi TC · FC Sopron (1921-2008)
- **G** (4): Győr · Gyori ETO · Győri ETO · Győri ETO FC
- **H** (3): Honvéd · Haladás · Honvéd Budapest
- **K** (8): Kecskemét · Kecskeméti TE · Komlói Bányász · Kispesti Honvéd · Kaposvári Rákóczi · Komlói Bányász SK · Kaposvári Rákóczi FC · Komlói Bányász Sport Klub
- **L** (1): Lombard Pápa TFC
- **M** (9): MTK · MOL Vidi · MSC Pécs · Mezőkövesd · MTK Budapest · MOL Fehérvár FC · Mezőkövesd-Zsóry · Mezőkövesd Zsóry SE · Magyar Testgyakorlók Köre Budapest Futball Club
- **P** (13): PMFC · Paks · Pápa · Paksi FC · Paksi SE · Puskás FC · Pécsi MFC · Pécsi Dózsa · Pécsi Mecsek FC · Puskás Akadémia FC · Pápai FC (1995-2015) · Pécsi Dózsa Sport Club · Pécsi Mecsek Football Club
- **R** (3): Rákóczi · Raba ETO Gyor · Rába ETO Győr
- **S** (6): Siófok · Salgótarján BTC · Siófoki Bányász · Salgótarjáni BTC · Szombathelyi Haladás · Salgótarjáni Barátok Torna Club
- **T** (2): Tatabánya · Tatabánya FC
- **V** (10): Varda · Vasas · Vác FC · Váci FC · Varda SE · Vasas FC · Videoton · Videoton FC · Vasas Budapest · Videoton Fehérvár
- **Z** (2): Zalaegerszeg · Zalaegerszegi TE
- **Ú** (7): Újpest · Újpest FC · Újpest TE · Ú. Dózsa SC · Újpest Dózsa · Újpesti Dózsa SC · Újpesti Dózsa Sport Club




