23 clubs

- **ŠK Slovan Bratislava** : (4) Slov. Bratisl. · Sl. Bratislava · Slovan Bratislava · SK Slovan Bratislava ⇒ (1) ≈SK Slovan Bratislava≈
- **FK Inter Bratislava** : (1) Inter Bratislava
- **FC Petržalka** : (3) Petržalka · FC Petržalka 1898 · Petrzalka Akademia ⇒ (3) ≈Petrzalka≈ · ≈FC Petrzalka≈ · ≈FC Petrzalka 1898≈
- **FC Spartak Trnava** : (2) Spartak Trnava · Spartak TAZ Trnava
- **MŠK Žilina** : (1) Žilina ⇒ (2) ≈Zilina≈ · ≈MSK Zilina≈
- **FK Senica** : (1) Senica
- **MFK Košice (1952-2017)** : (3) Košice · 1. FC Košice · FC VSS Košice ⇒ (4) ≈Kosice≈ · ≈MFK Kosice≈ · ≈1. FC Kosice≈ · ≈FC VSS Kosice≈
- **FC Lokomotíva Košice** : (2) Lokomotiva Košice · FK Lokomotiva Košice ⇒ (3) ≈Lokomotiva Kosice≈ · ≈FC Lokomotiva Kosice≈ · ≈FK Lokomotiva Kosice≈
- **Dukla Banská Bystrica** : (1) Banská Bystrica ⇒ (2) ≈Banska Bystrica≈ · ≈Dukla Banska Bystrica≈
- **FC Nitra** : (1) Nitra
- **MFK Petržalka** ⇒ (1) ≈MFK Petrzalka≈
- **AS Trenčín** : (2) Trenčín · FK AS Trenčín ⇒ (3) ≈Trencin≈ · ≈AS Trencin≈ · ≈FK AS Trencin≈
- **FC DAC 1904 Dunajská Streda** : (2) Dunajská Streda · DAC Dunajská Streda ⇒ (3) ≈Dunajska Streda≈ · ≈DAC Dunajska Streda≈ · ≈FC DAC 1904 Dunajska Streda≈
- **MFK Ružomberok** : (1) Ružomberok ⇒ (2) ≈Ruzomberok≈ · ≈MFK Ruzomberok≈
- **TJ Spartak Myjava** : (1) Spartak Myjava
- **FC ViOn Zlaté Moravce** : (1) Zlaté Moravce ⇒ (2) ≈Zlate Moravce≈ · ≈FC ViOn Zlate Moravce≈
- **SK Sered** : (2) Sered · ŠKF Sereď ⇒ (1) ≈SKF Sered≈
- **TJ Sokol Dolná Zdana** : (1) Sokol Dolná Zdana ⇒ (2) ≈Sokol Dolna Zdana≈ · ≈TJ Sokol Dolna Zdana≈
- **MFK Zemplín Michalovce** : (2) Michalovce · Zemplin Michalovce ⇒ (1) ≈MFK Zemplin Michalovce≈
- **FK Poprad**
- **MŠK Púchov** : (3) Matador Púchov · FK Matador Púchov · Mestský Športový Klub Púchov ⇒ (4) ≈MSK Puchov≈ · ≈Matador Puchov≈ · ≈FK Matador Puchov≈ · ≈Mestsky Sportovy Klub Puchov≈
- **1. FC Tatran Prešov** : (1) Tatran Prešov ⇒ (2) ≈Tatran Presov≈ · ≈1. FC Tatran Presov≈
- **FC Senec (1994-2008)**




Alphabet

- **Alphabet Specials** (11):  **á**  **é**  **í**  **ú**  **ý**  **č**  **ď**  **Š**  **š**  **Ž**  **ž** 
  - **á**×7 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×5 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ú**×4 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u
  - **ý**×2 U+00FD (253) - LATIN SMALL LETTER Y WITH ACUTE ⇒ y
  - **č**×3 U+010D (269) - LATIN SMALL LETTER C WITH CARON ⇒ c
  - **ď**×1 U+010F (271) - LATIN SMALL LETTER D WITH CARON ⇒ d
  - **Š**×5 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **š**×9 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s
  - **Ž**×2 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z
  - **ž**×6 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates

- **ŠK Slovan Bratislava**, Bratislava (1):
  - `skslovanbratislava` (2): **SK Slovan Bratislava** · **SK Slovan Bratislava**




By City

- **Bratislava** (3): 
  - ŠK Slovan Bratislava  (4) Slov. Bratisl. · Sl. Bratislava · Slovan Bratislava · SK Slovan Bratislava
  - FK Inter Bratislava  (1) Inter Bratislava
  - FC Petržalka  (3) Petržalka · FC Petržalka 1898 · Petrzalka Akademia
- **Košice** (2): 
  - MFK Košice (1952-2017)  (3) Košice · 1. FC Košice · FC VSS Košice
  - FC Lokomotíva Košice  (2) Lokomotiva Košice · FK Lokomotiva Košice
- **Poprad** (1): FK Poprad 
- **Prešov** (1): 1. FC Tatran Prešov  (1) Tatran Prešov
- **Púchov** (1): MŠK Púchov  (3) Mestský Športový Klub Púchov · Matador Púchov · FK Matador Púchov
- **Senec** (1): FC Senec (1994-2008) 
- **Trnava** (1): FC Spartak Trnava  (2) Spartak Trnava · Spartak TAZ Trnava
- ? (13): 
  - MŠK Žilina  (1) Žilina
  - FK Senica  (1) Senica
  - Dukla Banská Bystrica  (1) Banská Bystrica
  - FC Nitra  (1) Nitra
  - MFK Petržalka 
  - AS Trenčín  (2) Trenčín · FK AS Trenčín
  - FC DAC 1904 Dunajská Streda  (2) Dunajská Streda · DAC Dunajská Streda
  - MFK Ružomberok  (1) Ružomberok
  - TJ Spartak Myjava  (1) Spartak Myjava
  - FC ViOn Zlaté Moravce  (1) Zlaté Moravce
  - SK Sered  (2) Sered · ŠKF Sereď
  - TJ Sokol Dolná Zdana  (1) Sokol Dolná Zdana
  - MFK Zemplín Michalovce  (2) Michalovce · Zemplin Michalovce




By Region

- **Bratislava†** (3):   ŠK Slovan Bratislava · FK Inter Bratislava · FC Petržalka
- **Trnava†** (1):   FC Spartak Trnava
- **Košice†** (2):   MFK Košice (1952-2017) · FC Lokomotíva Košice
- **Poprad†** (1):   FK Poprad
- **Púchov†** (1):   MŠK Púchov
- **Prešov†** (1):   1. FC Tatran Prešov
- **Senec†** (1):   FC Senec (1994-2008)




By Year

- **1898** (2):   FC Petržalka · 1. FC Tatran Prešov
- **1906** (1):   FK Poprad
- **1920** (1):   MŠK Púchov
- **1923** (1):   FC Spartak Trnava
- **1940** (1):   FK Inter Bratislava
- **1946** (1):   FC Lokomotíva Košice
- **1952** (1):   MFK Košice (1952-2017)
- **1994** (1):   FC Senec (1994-2008)
- ? (14):   ŠK Slovan Bratislava · MŠK Žilina · FK Senica · Dukla Banská Bystrica · FC Nitra · MFK Petržalka · AS Trenčín · FC DAC 1904 Dunajská Streda · MFK Ružomberok · TJ Spartak Myjava · FC ViOn Zlaté Moravce · SK Sered · TJ Sokol Dolná Zdana · MFK Zemplín Michalovce




Historic

- **2008** (1):   FC Senec (1994-2008)
- **2017** (1):   MFK Košice (1952-2017)






By A to Z

- **1** (2): 1. FC Košice · 1. FC Tatran Prešov
- **A** (1): AS Trenčín
- **B** (1): Banská Bystrica
- **D** (3): Dunajská Streda · DAC Dunajská Streda · Dukla Banská Bystrica
- **F** (15): FC Nitra · FK Poprad · FK Senica · FC Petržalka · FC VSS Košice · FK AS Trenčín · FC Petržalka 1898 · FC Spartak Trnava · FK Matador Púchov · FK Inter Bratislava · FC Lokomotíva Košice · FC Senec (1994-2008) · FK Lokomotiva Košice · FC ViOn Zlaté Moravce · FC DAC 1904 Dunajská Streda
- **I** (1): Inter Bratislava
- **K** (1): Košice
- **L** (1): Lokomotiva Košice
- **M** (9): Michalovce · MŠK Púchov · MŠK Žilina · MFK Petržalka · MFK Ružomberok · Matador Púchov · MFK Košice (1952-2017) · MFK Zemplín Michalovce · Mestský Športový Klub Púchov
- **N** (1): Nitra
- **P** (2): Petržalka · Petrzalka Akademia
- **R** (1): Ružomberok
- **S** (11): Sered · Senica · SK Sered · Sl. Bratislava · Slov. Bratisl. · Spartak Myjava · Spartak Trnava · Slovan Bratislava · Sokol Dolná Zdana · Spartak TAZ Trnava · SK Slovan Bratislava
- **T** (4): Trenčín · Tatran Prešov · TJ Spartak Myjava · TJ Sokol Dolná Zdana
- **Z** (2): Zlaté Moravce · Zemplin Michalovce
- **Š** (2): ŠKF Sereď · ŠK Slovan Bratislava
- **Ž** (1): Žilina




