54 clubs

- [**SL Benfica**](https://en.wikipedia.org/wiki/S.L._Benfica) : (5) Benfica · Benfica Lis. · Benfica Lisboa · Benfica Lissab [de] · Benfica Lissabon [de]
- [**Sporting CP**](https://en.wikipedia.org/wiki/Sporting_CP) : (7) Sporting · Sp Lisbon [en] · Sporting Lisboa · Sporting CP Lisbon · Sporting Liss. [de] · Sporting Lissabon [de] · Sporting Clube de Portugal
- [**Os Belenenses**](https://en.wikipedia.org/wiki/Belenenses_SAD) : (4) Belenenses · Belenenses L. · Belenenses SAD · CF Os Belenenses
- **Casa Pia** : (3) Casa Pia AC · Casa Pia Atlético · Casa Pia Atlético Clube ⇒ (2) ≈Casa Pia Atletico≈ · ≈Casa Pia Atletico Clube≈
- **UD Vilafranquense** : (2) Vilafranquense · União Desportiva Vilafranquense ⇒ (1) ≈Uniao Desportiva Vilafranquense≈
- **CD Mafra** : (1) Clube Desportivo Mafra
- [**FC Porto**](https://en.wikipedia.org/wiki/FC_Porto) : (1) Porto
- [**Boavista FC**](https://en.wikipedia.org/wiki/Boavista_F.C.) : (3) Boavista · Boavista Porto · Boavista Porto FC
- **UD Oliveirense** : (2) Oliveirense · União Desportiva Oliveirense ⇒ (1) ≈Uniao Desportiva Oliveirense≈
- [**CD Aves**](https://en.wikipedia.org/wiki/C.D._Aves) : (4) Aves · CD das Aves · Desportivo Aves · Desportivo das Aves
- [**GD Chaves**](https://en.wikipedia.org/wiki/G.D._Chaves) : (1) Chaves
- **Estoril Praia** : (4) Estoril · GD Estoril · GD Estoril Praia · Grupo Desportivo Estoril Praia
- [**CD Feirense**](https://en.wikipedia.org/wiki/C.D._Feirense) : (1) Feirense
- [**Vitória de Guimarães**](https://en.wikipedia.org/wiki/Vitória_S.C.) : (5) Vitória · Guimarães · Vitória SC · Vit. Guimarães · Vitória Guimarães ⇒ (6) ≈Vitoria≈ · ≈Guimaraes≈ · ≈Vitoria SC≈ · ≈Vit. Guimaraes≈ · ≈Vitoria Guimaraes≈ · ≈Vitoria de Guimaraes≈
- [**Vitória de Setúbal**](https://en.wikipedia.org/wiki/Vitória_F.C.) : (3) Setúbal · Vitória FC · Vitória Setúbal ⇒ (4) ≈Setubal≈ · ≈Vitoria FC≈ · ≈Vitoria Setubal≈ · ≈Vitoria de Setubal≈
- [**CS Marítimo**](https://en.wikipedia.org/wiki/C.S._Marítimo) : (3) Marítimo · Marítimo Funchal · CS Marítimo Madeira ⇒ (4) ≈Maritimo≈ · ≈CS Maritimo≈ · ≈Maritimo Funchal≈ · ≈CS Maritimo Madeira≈
- [**CD Nacional Madeira**](https://en.wikipedia.org/wiki/C.D._Nacional) : (5) Nacional · CD Nacional · Nacional Funchal · Nacional da Madeira · Clube Desportivo Nacional
- [**Moreirense FC**](https://en.wikipedia.org/wiki/Moreirense_F.C.) : (1) Moreirense
- **FC Paços de Ferreira** : (4) Paços · Paços Ferreira · Paços de Ferreira · FC Paços Ferreira ⇒ (5) ≈Pacos≈ · ≈Pacos Ferreira≈ · ≈Pacos de Ferreira≈ · ≈FC Pacos Ferreira≈ · ≈FC Pacos de Ferreira≈
- [**Portimonense SC**](https://en.wikipedia.org/wiki/Portimonense_S.C.) : (1) Portimonense
- [**Rio Ave FC**](https://en.wikipedia.org/wiki/Rio_Ave_F.C.) : (1) Rio Ave
- [**SC Braga**](https://en.wikipedia.org/wiki/S.C._Braga) : (3) Braga · Sp Braga · Sporting Braga
- [**CD Tondela**](https://en.wikipedia.org/wiki/C.D._Tondela) : (1) Tondela
- **Académica de Coimbra** : (6) Académica · Académ. Coimbra · A. Académica de Coimbra · Associação Académica de Coimbra · Associação Académica de Coimbra - O.A.F · Associação Académica de Coimbra - Organismo Autónomo de Futebol ⇒ (7) ≈Academica≈ · ≈Academ. Coimbra≈ · ≈Academica de Coimbra≈ · ≈A. Academica de Coimbra≈ · ≈Associacao Academica de Coimbra≈ · ≈Associacao Academica de Coimbra - O.A.F≈ · ≈Associacao Academica de Coimbra - Organismo Autonomo de Futebol≈
- **.**
- **FC Arouca** : (1) Arouca
- **FC Penafiel** : (1) Penafiel
- **SC Beira-Mar** : (1) Beira-Mar
- **Desportivo de Chaves** : (1) Desp. Chaves
- **CF Estrela da Amadora** : (2) Est Amadora · Estrela Amadora
- **SC Farense** : (1) Farense
- **Gil Vicente FC** : (1) Gil Vicente
- **União de Leiria** : (4) Leiria · UD Leiria · União Leiria · União Desportiva de Leiria ⇒ (3) ≈Uniao Leiria≈ · ≈Uniao de Leiria≈ · ≈Uniao Desportiva de Leiria≈
- **União da Madeira** : (2) Madeira · União Madeira ⇒ (2) ≈Uniao Madeira≈ · ≈Uniao da Madeira≈
- **SC Salgueiros** : (1) Salgueiros
- **FC Tirsense** : (1) Tirsense
- **SC Campomaiorense** : (2) Campomaior · Campomaiorense
- **FC Felgueiras** : (1) Felgueiras
- **Leça FC** : (1) Leça ⇒ (2) ≈Leca≈ · ≈Leca FC≈
- **FC Alverca** : (2) Alverca · Alverca Futebol
- **Sporting de Espinho** : (3) Espinho · SC Espinho · Sporting Clube de Espinho
- **Leixões SC** : (1) Leixões ⇒ (2) ≈Leixoes≈ · ≈Leixoes SC≈
- **Naval 1º de Maio** : (2) Naval · Associação Naval 1º de Maio ⇒ (1) ≈Associacao Naval 1º de Maio≈
- **SC Olhanense** : (1) Olhanense
- [**CD Santa Clara**](https://en.wikipedia.org/wiki/C.D._Santa_Clara) : (1) Santa Clara
- **CD Trofense** : (2) Trofense · Clube Desportivo Trofense
- **Varzim SC** : (1) Varzim
- **FC Famalicão** : (2) Famalicão · Futebol Clube de Famalicão ⇒ (3) ≈Famalicao≈ · ≈FC Famalicao≈ · ≈Futebol Clube de Famalicao≈
- **SC Covilhã** : (2) Sporting da Covilhã · Sporting Clube da Covilhã ⇒ (3) ≈SC Covilha≈ · ≈Sporting da Covilha≈ · ≈Sporting Clube da Covilha≈
- **Académico Viseu** : (1) Académico de Viseu FC ⇒ (2) ≈Academico Viseu≈ · ≈Academico de Viseu FC≈
- **Anadia FC** : (1) Anadia Futebol Clube
- **AC Marinhense**
- **CU Fabril Barreiro** : (7) GD Fabril · CUF Barreiro · Fabril Barreiro · GD CUF Barreiro · CUF do Barreiro · Fabril do Barreiro · Grupo Desportivo Fabril
- **FC Barreirense** : (1) Futebol Clube Barreirense




Alphabet

- **Alphabet Specials** (7):  **ã**  **ç**  **é**  **í**  **ó**  **õ**  **ú** 
  - **ã**×21 U+00E3 (227) - LATIN SMALL LETTER A WITH TILDE ⇒ a
  - **ç**×11 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **é**×11 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×4 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×8 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **õ**×2 U+00F5 (245) - LATIN SMALL LETTER O WITH TILDE ⇒ o
  - **ú**×3 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Lisboa** (4): 
  - SL Benfica  (5) Benfica · Benfica Lis. · Benfica Lisboa · Benfica Lissab [de] · Benfica Lissabon [de]
  - Sporting CP  (7) Sporting · Sporting Lisboa · Sporting Clube de Portugal · Sp Lisbon [en] · Sporting CP Lisbon · Sporting Liss. [de] · Sporting Lissabon [de]
  - Os Belenenses  (4) Belenenses · Belenenses L. · Belenenses SAD · CF Os Belenenses
  - Casa Pia  (3) Casa Pia AC · Casa Pia Atlético · Casa Pia Atlético Clube
- **Funchal** (3): 
  - CS Marítimo  (3) Marítimo · Marítimo Funchal · CS Marítimo Madeira
  - CD Nacional Madeira  (5) Nacional · CD Nacional · Nacional da Madeira · Clube Desportivo Nacional · Nacional Funchal
  - União da Madeira  (2) Madeira · União Madeira
- **Barreiro** (2): 
  - CU Fabril Barreiro  (7) Fabril Barreiro · Fabril do Barreiro · GD Fabril · Grupo Desportivo Fabril · GD CUF Barreiro · CUF Barreiro · CUF do Barreiro
  - FC Barreirense  (1) Futebol Clube Barreirense
- **Chaves** (2): 
  - GD Chaves  (1) Chaves
  - Desportivo de Chaves  (1) Desp. Chaves
- **Porto** (2): 
  - FC Porto  (1) Porto
  - Boavista FC  (3) Boavista · Boavista Porto · Boavista Porto FC
- **Alverca do Ribatejo** (1): FC Alverca  (2) Alverca · Alverca Futebol
- **Amadora** (1): CF Estrela da Amadora  (2) Est Amadora · Estrela Amadora
- **Anadia** (1): Anadia FC  (1) Anadia Futebol Clube
- **Arouca** (1): FC Arouca  (1) Arouca
- **Aveiro** (1): SC Beira-Mar  (1) Beira-Mar
- **Aves** (1): CD Aves  (4) Aves · Desportivo Aves · CD das Aves · Desportivo das Aves
- **Barcelos** (1): Gil Vicente FC  (1) Gil Vicente
- **Braga** (1): SC Braga  (3) Braga · Sp Braga · Sporting Braga
- **Campo Maior** (1): SC Campomaiorense  (2) Campomaior · Campomaiorense
- **Coimbra** (1): Académica de Coimbra  (6) Académica · Académ. Coimbra · A. Académica de Coimbra · Associação Académica de Coimbra · Associação Académica de Coimbra - Organismo Autónomo de Futebol · Associação Académica de Coimbra - O.A.F
- **Covilhã** (1): SC Covilhã  (2) Sporting da Covilhã · Sporting Clube da Covilhã
- **Espinho** (1): Sporting de Espinho  (3) Espinho · SC Espinho · Sporting Clube de Espinho
- **Estoril** (1): Estoril Praia  (4) Estoril · GD Estoril Praia · Grupo Desportivo Estoril Praia · GD Estoril
- **Faro** (1): SC Farense  (1) Farense
- **Felgueiras** (1): FC Felgueiras  (1) Felgueiras
- **Figueira da Foz** (1): Naval 1º de Maio  (2) Naval · Associação Naval 1º de Maio
- **Guimarães** (1): Vitória de Guimarães  (5) Vitória · Guimarães · Vit. Guimarães · Vitória Guimarães · Vitória SC
- **Leiria** (1): União de Leiria  (4) Leiria · UD Leiria · União Desportiva de Leiria · União Leiria
- **Leça da Palmeira** (1): Leça FC  (1) Leça
- **Mafra** (1): CD Mafra  (1) Clube Desportivo Mafra
- **Marinha Grande** (1): AC Marinhense 
- **Matosinhos** (1): Leixões SC  (1) Leixões
- **Moreira de Cónegos** (1): Moreirense FC  (1) Moreirense
- **Olhão** (1): SC Olhanense  (1) Olhanense
- **Oliveira de Azeméis** (1): UD Oliveirense  (2) Oliveirense · União Desportiva Oliveirense
- **Paranhos** (1): SC Salgueiros  (1) Salgueiros
- **Paços de Ferreira** (1): FC Paços de Ferreira  (4) Paços · Paços Ferreira · Paços de Ferreira · FC Paços Ferreira
- **Penafiel** (1): FC Penafiel  (1) Penafiel
- **Ponta Delgada** (1): CD Santa Clara  (1) Santa Clara
- **Portimão** (1): Portimonense SC  (1) Portimonense
- **Póvoa de Varzim** (1): Varzim SC  (1) Varzim
- **Santa Maria da Feira** (1): CD Feirense  (1) Feirense
- **Santo Tirso** (1): FC Tirsense  (1) Tirsense
- **Setúbal** (1): Vitória de Setúbal  (3) Setúbal · Vitória Setúbal · Vitória FC
- **Tondela** (1): CD Tondela  (1) Tondela
- **Tulipa** (1): CD Trofense  (2) Trofense · Clube Desportivo Trofense
- **Vila Franca de Xira** (1): UD Vilafranquense  (2) Vilafranquense · União Desportiva Vilafranquense
- **Vila Nova de Famalicão** (1): FC Famalicão  (2) Famalicão · Futebol Clube de Famalicão
- **Vila do Conde** (1): Rio Ave FC  (1) Rio Ave
- **Viseu** (1): Académico Viseu  (1) Académico de Viseu FC
- ? (1): . 




By Region

- **Lisboa†** (4):   SL Benfica · Sporting CP · Os Belenenses · Casa Pia
- **Vila Franca de Xira†** (1):   UD Vilafranquense
- **Mafra†** (1):   CD Mafra
- **Porto†** (2):   FC Porto · Boavista FC
- **Oliveira de Azeméis†** (1):   UD Oliveirense
- **Aves†** (1):   CD Aves
- **Chaves†** (2):   GD Chaves · Desportivo de Chaves
- **Estoril†** (1):   Estoril Praia
- **Santa Maria da Feira†** (1):   CD Feirense
- **Guimarães†** (1):   Vitória de Guimarães
- **Setúbal†** (1):   Vitória de Setúbal
- **Funchal†** (3):   CS Marítimo · CD Nacional Madeira · União da Madeira
- **Moreira de Cónegos†** (1):   Moreirense FC
- **Paços de Ferreira†** (1):   FC Paços de Ferreira
- **Portimão†** (1):   Portimonense SC
- **Vila do Conde†** (1):   Rio Ave FC
- **Braga†** (1):   SC Braga
- **Tondela†** (1):   CD Tondela
- **Coimbra†** (1):   Académica de Coimbra
- **Arouca†** (1):   FC Arouca
- **Penafiel†** (1):   FC Penafiel
- **Aveiro†** (1):   SC Beira-Mar
- **Amadora†** (1):   CF Estrela da Amadora
- **Faro†** (1):   SC Farense
- **Barcelos†** (1):   Gil Vicente FC
- **Leiria†** (1):   União de Leiria
- **Paranhos†** (1):   SC Salgueiros
- **Santo Tirso†** (1):   FC Tirsense
- **Campo Maior†** (1):   SC Campomaiorense
- **Felgueiras†** (1):   FC Felgueiras
- **Leça da Palmeira†** (1):   Leça FC
- **Alverca do Ribatejo†** (1):   FC Alverca
- **Espinho†** (1):   Sporting de Espinho
- **Matosinhos†** (1):   Leixões SC
- **Figueira da Foz†** (1):   Naval 1º de Maio
- **Olhão†** (1):   SC Olhanense
- **Ponta Delgada†** (1):   CD Santa Clara
- **Tulipa†** (1):   CD Trofense
- **Póvoa de Varzim†** (1):   Varzim SC
- **Vila Nova de Famalicão†** (1):   FC Famalicão
- **Covilhã†** (1):   SC Covilhã
- **Viseu†** (1):   Académico Viseu
- **Anadia†** (1):   Anadia FC
- **Marinha Grande†** (1):   AC Marinhense
- **Barreiro†** (2):   CU Fabril Barreiro · FC Barreirense




By Year

- **1911** (1):   FC Barreirense
- **1930** (1):   CD Aves
- **1931** (1):   FC Famalicão
- **1937** (1):   CU Fabril Barreiro
- ? (50):   SL Benfica · Sporting CP · Os Belenenses · Casa Pia · UD Vilafranquense · CD Mafra · FC Porto · Boavista FC · UD Oliveirense · GD Chaves · Estoril Praia · CD Feirense · Vitória de Guimarães · Vitória de Setúbal · CS Marítimo · CD Nacional Madeira · Moreirense FC · FC Paços de Ferreira · Portimonense SC · Rio Ave FC · SC Braga · CD Tondela · Académica de Coimbra · . · FC Arouca · FC Penafiel · SC Beira-Mar · Desportivo de Chaves · CF Estrela da Amadora · SC Farense · Gil Vicente FC · União de Leiria · União da Madeira · SC Salgueiros · FC Tirsense · SC Campomaiorense · FC Felgueiras · Leça FC · FC Alverca · Sporting de Espinho · Leixões SC · Naval 1º de Maio · SC Olhanense · CD Santa Clara · CD Trofense · Varzim SC · SC Covilhã · Académico Viseu · Anadia FC · AC Marinhense






By A to Z

- **.** (1): .
- **A** (17): Aves · Arouca · Alverca · Académica · Anadia FC · AC Marinhense · Académ. Coimbra · Académico Viseu · Alverca Futebol · Académica de Coimbra · Anadia Futebol Clube · Académico de Viseu FC · A. Académica de Coimbra · Associação Naval 1º de Maio · Associação Académica de Coimbra · Associação Académica de Coimbra - O.A.F · Associação Académica de Coimbra - Organismo Autónomo de Futebol
- **B** (14): Braga · Benfica · Boavista · Beira-Mar · Belenenses · Boavista FC · Benfica Lis. · Belenenses L. · Belenenses SAD · Benfica Lisboa · Boavista Porto · Boavista Porto FC · Benfica Lissab [de] · Benfica Lissabon [de]
- **C** (26): Chaves · CD Aves · CD Mafra · Casa Pia · CD Tondela · Campomaior · CD Feirense · CD Nacional · CD Trofense · CD das Aves · CS Marítimo · Casa Pia AC · CUF Barreiro · CD Santa Clara · Campomaiorense · CUF do Barreiro · CF Os Belenenses · Casa Pia Atlético · CU Fabril Barreiro · CD Nacional Madeira · CS Marítimo Madeira · CF Estrela da Amadora · Clube Desportivo Mafra · Casa Pia Atlético Clube · Clube Desportivo Nacional · Clube Desportivo Trofense
- **D** (4): Desp. Chaves · Desportivo Aves · Desportivo das Aves · Desportivo de Chaves
- **E** (5): Espinho · Estoril · Est Amadora · Estoril Praia · Estrela Amadora
- **F** (18): Farense · FC Porto · Feirense · FC Arouca · Famalicão · FC Alverca · Felgueiras · FC Penafiel · FC Tirsense · FC Famalicão · FC Felgueiras · FC Barreirense · Fabril Barreiro · FC Paços Ferreira · Fabril do Barreiro · FC Paços de Ferreira · Futebol Clube Barreirense · Futebol Clube de Famalicão
- **G** (10): GD Chaves · GD Fabril · Guimarães · GD Estoril · Gil Vicente · Gil Vicente FC · GD CUF Barreiro · GD Estoril Praia · Grupo Desportivo Fabril · Grupo Desportivo Estoril Praia
- **L** (5): Leça · Leiria · Leixões · Leça FC · Leixões SC
- **M** (5): Madeira · Marítimo · Moreirense · Moreirense FC · Marítimo Funchal
- **N** (5): Naval · Nacional · Nacional Funchal · Naval 1º de Maio · Nacional da Madeira
- **O** (3): Olhanense · Oliveirense · Os Belenenses
- **P** (7): Paços · Porto · Penafiel · Portimonense · Paços Ferreira · Portimonense SC · Paços de Ferreira
- **R** (2): Rio Ave · Rio Ave FC
- **S** (26): Setúbal · SC Braga · Sp Braga · Sporting · SC Covilhã · SC Espinho · SC Farense · SL Benfica · Salgueiros · Santa Clara · Sporting CP · SC Beira-Mar · SC Olhanense · SC Salgueiros · Sp Lisbon [en] · Sporting Braga · Sporting Lisboa · SC Campomaiorense · Sporting CP Lisbon · Sporting Liss. [de] · Sporting da Covilhã · Sporting de Espinho · Sporting Lissabon [de] · Sporting Clube da Covilhã · Sporting Clube de Espinho · Sporting Clube de Portugal
- **T** (3): Tondela · Tirsense · Trofense
- **U** (10): UD Leiria · União Leiria · União Madeira · UD Oliveirense · União de Leiria · União da Madeira · UD Vilafranquense · União Desportiva de Leiria · União Desportiva Oliveirense · União Desportiva Vilafranquense
- **V** (11): Varzim · Vitória · Varzim SC · Vitória FC · Vitória SC · Vilafranquense · Vit. Guimarães · Vitória Setúbal · Vitória Guimarães · Vitória de Setúbal · Vitória de Guimarães




