42 clubs

- [**RSC Anderlecht**](https://en.wikipedia.org/wiki/R.S.C._Anderlecht) : (2) Anderlecht · Royal Sporting Club Anderlecht
- **RWD Molenbeek** : (7) Molenbeek · FC Brussels · RWDM Brussels FC · Racing White Brussels · R. Racing White Bruxelles · Racing White Daring Molenbeek · FC Molenbeek Brussels Strombeek
- **Saint-Gilloise** : (2) Union St. Gilloise · R. Union Saint-Gilloise
- [**Royal Antwerp FC**](https://en.wikipedia.org/wiki/Royal_Antwerp_F.C.) : (5) Antwerp · R. Antwerpen · Royal Antwerp · Royal Antwerpen · FC Royal Antwerpen
- **K Beerschot VA** : (2) KFCO Wilrijk · Koninklijke Beerschot Voetbalclub Antwerpen
- **Germinal Beerschot (1920-2013)** : (5) Germinal · Beerschot AC · Germinal Ekeren · KFC Germinal Beerschot Antwerpen · Koninklijke Beerschot Antwerpen Club
- **Beerschot VAC (1899-1999)** : (3) Beerschot VAV · K. Beerschot VAC · Koninklijke Beerschot Voetbal en Atletiek Club
- [**KV Mechelen**](https://en.wikipedia.org/wiki/KV_Mechelen) : (3) Mechelen · YR KV Mechelen · Yellow Red Koninklijke Voetbalclub Mechelen
- [**KVC Westerlo**](https://en.wikipedia.org/wiki/K.V.C._Westerlo) : (2) Westerlo · Koninklijke Voetbal Club Westerlo
- **K Lierse SK** : (2) Lierse · Lierse SK
- [**KRC Genk**](https://en.wikipedia.org/wiki/K.R.C._Genk) : (4) Genk · Racing Genk · KFC Winterslag · Koninklijke Racing Club Genk
- **Waterschei Thor (1919-1988)** : (2) Thor Waterschei · K. Waterschei S.V. Thor Genk
- [**Sint-Truidense VV**](https://en.wikipedia.org/wiki/Sint-Truidense_V.V.) : (6) St Truiden · Sint-Truiden · St. Truiden VV · Sint-Truidense · K. Sint-Truidense VV · Koninklijke Sint-Truidense Voetbalvereniging
- **Lommel United** : (1) Lommel SK
- [**KAA Gent**](https://en.wikipedia.org/wiki/K.A.A._Gent) : (3) Gent · AA Gent · Koninklijke Atletiek Associatie Gent
- [**KSC Lokeren OV**](https://en.wikipedia.org/wiki/K.S.C._Lokeren_Oost-Vlaanderen) : (5) Lokeren · KSC Lokeren · Sporting Lokeren · KSC Lokeren Oost-Vlaanderen · Koninklijke Sporting Club Lokeren Oost-Vlaanderen
- **SC Eendracht Aalst** : (3) Aalst · Eendracht Aalst · KSC Eendracht Aalst
- **FCV Dender EH** : (1) Dender
- [**Waasland-Beveren**](https://en.wikipedia.org/wiki/Waasland-Beveren) : (2) Waasland-Bev · Red Star Waasland
- **KSK Beveren** : (2) Beveren · SK Beveren
- [**Club Brugge**](https://en.wikipedia.org/wiki/Club_Brugge_KV) : (3) Club Brugge KV · Club Brügge [de] · Club Brugge Koninklijke Voetbalvereniging ⇒ (2) ≈Club Brugge≈ · ≈Club Bruegge≈
- [**Cercle Brugge**](https://en.wikipedia.org/wiki/Cercle_Brugge_K.S.V.) : (3) Cercle Brugge KSV · Cercle Brügge KSV [de] · Cercle Brugge Koninklijke Sportvereniging ⇒ (2) ≈Cercle Brugge KSV≈ · ≈Cercle Bruegge KSV≈
- [**KV Kortrijk**](https://en.wikipedia.org/wiki/K.V._Kortrijk) : (2) Kortrijk · Koninklijke Voetbalclub Kortrijk
- [**KV Oostende**](https://en.wikipedia.org/wiki/K.V._Oostende) : (2) Oostende · Koninklijke Voetbalclub Oostende
- [**SV Zulte Waregem**](https://en.wikipedia.org/wiki/S.V._Zulte_Waregem) : (3) Waregem · Zulte Waregem · Sportvereniging Zulte Waregem
- **KSV Waregem (1925-2001)** : (1) Koninklijke Sportvereniging Waregem
- [**Sporting Charleroi**](https://en.wikipedia.org/wiki/R._Charleroi_S.C.) : (5) Charleroi · R. Charleroi SC · Royal Charleroi SC · Sporting de Charleroi · Royal Charleroi Sporting Club
- [**Royal Excel Mouscron**](https://en.wikipedia.org/wiki/Royal_Excel_Mouscron) : (10) Mouscron · RE Mouscron · Excel Mouscron · Mouscron-Péruwelz · R. Excel Mouscron · Excelsior Mouscron · R. Mouscron-Péruwelz · R. Excelsior Mouscron · Royal Mouscron-Péruwelz · Royal Excel Mouscron Péruwelz ⇒ (4) ≈Mouscron-Peruwelz≈ · ≈R. Mouscron-Peruwelz≈ · ≈Royal Mouscron-Peruwelz≈ · ≈Royal Excel Mouscron Peruwelz≈
- **RAEC Mons** : (2) Mons · Bergen
- **Excelsior Virton** : (1) R.E. Virton
- [**KAS Eupen**](https://en.wikipedia.org/wiki/K.A.S._Eupen) : (2) Eupen · AS Eupen
- [**Standard Liège**](https://en.wikipedia.org/wiki/Standard_Liège) : (6) Standard · Standard de Liège · Stand. Lüttich [de] · R. Standard de Liège · Standard Lüttich [de] · Royal Standard de Liège ⇒ (8) ≈Standard Liege≈ · ≈Stand. Luttich≈ · ≈Stand. Luettich≈ · ≈Standard Luttich≈ · ≈Standard de Liege≈ · ≈Standard Luettich≈ · ≈R. Standard de Liege≈ · ≈Royal Standard de Liege≈
- **RFC Liège** : (4) FC Liège · RC Liégeois · RFC de Liège · Royal Football Club de Liège ⇒ (5) ≈FC Liege≈ · ≈RFC Liege≈ · ≈RC Liegeois≈ · ≈RFC de Liege≈ · ≈Royal Football Club de Liege≈
- **KFC Verbroedering Geel** : (1) Geel
- **KRC Harelbeke** : (1) Harelbeke
- **K Heusden-Zolder** : (1) Heusden Zolder
- **KFC Lommel SK** : (1) Lommel
- **RAA Louviéroise** : (2) Louvieroise · RAA La Louviéroise ⇒ (2) ≈RAA Louvieroise≈ · ≈RAA La Louvieroise≈
- **KSV Roeselare** : (2) Roeselare · SV Roeselare
- **RFC Seraing** : (1) Seraing
- **AFC Tubize** : (1) Tubize
- [**Oud-Heverlee Leuven**](https://en.wikipedia.org/wiki/Oud-Heverlee_Leuven) : (3) Leuven · OH Leuven · Oud-Heverlee




Alphabet

- **Alphabet Specials** (3):  **è**  **é**  **ü** 
  - **è**×8 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **é**×7 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ü**×4 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates

- **Club Brugge**, Brugge (1):
  - `clubbrugge` (2): **Club Brugge** · **Club Brugge**
- **Cercle Brugge**, Brugge (1):
  - `cerclebruggeksv` (2): **Cercle Brugge KSV** · **Cercle Brugge KSV**




By City

- **Antwerpen, Antwerpen › Vlaanderen** (4): 
  - Royal Antwerp FC  (5) Antwerp · Royal Antwerp · R. Antwerpen · Royal Antwerpen · FC Royal Antwerpen
  - K Beerschot VA  (2) Koninklijke Beerschot Voetbalclub Antwerpen · KFCO Wilrijk
  - Germinal Beerschot (1920-2013)  (5) Germinal · Germinal Ekeren · Beerschot AC · KFC Germinal Beerschot Antwerpen · Koninklijke Beerschot Antwerpen Club
  - Beerschot VAC (1899-1999)  (3) Koninklijke Beerschot Voetbal en Atletiek Club · K. Beerschot VAC · Beerschot VAV
- **Brussels, Brussels** (3): 
  - RSC Anderlecht  (2) Anderlecht · Royal Sporting Club Anderlecht
  - RWD Molenbeek  (7) Molenbeek · Racing White Daring Molenbeek · RWDM Brussels FC · FC Molenbeek Brussels Strombeek · FC Brussels · R. Racing White Bruxelles · Racing White Brussels
  - Saint-Gilloise  (2) R. Union Saint-Gilloise · Union St. Gilloise
- **Beveren, Oost-Vlaanderen › Vlaanderen** (2): 
  - Waasland-Beveren  (2) Waasland-Bev · Red Star Waasland
  - KSK Beveren  (2) Beveren · SK Beveren
- **Brugge, West-Vlaanderen › Vlaanderen** (2): 
  - Club Brugge  (3) Club Brugge KV · Club Brugge Koninklijke Voetbalvereniging · Club Brügge [de]
  - Cercle Brugge  (3) Cercle Brugge KSV · Cercle Brugge Koninklijke Sportvereniging · Cercle Brügge KSV [de]
- **Genk, Limburg › Vlaanderen** (2): 
  - KRC Genk  (4) Genk · Racing Genk · Koninklijke Racing Club Genk · KFC Winterslag
  - Waterschei Thor (1919-1988)  (2) K. Waterschei S.V. Thor Genk · Thor Waterschei
- **Liège, Liège › Wallonie** (2): 
  - Standard Liège  (6) Standard · R. Standard de Liège · Royal Standard de Liège · Standard de Liège · Stand. Lüttich [de] · Standard Lüttich [de]
  - RFC Liège  (4) RC Liégeois · RFC de Liège · Royal Football Club de Liège · FC Liège
- **Waregem, West-Vlaanderen › Vlaanderen** (2): 
  - SV Zulte Waregem  (3) Waregem · Zulte Waregem · Sportvereniging Zulte Waregem
  - KSV Waregem (1925-2001)  (1) Koninklijke Sportvereniging Waregem
- **Aalst, Oost-Vlaanderen › Vlaanderen** (1): SC Eendracht Aalst  (3) Aalst · Eendracht Aalst · KSC Eendracht Aalst
- **Charleroi, Hainaut › Wallonie** (1): Sporting Charleroi  (5) Charleroi · R. Charleroi SC · Royal Charleroi SC · Royal Charleroi Sporting Club · Sporting de Charleroi
- **Denderleeuw, Oost-Vlaanderen › Vlaanderen** (1): FCV Dender EH  (1) Dender
- **Eupen, Liège › Wallonie** (1): KAS Eupen  (2) Eupen · AS Eupen
- **Geel** (1): KFC Verbroedering Geel  (1) Geel
- **Gent, Oost-Vlaanderen › Vlaanderen** (1): KAA Gent  (3) Gent · Koninklijke Atletiek Associatie Gent · AA Gent
- **Harelbeke** (1): KRC Harelbeke  (1) Harelbeke
- **Heusden-Zolder** (1): K Heusden-Zolder  (1) Heusden Zolder
- **Kortrijk, West-Vlaanderen › Vlaanderen** (1): KV Kortrijk  (2) Kortrijk · Koninklijke Voetbalclub Kortrijk
- **La Louvière** (1): RAA Louviéroise  (2) Louvieroise · RAA La Louviéroise
- **Leuven** (1): Oud-Heverlee Leuven  (3) Leuven · OH Leuven · Oud-Heverlee
- **Lier, Antwerpen › Vlaanderen** (1): K Lierse SK  (2) Lierse · Lierse SK
- **Lokeren, Oost-Vlaanderen › Vlaanderen** (1): KSC Lokeren OV  (5) Lokeren · KSC Lokeren · KSC Lokeren Oost-Vlaanderen · Sporting Lokeren · Koninklijke Sporting Club Lokeren Oost-Vlaanderen
- **Lommel** (1): KFC Lommel SK  (1) Lommel
- **Lommel, Limburg › Vlaanderen** (1): Lommel United  (1) Lommel SK
- **Mechelen, Antwerpen › Vlaanderen** (1): KV Mechelen  (3) Mechelen · YR KV Mechelen · Yellow Red Koninklijke Voetbalclub Mechelen
- **Mons, Hainaut › Wallonie** (1): RAEC Mons  (2) Mons · Bergen
- **Mouscron, Hainaut › Wallonie** (1): Royal Excel Mouscron  (10) Mouscron · Mouscron-Péruwelz · RE Mouscron · Excel Mouscron · R. Excel Mouscron · R. Mouscron-Péruwelz · Royal Mouscron-Péruwelz · R. Excelsior Mouscron · Excelsior Mouscron · Royal Excel Mouscron Péruwelz
- **Oostende, West-Vlaanderen › Vlaanderen** (1): KV Oostende  (2) Oostende · Koninklijke Voetbalclub Oostende
- **Roeselare** (1): KSV Roeselare  (2) Roeselare · SV Roeselare
- **Seraing** (1): RFC Seraing  (1) Seraing
- **Sint-Truiden, Limburg › Vlaanderen** (1): Sint-Truidense VV  (6) St Truiden · St. Truiden VV · Sint-Truiden · Sint-Truidense · K. Sint-Truidense VV · Koninklijke Sint-Truidense Voetbalvereniging
- **Tubize** (1): AFC Tubize  (1) Tubize
- **Virton, Luxembourg › Wallonie** (1): Excelsior Virton  (1) R.E. Virton
- **Westerlo, Antwerpen › Vlaanderen** (1): KVC Westerlo  (2) Westerlo · Koninklijke Voetbal Club Westerlo




By Region

- **Brussels** (3):   RSC Anderlecht · RWD Molenbeek · Saint-Gilloise
- **Antwerpen › Vlaanderen** (7):   Royal Antwerp FC · K Beerschot VA · Germinal Beerschot (1920-2013) · Beerschot VAC (1899-1999) · KV Mechelen · KVC Westerlo · K Lierse SK
- **Limburg › Vlaanderen** (4):   KRC Genk · Waterschei Thor (1919-1988) · Sint-Truidense VV · Lommel United
- **Oost-Vlaanderen › Vlaanderen** (6):   KAA Gent · KSC Lokeren OV · SC Eendracht Aalst · FCV Dender EH · Waasland-Beveren · KSK Beveren
- **West-Vlaanderen › Vlaanderen** (6):   Club Brugge · Cercle Brugge · KV Kortrijk · KV Oostende · SV Zulte Waregem · KSV Waregem (1925-2001)
- **Hainaut › Wallonie** (3):   Sporting Charleroi · Royal Excel Mouscron · RAEC Mons
- **Luxembourg › Wallonie** (1):   Excelsior Virton
- **Liège › Wallonie** (3):   KAS Eupen · Standard Liège · RFC Liège
- **Geel†** (1):   KFC Verbroedering Geel
- **Harelbeke†** (1):   KRC Harelbeke
- **Heusden-Zolder†** (1):   K Heusden-Zolder
- **Lommel†** (1):   KFC Lommel SK
- **La Louvière†** (1):   RAA Louviéroise
- **Roeselare†** (1):   KSV Roeselare
- **Seraing†** (1):   RFC Seraing
- **Tubize†** (1):   AFC Tubize
- **Leuven†** (1):   Oud-Heverlee Leuven




By Year

- **1864** (1):   KAA Gent
- **1891** (1):   Club Brugge
- **1892** (1):   RFC Liège
- **1898** (1):   Standard Liège
- **1899** (3):   K Beerschot VA · Beerschot VAC (1899-1999) · Cercle Brugge
- **1901** (1):   KV Kortrijk
- **1904** (2):   KV Mechelen · Sporting Charleroi
- **1908** (1):   RSC Anderlecht
- **1919** (2):   Waterschei Thor (1919-1988) · SC Eendracht Aalst
- **1920** (1):   Germinal Beerschot (1920-2013)
- **1923** (1):   KSC Lokeren OV
- **1924** (1):   Sint-Truidense VV
- **1925** (1):   KSV Waregem (1925-2001)
- **1933** (1):   KVC Westerlo
- **1936** (1):   Waasland-Beveren
- **1950** (1):   SV Zulte Waregem
- **1981** (1):   KV Oostende
- **1988** (1):   KRC Genk
- **2002** (1):   Oud-Heverlee Leuven
- **2010** (1):   Royal Excel Mouscron
- ? (18):   RWD Molenbeek · Saint-Gilloise · Royal Antwerp FC · K Lierse SK · Lommel United · FCV Dender EH · KSK Beveren · RAEC Mons · Excelsior Virton · KAS Eupen · KFC Verbroedering Geel · KRC Harelbeke · K Heusden-Zolder · KFC Lommel SK · RAA Louviéroise · KSV Roeselare · RFC Seraing · AFC Tubize




Historic

- **1988** (1):   Waterschei Thor (1919-1988)
- **1999** (1):   Beerschot VAC (1899-1999)
- **2001** (1):   KSV Waregem (1925-2001)
- **2013** (1):   Germinal Beerschot (1920-2013)






By A to Z

- **A** (6): Aalst · AA Gent · Antwerp · AS Eupen · AFC Tubize · Anderlecht
- **B** (5): Bergen · Beveren · Beerschot AC · Beerschot VAV · Beerschot VAC (1899-1999)
- **C** (9): Charleroi · Club Brugge · Cercle Brugge · Club Brugge KV · Club Brügge [de] · Cercle Brugge KSV · Cercle Brügge KSV [de] · Cercle Brugge Koninklijke Sportvereniging · Club Brugge Koninklijke Voetbalvereniging
- **D** (1): Dender
- **E** (5): Eupen · Excel Mouscron · Eendracht Aalst · Excelsior Virton · Excelsior Mouscron
- **F** (5): FC Liège · FC Brussels · FCV Dender EH · FC Royal Antwerpen · FC Molenbeek Brussels Strombeek
- **G** (6): Geel · Genk · Gent · Germinal · Germinal Ekeren · Germinal Beerschot (1920-2013)
- **H** (2): Harelbeke · Heusden Zolder
- **K** (38): KAA Gent · KRC Genk · Kortrijk · KAS Eupen · K Lierse SK · KSC Lokeren · KSK Beveren · KV Kortrijk · KV Mechelen · KV Oostende · KFCO Wilrijk · KVC Westerlo · KFC Lommel SK · KRC Harelbeke · KSV Roeselare · K Beerschot VA · KFC Winterslag · KSC Lokeren OV · K Heusden-Zolder · K. Beerschot VAC · KSC Eendracht Aalst · K. Sint-Truidense VV · KFC Verbroedering Geel · KSV Waregem (1925-2001) · KSC Lokeren Oost-Vlaanderen · K. Waterschei S.V. Thor Genk · Koninklijke Racing Club Genk · KFC Germinal Beerschot Antwerpen · Koninklijke Voetbalclub Kortrijk · Koninklijke Voetbalclub Oostende · Koninklijke Voetbal Club Westerlo · Koninklijke Sportvereniging Waregem · Koninklijke Atletiek Associatie Gent · Koninklijke Beerschot Antwerpen Club · Koninklijke Beerschot Voetbalclub Antwerpen · Koninklijke Sint-Truidense Voetbalvereniging · Koninklijke Beerschot Voetbal en Atletiek Club · Koninklijke Sporting Club Lokeren Oost-Vlaanderen
- **L** (8): Leuven · Lierse · Lommel · Lokeren · Lierse SK · Lommel SK · Louvieroise · Lommel United
- **M** (5): Mons · Mechelen · Mouscron · Molenbeek · Mouscron-Péruwelz
- **O** (4): Oostende · OH Leuven · Oud-Heverlee · Oud-Heverlee Leuven
- **R** (36): RAEC Mons · RFC Liège · Roeselare · R.E. Virton · RC Liégeois · RE Mouscron · RFC Seraing · Racing Genk · R. Antwerpen · RFC de Liège · RWD Molenbeek · Royal Antwerp · RSC Anderlecht · R. Charleroi SC · RAA Louviéroise · Royal Antwerpen · RWDM Brussels FC · Royal Antwerp FC · R. Excel Mouscron · Red Star Waasland · RAA La Louviéroise · Royal Charleroi SC · R. Mouscron-Péruwelz · R. Standard de Liège · Royal Excel Mouscron · R. Excelsior Mouscron · Racing White Brussels · R. Union Saint-Gilloise · Royal Mouscron-Péruwelz · Royal Standard de Liège · R. Racing White Bruxelles · Royal Football Club de Liège · Racing White Daring Molenbeek · Royal Charleroi Sporting Club · Royal Excel Mouscron Péruwelz · Royal Sporting Club Anderlecht
- **S** (20): Seraing · Standard · SK Beveren · St Truiden · SV Roeselare · Sint-Truiden · Saint-Gilloise · Sint-Truidense · St. Truiden VV · Standard Liège · SV Zulte Waregem · Sporting Lokeren · Sint-Truidense VV · Standard de Liège · SC Eendracht Aalst · Sporting Charleroi · Stand. Lüttich [de] · Sporting de Charleroi · Standard Lüttich [de] · Sportvereniging Zulte Waregem
- **T** (2): Tubize · Thor Waterschei
- **U** (1): Union St. Gilloise
- **W** (5): Waregem · Westerlo · Waasland-Bev · Waasland-Beveren · Waterschei Thor (1919-1988)
- **Y** (2): YR KV Mechelen · Yellow Red Koninklijke Voetbalclub Mechelen
- **Z** (1): Zulte Waregem




