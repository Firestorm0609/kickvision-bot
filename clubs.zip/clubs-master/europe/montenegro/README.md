14 clubs

- **FK Budućnost Podgorica** : (2) Budućnost · Budućnost Podgorica ⇒ (3) ≈Buducnost≈ · ≈Buducnost Podgorica≈ · ≈FK Buducnost Podgorica≈
- **FK Mogren (1920-2016)** : (1) FK Mogren Budva
- **FK Zeta** : (2) Zeta · Zeta Golubovci
- **FK Rudar Pljevlja** : (1) Rudar Pljevlja
- **OFK Petrovac** : (1) Petrovac
- **FK Čelik Nikšić** : (1) Čelik Nikšić ⇒ (2) ≈Celik Niksic≈ · ≈FK Celik Niksic≈
- **FK Sutjeska** : (2) Sutjeska · Sutjeska Nikšić ⇒ (1) ≈Sutjeska Niksic≈
- **OFK Titograd** : (1) Titograd
- **FK Bokelj** : (2) Bokelj · Bokelj Kotor
- **FK Lovćen** : (1) Lovćen Cetinje ⇒ (2) ≈FK Lovcen≈ · ≈Lovcen Cetinje≈
- **FK Iskra** : (1) Iskra
- **Mladost Ljeskopolje**
- **FK Kom** : (1) Kom
- **OFK Grbalj** : (1) Grbalj




Alphabet

- **Alphabet Specials** (3):  **ć**  **Č**  **š** 
  - **ć**×8 U+0107 (263) - LATIN SMALL LETTER C WITH ACUTE ⇒ c
  - **Č**×2 U+010C (268) - LATIN CAPITAL LETTER C WITH CARON ⇒ C
  - **š**×3 U+0161 (353) - LATIN SMALL LETTER S WITH CARON ⇒ s




Duplicates





By City

- **Budva** (1): FK Mogren (1920-2016)  (1) FK Mogren Budva
- ? (13): 
  - FK Budućnost Podgorica  (2) Budućnost · Budućnost Podgorica
  - FK Zeta  (2) Zeta · Zeta Golubovci
  - FK Rudar Pljevlja  (1) Rudar Pljevlja
  - OFK Petrovac  (1) Petrovac
  - FK Čelik Nikšić  (1) Čelik Nikšić
  - FK Sutjeska  (2) Sutjeska · Sutjeska Nikšić
  - OFK Titograd  (1) Titograd
  - FK Bokelj  (2) Bokelj · Bokelj Kotor
  - FK Lovćen  (1) Lovćen Cetinje
  - FK Iskra  (1) Iskra
  - Mladost Ljeskopolje 
  - FK Kom  (1) Kom
  - OFK Grbalj  (1) Grbalj




By Region

- **Budva†** (1):   FK Mogren (1920-2016)




By Year

- **1920** (1):   FK Mogren (1920-2016)
- ? (13):   FK Budućnost Podgorica · FK Zeta · FK Rudar Pljevlja · OFK Petrovac · FK Čelik Nikšić · FK Sutjeska · OFK Titograd · FK Bokelj · FK Lovćen · FK Iskra · Mladost Ljeskopolje · FK Kom · OFK Grbalj




Historic

- **2016** (1):   FK Mogren (1920-2016)






By A to Z

- **B** (4): Bokelj · Budućnost · Bokelj Kotor · Budućnost Podgorica
- **F** (11): FK Kom · FK Zeta · FK Iskra · FK Bokelj · FK Lovćen · FK Sutjeska · FK Mogren Budva · FK Čelik Nikšić · FK Rudar Pljevlja · FK Mogren (1920-2016) · FK Budućnost Podgorica
- **G** (1): Grbalj
- **I** (1): Iskra
- **K** (1): Kom
- **L** (1): Lovćen Cetinje
- **M** (1): Mladost Ljeskopolje
- **O** (3): OFK Grbalj · OFK Petrovac · OFK Titograd
- **P** (1): Petrovac
- **R** (1): Rudar Pljevlja
- **S** (2): Sutjeska · Sutjeska Nikšić
- **T** (1): Titograd
- **Z** (2): Zeta · Zeta Golubovci
- **Č** (1): Čelik Nikšić




