24 clubs

- [**Grasshoppers Zürich**](https://en.wikipedia.org/wiki/Grasshopper_Club_Zürich) : (2) Grasshoppers · Grasshopper Club Zürich ⇒ (4) ≈Grasshoppers Zurich≈ · ≈Grasshoppers Zuerich≈ · ≈Grasshopper Club Zurich≈ · ≈Grasshopper Club Zuerich≈
- [**FC Zürich**](https://en.wikipedia.org/wiki/FC_Zürich) : (1) Zürich ⇒ (4) ≈Zurich≈ · ≈Zuerich≈ · ≈FC Zurich≈ · ≈FC Zuerich≈
- **FC Winterthur** : (1) Winterthur
- [**FC Basel**](https://en.wikipedia.org/wiki/FC_Basel) : (2) Basel · FC Basel 1893
- [**BSC Young Boys**](https://en.wikipedia.org/wiki/BSC_Young_Boys) : (5) BSC YB · YB Bern · Young Boys · Young Boys Bern · Berner Sport Club Young Boys
- **FC Biel-Bienne** : (1) Biel-Bienne
- [**FC Thun**](https://en.wikipedia.org/wiki/FC_Thun) : (2) Thun · FC Thun 1898
- [**FC Luzern**](https://en.wikipedia.org/wiki/FC_Luzern) : (1) Luzern
- [**FC St. Gallen**](https://en.wikipedia.org/wiki/FC_St._Gallen) : (3) St. Gallen · FC Sankt Gallen · FC St. Gallen 1879
- **FC Wil** : (2) Wil · FC Wil 1900
- **FC Schaffhausen**
- **FC Aarau** : (1) Aarau
- **FC Wohlen** : (1) Wohlen
- **FC Wettingen** : (1) FC Wettingen 93
- [**FC Sion**](https://en.wikipedia.org/wiki/FC_Sion) : (1) Sion
- [**Xamax Neuchâtel**](https://en.wikipedia.org/wiki/Neuchâtel_Xamax_FCS) : (5) Xamax · Neuchâtel Xam · Neuchâtel Xamax · Neuchâtel Xamax FC · Neuchâtel Xamax FCS ⇒ (5) ≈Neuchatel Xam≈ · ≈Xamax Neuchatel≈ · ≈Neuchatel Xamax≈ · ≈Neuchatel Xamax FC≈ · ≈Neuchatel Xamax FCS≈
- **FC La Chaux-de-Fonds**
- [**FC Lausanne**](https://en.wikipedia.org/wiki/FC_Lausanne-Sport) : (4) Lausanne · Lausanne Sport · Lausanne Sports · FC Lausanne-Sport
- **FC Le Mont** : (1) FC Le Mont-sur-Lausanne,
- **Servette FC** : (4) Servette · Servette Genève · Servette FC Genève · FC Servette Genf [de] ⇒ (2) ≈Servette Geneve≈ · ≈Servette FC Geneve≈
- [**FC Lugano**](https://en.wikipedia.org/wiki/FC_Lugano) : (1) Lugano
- **FC Chiasso** : (1) Chiasso
- **FC Locarno** : (1) Locarno
- **AC Bellinzona** : (1) Bellinzona




Alphabet

- **Alphabet Specials** (3):  **â**  **è**  **ü** 
  - **â**×5 U+00E2 (226) - LATIN SMALL LETTER A WITH CIRCUMFLEX ⇒ a
  - **è**×2 U+00E8 (232) - LATIN SMALL LETTER E WITH GRAVE ⇒ e
  - **ü**×4 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates





By City

- **Zürich, Zürich** (2): 
  - Grasshoppers Zürich  (2) Grasshoppers · Grasshopper Club Zürich
  - FC Zürich  (1) Zürich
- **Aarau, Aargau** (1): FC Aarau  (1) Aarau
- **Basel, Basel-Stadt** (1): FC Basel  (2) Basel · FC Basel 1893
- **Bellinzona, Ticino** (1): AC Bellinzona  (1) Bellinzona
- **Bern, Bern** (1): BSC Young Boys  (5) Young Boys · Young Boys Bern · Berner Sport Club Young Boys · BSC YB · YB Bern
- **Biel/Bienne, Bern** (1): FC Biel-Bienne  (1) Biel-Bienne
- **Chiasso, Ticino** (1): FC Chiasso  (1) Chiasso
- **Genève, Genève** (1): Servette FC  (4) Servette · Servette Genève · Servette FC Genève · FC Servette Genf [de]
- **La Chaux-de-Fonds, Neuchâtel** (1): FC La Chaux-de-Fonds 
- **Lausanne, Lausanne** (1): FC Lausanne  (4) Lausanne · FC Lausanne-Sport · Lausanne Sports · Lausanne Sport
- **Le Mont-sur-Lausanne, Lausanne** (1): FC Le Mont  (1) FC Le Mont-sur-Lausanne,
- **Locarno, Ticino** (1): FC Locarno  (1) Locarno
- **Lugano, Ticino** (1): FC Lugano  (1) Lugano
- **Luzern, Luzern** (1): FC Luzern  (1) Luzern
- **Neuchâtel, Neuchâtel** (1): Xamax Neuchâtel  (5) Xamax · Neuchâtel Xam · Neuchâtel Xamax · Neuchâtel Xamax FC · Neuchâtel Xamax FCS
- **Schaffhausen, Schaffhausen** (1): FC Schaffhausen 
- **Sion, Valais** (1): FC Sion  (1) Sion
- **St. Gallen, St. Gallen** (1): FC St. Gallen  (3) St. Gallen · FC St. Gallen 1879 · FC Sankt Gallen
- **Thun, Bern** (1): FC Thun  (2) Thun · FC Thun 1898
- **Wettingen, Aargau** (1): FC Wettingen  (1) FC Wettingen 93
- **Wil, St. Gallen** (1): FC Wil  (2) Wil · FC Wil 1900
- **Winterthur, Zürich** (1): FC Winterthur  (1) Winterthur
- **Wohlen, Aargau** (1): FC Wohlen  (1) Wohlen




By Region

- **Zürich** (3):   Grasshoppers Zürich · FC Zürich · FC Winterthur
- **Basel-Stadt** (1):   FC Basel
- **Bern** (3):   BSC Young Boys · FC Biel-Bienne · FC Thun
- **Luzern** (1):   FC Luzern
- **St. Gallen** (2):   FC St. Gallen · FC Wil
- **Schaffhausen** (1):   FC Schaffhausen
- **Aargau** (3):   FC Aarau · FC Wohlen · FC Wettingen
- **Valais** (1):   FC Sion
- **Neuchâtel** (2):   Xamax Neuchâtel · FC La Chaux-de-Fonds
- **Lausanne** (2):   FC Lausanne · FC Le Mont
- **Genève** (1):   Servette FC
- **Ticino** (4):   FC Lugano · FC Chiasso · FC Locarno · AC Bellinzona




By Year

- **1879** (1):   FC St. Gallen
- **1886** (1):   Grasshoppers Zürich
- **1890** (1):   Servette FC
- **1893** (1):   FC Basel
- **1894** (1):   FC La Chaux-de-Fonds
- **1896** (5):   FC Zürich · FC Winterthur · FC Biel-Bienne · FC Schaffhausen · FC Lausanne
- **1898** (2):   BSC Young Boys · FC Thun
- **1900** (1):   FC Wil
- **1901** (1):   FC Luzern
- **1902** (1):   FC Aarau
- **1904** (2):   FC Wohlen · AC Bellinzona
- **1905** (1):   FC Chiasso
- **1906** (1):   FC Locarno
- **1908** (1):   FC Lugano
- **1909** (1):   FC Sion
- **1931** (1):   FC Wettingen
- **1942** (1):   FC Le Mont
- ? (1):   Xamax Neuchâtel






By A to Z

- **A** (2): Aarau · AC Bellinzona
- **B** (6): Basel · BSC YB · Bellinzona · Biel-Bienne · BSC Young Boys · Berner Sport Club Young Boys
- **C** (1): Chiasso
- **F** (28): FC Wil · FC Sion · FC Thun · FC Aarau · FC Basel · FC Lugano · FC Luzern · FC Wohlen · FC Zürich · FC Chiasso · FC Le Mont · FC Locarno · FC Lausanne · FC Wil 1900 · FC Thun 1898 · FC Wettingen · FC Basel 1893 · FC St. Gallen · FC Winterthur · FC Biel-Bienne · FC Sankt Gallen · FC Schaffhausen · FC Wettingen 93 · FC Lausanne-Sport · FC St. Gallen 1879 · FC La Chaux-de-Fonds · FC Servette Genf [de] · FC Le Mont-sur-Lausanne,
- **G** (3): Grasshoppers · Grasshoppers Zürich · Grasshopper Club Zürich
- **L** (6): Lugano · Luzern · Locarno · Lausanne · Lausanne Sport · Lausanne Sports
- **N** (4): Neuchâtel Xam · Neuchâtel Xamax · Neuchâtel Xamax FC · Neuchâtel Xamax FCS
- **S** (6): Sion · Servette · St. Gallen · Servette FC · Servette Genève · Servette FC Genève
- **T** (1): Thun
- **W** (3): Wil · Wohlen · Winterthur
- **X** (2): Xamax · Xamax Neuchâtel
- **Y** (3): YB Bern · Young Boys · Young Boys Bern
- **Z** (1): Zürich




