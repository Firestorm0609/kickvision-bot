15 clubs

- **SP Tre Fiori** : (2) Tre Fiori · SS Tre Fiori FC
- **SP Tre Penne** : (1) Tre Penne
- **AC Juvenes-Dogana** : (2) Juvenes/Dogana · AC Juvenes/Dogana
- **SP La Fiorita** : (2) La Fiorita · La Fiorita 1967
- **AC Libertas** : (1) Libertas
- **SC Faetano** : (1) Faetano
- **SS Murata** : (1) Murata
- **SS Folgore** : (3) Folgore · SS Folgore/Falciano · SS Folgore Falciano Calcio
- **SP Cailungo** : (1) Cailungo
- **SS Cosmos** : (1) Cosmos
- **FC Domagnano** : (2) Domagnano · Domagnano FC
- **FC Fiorentino** : (1) Fiorentino
- **SS Pennarossa** : (1) Pennarossa
- **SS San Giovanni** : (1) San Giovanni
- **Virtus FC** : (1) Virtus




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **AC Juvenes-Dogana**,  (1):
  - `acjuvenesdogana` (2): AC Juvenes-Dogana · AC Juvenes/Dogana




By City

- ? (15): 
  - SP Tre Fiori  (2) Tre Fiori · SS Tre Fiori FC
  - SP Tre Penne  (1) Tre Penne
  - AC Juvenes-Dogana  (2) Juvenes/Dogana · AC Juvenes/Dogana
  - SP La Fiorita  (2) La Fiorita · La Fiorita 1967
  - AC Libertas  (1) Libertas
  - SC Faetano  (1) Faetano
  - SS Murata  (1) Murata
  - SS Folgore  (3) Folgore · SS Folgore Falciano Calcio · SS Folgore/Falciano
  - SP Cailungo  (1) Cailungo
  - SS Cosmos  (1) Cosmos
  - FC Domagnano  (2) Domagnano · Domagnano FC
  - FC Fiorentino  (1) Fiorentino
  - SS Pennarossa  (1) Pennarossa
  - SS San Giovanni  (1) San Giovanni
  - Virtus FC  (1) Virtus




By Region





By Year

- ? (15):   SP Tre Fiori · SP Tre Penne · AC Juvenes-Dogana · SP La Fiorita · AC Libertas · SC Faetano · SS Murata · SS Folgore · SP Cailungo · SS Cosmos · FC Domagnano · FC Fiorentino · SS Pennarossa · SS San Giovanni · Virtus FC






By A to Z

- **A** (3): AC Libertas · AC Juvenes-Dogana · AC Juvenes/Dogana
- **C** (2): Cosmos · Cailungo
- **D** (2): Domagnano · Domagnano FC
- **F** (5): Faetano · Folgore · Fiorentino · FC Domagnano · FC Fiorentino
- **J** (1): Juvenes/Dogana
- **L** (3): Libertas · La Fiorita · La Fiorita 1967
- **M** (1): Murata
- **P** (1): Pennarossa
- **S** (14): SS Cosmos · SS Murata · SC Faetano · SS Folgore · SP Cailungo · SP Tre Fiori · SP Tre Penne · San Giovanni · SP La Fiorita · SS Pennarossa · SS San Giovanni · SS Tre Fiori FC · SS Folgore/Falciano · SS Folgore Falciano Calcio
- **T** (2): Tre Fiori · Tre Penne
- **V** (2): Virtus · Virtus FC




