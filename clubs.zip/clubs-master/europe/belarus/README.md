21 clubs

- **FC BATE Borisov** : (3) BATE · BATE Borisov · BATE Borissow
- **FC Gomel** : (2) Gomel · FK Gomel
- **FC Dinamo Minsk** : (1) Dinamo Minsk
- **FC Dinamo-93 Minsk (1992-1998)** : (1) Dinamo-93 Minsk
- **FC Partizan Minsk** : (1) Partizan Minsk
- **FC Minsk** : (1) Minsk
- **FC Dnepr Mogilev** : (2) Dnepr · Dnepr Mogilev
- **FC Shakhtyor Soligorsk** : (4) Shakhtyor · Shakhter Soligorsk · Shakhtyor Soligorsk · Shakhtior Saligorsk
- **FC Naftan Novopolotsk** : (1) Naftan
- **FC Torpedo Zhodino** : (2) Torpedo Zhodino · FC Torpedo-Belaz Zhodino
- **FC Dinamo Brest** : (3) Dinamo Brest · Dynamo Brest · FC Dynamo Brest
- **FC Neman Grodno** : (2) Neman · Neman Grodno
- **FC Isloch** : (1) Isloch
- **FC Gorodeya** : (1) Gorodeya
- **SFC Slutsk** : (2) Slutsk · Slutsksak. Slutsk
- **FC Slavia-Mozyr** : (2) Slavia-Mozyr · FK Slaviya Mozyr
- **FC Vitebsk** : (2) Vitebsk · FK Vitebsk
- **FC Zvezda-BGU Minsk** : (2) Zvezda · FC BGU Minsk
- **FC Dnyapro Mogilev** : (1) FK Dnyapro Mogilev
- **FC Torpedo-SKA Minsk** : (2) Torpedo-SKA · FC Torpedo Minsk
- **FC Belshina Bobruisk** : (2) Belshina Bobruisk · FK Belshyna Babruisk




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Barysaw** (1): FC BATE Borisov  (3) BATE · BATE Borisov · BATE Borissow
- **Bobruisk** (1): FC Belshina Bobruisk  (2) Belshina Bobruisk · FK Belshyna Babruisk
- ? (19): 
  - FC Gomel  (2) Gomel · FK Gomel
  - FC Dinamo Minsk  (1) Dinamo Minsk
  - FC Dinamo-93 Minsk (1992-1998)  (1) Dinamo-93 Minsk
  - FC Partizan Minsk  (1) Partizan Minsk
  - FC Minsk  (1) Minsk
  - FC Dnepr Mogilev  (2) Dnepr · Dnepr Mogilev
  - FC Shakhtyor Soligorsk  (4) Shakhtyor · Shakhter Soligorsk · Shakhtyor Soligorsk · Shakhtior Saligorsk
  - FC Naftan Novopolotsk  (1) Naftan
  - FC Torpedo Zhodino  (2) Torpedo Zhodino · FC Torpedo-Belaz Zhodino
  - FC Dinamo Brest  (3) Dinamo Brest · Dynamo Brest · FC Dynamo Brest
  - FC Neman Grodno  (2) Neman · Neman Grodno
  - FC Isloch  (1) Isloch
  - FC Gorodeya  (1) Gorodeya
  - SFC Slutsk  (2) Slutsk · Slutsksak. Slutsk
  - FC Slavia-Mozyr  (2) Slavia-Mozyr · FK Slaviya Mozyr
  - FC Vitebsk  (2) Vitebsk · FK Vitebsk
  - FC Zvezda-BGU Minsk  (2) Zvezda · FC BGU Minsk
  - FC Dnyapro Mogilev  (1) FK Dnyapro Mogilev
  - FC Torpedo-SKA Minsk  (2) Torpedo-SKA · FC Torpedo Minsk




By Region

- **Barysaw†** (1):   FC BATE Borisov
- **Bobruisk†** (1):   FC Belshina Bobruisk




By Year

- **1976** (1):   FC Belshina Bobruisk
- **1992** (1):   FC Dinamo-93 Minsk (1992-1998)
- ? (19):   FC BATE Borisov · FC Gomel · FC Dinamo Minsk · FC Partizan Minsk · FC Minsk · FC Dnepr Mogilev · FC Shakhtyor Soligorsk · FC Naftan Novopolotsk · FC Torpedo Zhodino · FC Dinamo Brest · FC Neman Grodno · FC Isloch · FC Gorodeya · SFC Slutsk · FC Slavia-Mozyr · FC Vitebsk · FC Zvezda-BGU Minsk · FC Dnyapro Mogilev · FC Torpedo-SKA Minsk




Historic

- **1998** (1):   FC Dinamo-93 Minsk (1992-1998)






By A to Z

- **B** (4): BATE · BATE Borisov · BATE Borissow · Belshina Bobruisk
- **D** (6): Dnepr · Dinamo Brest · Dinamo Minsk · Dynamo Brest · Dnepr Mogilev · Dinamo-93 Minsk
- **F** (29): FC Gomel · FC Minsk · FK Gomel · FC Isloch · FC Vitebsk · FK Vitebsk · FC Gorodeya · FC BGU Minsk · FC BATE Borisov · FC Dinamo Brest · FC Dinamo Minsk · FC Dynamo Brest · FC Neman Grodno · FC Slavia-Mozyr · FC Dnepr Mogilev · FC Torpedo Minsk · FK Slaviya Mozyr · FC Partizan Minsk · FC Dnyapro Mogilev · FC Torpedo Zhodino · FK Dnyapro Mogilev · FC Zvezda-BGU Minsk · FC Belshina Bobruisk · FC Torpedo-SKA Minsk · FK Belshyna Babruisk · FC Naftan Novopolotsk · FC Shakhtyor Soligorsk · FC Torpedo-Belaz Zhodino · FC Dinamo-93 Minsk (1992-1998)
- **G** (2): Gomel · Gorodeya
- **I** (1): Isloch
- **M** (1): Minsk
- **N** (3): Neman · Naftan · Neman Grodno
- **P** (1): Partizan Minsk
- **S** (8): Slutsk · Shakhtyor · SFC Slutsk · Slavia-Mozyr · Slutsksak. Slutsk · Shakhter Soligorsk · Shakhtior Saligorsk · Shakhtyor Soligorsk
- **T** (2): Torpedo-SKA · Torpedo Zhodino
- **V** (1): Vitebsk
- **Z** (1): Zvezda




