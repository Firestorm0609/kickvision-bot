54 clubs

- [**Lokomotiv Moskva**](https://en.wikipedia.org/wiki/FC_Lokomotiv_Moscow) : (7) Lokomotiv · FC Lokomotiv · Lok Moskau [de] · Loko Moscow [en] · FC Lokomotiv Moskva · Lokomotiv Moscow [en] · FC Lokomotiv Moscow [en]
- [**PFC CSKA Moskva**](https://en.wikipedia.org/wiki/PFC_CSKA_Moscow) : (7) CSKA · PFK CSCA · CSKA Moskva · CSKA Moscow [en] · ZSKA Moskau [de] · PFK CSKA Moscow [en] · PFC CSKA Moscow [en]
- [**Dynamo Moskva**](https://en.wikipedia.org/wiki/FC_Dynamo_Moscow) : (9) Dynamo · Dinamo · Dinamo Moskva · FC Dinamo Moskva · Dynamo Mosc [en] · Dynamo Moscow [en] · Dinamo Moscow [en] · Dinamo Moskau [de] · FC Dynamo Moscow [en]
- [**FC Spartak Moskva**](https://en.wikipedia.org/wiki/FC_Spartak_Moscow) : (7) Spartak · FC Spartak · Spartak Moskva · Spartak Moskau [de] · Spartak Moscow [en] · FC Spartak Moscow [en] · FC Spartak Moskau [de]
- **Spartak Moskva II** : (1) Spartak Moskau II [de]
- [**FC Moskva**](https://en.wikipedia.org/wiki/FC_Moscow) : (3) Moskva · FK Moskva · FC Moscow [en]
- [**Torpedo Moskva**](https://en.wikipedia.org/wiki/FC_Torpedo_Moscow) : (6) Torpedo · T. Moscow [en] · FC Torpedo Moskva · Torpedo Moscow [en] · FC Torpedo Moscow [en] · FC Torpedo Moskau [de]
- **FC Chertanovo Moskva** : (3) Chertanovo Moscow [en] · FC Chertanovo Mosk [de] · FC Chertanovo Moscow [en]
- [**Zenit St. Petersburg**](https://en.wikipedia.org/wiki/FC_Zenit_Saint_Petersburg) : (9) Zenit · FC Zenit · Zenit Petersb. · Zenit St. Peter · Zenit Petersburg · Zenit St. Petersb. · Zenit Saint Petersburg · FC Zenit St Petersburg · FC Zenit Saint Petersburg
- **Dinamo St. Petersburg**
- **PFC Sochi** : (3) Sochi · FK Sochi [de] · Professional Football Club Sochi
- [**FC Rubin Kazan**](https://en.wikipedia.org/wiki/FC_Rubin_Kazan) : (3) Rubin · FC Rubin · Rubin Kazan
- [**FC Amkar Perm**](https://en.wikipedia.org/wiki/FC_Amkar_Perm) : (2) Amkar · Amkar Perm
- [**FC Anzhi Makhachkala**](https://en.wikipedia.org/wiki/FC_Anzhi_Makhachkala) : (5) Anji · Anzhi · Anzhi Makhachkala · FK Anzi Makhackala · FC Anji Makhachkala
- [**FC Sibir Novosibirsk**](https://en.wikipedia.org/wiki/FC_Sibir_Novosibirsk) : (4) Sibir · Sibir' · FC Sibir · Sibir Novosibirsk
- [**FC Alania Vladikavkaz**](https://en.wikipedia.org/wiki/FC_Alania_Vladikavkaz) : (3) Alania · Alaniya · Alania Vladikavkaz
- [**PFC Krylya Sovetov Samara**](https://en.wikipedia.org/wiki/PFC_Krylia_Sovetov_Samara) : (9) Samara · Krylya Sovetov · Krylia Sovetov · Kryl'ia Sovetov · Kryliya Sovetov [de] · Krylia Sovetov Samara · Krylya Sovetov Samara · FK Krylya Sovetov Samara · PFC Krylia Sovetov Samara
- [**Arsenal Tula**](https://en.wikipedia.org/wiki/FC_Arsenal_Tula) : (2) Arsenal · FC Arsenal Tula
- [**Chernomorets Novorosisk**](https://en.wikipedia.org/wiki/FC_Chernomorets_Novorossiysk) : (4) Chernomorets · Chernomorets Novorossisk · FC Chernomorets Novorossiysk · FC Chernomorets Krasnodarskiy Kray
- **FC Khimki** : (2) Khimki · FK Khimki [de]
- [**FC Krasnodar**](https://en.wikipedia.org/wiki/FC_Krasnodar) : (3) Krasnodar · FK Krasnodar · Krasnodar Krasnodar
- **FC Krasnodar 2**
- [**FC Kuban**](https://en.wikipedia.org/wiki/FC_Kuban_Krasnodar) : (4) Kuban · Kuban' · Kuban Krasnodar · FC Kuban Krasnodar
- **FC Baltika** : (3) FK Baltika · Baltika Kaliningrad · FC Baltika Kaliningrad
- **Luch Energia Vladivostok** : (3) Luch · Luch Vladivostok · Luch Wladivostok [de]
- **FC Mordovia** : (3) Mordovia · M. Saransk · Mordovia Saransk
- **Spartak Nalchik** : (1) Nalchik
- **Nizhnii Novgorod** : (2) Nizhny Novgorod · FC Nizhny Novgorod
- [**FC Rostov**](https://en.wikipedia.org/wiki/FC_Rostov) : (3) Rostov · FK Rostov · Rostov Rostov-on-Don
- **Rotor** : (4) Rotor Volgograd · FC Rotor Volgograd · SC Rotor Volgograd · FC Rotor Wolgograd [de]
- **Saturn**
- **Shinnik** : (1) Shinnik Yaroslavl
- **SKA Khabarovsk** : (4) SKA Energia · SKA-Energiia · Energ. Khabarovsk · FC SKA-Khabarovsk
- **Sokol**
- [**Terek Grozny**](https://en.wikipedia.org/wiki/FC_Terek_Grozny) : (2) Terek · FC Terek Grozny
- [**Akhmat Grozny**](https://en.wikipedia.org/wiki/FC_Akhmat_Grozny) : (4) Akhmat · FC Akhmat Grozny · FK Akhmat Grozny · FK Achmat Grozny [de]
- [**Tom Tomsk**](https://en.wikipedia.org/wiki/FC_Tom_Tomsk) : (4) Tom · Tom' · Tomsk · FC Tom Tomsk
- **Tosno** : (1) FK Tosno
- [**FC Ufa**](https://en.wikipedia.org/wiki/FC_Ufa) : (2) Ufa · Ufa Ufa
- [**Ural Yekaterinburg**](https://en.wikipedia.org/wiki/FC_Ural_Yekaterinburg) : (6) Ural · FC Ural · FC Ural Yekaterinburg · Ural Jekaterinburg [de] · FC Ural Sverdlovsk Oblast · Football Club Ural Sverdlovsk Oblast
- **Uralan**
- **Volga Nizhnii Novgorod** : (3) Volga · Volga Nyzhnyi · Volga N. Novgorod
- **FC Tambov** : (2) Tambov · FK Tambov
- [**FC Orenburg**](https://en.wikipedia.org/wiki/FC_Orenburg) : (3) Orenburg · FK Orenburg · Gazovik Orenburg
- **Volgar-Astrakhan**
- **Vladikavkaz** : (2) Spartak Vladikavkaz · FC Spartak Vladikavkaz
- [**Yenisey**](https://en.wikipedia.org/wiki/FC_Yenisey_Krasnoyarsk) : (3) FC Yenisey · Yenisey Krasnoyarsk · FC Yenisey Krasnoyarsk
- **FC Avangard Kursk**
- **FC Tekstilshchik Ivanovo** : (1) Tekstilshchik
- **Neftekhimik Nizhnekamsk** : (2) FC Neftekhimik · FC Neftekhimik Nizhnekamsk
- **FC Chayka** : (2) Chayka Peschanokopskoye · FC Chayka Peschanokopskoye
- **FC Fakel Voronezh** : (2) Fakel Voronezh · Fakel Worenesch [de]
- **FC Armavir** : (1) Torpedo Armavir
- **FC Tekstilshchik Kamyshin** : (4) Tekstilshchik · FC Rotor Kamyshin · Tekstilschik Kamyshin · Tekstilshchik Kamyshin




Alphabet

- **Alphabet Specials** (0): 




Duplicates

- **FC Sibir Novosibirsk**, Novosibirsk (1):
  - `sibir` (2): Sibir · Sibir'
- **PFC Krylya Sovetov Samara**, Samara (1):
  - `kryliasovetov` (2): Krylia Sovetov · Kryl'ia Sovetov
- **FC Kuban**, Krasnodar (1):
  - `kuban` (2): Kuban · Kuban'
- **Tom Tomsk**, Tomsk (1):
  - `tom` (2): Tom · Tom'




By City

- **Moskva** (8): 
  - Lokomotiv Moskva  (7) Lokomotiv · FC Lokomotiv · FC Lokomotiv Moskva · Loko Moscow [en] · Lokomotiv Moscow [en] · FC Lokomotiv Moscow [en] · Lok Moskau [de]
  - PFC CSKA Moskva  (7) CSKA · PFK CSCA · CSKA Moskva · CSKA Moscow [en] · PFC CSKA Moscow [en] · PFK CSKA Moscow [en] · ZSKA Moskau [de]
  - Dynamo Moskva  (9) Dynamo · Dinamo · Dinamo Moskva · FC Dinamo Moskva · Dynamo Mosc [en] · Dynamo Moscow [en] · Dinamo Moscow [en] · FC Dynamo Moscow [en] · Dinamo Moskau [de]
  - FC Spartak Moskva  (7) Spartak · FC Spartak · Spartak Moskva · Spartak Moscow [en] · FC Spartak Moscow [en] · Spartak Moskau [de] · FC Spartak Moskau [de]
  - Spartak Moskva II  (1) Spartak Moskau II [de]
  - FC Moskva  (3) Moskva · FK Moskva · FC Moscow [en]
  - Torpedo Moskva  (6) Torpedo · FC Torpedo Moskva · T. Moscow [en] · Torpedo Moscow [en] · FC Torpedo Moscow [en] · FC Torpedo Moskau [de]
  - FC Chertanovo Moskva  (3) Chertanovo Moscow [en] · FC Chertanovo Moscow [en] · FC Chertanovo Mosk [de]
- **Krasnodar** (3): 
  - FC Krasnodar  (3) Krasnodar · Krasnodar Krasnodar · FK Krasnodar
  - FC Krasnodar 2 
  - FC Kuban  (4) Kuban · Kuban' · Kuban Krasnodar · FC Kuban Krasnodar
- **Grozny** (2): 
  - Terek Grozny  (2) Terek · FC Terek Grozny
  - Akhmat Grozny  (4) Akhmat · FC Akhmat Grozny · FK Akhmat Grozny · FK Achmat Grozny [de]
- **Nizhny Novgorod** (2): 
  - Nizhnii Novgorod  (2) Nizhny Novgorod · FC Nizhny Novgorod
  - Volga Nizhnii Novgorod  (3) Volga · Volga N. Novgorod · Volga Nyzhnyi
- **St. Petersburg** (2): 
  - Zenit St. Petersburg  (9) Zenit · Zenit Petersb. · Zenit Petersburg · Zenit St. Peter · Zenit St. Petersb. · Zenit Saint Petersburg · FC Zenit · FC Zenit St Petersburg · FC Zenit Saint Petersburg
  - Dinamo St. Petersburg 
- **Armavir** (1): FC Armavir  (1) Torpedo Armavir
- **Astrakhan** (1): Volgar-Astrakhan 
- **Elista** (1): Uralan 
- **Ivanovo** (1): FC Tekstilshchik Ivanovo  (1) Tekstilshchik
- **Kaliningrad** (1): FC Baltika  (3) Baltika Kaliningrad · FC Baltika Kaliningrad · FK Baltika
- **Kamyshin** (1): FC Tekstilshchik Kamyshin  (4) Tekstilshchik · Tekstilshchik Kamyshin · Tekstilschik Kamyshin · FC Rotor Kamyshin
- **Kazan** (1): FC Rubin Kazan  (3) Rubin · FC Rubin · Rubin Kazan
- **Khabarovsk** (1): SKA Khabarovsk  (4) SKA-Energiia · SKA Energia · Energ. Khabarovsk · FC SKA-Khabarovsk
- **Khimki** (1): FC Khimki  (2) Khimki · FK Khimki [de]
- **Krasnoyarsk** (1): Yenisey  (3) FC Yenisey · Yenisey Krasnoyarsk · FC Yenisey Krasnoyarsk
- **Kursk** (1): FC Avangard Kursk 
- **Makhachkala** (1): FC Anzhi Makhachkala  (5) Anzhi · Anzhi Makhachkala · FK Anzi Makhackala · Anji · FC Anji Makhachkala
- **Nalchik** (1): Spartak Nalchik  (1) Nalchik
- **Nizhnekamsk** (1): Neftekhimik Nizhnekamsk  (2) FC Neftekhimik · FC Neftekhimik Nizhnekamsk
- **Novorosisk** (1): Chernomorets Novorosisk  (4) Chernomorets · FC Chernomorets Novorossiysk · FC Chernomorets Krasnodarskiy Kray · Chernomorets Novorossisk
- **Novosibirsk** (1): FC Sibir Novosibirsk  (4) Sibir · Sibir' · FC Sibir · Sibir Novosibirsk
- **Orenburg** (1): FC Orenburg  (3) Orenburg · FK Orenburg · Gazovik Orenburg
- **Perm** (1): FC Amkar Perm  (2) Amkar · Amkar Perm
- **Peschanokopskoye** (1): FC Chayka  (2) Chayka Peschanokopskoye · FC Chayka Peschanokopskoye
- **Ramenskoe** (1): Saturn 
- **Rostov-on-Don** (1): FC Rostov  (3) Rostov · Rostov Rostov-on-Don · FK Rostov
- **Samara** (1): PFC Krylya Sovetov Samara  (9) Samara · Krylya Sovetov · FK Krylya Sovetov Samara · Krylia Sovetov · Kryl'ia Sovetov · Krylia Sovetov Samara · PFC Krylia Sovetov Samara · Krylya Sovetov Samara · Kryliya Sovetov [de]
- **Saransk** (1): FC Mordovia  (3) Mordovia · Mordovia Saransk · M. Saransk
- **Saratov** (1): Sokol 
- **Sochi** (1): PFC Sochi  (3) Sochi · Professional Football Club Sochi · FK Sochi [de]
- **Tambov** (1): FC Tambov  (2) Tambov · FK Tambov
- **Tomsk** (1): Tom Tomsk  (4) Tom · Tom' · Tomsk · FC Tom Tomsk
- **Tosno** (1): Tosno  (1) FK Tosno
- **Tula** (1): Arsenal Tula  (2) Arsenal · FC Arsenal Tula
- **Ufa** (1): FC Ufa  (2) Ufa · Ufa Ufa
- **Vladikavkaz** (1): Vladikavkaz  (2) Spartak Vladikavkaz · FC Spartak Vladikavkaz
- **Vladikovkaz** (1): FC Alania Vladikavkaz  (3) Alania · Alania Vladikavkaz · Alaniya
- **Vladivostok** (1): Luch Energia Vladivostok  (3) Luch · Luch Vladivostok · Luch Wladivostok [de]
- **Volgograd** (1): Rotor  (4) Rotor Volgograd · FC Rotor Volgograd · SC Rotor Volgograd · FC Rotor Wolgograd [de]
- **Voronezh** (1): FC Fakel Voronezh  (2) Fakel Voronezh · Fakel Worenesch [de]
- **Yaroslavl** (1): Shinnik  (1) Shinnik Yaroslavl
- **Yekaterinburg** (1): Ural Yekaterinburg  (6) Ural · FC Ural · FC Ural Yekaterinburg · FC Ural Sverdlovsk Oblast · Football Club Ural Sverdlovsk Oblast · Ural Jekaterinburg [de]




By Region

- **Moskva†** (8):   Lokomotiv Moskva · PFC CSKA Moskva · Dynamo Moskva · FC Spartak Moskva · Spartak Moskva II · FC Moskva · Torpedo Moskva · FC Chertanovo Moskva
- **St. Petersburg†** (2):   Zenit St. Petersburg · Dinamo St. Petersburg
- **Sochi†** (1):   PFC Sochi
- **Kazan†** (1):   FC Rubin Kazan
- **Perm†** (1):   FC Amkar Perm
- **Makhachkala†** (1):   FC Anzhi Makhachkala
- **Novosibirsk†** (1):   FC Sibir Novosibirsk
- **Vladikovkaz†** (1):   FC Alania Vladikavkaz
- **Samara†** (1):   PFC Krylya Sovetov Samara
- **Tula†** (1):   Arsenal Tula
- **Novorosisk†** (1):   Chernomorets Novorosisk
- **Khimki†** (1):   FC Khimki
- **Krasnodar†** (3):   FC Krasnodar · FC Krasnodar 2 · FC Kuban
- **Kaliningrad†** (1):   FC Baltika
- **Vladivostok†** (1):   Luch Energia Vladivostok
- **Saransk†** (1):   FC Mordovia
- **Nalchik†** (1):   Spartak Nalchik
- **Nizhny Novgorod†** (2):   Nizhnii Novgorod · Volga Nizhnii Novgorod
- **Rostov-on-Don†** (1):   FC Rostov
- **Volgograd†** (1):   Rotor
- **Ramenskoe†** (1):   Saturn
- **Yaroslavl†** (1):   Shinnik
- **Khabarovsk†** (1):   SKA Khabarovsk
- **Saratov†** (1):   Sokol
- **Grozny†** (2):   Terek Grozny · Akhmat Grozny
- **Tomsk†** (1):   Tom Tomsk
- **Tosno†** (1):   Tosno
- **Ufa†** (1):   FC Ufa
- **Yekaterinburg†** (1):   Ural Yekaterinburg
- **Elista†** (1):   Uralan
- **Tambov†** (1):   FC Tambov
- **Orenburg†** (1):   FC Orenburg
- **Astrakhan†** (1):   Volgar-Astrakhan
- **Vladikavkaz†** (1):   Vladikavkaz
- **Krasnoyarsk†** (1):   Yenisey
- **Kursk†** (1):   FC Avangard Kursk
- **Ivanovo†** (1):   FC Tekstilshchik Ivanovo
- **Nizhnekamsk†** (1):   Neftekhimik Nizhnekamsk
- **Peschanokopskoye†** (1):   FC Chayka
- **Voronezh†** (1):   FC Fakel Voronezh
- **Armavir†** (1):   FC Armavir
- **Kamyshin†** (1):   FC Tekstilshchik Kamyshin




By Year

- **1907** (1):   Chernomorets Novorosisk
- **1911** (1):   PFC CSKA Moskva
- **1922** (1):   FC Spartak Moskva
- **1923** (2):   Lokomotiv Moskva · Dynamo Moskva
- **1925** (1):   Zenit St. Petersburg
- **1958** (2):   FC Rubin Kazan · FC Tekstilshchik Kamyshin
- **1991** (1):   FC Anzhi Makhachkala
- **1994** (1):   FC Amkar Perm
- **2013** (1):   FC Tambov
- **2018** (1):   PFC Sochi
- ? (42):   Spartak Moskva II · FC Moskva · Torpedo Moskva · FC Chertanovo Moskva · Dinamo St. Petersburg · FC Sibir Novosibirsk · FC Alania Vladikavkaz · PFC Krylya Sovetov Samara · Arsenal Tula · FC Khimki · FC Krasnodar · FC Krasnodar 2 · FC Kuban · FC Baltika · Luch Energia Vladivostok · FC Mordovia · Spartak Nalchik · Nizhnii Novgorod · FC Rostov · Rotor · Saturn · Shinnik · SKA Khabarovsk · Sokol · Terek Grozny · Akhmat Grozny · Tom Tomsk · Tosno · FC Ufa · Ural Yekaterinburg · Uralan · Volga Nizhnii Novgorod · FC Orenburg · Volgar-Astrakhan · Vladikavkaz · Yenisey · FC Avangard Kursk · FC Tekstilshchik Ivanovo · Neftekhimik Nizhnekamsk · FC Chayka · FC Fakel Voronezh · FC Armavir






By A to Z

- **A** (12): Anji · Amkar · Anzhi · Akhmat · Alania · Alaniya · Arsenal · Amkar Perm · Arsenal Tula · Akhmat Grozny · Anzhi Makhachkala · Alania Vladikavkaz
- **B** (1): Baltika Kaliningrad
- **C** (8): CSKA · CSKA Moskva · Chernomorets · CSKA Moscow [en] · Chertanovo Moscow [en] · Chayka Peschanokopskoye · Chernomorets Novorosisk · Chernomorets Novorossisk
- **D** (9): Dinamo · Dynamo · Dinamo Moskva · Dynamo Moskva · Dynamo Mosc [en] · Dinamo Moscow [en] · Dinamo Moskau [de] · Dynamo Moscow [en] · Dinamo St. Petersburg
- **E** (1): Energ. Khabarovsk
- **F** (82): FC Ufa · FC Ural · FC Kuban · FC Rubin · FC Sibir · FC Zenit · FK Tosno · FC Chayka · FC Khimki · FC Moskva · FC Rostov · FC Tambov · FK Moskva · FK Rostov · FK Tambov · FC Armavir · FC Baltika · FC Spartak · FC Yenisey · FK Baltika · FC Mordovia · FC Orenburg · FK Orenburg · FC Krasnodar · FC Lokomotiv · FC Tom Tomsk · FK Krasnodar · FC Amkar Perm · FK Sochi [de] · FC Krasnodar 2 · FC Moscow [en] · FC Neftekhimik · FC Rubin Kazan · FK Khimki [de] · Fakel Voronezh · FC Arsenal Tula · FC Terek Grozny · FC Akhmat Grozny · FC Dinamo Moskva · FK Akhmat Grozny · FC Avangard Kursk · FC Fakel Voronezh · FC Rotor Kamyshin · FC SKA-Khabarovsk · FC Spartak Moskva · FC Torpedo Moskva · FC Kuban Krasnodar · FC Nizhny Novgorod · FC Rotor Volgograd · FK Anzi Makhackala · FC Anji Makhachkala · FC Lokomotiv Moskva · FC Anzhi Makhachkala · FC Chertanovo Moskva · FC Sibir Novosibirsk · Fakel Worenesch [de] · FC Alania Vladikavkaz · FC Dynamo Moscow [en] · FC Ural Yekaterinburg · FK Achmat Grozny [de] · FC Baltika Kaliningrad · FC Spartak Moscow [en] · FC Spartak Moskau [de] · FC Spartak Vladikavkaz · FC Torpedo Moscow [en] · FC Torpedo Moskau [de] · FC Yenisey Krasnoyarsk · FC Zenit St Petersburg · FC Chertanovo Mosk [de] · FC Rotor Wolgograd [de] · FC Lokomotiv Moscow [en] · FC Tekstilshchik Ivanovo · FK Krylya Sovetov Samara · FC Chertanovo Moscow [en] · FC Tekstilshchik Kamyshin · FC Ural Sverdlovsk Oblast · FC Zenit Saint Petersburg · FC Chayka Peschanokopskoye · FC Neftekhimik Nizhnekamsk · FC Chernomorets Novorossiysk · FC Chernomorets Krasnodarskiy Kray · Football Club Ural Sverdlovsk Oblast
- **G** (1): Gazovik Orenburg
- **K** (12): Kuban · Khimki · Kuban' · Krasnodar · Krylia Sovetov · Krylya Sovetov · Kryl'ia Sovetov · Kuban Krasnodar · Krasnodar Krasnodar · Kryliya Sovetov [de] · Krylia Sovetov Samara · Krylya Sovetov Samara
- **L** (9): Luch · Lokomotiv · Lok Moskau [de] · Loko Moscow [en] · Lokomotiv Moskva · Luch Vladivostok · Lokomotiv Moscow [en] · Luch Wladivostok [de] · Luch Energia Vladivostok
- **M** (4): Moskva · Mordovia · M. Saransk · Mordovia Saransk
- **N** (4): Nalchik · Nizhny Novgorod · Nizhnii Novgorod · Neftekhimik Nizhnekamsk
- **O** (1): Orenburg
- **P** (8): PFK CSCA · PFC Sochi · PFC CSKA Moskva · PFC CSKA Moscow [en] · PFK CSKA Moscow [en] · PFC Krylia Sovetov Samara · PFC Krylya Sovetov Samara · Professional Football Club Sochi
- **R** (6): Rotor · Rubin · Rostov · Rubin Kazan · Rotor Volgograd · Rostov Rostov-on-Don
- **S** (21): Sibir · Sochi · Sokol · Samara · Saturn · Sibir' · Shinnik · Spartak · SKA Energia · SKA-Energiia · SKA Khabarovsk · Spartak Moskva · Spartak Nalchik · Shinnik Yaroslavl · Sibir Novosibirsk · Spartak Moskva II · SC Rotor Volgograd · Spartak Moscow [en] · Spartak Moskau [de] · Spartak Vladikavkaz · Spartak Moskau II [de]
- **T** (16): Tom · Tom' · Terek · Tomsk · Tosno · Tambov · Torpedo · Tom Tomsk · Terek Grozny · !! **Tekstilshchik (2)** !! · T. Moscow [en] · Torpedo Moskva · Torpedo Armavir · Torpedo Moscow [en] · Tekstilschik Kamyshin · Tekstilshchik Kamyshin
- **U** (6): Ufa · Ural · Uralan · Ufa Ufa · Ural Yekaterinburg · Ural Jekaterinburg [de]
- **V** (6): Volga · Vladikavkaz · Volga Nyzhnyi · Volgar-Astrakhan · Volga N. Novgorod · Volga Nizhnii Novgorod
- **Y** (2): Yenisey · Yenisey Krasnoyarsk
- **Z** (8): Zenit · Zenit Petersb. · Zenit St. Peter · ZSKA Moskau [de] · Zenit Petersburg · Zenit St. Petersb. · Zenit St. Petersburg · Zenit Saint Petersburg




