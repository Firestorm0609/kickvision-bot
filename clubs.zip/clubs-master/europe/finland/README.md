38 clubs

- **HJK Helsinki** : (2) HJK · Helsingin Jalkapalloklubi
- **HIFK Helsinki** : (5) HIFK · HIFK Fotboll · Helsinki IFK · Helsingfors IFK · IFK Helsingfors
- **HPS Helsinki** : (2) HPS · Helsingin Palloseura
- **Finnairin Palloilijat Helsinki (1965-1998)** : (3) FinnPa · FinnPa Helsinki · Finnairin Palloilijat
- **FC Jokerit (1999-2004)**
- **FC Haka Valkeakoski** : (2) Haka Valkeakoski · Valkeakosken Haka
- **FC Inter Turku** : (2) FC Inter · Inter Turku
- **TPS Turku** : (3) TPS · Turku PS · Turun Palloseura
- **FC Honka Espoo** : (3) Honka · FC Honka · Honka Espoo
- **KuPS Kuopio** : (4) KuPS · Kuopio PS · Kuopion PS · Kuopion Palloseura
- **Koparit Kuopio (1931-1990)** : (4) KPT · Koparit · Koparit FC · Kuopion Pallotoverit
- **Myllykosken Pallo -47** : (5) MYPA · MyPa · MyPa-47 · Myllykosken Pallo-47 · Myllykosken Pallo −47
- **FC Lahti** : (1) Lahti
- **FC Kuusysi** : (1) Kuusysi Lahti
- **FC Reipas Lahti** : (2) FC Reipas · Reipas Lahti
- **JJK Jyväskylä** : (3) JJK · Jyvaskyla JK · JJK Jyvaskyla ⇒ (2) ≈JJK Jyvaskyla≈ · ≈JJK Jyvaeskylae≈
- **Tampere United**
- **FC Ilves** : (4) Ilves · Ilves Tampere · Tampereen Ilves · FC Ilves Tampere
- **Ilves-Kissat Tampere** : (2) Ilves-Kissat · Tampereen-Viipurin Ilves-Kissat
- **Tampereen Pallo-Veikot** : (2) TPV · TPV Tampere
- **IFK Mariehamn** : (1) Mariehamn
- **KPV Kokkola** : (2) KPV · Kokkolan Palloveikot
- **Rovaniemen Palloseura** : (4) RoPS · Rovaniemi · Rovaniemi PS · RoPS Rovaniemi
- **SJK Seinäjoki** : (4) SJK · Seinäjoki · Seinäjoen JK · Seinäjoen Jalkapallokerho ⇒ (8) ≈Seinajoki≈ · ≈Seinaejoki≈ · ≈Seinajoen JK≈ · ≈SJK Seinajoki≈ · ≈Seinaejoen JK≈ · ≈SJK Seinaejoki≈ · ≈Seinajoen Jalkapallokerho≈ · ≈Seinaejoen Jalkapallokerho≈
- **Vaasan Palloseura** : (4) VPS · Vaasa PS · VPS Vaasa · Vaasan PS
- **FC Haka** : (1) Haka
- **FF Jaro** : (2) Jaro · Fotbollsföreningen Jaro Jalkapalloseura ⇒ (2) ≈Fotbollsforeningen Jaro Jalkapalloseura≈ · ≈Fotbollsfoereningen Jaro Jalkapalloseura≈
- **KTP Kotka** : (3) KTP · FC KTP · Kotkan Työväen Palloilijat ⇒ (2) ≈Kotkan Tyovaen Palloilijat≈ · ≈Kotkan Tyoevaeen Palloilijat≈
- **PK-35 Vantaa** : (2) PK-35 · Pallokerho-35
- **Palloseura Kemi Kings** : (3) PS Kemi · Kemi City FC · Kemi City Football Club
- **Ekenäs IF** ⇒ (2) ≈Ekenas IF≈ · ≈Ekenaes IF≈
- **PEPO Lappeenranta** : (1) PEPO
- **JIPPO Joensuu** : (1) JIPPO
- **FC Jazz** : (1) FC Jazz Pori
- **AC Oulu**
- **OPS Oulu** : (2) OPS · Oulun Palloseura
- **Mikkelin Palloilijat** : (2) MP · MP Mikkeli
- **AC Vantaan Allianssi (2002-2006)** : (1) AC Allianssi




Alphabet

- **Alphabet Specials** (3):  **ä**  **ö**  **−** 
  - **ä**×8 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **ö**×2 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **−**×1 U+2212 (8722) - MINUS SIGN ⇒ **?**




Duplicates

- **Myllykosken Pallo -47**, Myllykoski (2):
  - `myllykoskenpallo47` (3): Myllykosken Pallo -47 · Myllykosken Pallo-47 · Myllykosken Pallo −47
  - `mypa` (2): MYPA · MyPa
- **JJK Jyväskylä**, Jyväskylä (1):
  - `jjkjyvaskyla` (2): **JJK Jyvaskyla** · **JJK Jyvaskyla**




By City

- **Helsinki** (5): 
  - HJK Helsinki  (2) HJK · Helsingin Jalkapalloklubi
  - HIFK Helsinki  (5) HIFK · HIFK Fotboll · IFK Helsingfors · Helsingfors IFK · Helsinki IFK
  - HPS Helsinki  (2) HPS · Helsingin Palloseura
  - Finnairin Palloilijat Helsinki (1965-1998)  (3) FinnPa · FinnPa Helsinki · Finnairin Palloilijat
  - FC Jokerit (1999-2004) 
- **Tampere** (4): 
  - Tampere United 
  - FC Ilves  (4) Ilves · Ilves Tampere · FC Ilves Tampere · Tampereen Ilves
  - Ilves-Kissat Tampere  (2) Ilves-Kissat · Tampereen-Viipurin Ilves-Kissat
  - Tampereen Pallo-Veikot  (2) TPV · TPV Tampere
- **Lahti** (3): 
  - FC Lahti  (1) Lahti
  - FC Kuusysi  (1) Kuusysi Lahti
  - FC Reipas Lahti  (2) FC Reipas · Reipas Lahti
- **Kuopio** (2): 
  - KuPS Kuopio  (4) KuPS · Kuopio PS · Kuopion PS · Kuopion Palloseura
  - Koparit Kuopio (1931-1990)  (4) Koparit · Koparit FC · KPT · Kuopion Pallotoverit
- **Oulu** (2): 
  - AC Oulu 
  - OPS Oulu  (2) OPS · Oulun Palloseura
- **Turku** (2): 
  - FC Inter Turku  (2) FC Inter · Inter Turku
  - TPS Turku  (3) TPS · Turun Palloseura · Turku PS
- **Valkeakoski** (2): 
  - FC Haka Valkeakoski  (2) Haka Valkeakoski · Valkeakosken Haka
  - FC Haka  (1) Haka
- **Vantaa** (2): 
  - PK-35 Vantaa  (2) PK-35 · Pallokerho-35
  - AC Vantaan Allianssi (2002-2006)  (1) AC Allianssi
- **Espoo** (1): FC Honka Espoo  (3) Honka · Honka Espoo · FC Honka
- **Jakobstad** (1): FF Jaro  (2) Jaro · Fotbollsföreningen Jaro Jalkapalloseura
- **Joensuu** (1): JIPPO Joensuu  (1) JIPPO
- **Jyväskylä** (1): JJK Jyväskylä  (3) JJK · JJK Jyvaskyla · Jyvaskyla JK
- **Kemi** (1): Palloseura Kemi Kings  (3) PS Kemi · Kemi City FC · Kemi City Football Club
- **Kokkola** (1): KPV Kokkola  (2) KPV · Kokkolan Palloveikot
- **Kotka** (1): KTP Kotka  (3) KTP · Kotkan Työväen Palloilijat · FC KTP
- **Lappeenranta** (1): PEPO Lappeenranta  (1) PEPO
- **Mariehamn** (1): IFK Mariehamn  (1) Mariehamn
- **Mikkeli** (1): Mikkelin Palloilijat  (2) MP · MP Mikkeli
- **Myllykoski** (1): Myllykosken Pallo -47  (5) MYPA · MyPa · MyPa-47 · Myllykosken Pallo-47 · Myllykosken Pallo −47
- **Pori** (1): FC Jazz  (1) FC Jazz Pori
- **Raseborg** (1): Ekenäs IF 
- **Rovaniemi** (1): Rovaniemen Palloseura  (4) RoPS · Rovaniemi · RoPS Rovaniemi · Rovaniemi PS
- **Seinäjoki** (1): SJK Seinäjoki  (4) Seinäjoki · SJK · Seinäjoen Jalkapallokerho · Seinäjoen JK
- **Vaasa** (1): Vaasan Palloseura  (4) VPS · VPS Vaasa · Vaasa PS · Vaasan PS




By Region

- **Helsinki†** (5):   HJK Helsinki · HIFK Helsinki · HPS Helsinki · Finnairin Palloilijat Helsinki (1965-1998) · FC Jokerit (1999-2004)
- **Valkeakoski†** (2):   FC Haka Valkeakoski · FC Haka
- **Turku†** (2):   FC Inter Turku · TPS Turku
- **Espoo†** (1):   FC Honka Espoo
- **Kuopio†** (2):   KuPS Kuopio · Koparit Kuopio (1931-1990)
- **Myllykoski†** (1):   Myllykosken Pallo -47
- **Lahti†** (3):   FC Lahti · FC Kuusysi · FC Reipas Lahti
- **Jyväskylä†** (1):   JJK Jyväskylä
- **Tampere†** (4):   Tampere United · FC Ilves · Ilves-Kissat Tampere · Tampereen Pallo-Veikot
- **Mariehamn†** (1):   IFK Mariehamn
- **Kokkola†** (1):   KPV Kokkola
- **Rovaniemi†** (1):   Rovaniemen Palloseura
- **Seinäjoki†** (1):   SJK Seinäjoki
- **Vaasa†** (1):   Vaasan Palloseura
- **Jakobstad†** (1):   FF Jaro
- **Kotka†** (1):   KTP Kotka
- **Vantaa†** (2):   PK-35 Vantaa · AC Vantaan Allianssi (2002-2006)
- **Kemi†** (1):   Palloseura Kemi Kings
- **Raseborg†** (1):   Ekenäs IF
- **Lappeenranta†** (1):   PEPO Lappeenranta
- **Joensuu†** (1):   JIPPO Joensuu
- **Pori†** (1):   FC Jazz
- **Oulu†** (2):   AC Oulu · OPS Oulu
- **Mikkeli†** (1):   Mikkelin Palloilijat




By Year

- **1922** (1):   TPS Turku
- **1929** (1):   Mikkelin Palloilijat
- **1930** (1):   Tampereen Pallo-Veikot
- **1931** (1):   Koparit Kuopio (1931-1990)
- **1965** (1):   Finnairin Palloilijat Helsinki (1965-1998)
- **1999** (1):   FC Jokerit (1999-2004)
- **2002** (2):   AC Oulu · AC Vantaan Allianssi (2002-2006)
- ? (30):   HJK Helsinki · HIFK Helsinki · HPS Helsinki · FC Haka Valkeakoski · FC Inter Turku · FC Honka Espoo · KuPS Kuopio · Myllykosken Pallo -47 · FC Lahti · FC Kuusysi · FC Reipas Lahti · JJK Jyväskylä · Tampere United · FC Ilves · Ilves-Kissat Tampere · IFK Mariehamn · KPV Kokkola · Rovaniemen Palloseura · SJK Seinäjoki · Vaasan Palloseura · FC Haka · FF Jaro · KTP Kotka · PK-35 Vantaa · Palloseura Kemi Kings · Ekenäs IF · PEPO Lappeenranta · JIPPO Joensuu · FC Jazz · OPS Oulu




Historic

- **1990** (1):   Koparit Kuopio (1931-1990)
- **1998** (1):   Finnairin Palloilijat Helsinki (1965-1998)
- **2004** (1):   FC Jokerit (1999-2004)
- **2006** (1):   AC Vantaan Allianssi (2002-2006)






By A to Z

- **A** (3): AC Oulu · AC Allianssi · AC Vantaan Allianssi (2002-2006)
- **E** (1): Ekenäs IF
- **F** (22): FC KTP · FinnPa · FC Haka · FC Jazz · FF Jaro · FC Honka · FC Ilves · FC Inter · FC Lahti · FC Reipas · FC Kuusysi · FC Jazz Pori · FC Honka Espoo · FC Inter Turku · FC Reipas Lahti · FinnPa Helsinki · FC Ilves Tampere · FC Haka Valkeakoski · Finnairin Palloilijat · FC Jokerit (1999-2004) · Fotbollsföreningen Jaro Jalkapalloseura · Finnairin Palloilijat Helsinki (1965-1998)
- **H** (15): HJK · HPS · HIFK · Haka · Honka · Honka Espoo · HIFK Fotboll · HJK Helsinki · HPS Helsinki · Helsinki IFK · HIFK Helsinki · Helsingfors IFK · Haka Valkeakoski · Helsingin Palloseura · Helsingin Jalkapalloklubi
- **I** (7): Ilves · Inter Turku · Ilves-Kissat · IFK Mariehamn · Ilves Tampere · IFK Helsingfors · Ilves-Kissat Tampere
- **J** (7): JJK · Jaro · JIPPO · Jyvaskyla JK · JIPPO Joensuu · JJK Jyvaskyla · JJK Jyväskylä
- **K** (19): KPT · KPV · KTP · KuPS · Koparit · KTP Kotka · Kuopio PS · Koparit FC · Kuopion PS · KPV Kokkola · KuPS Kuopio · Kemi City FC · Kuusysi Lahti · Kuopion Palloseura · Kokkolan Palloveikot · Kuopion Pallotoverit · Kemi City Football Club · Koparit Kuopio (1931-1990) · Kotkan Työväen Palloilijat
- **L** (1): Lahti
- **M** (10): MP · MYPA · MyPa · MyPa-47 · Mariehamn · MP Mikkeli · Mikkelin Palloilijat · Myllykosken Pallo-47 · Myllykosken Pallo -47 · Myllykosken Pallo −47
- **O** (3): OPS · OPS Oulu · Oulun Palloseura
- **P** (7): PEPO · PK-35 · PS Kemi · PK-35 Vantaa · Pallokerho-35 · PEPO Lappeenranta · Palloseura Kemi Kings
- **R** (6): RoPS · Rovaniemi · Reipas Lahti · Rovaniemi PS · RoPS Rovaniemi · Rovaniemen Palloseura
- **S** (5): SJK · Seinäjoki · Seinäjoen JK · SJK Seinäjoki · Seinäjoen Jalkapallokerho
- **T** (10): TPS · TPV · Turku PS · TPS Turku · TPV Tampere · Tampere United · Tampereen Ilves · Turun Palloseura · Tampereen Pallo-Veikot · Tampereen-Viipurin Ilves-Kissat
- **V** (6): VPS · Vaasa PS · VPS Vaasa · Vaasan PS · Vaasan Palloseura · Valkeakosken Haka




