19 clubs

- **Derry City FC** : (3) Derry · Derry City · FC Derry City
- **Institute FC** : (2) Institute · FC Institute
- **Linfield FC** : (3) Linfield · FC Linfield · Linfield Belfast
- **Glentoran FC** : (2) Glentoran · Glentoran Belfast
- **Crusaders FC** : (2) Crusaders · Crusaders Belfast
- **Cliftonville FC** : (1) Cliftonville
- **Portadown FC** : (1) Portadown
- **Lisburn Distillery FC** : (1) Lisburn Distillery
- **Glenavon FC** : (2) Glenavon · FC Glenavon
- **Coleraine FC** : (1) Coleraine
- **Ballymena United FC** : (2) Ballymena · Ballymena United
- **Ballinamallard United FC** : (1) Ballinamallard United
- **Dungannon Swifts FC** : (2) Dungannon · Dungannon Swifts
- **Larne FC** : (1) Larne
- **Carrick Rangers FC** : (3) Carrick · Carrick Rangers · FC Carrick Rangers
- **Warrenpoint Town FC** : (2) Warrenpoint · Warrenpoint Town
- **Ards FC** : (1) Ards
- **Bangor FC**
- **Newry City AFC**




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Belfast** (3): 
  - Linfield FC  (3) Linfield · Linfield Belfast · FC Linfield
  - Glentoran FC  (2) Glentoran · Glentoran Belfast
  - Crusaders FC  (2) Crusaders · Crusaders Belfast
- **Derry** (2): 
  - Derry City FC  (3) Derry · Derry City · FC Derry City
  - Institute FC  (2) Institute · FC Institute
- **Ballinamallard** (1): Ballinamallard United FC  (1) Ballinamallard United
- **Ballymena** (1): Ballymena United FC  (2) Ballymena · Ballymena United
- **Ballyskeagh** (1): Lisburn Distillery FC  (1) Lisburn Distillery
- **Bangor** (1): Bangor FC 
- **Newry** (1): Newry City AFC 
- ? (9): 
  - Cliftonville FC  (1) Cliftonville
  - Portadown FC  (1) Portadown
  - Glenavon FC  (2) Glenavon · FC Glenavon
  - Coleraine FC  (1) Coleraine
  - Dungannon Swifts FC  (2) Dungannon · Dungannon Swifts
  - Larne FC  (1) Larne
  - Carrick Rangers FC  (3) Carrick · FC Carrick Rangers · Carrick Rangers
  - Warrenpoint Town FC  (2) Warrenpoint · Warrenpoint Town
  - Ards FC  (1) Ards




By Region

- **Derry†** (2):   Derry City FC · Institute FC
- **Belfast†** (3):   Linfield FC · Glentoran FC · Crusaders FC
- **Ballyskeagh†** (1):   Lisburn Distillery FC
- **Ballymena†** (1):   Ballymena United FC
- **Ballinamallard†** (1):   Ballinamallard United FC
- **Bangor†** (1):   Bangor FC
- **Newry†** (1):   Newry City AFC




By Year

- **1880** (1):   Lisburn Distillery FC
- **1900** (1):   Ards FC
- **1928** (1):   Ballymena United FC
- ? (16):   Derry City FC · Institute FC · Linfield FC · Glentoran FC · Crusaders FC · Cliftonville FC · Portadown FC · Glenavon FC · Coleraine FC · Ballinamallard United FC · Dungannon Swifts FC · Larne FC · Carrick Rangers FC · Warrenpoint Town FC · Bangor FC · Newry City AFC






By A to Z

- **A** (2): Ards · Ards FC
- **B** (6): Ballymena · Bangor FC · Ballymena United · Ballymena United FC · Ballinamallard United · Ballinamallard United FC
- **C** (10): Carrick · Coleraine · Crusaders · Cliftonville · Coleraine FC · Crusaders FC · Carrick Rangers · Cliftonville FC · Crusaders Belfast · Carrick Rangers FC
- **D** (6): Derry · Dungannon · Derry City · Derry City FC · Dungannon Swifts · Dungannon Swifts FC
- **F** (5): FC Glenavon · FC Linfield · FC Institute · FC Derry City · FC Carrick Rangers
- **G** (5): Glenavon · Glentoran · Glenavon FC · Glentoran FC · Glentoran Belfast
- **I** (2): Institute · Institute FC
- **L** (7): Larne · Larne FC · Linfield · Linfield FC · Linfield Belfast · Lisburn Distillery · Lisburn Distillery FC
- **N** (1): Newry City AFC
- **P** (2): Portadown · Portadown FC
- **W** (3): Warrenpoint · Warrenpoint Town · Warrenpoint Town FC




