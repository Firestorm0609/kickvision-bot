20 clubs

- **AC Omonia Nicosia** : (4) Omonia · AC Omonia · Omonia Nicosia · Omonia Nikosia [de]
- **APOEL Nicosia FC** : (4) APOEL · APOEL FC · APOEL Nicosia · APOEL Nikosia [de]
- **Olympiakos Nicosia FC** : (3) Olympiakos · Olympiakos Nicosia · Olympiakos Nikosia
- **AEL Limassol** : (3) AEL · AEL Limassol FC · Athlitiki Enosi Lemesou
- **Apollon Limassol FC** : (3) Apollon · Apollon L. · Apollon Limassol
- **Karmiotissa Pano Polemidia** : (4) Karmiotissa FC · Karmiotissa Pol. · Karmiotissa Polemidion · Karmiotissa Pano Polemidion
- **Anorthosis Famagusta FC** : (2) Anorthosis · Anorthosis Famagusta
- **AEK Larnaca FC** : (1) AEK Larnaca
- **Pezoporikos Larnaca (1927-1994)** : (2) Pezoporikos FC · Pezoporikos Larnaca FC
- **EPA Larnaca (1930-1994)** : (2) EPA Larnaca FC · Enosis Pezoporikou Amol FC
- **Alki Larnaca FC (1948-2014)** : (1) Alki Larnaca
- **APOP/Kinyras Peyias FC** : (2) APOP · APOP / Kinyras
- **Ermis Aradippou FC** : (2) Ermis · Ermis Aradippou
- **Ethnikos Achnas FC** : (2) Ethnikos Achna · Ethnikos Achnas
- **Pafos FC** : (2) Pafos · FC Pafos
- **Doxa Katokopia FC** : (3) Doxa · Doxa Katokopia · Doxa Katokopias FC
- **Enosis Neon Paralimni FC** : (4) Paralimni · Enosis Paralimni · Enosis N. Paralimni · Enosis Neon Paralimni
- **Nea Salamis Famagusta FC** : (3) Nea Salamis · Salamis Famagusta · Nea Salamina Fama.
- **Digenis Morphou** : (3) Dighenis Morphou · Digenis Akritas Morphou FC · Dighenis Akritas Morphou FC
- **Alki Oroklini** : (1) Alki Oroklinis




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Larnaca** (5): 
  - Anorthosis Famagusta FC  (2) Anorthosis · Anorthosis Famagusta
  - AEK Larnaca FC  (1) AEK Larnaca
  - Pezoporikos Larnaca (1927-1994)  (2) Pezoporikos Larnaca FC · Pezoporikos FC
  - EPA Larnaca (1930-1994)  (2) EPA Larnaca FC · Enosis Pezoporikou Amol FC
  - Alki Larnaca FC (1948-2014)  (1) Alki Larnaca
- **Limassol** (3): 
  - AEL Limassol  (3) AEL · AEL Limassol FC · Athlitiki Enosi Lemesou
  - Apollon Limassol FC  (3) Apollon · Apollon L. · Apollon Limassol
  - Karmiotissa Pano Polemidia  (4) Karmiotissa Pol. · Karmiotissa Polemidion · Karmiotissa FC · Karmiotissa Pano Polemidion
- **Nicosia** (3): 
  - AC Omonia Nicosia  (4) Omonia · Omonia Nicosia · AC Omonia · Omonia Nikosia [de]
  - APOEL Nicosia FC  (4) APOEL Nicosia · APOEL · APOEL FC · APOEL Nikosia [de]
  - Olympiakos Nicosia FC  (3) Olympiakos · Olympiakos Nicosia · Olympiakos Nikosia
- **Katokopia** (1): Doxa Katokopia FC  (3) Doxa · Doxa Katokopias FC · Doxa Katokopia
- **Morphou** (1): Digenis Morphou  (3) Digenis Akritas Morphou FC · Dighenis Akritas Morphou FC · Dighenis Morphou
- **Oroklini** (1): Alki Oroklini  (1) Alki Oroklinis
- ? (6): 
  - APOP/Kinyras Peyias FC  (2) APOP · APOP / Kinyras
  - Ermis Aradippou FC  (2) Ermis · Ermis Aradippou
  - Ethnikos Achnas FC  (2) Ethnikos Achnas · Ethnikos Achna
  - Pafos FC  (2) Pafos · FC Pafos
  - Enosis Neon Paralimni FC  (4) Paralimni · Enosis N. Paralimni · Enosis Neon Paralimni · Enosis Paralimni
  - Nea Salamis Famagusta FC  (3) Nea Salamis · Nea Salamina Fama. · Salamis Famagusta




By Region

- **Nicosia†** (3):   AC Omonia Nicosia · APOEL Nicosia FC · Olympiakos Nicosia FC
- **Limassol†** (3):   AEL Limassol · Apollon Limassol FC · Karmiotissa Pano Polemidia
- **Larnaca†** (5):   Anorthosis Famagusta FC · AEK Larnaca FC · Pezoporikos Larnaca (1927-1994) · EPA Larnaca (1930-1994) · Alki Larnaca FC (1948-2014)
- **Katokopia†** (1):   Doxa Katokopia FC
- **Morphou†** (1):   Digenis Morphou
- **Oroklini†** (1):   Alki Oroklini




By Year

- **1927** (1):   Pezoporikos Larnaca (1927-1994)
- **1930** (1):   EPA Larnaca (1930-1994)
- **1948** (1):   Alki Larnaca FC (1948-2014)
- ? (17):   AC Omonia Nicosia · APOEL Nicosia FC · Olympiakos Nicosia FC · AEL Limassol · Apollon Limassol FC · Karmiotissa Pano Polemidia · Anorthosis Famagusta FC · AEK Larnaca FC · APOP/Kinyras Peyias FC · Ermis Aradippou FC · Ethnikos Achnas FC · Pafos FC · Doxa Katokopia FC · Enosis Neon Paralimni FC · Nea Salamis Famagusta FC · Digenis Morphou · Alki Oroklini




Historic

- **1994** (2):   Pezoporikos Larnaca (1927-1994) · EPA Larnaca (1930-1994)
- **2014** (1):   Alki Larnaca FC (1948-2014)






By A to Z

- **A** (27): AEL · APOP · APOEL · Apollon · APOEL FC · AC Omonia · Anorthosis · Apollon L. · AEK Larnaca · AEL Limassol · Alki Larnaca · APOEL Nicosia · Alki Oroklini · AEK Larnaca FC · APOP / Kinyras · Alki Oroklinis · AEL Limassol FC · APOEL Nicosia FC · Apollon Limassol · AC Omonia Nicosia · APOEL Nikosia [de] · Apollon Limassol FC · Anorthosis Famagusta · APOP/Kinyras Peyias FC · Anorthosis Famagusta FC · Athlitiki Enosi Lemesou · Alki Larnaca FC (1948-2014)
- **D** (8): Doxa · Doxa Katokopia · Digenis Morphou · Dighenis Morphou · Doxa Katokopia FC · Doxa Katokopias FC · Digenis Akritas Morphou FC · Dighenis Akritas Morphou FC
- **E** (13): Ermis · EPA Larnaca FC · Ethnikos Achna · Ermis Aradippou · Ethnikos Achnas · Enosis Paralimni · Ermis Aradippou FC · Ethnikos Achnas FC · Enosis N. Paralimni · Enosis Neon Paralimni · EPA Larnaca (1930-1994) · Enosis Neon Paralimni FC · Enosis Pezoporikou Amol FC
- **F** (1): FC Pafos
- **K** (5): Karmiotissa FC · Karmiotissa Pol. · Karmiotissa Polemidion · Karmiotissa Pano Polemidia · Karmiotissa Pano Polemidion
- **N** (3): Nea Salamis · Nea Salamina Fama. · Nea Salamis Famagusta FC
- **O** (7): Omonia · Olympiakos · Omonia Nicosia · Olympiakos Nicosia · Olympiakos Nikosia · Omonia Nikosia [de] · Olympiakos Nicosia FC
- **P** (6): Pafos · Pafos FC · Paralimni · Pezoporikos FC · Pezoporikos Larnaca FC · Pezoporikos Larnaca (1927-1994)
- **S** (1): Salamis Famagusta




