18 clubs

- **FK Riteriai** : (2) Riteriai · FK Trakai
- **VMFD Žalgiris** : (4) Žalgiris · FK Žalgiris · Žalgiris Vilnius · FK Žalgiris Vilnius ⇒ (5) ≈Zalgiris≈ · ≈FK Zalgiris≈ · ≈VMFD Zalgiris≈ · ≈Zalgiris Vilnius≈ · ≈FK Zalgiris Vilnius≈
- **FK Kauno Žalgiris** : (2) Kauno Žalgiris · FK Žalgiris Kaunas ⇒ (3) ≈Kauno Zalgiris≈ · ≈FK Kauno Zalgiris≈ · ≈FK Zalgiris Kaunas≈
- **FC Stumbras** : (2) Stumbras · Stumbras Kaunas
- **FBK Kaunas**
- **FK Kareda Kaunas (1935-2003)** : (2) FK Kareda · Kareda Kaunas
- **FK Inkaras Kaunas (1937-2003)** : (1) FK Inkaras
- **FK Ekranas** : (2) Ekranas · Ekranas Panevezys
- **FK Sūduva** : (3) Sūduva · Sūduva Marija. · Sūduva Marijampolė ⇒ (4) ≈Suduva≈ · ≈FK Suduva≈ · ≈Suduva Marija.≈ · ≈Suduva Marijampole≈
- **FK Tauras**
- **FK Vėtra** ⇒ (1) ≈FK Vetra≈
- **FC Šiauliai** ⇒ (1) ≈FC Siauliai≈
- **FK Banga** : (1) Banga Gargzdai
- **FK Atlantas** : (2) Atlantas · Atlantas Klaipeda
- **FK Kruoja** : (2) Kruoja Pakruojis · FK Kruoja Pakruojis
- **Panevezys**
- **FK Palanga**
- **FK Mažeikiai** ⇒ (1) ≈FK Mazeikiai≈




Alphabet

- **Alphabet Specials** (5):  **ė**  **Š**  **ū**  **Ž**  **ž** 
  - **ė**×2 U+0117 (279) - LATIN SMALL LETTER E WITH DOT ABOVE ⇒ e
  - **Š**×1 U+0160 (352) - LATIN CAPITAL LETTER S WITH CARON ⇒ S
  - **ū**×4 U+016B (363) - LATIN SMALL LETTER U WITH MACRON ⇒ u
  - **Ž**×8 U+017D (381) - LATIN CAPITAL LETTER Z WITH CARON ⇒ Z
  - **ž**×1 U+017E (382) - LATIN SMALL LETTER Z WITH CARON ⇒ z




Duplicates





By City

- **Kaunas** (5): 
  - FK Kauno Žalgiris  (2) Kauno Žalgiris · FK Žalgiris Kaunas
  - FC Stumbras  (2) Stumbras · Stumbras Kaunas
  - FBK Kaunas 
  - FK Kareda Kaunas (1935-2003)  (2) FK Kareda · Kareda Kaunas
  - FK Inkaras Kaunas (1937-2003)  (1) FK Inkaras
- **Vilnius** (2): 
  - FK Riteriai  (2) Riteriai · FK Trakai
  - VMFD Žalgiris  (4) Žalgiris · Žalgiris Vilnius · FK Žalgiris · FK Žalgiris Vilnius
- **Marijampolė** (1): FK Sūduva  (3) Sūduva · Sūduva Marija. · Sūduva Marijampolė
- **Mažeikiai** (1): FK Mažeikiai 
- ? (9): 
  - FK Ekranas  (2) Ekranas · Ekranas Panevezys
  - FK Tauras 
  - FK Vėtra 
  - FC Šiauliai 
  - FK Banga  (1) Banga Gargzdai
  - FK Atlantas  (2) Atlantas · Atlantas Klaipeda
  - FK Kruoja  (2) Kruoja Pakruojis · FK Kruoja Pakruojis
  - Panevezys 
  - FK Palanga 




By Region

- **Vilnius†** (2):   FK Riteriai · VMFD Žalgiris
- **Kaunas†** (5):   FK Kauno Žalgiris · FC Stumbras · FBK Kaunas · FK Kareda Kaunas (1935-2003) · FK Inkaras Kaunas (1937-2003)
- **Marijampolė†** (1):   FK Sūduva
- **Mažeikiai†** (1):   FK Mažeikiai




By Year

- **1935** (1):   FK Kareda Kaunas (1935-2003)
- **1937** (1):   FK Inkaras Kaunas (1937-2003)
- **2005** (1):   FK Riteriai
- ? (15):   VMFD Žalgiris · FK Kauno Žalgiris · FC Stumbras · FBK Kaunas · FK Ekranas · FK Sūduva · FK Tauras · FK Vėtra · FC Šiauliai · FK Banga · FK Atlantas · FK Kruoja · Panevezys · FK Palanga · FK Mažeikiai




Historic

- **2003** (2):   FK Kareda Kaunas (1935-2003) · FK Inkaras Kaunas (1937-2003)






By A to Z

- **A** (2): Atlantas · Atlantas Klaipeda
- **B** (1): Banga Gargzdai
- **E** (2): Ekranas · Ekranas Panevezys
- **F** (23): FK Banga · FK Vėtra · FK Kareda · FK Kruoja · FK Sūduva · FK Tauras · FK Trakai · FBK Kaunas · FK Ekranas · FK Inkaras · FK Palanga · FC Stumbras · FC Šiauliai · FK Atlantas · FK Riteriai · FK Žalgiris · FK Mažeikiai · FK Kauno Žalgiris · FK Žalgiris Kaunas · FK Kruoja Pakruojis · FK Žalgiris Vilnius · FK Kareda Kaunas (1935-2003) · FK Inkaras Kaunas (1937-2003)
- **K** (3): Kareda Kaunas · Kauno Žalgiris · Kruoja Pakruojis
- **P** (1): Panevezys
- **R** (1): Riteriai
- **S** (5): Sūduva · Stumbras · Sūduva Marija. · Stumbras Kaunas · Sūduva Marijampolė
- **V** (1): VMFD Žalgiris
- **Ž** (2): Žalgiris · Žalgiris Vilnius




