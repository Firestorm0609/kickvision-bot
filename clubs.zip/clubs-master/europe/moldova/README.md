17 clubs

- **FC Sheriff Tiraspol** : (5) Sheriff · Tiraspol · FC Sheriff · FC Tiraspol · Sheriff Tiraspol
- **FC Dinamo-Auto Tiraspol** : (1) Dinamo-Auto
- **CS Tiligul-Tiras Tiraspol (1938-2009)** : (1) FC Tiligul Tiraspol
- **FC Dacia Chișinău** : (2) Dacia · Dacia Chișinău ⇒ (2) ≈Dacia Chisinau≈ · ≈FC Dacia Chisinau≈
- **FC Zimbru Chișinău** : (3) Zimbru · FC Zimbru · Zimbru Chisinau ⇒ (1) ≈FC Zimbru Chisinau≈
- **FC Veris (2011-2014)** : (3) Veris · Veris Chișinău · FC Veris Chișinău ⇒ (2) ≈Veris Chisinau≈ · ≈FC Veris Chisinau≈
- **FC Iskra-Stal** : (1) Iskra-Stal
- **FC Milsami Orhei** : (3) Milsami · FC Milsami · Milsami Orhei
- **FC Olimpia Balti**
- **FC Zaria Balti** : (2) Zaria · Zaria Balti
- **FC Nistru Otaci**
- **CS Petrocub** : (2) Petrocub · Petrocub-Hincesti
- **FC Saxan** : (2) Saxan · Saxan Gagauz Yeri
- **FC Sfintul Gheorghe Suruceni** : (1) Sfintul Gheorghe
- **FC Speranța Nisporeni** : (1) Speranța Nisporeni ⇒ (2) ≈Speranta Nisporeni≈ · ≈FC Speranta Nisporeni≈
- **FC Codru**
- **CS Petrocub Hîncești** : (1) FC Petrocub-Hincesti ⇒ (1) ≈CS Petrocub Hincesti≈




Alphabet

- **Alphabet Specials** (4):  **î**  **ă**  **ș**  **ț** 
  - **î**×1 U+00EE (238) - LATIN SMALL LETTER I WITH CIRCUMFLEX ⇒ i
  - **ă**×5 U+0103 (259) - LATIN SMALL LETTER A WITH BREVE ⇒ a
  - **ș**×6 U+0219 (537) - LATIN SMALL LETTER S WITH COMMA BELOW ⇒ s
  - **ț**×2 U+021B (539) - LATIN SMALL LETTER T WITH COMMA BELOW ⇒ t




Duplicates





By City

- **Chișinău** (3): 
  - FC Dacia Chișinău  (2) Dacia · Dacia Chișinău
  - FC Zimbru Chișinău  (3) Zimbru · FC Zimbru · Zimbru Chisinau
  - FC Veris (2011-2014)  (3) Veris · Veris Chișinău · FC Veris Chișinău
- **Tiraspol** (3): 
  - FC Sheriff Tiraspol  (5) Sheriff · FC Sheriff · Sheriff Tiraspol · FC Tiraspol · Tiraspol
  - FC Dinamo-Auto Tiraspol  (1) Dinamo-Auto
  - CS Tiligul-Tiras Tiraspol (1938-2009)  (1) FC Tiligul Tiraspol
- **Sărata-Galbenă** (1): CS Petrocub Hîncești  (1) FC Petrocub-Hincesti
- ? (10): 
  - FC Iskra-Stal  (1) Iskra-Stal
  - FC Milsami Orhei  (3) Milsami · Milsami Orhei · FC Milsami
  - FC Olimpia Balti 
  - FC Zaria Balti  (2) Zaria · Zaria Balti
  - FC Nistru Otaci 
  - CS Petrocub  (2) Petrocub · Petrocub-Hincesti
  - FC Saxan  (2) Saxan · Saxan Gagauz Yeri
  - FC Sfintul Gheorghe Suruceni  (1) Sfintul Gheorghe
  - FC Speranța Nisporeni  (1) Speranța Nisporeni
  - FC Codru 




By Region

- **Tiraspol†** (3):   FC Sheriff Tiraspol · FC Dinamo-Auto Tiraspol · CS Tiligul-Tiras Tiraspol (1938-2009)
- **Chișinău†** (3):   FC Dacia Chișinău · FC Zimbru Chișinău · FC Veris (2011-2014)
- **Sărata-Galbenă†** (1):   CS Petrocub Hîncești




By Year

- **1938** (1):   CS Tiligul-Tiras Tiraspol (1938-2009)
- **1990** (1):   CS Petrocub Hîncești
- **2011** (1):   FC Veris (2011-2014)
- ? (14):   FC Sheriff Tiraspol · FC Dinamo-Auto Tiraspol · FC Dacia Chișinău · FC Zimbru Chișinău · FC Iskra-Stal · FC Milsami Orhei · FC Olimpia Balti · FC Zaria Balti · FC Nistru Otaci · CS Petrocub · FC Saxan · FC Sfintul Gheorghe Suruceni · FC Speranța Nisporeni · FC Codru




Historic

- **2009** (1):   CS Tiligul-Tiras Tiraspol (1938-2009)
- **2014** (1):   FC Veris (2011-2014)






By A to Z

- **C** (3): CS Petrocub · CS Petrocub Hîncești · CS Tiligul-Tiras Tiraspol (1938-2009)
- **D** (3): Dacia · Dinamo-Auto · Dacia Chișinău
- **F** (21): FC Codru · FC Saxan · FC Zimbru · FC Milsami · FC Sheriff · FC Tiraspol · FC Iskra-Stal · FC Zaria Balti · FC Nistru Otaci · FC Milsami Orhei · FC Olimpia Balti · FC Dacia Chișinău · FC Veris Chișinău · FC Zimbru Chișinău · FC Sheriff Tiraspol · FC Tiligul Tiraspol · FC Petrocub-Hincesti · FC Veris (2011-2014) · FC Speranța Nisporeni · FC Dinamo-Auto Tiraspol · FC Sfintul Gheorghe Suruceni
- **I** (1): Iskra-Stal
- **M** (2): Milsami · Milsami Orhei
- **P** (2): Petrocub · Petrocub-Hincesti
- **S** (6): Saxan · Sheriff · Sfintul Gheorghe · Sheriff Tiraspol · Saxan Gagauz Yeri · Speranța Nisporeni
- **T** (1): Tiraspol
- **V** (2): Veris · Veris Chișinău
- **Z** (4): Zaria · Zimbru · Zaria Balti · Zimbru Chisinau




