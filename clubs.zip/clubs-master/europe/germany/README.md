159 clubs

- [**Bayern München**](https://en.wikipedia.org/wiki/FC_Bayern_Munich) : (4) Bayern · FC Bayern München · Bayern Munich [en] · FC Bayern Munich [en] ⇒ (4) ≈Bayern Munchen≈ · ≈Bayern Muenchen≈ · ≈FC Bayern Munchen≈ · ≈FC Bayern Muenchen≈
- **Bayern München II** : (2) Bayern II · Bayern München Am. ⇒ (4) ≈Bayern Munchen II≈ · ≈Bayern Muenchen II≈ · ≈Bayern Munchen Am.≈ · ≈Bayern Muenchen Am.≈
- [**TSV 1860 München**](https://en.wikipedia.org/wiki/TSV_1860_Munich) : (4) 1860 München · TSV München 1860 · Munich 1860 [en] · TSV 1860 Munich [en] ⇒ (6) ≈1860 Munchen≈ · ≈1860 Muenchen≈ · ≈TSV 1860 Munchen≈ · ≈TSV Munchen 1860≈ · ≈TSV 1860 Muenchen≈ · ≈TSV Muenchen 1860≈
- **Türkgücü München** : (1) Türkgücü ⇒ (4) ≈Turkgucu≈ · ≈Tuerkguecue≈ · ≈Turkgucu Munchen≈ · ≈Tuerkguecue Muenchen≈
- [**1. FC Nürnberg**](https://en.wikipedia.org/wiki/1._FC_Nürnberg) : (2) Nürnberg · 1. FC Nuremberg [en] ⇒ (4) ≈Nurnberg≈ · ≈Nuernberg≈ · ≈1. FC Nurnberg≈ · ≈1. FC Nuernberg≈
- **1. FC Nürnberg II** : (1) Nürnberg II ⇒ (4) ≈Nurnberg II≈ · ≈Nuernberg II≈ · ≈1. FC Nurnberg II≈ · ≈1. FC Nuernberg II≈
- [**SpVgg Greuther Fürth**](https://en.wikipedia.org/wiki/SpVgg_Greuther_Fürth) : (1) Greuther Fürth ⇒ (4) ≈Greuther Furth≈ · ≈Greuther Fuerth≈ · ≈SpVgg Greuther Furth≈ · ≈SpVgg Greuther Fuerth≈
- **SpVgg Greuther Fürth II** : (2) Gr. Fürth II · Greuther Fürth II ⇒ (6) ≈Gr. Furth II≈ · ≈Gr. Fuerth II≈ · ≈Greuther Furth II≈ · ≈Greuther Fuerth II≈ · ≈SpVgg Greuther Furth II≈ · ≈SpVgg Greuther Fuerth II≈
- [**FC Augsburg**](https://en.wikipedia.org/wiki/FC_Augsburg) : (1) Augsburg
- **FC Augsburg II** : (1) Augsburg II
- [**SpVgg Unterhaching**](https://en.wikipedia.org/wiki/SpVgg_Unterhaching) : (2) U'haching · Unterhaching
- [**FC Ingolstadt 04**](https://en.wikipedia.org/wiki/FC_Ingolstadt_04) : (2) Ingolstadt · FC Ingolstadt
- [**SSV Jahn Regensburg**](https://en.wikipedia.org/wiki/SSV_Jahn_Regensburg) : (2) Regensburg · Jahn Regensburg
- **1. FC Schweinfurt 05** : (2) Schweinfurt · Schweinfurt 05
- [**Würzburger Kickers**](https://en.wikipedia.org/wiki/Würzburger_Kickers) : (2) Kickers Würzburg · FC Würzburger Kickers ⇒ (6) ≈Kickers Wurzburg≈ · ≈Kickers Wuerzburg≈ · ≈Wurzburger Kickers≈ · ≈Wuerzburger Kickers≈ · ≈FC Wurzburger Kickers≈ · ≈FC Wuerzburger Kickers≈
- **Wacker Burghausen** : (1) Burghausen
- **Viktoria Aschaffenburg** : (1) Aschaffenburg
- **TSV 1860 Rosenheim** : (1) 1860 Rosenheim
- **FV Illertissen** : (1) Illertissen
- **SpVgg Bayreuth** : (1) Bayreuth
- **TSV Aubstadt**
- **TSV Buchbach** : (1) Buchbach
- **VfB Eichstätt** : (1) Eichstätt ⇒ (4) ≈Eichstatt≈ · ≈Eichstaett≈ · ≈VfB Eichstatt≈ · ≈VfB Eichstaett≈
- **SV Heimstetten** : (1) Heimstetten
- **SV Schalding-Heining** : (2) Schald.-Hein. · Schalding-Heining
- **FC Memmingen** : (1) Memmingen
- **VfR Garching**
- **TSV 1896 Rain** : (3) TSV Rain · TSV Rain/Lech · TSV Rain am Lech
- [**1. FC Köln**](https://en.wikipedia.org/wiki/1._FC_Köln) : (2) Köln · FC Köln ⇒ (6) ≈Koln≈ · ≈Koeln≈ · ≈FC Koln≈ · ≈FC Koeln≈ · ≈1. FC Koln≈ · ≈1. FC Koeln≈
- [**Fortuna Köln**](https://en.wikipedia.org/wiki/SC_Fortuna_Köln) : (3) F Köln · SC Fortuna Köln · Sportclub Fortuna Köln ⇒ (8) ≈F Koln≈ · ≈F Koeln≈ · ≈Fortuna Koln≈ · ≈Fortuna Koeln≈ · ≈SC Fortuna Koln≈ · ≈SC Fortuna Koeln≈ · ≈Sportclub Fortuna Koln≈ · ≈Sportclub Fortuna Koeln≈
- **FC Viktoria Köln** : (1) Viktoria Köln ⇒ (4) ≈Viktoria Koln≈ · ≈Viktoria Koeln≈ · ≈FC Viktoria Koln≈ · ≈FC Viktoria Koeln≈
- [**Fortuna Düsseldorf**](https://en.wikipedia.org/wiki/Fortuna_Düsseldorf) : (2) Düsseldorf · F. Düsseldorf ⇒ (6) ≈Dusseldorf≈ · ≈Duesseldorf≈ · ≈F. Dusseldorf≈ · ≈F. Duesseldorf≈ · ≈Fortuna Dusseldorf≈ · ≈Fortuna Duesseldorf≈
- [**Borussia Dortmund**](https://en.wikipedia.org/wiki/Borussia_Dortmund) : (3) Dortmund · Bor. Dortmund · BV 09 Borussia Dortmund
- **Borussia Dortmund II** : (2) Dortmund II · Bor. Dortmund II
- [**FC Schalke 04**](https://en.wikipedia.org/wiki/FC_Schalke_04) : (2) Schalke · Schalke 04
- [**Bayer 04 Leverkusen**](https://en.wikipedia.org/wiki/Bayer_04_Leverkusen) : (4) Bayer · Leverkusen · Bay. Leverkusen · Bayer Leverkusen
- [**MSV Duisburg**](https://en.wikipedia.org/wiki/MSV_Duisburg) : (2) Duisburg · Meidericher SV
- [**Bor. Mönchengladbach**](https://en.wikipedia.org/wiki/Borussia_Mönchengladbach) : (6) M'Gladbach · Mönchengladbach · Bor. M'gladbach · Borussia M'gladbach · Borussia Mönchengladbach · VfL Borussia Mönchengladbach ⇒ (8) ≈Monchengladbach≈ · ≈Moenchengladbach≈ · ≈Bor. Monchengladbach≈ · ≈Bor. Moenchengladbach≈ · ≈Borussia Monchengladbach≈ · ≈Borussia Moenchengladbach≈ · ≈VfL Borussia Monchengladbach≈ · ≈VfL Borussia Moenchengladbach≈
- [**VfL Bochum**](https://en.wikipedia.org/wiki/VfL_Bochum) : (2) Bochum · VfL Bochum 1848
- **SG Wattenscheid 09** : (2) Wattenscheid · Wattenscheid 09
- [**Arminia Bielefeld**](https://en.wikipedia.org/wiki/Arminia_Bielefeld) : (2) Bielefeld · DSC Arminia Bielefeld
- [**Preußen Münster**](https://en.wikipedia.org/wiki/SC_Preußen_Münster) : (3) Münster · SC Preußen 06 · SC Preußen Münster ⇒ (7) ≈Munster≈ · ≈Muenster≈ · ≈SC Preussen 06≈ · ≈Preussen Munster≈ · ≈Preussen Muenster≈ · ≈SC Preussen Munster≈ · ≈SC Preussen Muenster≈
- **Gütersloh** ⇒ (2) ≈Gutersloh≈ · ≈Guetersloh≈
- [**KFC Uerdingen**](https://en.wikipedia.org/wiki/KFC_Uerdingen_05) : (5) Uerdingen · Bayer Uerdingen · KFC Uerdingen 05 · Bayer 05 Uerdingen · FC Bayer 05 Uerdingen
- **Alemannia Aachen** : (2) Aachen · TSV Alemannia Aachen
- [**SC Paderborn 07**](https://en.wikipedia.org/wiki/SC_Paderborn_07) : (3) Paderborn · Paderborn 07 · SC Paderborn
- **Rot Weiss Ahlen** : (1) Ahlen
- **Rot-Weiß Oberhausen** : (2) Oberhausen · Rot-Weiss Oberhausen ⇒ (1) ≈Rot-Weiss Oberhausen≈
- **SF Siegen** : (2) Siegen · Sportfreunde Siegen
- **Wuppertaler SV** : (1) Wuppertaler
- **Rot-Weiss Essen** : (3) Essen · RW Essen · SC Rot-Weiss Essen
- **SF Baumberg** : (1) Sportfreunde Baumberg
- [**SF Lotte**](https://en.wikipedia.org/wiki/Sportfreunde_Lotte) : (1) Sportfreunde Lotte
- **SV Lippstadt 08**
- **SC Wiedenbrück** : (1) SC Wiedenbrück 2000 ⇒ (4) ≈SC Wiedenbruck≈ · ≈SC Wiedenbrueck≈ · ≈SC Wiedenbruck 2000≈ · ≈SC Wiedenbrueck 2000≈
- **FC Hennef 05**
- **TuS Erndtebrück** ⇒ (2) ≈TuS Erndtebruck≈ · ≈TuS Erndtebrueck≈
- **SC Verl**
- **SV Rödinghausen** ⇒ (2) ≈SV Rodinghausen≈ · ≈SV Roedinghausen≈
- **1. FC Saarbrücken** : (2) Saarbrücken · FC Saarbrücken ⇒ (6) ≈Saarbrucken≈ · ≈Saarbruecken≈ · ≈FC Saarbrucken≈ · ≈FC Saarbruecken≈ · ≈1. FC Saarbrucken≈ · ≈1. FC Saarbruecken≈
- **FC 08 Homburg** : (3) Homburg · FC Homburg · FC Homburg/Saar
- **VfB Borussia Neunkirchen** : (1) Borussia Neunkirchen
- **SV Elversberg** : (1) SV 07 Elversberg
- [**VfL Osnabrück**](https://en.wikipedia.org/wiki/VfL_Osnabrück) : (1) Osnabrück ⇒ (4) ≈Osnabruck≈ · ≈Osnabrueck≈ · ≈VfL Osnabruck≈ · ≈VfL Osnabrueck≈
- [**VfL Wolfsburg**](https://en.wikipedia.org/wiki/VfL_Wolfsburg) : (1) Wolfsburg
- [**Hannover 96**](https://en.wikipedia.org/wiki/Hannover_96) : (2) Hannover · Hannover 1896
- [**Eintracht Braunschweig**](https://en.wikipedia.org/wiki/Eintracht_Braunschweig) : (4) Braunschweig · E. Braunschweig · Eintr. Braunschweig · TSV Eintracht Braunschweig
- **FT Braunschweig** : (1) Freie Turnerschaft Braunschweig
- [**SV Meppen**](https://en.wikipedia.org/wiki/SV_Meppen) : (1) Meppen
- **VfB Oldenburg** : (1) Oldenburg
- **SV Wilhelmshaven**
- **BSV Schwarz-Weiß Rehden** ⇒ (1) ≈BSV Schwarz-Weiss Rehden≈
- **TSV Havelse**
- [**Energie Cottbus**](https://en.wikipedia.org/wiki/FC_Energie_Cottbus) : (2) Cottbus · FC Energie Cottbus
- **SV Babelsberg 03** : (1) Babelsberg
- **FSV Optik Rathenow**
- **SV Falkensee-Finkenkrug**
- **FFC Victoria 91** : (4) 1. FC Frankfurt · FC Vorwärts Frankfurt · 1. FC Frankfurt (Oder) · FC Frankfurt Viktoria/Oder ⇒ (2) ≈FC Vorwarts Frankfurt≈ · ≈FC Vorwaerts Frankfurt≈
- **FC Stahl Brandenburg** : (3) BSV Brandenburg · Stahl Brandenburg · BSV Stahl Brandenburg
- [**Hertha BSC**](https://en.wikipedia.org/wiki/Hertha_BSC) : (4) Hertha · Hertha Berlin · Hertha BSC Berlin · Hertha Berliner Sport-Club
- [**1. FC Union Berlin**](https://en.wikipedia.org/wiki/1._FC_Union_Berlin) : (2) Union Berlin · FC Union Berlin
- **Tennis Borussia Berlin** : (2) TB Berlin · TeBe Berlin
- **Blau-Weiß 90 Berlin (-1992)** : (1) Blau-Weiss 90 Berlin ⇒ (1) ≈Blau-Weiss 90 Berlin≈
- **SC Tasmania 1900 Berlin (-1973)** : (3) Tasmania Berlin · SV Tasmania Berlin · Tasmania 1900 Berlin
- **BFC Dynamo Berlin** : (2) BFC Dynamo · Berliner FC Dynamo
- **Berliner AK 07**
- **FC Viktoria 1889 Berlin** : (1) Viktoria Berlin
- **ASK Vorwärts Berlin** : (1) Vorwärts Berlin ⇒ (4) ≈Vorwarts Berlin≈ · ≈Vorwaerts Berlin≈ · ≈ASK Vorwarts Berlin≈ · ≈ASK Vorwaerts Berlin≈
- [**Hamburger SV**](https://en.wikipedia.org/wiki/Hamburger_SV) : (1) Hamburg
- [**FC St. Pauli**](https://en.wikipedia.org/wiki/FC_St._Pauli) : (3) St Pauli · St. Pauli · FC Sankt Pauli
- **SC Victoria Hamburg** : (1) Victoria Hamburg
- **USC Paloma Hamburg**
- **HSV Barmbek-Uhlenhorst**
- [**Werder Bremen**](https://en.wikipedia.org/wiki/SV_Werder_Bremen) : (2) Bremen · SV Werder Bremen
- **Werder Bremen II**
- **SG Aumund-Vegesack**
- **FC Oberneuland**
- **Bremer SV**
- [**VfB Stuttgart**](https://en.wikipedia.org/wiki/VfB_Stuttgart) : (1) Stuttgart
- **VfB Stuttgart II** : (1) Stuttgart II
- **Stuttgarter Kickers** : (2) Stutt. Kick. · Stuttgarter K
- [**SC Freiburg**](https://en.wikipedia.org/wiki/SC_Freiburg) : (1) Freiburg
- [**TSG 1899 Hoffenheim**](https://en.wikipedia.org/wiki/TSG_1899_Hoffenheim) : (3) Hoffenheim · TSG Hoffenheim · 1899 Hoffenheim
- [**Karlsruher SC**](https://en.wikipedia.org/wiki/Karlsruher_SC) : (1) Karlsruhe
- **SSV Ulm 1846** : (1) Ulm
- [**VfR Aalen**](https://en.wikipedia.org/wiki/VfR_Aalen) : (1) Aalen
- [**1. FC Heidenheim**](https://en.wikipedia.org/wiki/1._FC_Heidenheim) : (3) Heidenheim · FC Heidenheim · 1. FC Heidenheim 1846
- **SSV Reutlingen 05** : (1) Reutlingen
- [**SV Sandhausen**](https://en.wikipedia.org/wiki/SV_Sandhausen) : (2) Sandhausen · SV Sandhausen 1916
- **VfR Mannheim** : (1) Mannheim
- **SV Waldhof Mannheim** : (3) W. Mannheim · Waldhof Mannheim · SV Waldhof Mannheim 07
- [**SG Großaspach**](https://en.wikipedia.org/wiki/SG_Sonnenhof_Großaspach) : (3) Großaspach · SG Sonnenhof Großaspach · Sportgemeinschaft Sonnenhof Großaspach ⇒ (4) ≈Grossaspach≈ · ≈SG Grossaspach≈ · ≈SG Sonnenhof Grossaspach≈ · ≈Sportgemeinschaft Sonnenhof Grossaspach≈
- **FC Nöttingen** ⇒ (2) ≈FC Nottingen≈ · ≈FC Noettingen≈
- **Bahlinger SC**
- **Neckarsulmer Sport-Union**
- **Offenburger FV**
- **FC-Astoria Walldorf**
- **SV Waldkirch**
- [**Eintracht Frankfurt**](https://en.wikipedia.org/wiki/Eintracht_Frankfurt) : (8) Frankfurt · E. Frankfurt · Ein Frankfurt · Eint Frankfurt · Eintr. Frankfurt · SG Eintracht Frankfurt · Frankfurter SG Eintracht · Frankfurter Sportgemeinde Eintracht
- **FSV Frankfurt** : (2) Frankfurt FSV · FSV Frankfurt 1899
- [**SV Darmstadt 98**](https://en.wikipedia.org/wiki/SV_Darmstadt_98) : (1) Darmstadt
- [**SV Wehen Wiesbaden**](https://en.wikipedia.org/wiki/SV_Wehen_Wiesbaden) : (3) Wehen · Wiesbaden · Wehen Wiesbaden
- **Kickers Offenbach** : (1) Offenbach
- **KSV Hessen Kassel**
- [**1. FC Kaiserslautern**](https://en.wikipedia.org/wiki/1._FC_Kaiserslautern) : (4) K'lautern · Kaiserslautern · 1. FC K'lautern · FC Kaiserslautern
- [**1. FSV Mainz 05**](https://en.wikipedia.org/wiki/1._FSV_Mainz_05) : (3) Mainz · Mainz 05 · FSV Mainz 05
- **1. FSV Mainz 05 II**
- **Eintracht Trier** : (1) Ein Trier
- **TuS Koblenz** : (1) Koblenz
- **TSG Pfeddersheim**
- **SV Roßbach/Verscheid** ⇒ (1) ≈SV Rossbach/Verscheid≈
- **Wormatia Worms**
- **SV Alemannia Waldalgesheim**
- **FSV Salmrohr**
- **FK Pirmasens** : (1) FK 03 Pirmasens
- **VfB Lübeck** : (1) Lübeck ⇒ (4) ≈Lubeck≈ · ≈Luebeck≈ · ≈VfB Lubeck≈ · ≈VfB Luebeck≈
- [**Holstein Kiel**](https://en.wikipedia.org/wiki/Holstein_Kiel) : (1) Kiel
- **VfR Neumünster** ⇒ (2) ≈VfR Neumunster≈ · ≈VfR Neumuenster≈
- [**Hansa Rostock**](https://en.wikipedia.org/wiki/F.C._Hansa_Rostock) : (2) Rostock · FC Hansa Rostock
- **TSG Neustrelitz**
- **FC Schönberg 95** ⇒ (2) ≈FC Schonberg 95≈ · ≈FC Schoenberg 95≈
- **1. FC Neubrandenburg 04**
- **FC Mecklenburg Schwerin** : (3) PSV Schwerin · Polizei SV Schwerin · FC Eintracht Schwerin
- [**Dynamo Dresden**](https://en.wikipedia.org/wiki/Dynamo_Dresden) : (3) Dresden · SG Dynamo Dresden · 1. FC Dynamo Dresden
- [**RB Leipzig**](https://en.wikipedia.org/wiki/RB_Leipzig) : (1) Rasenballsport Leipzig
- **VfB Leipzig (-2004)** : (1) Leipzig
- **1. FC Lokomotive Leipzig (1966-1991)** : (4) 1. FC Lok · Lok Leipzig · 1. FC Lok Leipzig · Lokomotive Leipzig
- **BSG Chemie Leipzig** : (1) Betriebssportgemeinschaft Chemie Leipzig
- **FC Sachsen Leipzig (1990-2011)**
- **SG Sachsen Leipzig (2011-2014)**
- **Chemnitzer FC** : (2) Chemnitz · FC Karl-Marx-Stadt
- [**FC Erzgebirge Aue**](https://en.wikipedia.org/wiki/FC_Erzgebirge_Aue) : (5) Aue · Wismut Aue · FC Wismut Aue · Erzgebirge Aue · SC Wismut Karl-Marx-Stadt
- [**FSV Zwickau**](https://en.wikipedia.org/wiki/FSV_Zwickau) : (1) Zwickau
- [**Hallescher FC**](https://en.wikipedia.org/wiki/Hallescher_FC) : (3) Halle · FC Halle · Hallescher FC Chemie
- [**1. FC Magdeburg**](https://en.wikipedia.org/wiki/1._FC_Magdeburg) : (2) Magdeburg · FC Magdeburg
- [**FC Carl Zeiss Jena**](https://en.wikipedia.org/wiki/FC_Carl_Zeiss_Jena) : (3) CZ Jena · SC Motor Jena · Carl Zeiss Jena
- **SV Schott Jena**
- **FC Rot-Weiß Erfurt** : (3) Erfurt · RW Erfurt · Rot-Weiß Erfurt ⇒ (2) ≈Rot-Weiss Erfurt≈ · ≈FC Rot-Weiss Erfurt≈
- **Wacker Nordhausen** : (1) FSV Wacker 90 Nordhausen




Alphabet

- **Alphabet Specials** (4):  **ß**  **ä**  **ö**  **ü** 
  - **ß**×13 U+00DF (223) - LATIN SMALL LETTER SHARP S ⇒ ss
  - **ä**×5 U+00E4 (228) - LATIN SMALL LETTER A WITH DIAERESIS ⇒ a•ae
  - **ö**×16 U+00F6 (246) - LATIN SMALL LETTER O WITH DIAERESIS ⇒ o•oe
  - **ü**×44 U+00FC (252) - LATIN SMALL LETTER U WITH DIAERESIS ⇒ u•ue




Duplicates

- **Rot-Weiß Oberhausen**, Oberhausen (1):
  - `rotweissoberhausen` (2): **Rot-Weiss Oberhausen** · **Rot-Weiss Oberhausen**
- **Blau-Weiß 90 Berlin (-1992)**, Berlin (1):
  - `blauweiss90berlin` (2): **Blau-Weiss 90 Berlin** · **Blau-Weiss 90 Berlin**
- **FC St. Pauli**, Hamburg (1):
  - `stpauli` (2): St Pauli · St. Pauli




By City

- **Berlin, Berlin** (8): 
  - Hertha BSC  (4) Hertha · Hertha Berlin · Hertha BSC Berlin · Hertha Berliner Sport-Club
  - 1\. FC Union Berlin  (2) Union Berlin · FC Union Berlin
  - Tennis Borussia Berlin  (2) TB Berlin · TeBe Berlin
  - Blau-Weiß 90 Berlin (-1992)  (1) Blau-Weiss 90 Berlin
  - SC Tasmania 1900 Berlin (-1973)  (3) Tasmania Berlin · Tasmania 1900 Berlin · SV Tasmania Berlin
  - BFC Dynamo Berlin  (2) BFC Dynamo · Berliner FC Dynamo
  - Berliner AK 07 
  - FC Viktoria 1889 Berlin  (1) Viktoria Berlin
- **Leipzig, Sachsen** (6): 
  - RB Leipzig  (1) Rasenballsport Leipzig
  - VfB Leipzig (-2004)  (1) Leipzig
  - 1\. FC Lokomotive Leipzig (1966-1991)  (4) 1. FC Lok · 1. FC Lok Leipzig · Lok Leipzig · Lokomotive Leipzig
  - BSG Chemie Leipzig  (1) Betriebssportgemeinschaft Chemie Leipzig
  - FC Sachsen Leipzig (1990-2011) 
  - SG Sachsen Leipzig (2011-2014) 
- **München, Bayern** (4): 
  - Bayern München  (4) Bayern · FC Bayern München · Bayern Munich [en] · FC Bayern Munich [en]
  - Bayern München II  (2) Bayern II · Bayern München Am.
  - TSV 1860 München  (4) 1860 München · TSV München 1860 · Munich 1860 [en] · TSV 1860 Munich [en]
  - Türkgücü München  (1) Türkgücü
- **Köln, Nordrhein-Westfalen** (3): 
  - 1\. FC Köln  (2) Köln · FC Köln
  - Fortuna Köln  (3) F Köln · SC Fortuna Köln · Sportclub Fortuna Köln
  - FC Viktoria Köln  (1) Viktoria Köln
- **Stuttgart, Baden-Württemberg** (3): 
  - VfB Stuttgart  (1) Stuttgart
  - VfB Stuttgart II  (1) Stuttgart II
  - Stuttgarter Kickers  (2) Stutt. Kick. · Stuttgarter K
- **Augsburg, Bayern** (2): 
  - FC Augsburg  (1) Augsburg
  - FC Augsburg II  (1) Augsburg II
- **Bochum, Nordrhein-Westfalen** (2): 
  - VfL Bochum  (2) Bochum · VfL Bochum 1848
  - SG Wattenscheid 09  (2) Wattenscheid · Wattenscheid 09
- **Bremen, Bremen** (2): 
  - Werder Bremen  (2) Bremen · SV Werder Bremen
  - Werder Bremen II 
- **Dortmund, Nordrhein-Westfalen** (2): 
  - Borussia Dortmund  (3) Dortmund · Bor. Dortmund · BV 09 Borussia Dortmund
  - Borussia Dortmund II  (2) Dortmund II · Bor. Dortmund II
- **Frankfurt am Main, Hessen** (2): 
  - Eintracht Frankfurt  (8) Frankfurt · E. Frankfurt · Ein Frankfurt · Eint Frankfurt · Eintr. Frankfurt · SG Eintracht Frankfurt · Frankfurter SG Eintracht · Frankfurter Sportgemeinde Eintracht
  - FSV Frankfurt  (2) Frankfurt FSV · FSV Frankfurt 1899
- **Fürth, Bayern** (2): 
  - SpVgg Greuther Fürth  (1) Greuther Fürth
  - SpVgg Greuther Fürth II  (2) Gr. Fürth II · Greuther Fürth II
- **Hamburg, Hamburg** (2): 
  - Hamburger SV  (1) Hamburg
  - FC St. Pauli  (3) St Pauli · St. Pauli · FC Sankt Pauli
- **Mainz, Rheinland-Pfalz** (2): 
  - 1\. FSV Mainz 05  (3) Mainz · Mainz 05 · FSV Mainz 05
  - 1\. FSV Mainz 05 II 
- **Mannheim, Baden-Württemberg** (2): 
  - VfR Mannheim  (1) Mannheim
  - SV Waldhof Mannheim  (3) W. Mannheim · Waldhof Mannheim · SV Waldhof Mannheim 07
- **Nürnberg, Bayern** (2): 
  - 1\. FC Nürnberg  (2) Nürnberg · 1. FC Nuremberg [en]
  - 1\. FC Nürnberg II  (1) Nürnberg II
- **1966 Chemnitz, Sachsen** (1): Chemnitzer FC  (2) Chemnitz · FC Karl-Marx-Stadt
- **Aachen, Nordrhein-Westfalen** (1): Alemannia Aachen  (2) Aachen · TSV Alemannia Aachen
- **Aalen, Baden-Württemberg** (1): VfR Aalen  (1) Aalen
- **Ahlen, Nordrhein-Westfalen** (1): Rot Weiss Ahlen  (1) Ahlen
- **Aschaffenburg, Bayern** (1): Viktoria Aschaffenburg  (1) Aschaffenburg
- **Aue, Sachsen** (1): FC Erzgebirge Aue  (5) Aue · Erzgebirge Aue · SC Wismut Karl-Marx-Stadt · Wismut Aue · FC Wismut Aue
- **Bayreuth, Bayern** (1): SpVgg Bayreuth  (1) Bayreuth
- **Bielefeld, Nordrhein-Westfalen** (1): Arminia Bielefeld  (2) Bielefeld · DSC Arminia Bielefeld
- **Brandenburg an der Havel, Brandenburg** (1): FC Stahl Brandenburg  (3) Stahl Brandenburg · BSV Brandenburg · BSV Stahl Brandenburg
- **Braunschweig, Niedersachsen** (1): Eintracht Braunschweig  (4) Braunschweig · E. Braunschweig · Eintr. Braunschweig · TSV Eintracht Braunschweig
- **Burghausen, Bayern** (1): Wacker Burghausen  (1) Burghausen
- **Cottbus, Brandenburg** (1): Energie Cottbus  (2) Cottbus · FC Energie Cottbus
- **Darmstadt, Hessen** (1): SV Darmstadt 98  (1) Darmstadt
- **Dresden, Sachsen** (1): Dynamo Dresden  (3) Dresden · SG Dynamo Dresden · 1. FC Dynamo Dresden
- **Duisburg, Nordrhein-Westfalen** (1): MSV Duisburg  (2) Duisburg · Meidericher SV
- **Düsseldorf, Nordrhein-Westfalen** (1): Fortuna Düsseldorf  (2) Düsseldorf · F. Düsseldorf
- **Erfurt, Thüringen** (1): FC Rot-Weiß Erfurt  (3) Erfurt · RW Erfurt · Rot-Weiß Erfurt
- **Essen, Nordrhein-Westfalen** (1): Rot-Weiss Essen  (3) Essen · RW Essen · SC Rot-Weiss Essen
- **Frankfurt an der Oder, Brandenburg** (1): FFC Victoria 91  (4) 1. FC Frankfurt · 1. FC Frankfurt (Oder) · FC Frankfurt Viktoria/Oder · FC Vorwärts Frankfurt
- **Freiburg, Baden-Württemberg** (1): SC Freiburg  (1) Freiburg
- **Gelsenkirchen, Nordrhein-Westfalen** (1): FC Schalke 04  (2) Schalke · Schalke 04
- **Gütersloh, Nordrhein-Westfalen** (1): Gütersloh 
- **Halle an der Saale, Sachsen-Anhalt** (1): Hallescher FC  (3) Halle · FC Halle · Hallescher FC Chemie
- **Hannover, Niedersachsen** (1): Hannover 96  (2) Hannover · Hannover 1896
- **Heidenheim an der Brenz, Baden-Württemberg** (1): 1. FC Heidenheim  (3) Heidenheim · FC Heidenheim · 1. FC Heidenheim 1846
- **Homburg, Saarland** (1): FC 08 Homburg  (3) Homburg · FC Homburg · FC Homburg/Saar
- **Ingolstadt, Bayern** (1): FC Ingolstadt 04  (2) Ingolstadt · FC Ingolstadt
- **Jena, Thüringen** (1): FC Carl Zeiss Jena  (3) CZ Jena · Carl Zeiss Jena · SC Motor Jena
- **Kaiserslautern, Rheinland-Pfalz** (1): 1. FC Kaiserslautern  (4) K'lautern · Kaiserslautern · 1. FC K'lautern · FC Kaiserslautern
- **Karlsruhe, Baden-Württemberg** (1): Karlsruher SC  (1) Karlsruhe
- **Kiel, Schleswig-Holstein** (1): Holstein Kiel  (1) Kiel
- **Koblenz, Rheinland-Pfalz** (1): TuS Koblenz  (1) Koblenz
- **Krefeld, Nordrhein-Westfalen** (1): KFC Uerdingen  (5) Uerdingen · KFC Uerdingen 05 · Bayer 05 Uerdingen · FC Bayer 05 Uerdingen · Bayer Uerdingen
- **Leverkusen, Nordrhein-Westfalen** (1): Bayer 04 Leverkusen  (4) Bayer · Leverkusen · Bayer Leverkusen · Bay. Leverkusen
- **Lübeck, Schleswig-Holstein** (1): VfB Lübeck  (1) Lübeck
- **Magdeburg, Sachsen-Anhalt** (1): 1. FC Magdeburg  (2) Magdeburg · FC Magdeburg
- **Meppen, Niedersachsen** (1): SV Meppen  (1) Meppen
- **Mönchengladbach, Nordrhein-Westfalen** (1): Bor. Mönchengladbach  (6) Mönchengladbach · M'Gladbach · Borussia M'gladbach · Bor. M'gladbach · Borussia Mönchengladbach · VfL Borussia Mönchengladbach
- **Münster, Nordrhein-Westfalen** (1): Preußen Münster  (3) Münster · SC Preußen 06 · SC Preußen Münster
- **Neunkirchen, Saarland** (1): VfB Borussia Neunkirchen  (1) Borussia Neunkirchen
- **Nordhausen, Thüringen** (1): Wacker Nordhausen  (1) FSV Wacker 90 Nordhausen
- **Oberhausen, Nordrhein-Westfalen** (1): Rot-Weiß Oberhausen  (2) Oberhausen · Rot-Weiss Oberhausen
- **Offenbach am Main, Hessen** (1): Kickers Offenbach  (1) Offenbach
- **Oldenburg, Niedersachsen** (1): VfB Oldenburg  (1) Oldenburg
- **Osnabrück, Niedersachsen** (1): VfL Osnabrück  (1) Osnabrück
- **Paderborn, Nordrhein-Westfalen** (1): SC Paderborn 07  (3) Paderborn · Paderborn 07 · SC Paderborn
- **Potsdam, Brandenburg** (1): SV Babelsberg 03  (1) Babelsberg
- **Regensburg, Bayern** (1): SSV Jahn Regensburg  (2) Regensburg · Jahn Regensburg
- **Reutlingen, Baden-Württemberg** (1): SSV Reutlingen 05  (1) Reutlingen
- **Rosenheim, Bayern** (1): TSV 1860 Rosenheim  (1) 1860 Rosenheim
- **Rostock, Mecklenburg-Vorpommern** (1): Hansa Rostock  (2) Rostock · FC Hansa Rostock
- **Rödinghausen, Nordrhein-Westfalen** (1): SV Rödinghausen 
- **Saarbrücken, Saarland** (1): 1. FC Saarbrücken  (2) Saarbrücken · FC Saarbrücken
- **Sandhausen, Baden-Württemberg** (1): SV Sandhausen  (2) Sandhausen · SV Sandhausen 1916
- **Schweinfurt, Bayern** (1): 1. FC Schweinfurt 05  (2) Schweinfurt · Schweinfurt 05
- **Schwerin, Mecklenburg-Vorpommern** (1): FC Mecklenburg Schwerin  (3) FC Eintracht Schwerin · PSV Schwerin · Polizei SV Schwerin
- **Siegen, Nordrhein-Westfalen** (1): SF Siegen  (2) Siegen · Sportfreunde Siegen
- **Sinsheim, Baden-Württemberg** (1): TSG 1899 Hoffenheim  (3) Hoffenheim · 1899 Hoffenheim · TSG Hoffenheim
- **Trier, Rheinland-Pfalz** (1): Eintracht Trier  (1) Ein Trier
- **Ulm, Baden-Württemberg** (1): SSV Ulm 1846  (1) Ulm
- **Unterhaching, Bayern** (1): SpVgg Unterhaching  (2) U'haching · Unterhaching
- **Verl, Nordrhein-Westfalen** (1): SC Verl 
- **Wiesbaden, Hessen** (1): SV Wehen Wiesbaden  (3) Wehen · Wiesbaden · Wehen Wiesbaden
- **Wolfsburg, Niedersachsen** (1): VfL Wolfsburg  (1) Wolfsburg
- **Wuppertal, Nordrhein-Westfalen** (1): Wuppertaler SV  (1) Wuppertaler
- **Würzburg, Bayern** (1): Würzburger Kickers  (2) FC Würzburger Kickers · Kickers Würzburg
- **Zwickau, Sachsen** (1): FSV Zwickau  (1) Zwickau
- ? (48): 
  - FV Illertissen  (1) Illertissen
  - TSV Aubstadt 
  - TSV Buchbach  (1) Buchbach
  - VfB Eichstätt  (1) Eichstätt
  - SV Heimstetten  (1) Heimstetten
  - SV Schalding-Heining  (2) Schald.-Hein. · Schalding-Heining
  - FC Memmingen  (1) Memmingen
  - VfR Garching 
  - TSV 1896 Rain  (3) TSV Rain · TSV Rain/Lech · TSV Rain am Lech
  - SF Baumberg  (1) Sportfreunde Baumberg
  - SF Lotte  (1) Sportfreunde Lotte
  - SV Lippstadt 08 
  - SC Wiedenbrück  (1) SC Wiedenbrück 2000
  - FC Hennef 05 
  - TuS Erndtebrück 
  - SV Elversberg  (1) SV 07 Elversberg
  - FT Braunschweig  (1) Freie Turnerschaft Braunschweig
  - SV Wilhelmshaven 
  - BSV Schwarz-Weiß Rehden 
  - TSV Havelse 
  - FSV Optik Rathenow 
  - SV Falkensee-Finkenkrug 
  - ASK Vorwärts Berlin  (1) Vorwärts Berlin
  - SC Victoria Hamburg  (1) Victoria Hamburg
  - USC Paloma Hamburg 
  - HSV Barmbek-Uhlenhorst 
  - SG Aumund-Vegesack 
  - FC Oberneuland 
  - Bremer SV 
  - SG Großaspach  (3) Großaspach · SG Sonnenhof Großaspach · Sportgemeinschaft Sonnenhof Großaspach
  - FC Nöttingen 
  - Bahlinger SC 
  - Neckarsulmer Sport-Union 
  - Offenburger FV 
  - FC-Astoria Walldorf 
  - SV Waldkirch 
  - KSV Hessen Kassel 
  - TSG Pfeddersheim 
  - SV Roßbach/Verscheid 
  - Wormatia Worms 
  - SV Alemannia Waldalgesheim 
  - FSV Salmrohr 
  - FK Pirmasens  (1) FK 03 Pirmasens
  - VfR Neumünster 
  - TSG Neustrelitz 
  - FC Schönberg 95 
  - 1\. FC Neubrandenburg 04 
  - SV Schott Jena 




By Region

- **Bayern** (19):   Bayern München · Bayern München II · TSV 1860 München · Türkgücü München · 1. FC Nürnberg · 1. FC Nürnberg II · SpVgg Greuther Fürth · SpVgg Greuther Fürth II · FC Augsburg · FC Augsburg II · SpVgg Unterhaching · FC Ingolstadt 04 · SSV Jahn Regensburg · 1. FC Schweinfurt 05 · Würzburger Kickers · Wacker Burghausen · Viktoria Aschaffenburg · TSV 1860 Rosenheim · SpVgg Bayreuth
- **Nordrhein-Westfalen** (25):   1. FC Köln · Fortuna Köln · FC Viktoria Köln · Fortuna Düsseldorf · Borussia Dortmund · Borussia Dortmund II · FC Schalke 04 · Bayer 04 Leverkusen · MSV Duisburg · Bor. Mönchengladbach · VfL Bochum · SG Wattenscheid 09 · Arminia Bielefeld · Preußen Münster · Gütersloh · KFC Uerdingen · Alemannia Aachen · SC Paderborn 07 · Rot Weiss Ahlen · Rot-Weiß Oberhausen · SF Siegen · Wuppertaler SV · Rot-Weiss Essen · SC Verl · SV Rödinghausen
- **Saarland** (3):   1. FC Saarbrücken · FC 08 Homburg · VfB Borussia Neunkirchen
- **Niedersachsen** (6):   VfL Osnabrück · VfL Wolfsburg · Hannover 96 · Eintracht Braunschweig · SV Meppen · VfB Oldenburg
- **Brandenburg** (4):   Energie Cottbus · SV Babelsberg 03 · FFC Victoria 91 · FC Stahl Brandenburg
- **Berlin** (8):   Hertha BSC · 1. FC Union Berlin · Tennis Borussia Berlin · Blau-Weiß 90 Berlin (-1992) · SC Tasmania 1900 Berlin (-1973) · BFC Dynamo Berlin · Berliner AK 07 · FC Viktoria 1889 Berlin
- **Hamburg** (2):   Hamburger SV · FC St. Pauli
- **Bremen** (2):   Werder Bremen · Werder Bremen II
- **Baden-Württemberg** (13):   VfB Stuttgart · VfB Stuttgart II · Stuttgarter Kickers · SC Freiburg · TSG 1899 Hoffenheim · Karlsruher SC · SSV Ulm 1846 · VfR Aalen · 1. FC Heidenheim · SSV Reutlingen 05 · SV Sandhausen · VfR Mannheim · SV Waldhof Mannheim
- **Hessen** (5):   Eintracht Frankfurt · FSV Frankfurt · SV Darmstadt 98 · SV Wehen Wiesbaden · Kickers Offenbach
- **Rheinland-Pfalz** (5):   1. FC Kaiserslautern · 1. FSV Mainz 05 · 1. FSV Mainz 05 II · Eintracht Trier · TuS Koblenz
- **Schleswig-Holstein** (2):   VfB Lübeck · Holstein Kiel
- **Mecklenburg-Vorpommern** (2):   Hansa Rostock · FC Mecklenburg Schwerin
- **Sachsen** (10):   Dynamo Dresden · RB Leipzig · VfB Leipzig (-2004) · 1. FC Lokomotive Leipzig (1966-1991) · BSG Chemie Leipzig · FC Sachsen Leipzig (1990-2011) · SG Sachsen Leipzig (2011-2014) · Chemnitzer FC · FC Erzgebirge Aue · FSV Zwickau
- **Sachsen-Anhalt** (2):   Hallescher FC · 1. FC Magdeburg
- **Thüringen** (3):   FC Carl Zeiss Jena · FC Rot-Weiß Erfurt · Wacker Nordhausen




By Year

- **1860** (1):   TSV 1860 München
- **1887** (1):   Hamburger SV
- **1892** (1):   Hertha BSC
- **1893** (1):   VfB Stuttgart
- **1894** (1):   Karlsruher SC
- **1895** (2):   Fortuna Düsseldorf · Eintracht Braunschweig
- **1896** (1):   Hannover 96
- **1898** (1):   SV Darmstadt 98
- **1899** (4):   Werder Bremen · TSG 1899 Hoffenheim · Eintracht Frankfurt · FSV Frankfurt
- **1900** (4):   Bayern München · 1. FC Nürnberg · Bor. Mönchengladbach · 1. FC Kaiserslautern
- **1903** (1):   SpVgg Greuther Fürth
- **1904** (3):   FC Schalke 04 · Bayer 04 Leverkusen · SC Freiburg
- **1905** (2):   Arminia Bielefeld · 1. FSV Mainz 05
- **1907** (3):   FC Augsburg · Würzburger Kickers · SC Paderborn 07
- **1909** (1):   Borussia Dortmund
- **1910** (1):   FC St. Pauli
- **1916** (1):   SV Sandhausen
- **1921** (1):   VfR Aalen
- **1924** (1):   SC Verl
- **1938** (1):   VfL Bochum
- **1948** (2):   1. FC Köln · Fortuna Köln
- **1949** (1):   FC Erzgebirge Aue
- **1953** (1):   Dynamo Dresden
- **1965** (2):   Hansa Rostock · 1. FC Magdeburg
- **1966** (4):   Energie Cottbus · 1. FC Union Berlin · 1. FC Lokomotive Leipzig (1966-1991) · Hallescher FC
- **1970** (1):   SV Rödinghausen
- **1990** (1):   FC Sachsen Leipzig (1990-2011)
- **1994** (1):   SG Großaspach
- **2004** (1):   FC Ingolstadt 04
- **2007** (1):   1. FC Heidenheim
- **2009** (1):   RB Leipzig
- **2011** (1):   SG Sachsen Leipzig (2011-2014)
- ? (110):   Bayern München II · Türkgücü München · 1. FC Nürnberg II · SpVgg Greuther Fürth II · FC Augsburg II · SpVgg Unterhaching · SSV Jahn Regensburg · 1. FC Schweinfurt 05 · Wacker Burghausen · Viktoria Aschaffenburg · TSV 1860 Rosenheim · FV Illertissen · SpVgg Bayreuth · TSV Aubstadt · TSV Buchbach · VfB Eichstätt · SV Heimstetten · SV Schalding-Heining · FC Memmingen · VfR Garching · TSV 1896 Rain · FC Viktoria Köln · Borussia Dortmund II · MSV Duisburg · SG Wattenscheid 09 · Preußen Münster · Gütersloh · KFC Uerdingen · Alemannia Aachen · Rot Weiss Ahlen · Rot-Weiß Oberhausen · SF Siegen · Wuppertaler SV · Rot-Weiss Essen · SF Baumberg · SF Lotte · SV Lippstadt 08 · SC Wiedenbrück · FC Hennef 05 · TuS Erndtebrück · 1. FC Saarbrücken · FC 08 Homburg · VfB Borussia Neunkirchen · SV Elversberg · VfL Osnabrück · VfL Wolfsburg · FT Braunschweig · SV Meppen · VfB Oldenburg · SV Wilhelmshaven · BSV Schwarz-Weiß Rehden · TSV Havelse · SV Babelsberg 03 · FSV Optik Rathenow · SV Falkensee-Finkenkrug · FFC Victoria 91 · FC Stahl Brandenburg · Tennis Borussia Berlin · Blau-Weiß 90 Berlin (-1992) · SC Tasmania 1900 Berlin (-1973) · BFC Dynamo Berlin · Berliner AK 07 · FC Viktoria 1889 Berlin · ASK Vorwärts Berlin · SC Victoria Hamburg · USC Paloma Hamburg · HSV Barmbek-Uhlenhorst · Werder Bremen II · SG Aumund-Vegesack · FC Oberneuland · Bremer SV · VfB Stuttgart II · Stuttgarter Kickers · SSV Ulm 1846 · SSV Reutlingen 05 · VfR Mannheim · SV Waldhof Mannheim · FC Nöttingen · Bahlinger SC · Neckarsulmer Sport-Union · Offenburger FV · FC-Astoria Walldorf · SV Waldkirch · SV Wehen Wiesbaden · Kickers Offenbach · KSV Hessen Kassel · 1. FSV Mainz 05 II · Eintracht Trier · TuS Koblenz · TSG Pfeddersheim · SV Roßbach/Verscheid · Wormatia Worms · SV Alemannia Waldalgesheim · FSV Salmrohr · FK Pirmasens · VfB Lübeck · Holstein Kiel · VfR Neumünster · TSG Neustrelitz · FC Schönberg 95 · 1. FC Neubrandenburg 04 · FC Mecklenburg Schwerin · VfB Leipzig (-2004) · BSG Chemie Leipzig · Chemnitzer FC · FSV Zwickau · FC Carl Zeiss Jena · SV Schott Jena · FC Rot-Weiß Erfurt · Wacker Nordhausen




Historic

- **1973** (1):   SC Tasmania 1900 Berlin (-1973)
- **1991** (1):   1. FC Lokomotive Leipzig (1966-1991)
- **1992** (1):   Blau-Weiß 90 Berlin (-1992)
- **2004** (1):   VfB Leipzig (-2004)
- **2011** (1):   FC Sachsen Leipzig (1990-2011)
- **2014** (1):   SG Sachsen Leipzig (2011-2014)






By A to Z

- **1** (24): 1. FC Lok · 1. FC Köln · 1860 München · 1. FC Nürnberg · 1860 Rosenheim · 1. FC Frankfurt · 1. FC K'lautern · 1. FC Magdeburg · 1. FSV Mainz 05 · 1899 Hoffenheim · 1. FC Heidenheim · 1. FC Lok Leipzig · 1. FC Nürnberg II · 1. FC Saarbrücken · 1. FC Union Berlin · 1. FSV Mainz 05 II · 1. FC Dynamo Dresden · 1. FC Kaiserslautern · 1. FC Nuremberg [en] · 1. FC Schweinfurt 05 · 1. FC Heidenheim 1846 · 1. FC Frankfurt (Oder) · 1. FC Neubrandenburg 04 · 1. FC Lokomotive Leipzig (1966-1991)
- **A** (10): Aue · Aalen · Ahlen · Aachen · Augsburg · Augsburg II · Aschaffenburg · Alemannia Aachen · Arminia Bielefeld · ASK Vorwärts Berlin
- **B** (43): Bayer · Bayern · Bochum · Bremen · Bayreuth · Buchbach · Bayern II · Bielefeld · Bremer SV · BFC Dynamo · Babelsberg · Burghausen · Bahlinger SC · Braunschweig · Bor. Dortmund · Bayern München · Berliner AK 07 · BSV Brandenburg · Bay. Leverkusen · Bayer Uerdingen · Bor. M'gladbach · Bayer Leverkusen · Bor. Dortmund II · BFC Dynamo Berlin · Bayern München II · Borussia Dortmund · BSG Chemie Leipzig · Bayer 05 Uerdingen · Bayern Munich [en] · Bayern München Am. · Berliner FC Dynamo · Bayer 04 Leverkusen · Borussia M'gladbach · Blau-Weiss 90 Berlin · Bor. Mönchengladbach · Borussia Dortmund II · Borussia Neunkirchen · BSV Stahl Brandenburg · BSV Schwarz-Weiß Rehden · BV 09 Borussia Dortmund · Borussia Mönchengladbach · Blau-Weiß 90 Berlin (-1992) · Betriebssportgemeinschaft Chemie Leipzig
- **C** (5): CZ Jena · Cottbus · Chemnitz · Chemnitzer FC · Carl Zeiss Jena
- **D** (8): Dresden · Dortmund · Duisburg · Darmstadt · Düsseldorf · Dortmund II · Dynamo Dresden · DSC Arminia Bielefeld
- **E** (15): Essen · Erfurt · Eichstätt · Ein Trier · E. Frankfurt · Ein Frankfurt · Eint Frankfurt · Erzgebirge Aue · E. Braunschweig · Eintracht Trier · Energie Cottbus · Eintr. Frankfurt · Eintr. Braunschweig · Eintracht Frankfurt · Eintracht Braunschweig
- **F** (64): F Köln · FC Köln · FC Halle · Freiburg · Frankfurt · FC Homburg · FC Augsburg · FSV Zwickau · FC Hennef 05 · FC Magdeburg · FC Memmingen · FC Nöttingen · FC St. Pauli · FK Pirmasens · FSV Mainz 05 · FSV Salmrohr · Fortuna Köln · F. Düsseldorf · FC 08 Homburg · FC Heidenheim · FC Ingolstadt · FC Schalke 04 · FC Wismut Aue · FSV Frankfurt · Frankfurt FSV · FC Augsburg II · FC Oberneuland · FC Saarbrücken · FC Sankt Pauli · FV Illertissen · FC Homburg/Saar · FC Schönberg 95 · FC Union Berlin · FFC Victoria 91 · FK 03 Pirmasens · FT Braunschweig · FC Hansa Rostock · FC Ingolstadt 04 · FC Viktoria Köln · FC Bayern München · FC Erzgebirge Aue · FC Kaiserslautern · FC Carl Zeiss Jena · FC Energie Cottbus · FC Karl-Marx-Stadt · FC Rot-Weiß Erfurt · FSV Frankfurt 1899 · FSV Optik Rathenow · Fortuna Düsseldorf · FC-Astoria Walldorf · FC Stahl Brandenburg · FC Bayer 05 Uerdingen · FC Bayern Munich [en] · FC Eintracht Schwerin · FC Vorwärts Frankfurt · FC Würzburger Kickers · FC Mecklenburg Schwerin · FC Viktoria 1889 Berlin · FSV Wacker 90 Nordhausen · Frankfurter SG Eintracht · FC Frankfurt Viktoria/Oder · FC Sachsen Leipzig (1990-2011) · Freie Turnerschaft Braunschweig · Frankfurter Sportgemeinde Eintracht
- **G** (5): Gütersloh · Großaspach · Gr. Fürth II · Greuther Fürth · Greuther Fürth II
- **H** (20): Halle · Hertha · Hamburg · Homburg · Hannover · Heidenheim · Hertha BSC · Hoffenheim · Hannover 96 · Heimstetten · Hamburger SV · Hallescher FC · Hannover 1896 · Hansa Rostock · Hertha Berlin · Holstein Kiel · Hertha BSC Berlin · Hallescher FC Chemie · HSV Barmbek-Uhlenhorst · Hertha Berliner Sport-Club
- **I** (2): Ingolstadt · Illertissen
- **J** (1): Jahn Regensburg
- **K** (12): Kiel · Köln · Koblenz · K'lautern · Karlsruhe · KFC Uerdingen · Karlsruher SC · Kaiserslautern · KFC Uerdingen 05 · Kickers Würzburg · KSV Hessen Kassel · Kickers Offenbach
- **L** (5): Lübeck · Leipzig · Leverkusen · Lok Leipzig · Lokomotive Leipzig
- **M** (12): Mainz · Meppen · Münster · Mainz 05 · Mannheim · Magdeburg · Memmingen · M'Gladbach · MSV Duisburg · Meidericher SV · Mönchengladbach · Munich 1860 [en]
- **N** (3): Nürnberg · Nürnberg II · Neckarsulmer Sport-Union
- **O** (5): Offenbach · Oldenburg · Osnabrück · Oberhausen · Offenburger FV
- **P** (5): Paderborn · PSV Schwerin · Paderborn 07 · Preußen Münster · Polizei SV Schwerin
- **R** (12): Rostock · RW Essen · RW Erfurt · RB Leipzig · Regensburg · Reutlingen · Rot Weiss Ahlen · Rot-Weiss Essen · Rot-Weiß Erfurt · Rot-Weiß Oberhausen · Rot-Weiss Oberhausen · Rasenballsport Leipzig
- **S** (75): Siegen · SC Verl · Schalke · SF Lotte · St Pauli · SF Siegen · SV Meppen · St. Pauli · Stuttgart · Sandhausen · Schalke 04 · SC Freiburg · SF Baumberg · Saarbrücken · Schweinfurt · SC Paderborn · SSV Ulm 1846 · SV Waldkirch · Stutt. Kick. · Stuttgart II · SC Motor Jena · SC Preußen 06 · SG Großaspach · SV Elversberg · SV Sandhausen · Schald.-Hein. · Stuttgarter K · SC Wiedenbrück · SV Heimstetten · SV Schott Jena · Schweinfurt 05 · SpVgg Bayreuth · SC Fortuna Köln · SC Paderborn 07 · SV Darmstadt 98 · SV Lippstadt 08 · SV Rödinghausen · SV 07 Elversberg · SV Babelsberg 03 · SV Werder Bremen · SV Wilhelmshaven · SG Dynamo Dresden · SSV Reutlingen 05 · Schalding-Heining · Stahl Brandenburg · SC Preußen Münster · SC Rot-Weiss Essen · SG Aumund-Vegesack · SG Wattenscheid 09 · SV Sandhausen 1916 · SV Tasmania Berlin · SV Wehen Wiesbaden · SpVgg Unterhaching · Sportfreunde Lotte · SC Victoria Hamburg · SC Wiedenbrück 2000 · SSV Jahn Regensburg · SV Waldhof Mannheim · Sportfreunde Siegen · Stuttgarter Kickers · SV Roßbach/Verscheid · SV Schalding-Heining · SpVgg Greuther Fürth · Sportfreunde Baumberg · SG Eintracht Frankfurt · SV Waldhof Mannheim 07 · Sportclub Fortuna Köln · SG Sonnenhof Großaspach · SV Falkensee-Finkenkrug · SpVgg Greuther Fürth II · SC Wismut Karl-Marx-Stadt · SV Alemannia Waldalgesheim · SG Sachsen Leipzig (2011-2014) · SC Tasmania 1900 Berlin (-1973) · Sportgemeinschaft Sonnenhof Großaspach
- **T** (26): TSV Rain · Türkgücü · TB Berlin · TSV Havelse · TeBe Berlin · TuS Koblenz · TSV Aubstadt · TSV Buchbach · TSV 1896 Rain · TSV Rain/Lech · TSG Hoffenheim · TSG Neustrelitz · Tasmania Berlin · TuS Erndtebrück · TSG Pfeddersheim · TSV 1860 München · TSV München 1860 · TSV Rain am Lech · Türkgücü München · TSV 1860 Rosenheim · TSG 1899 Hoffenheim · TSV 1860 Munich [en] · TSV Alemannia Aachen · Tasmania 1900 Berlin · Tennis Borussia Berlin · TSV Eintracht Braunschweig
- **U** (6): Ulm · U'haching · Uerdingen · Union Berlin · Unterhaching · USC Paloma Hamburg
- **V** (21): VfR Aalen · VfB Lübeck · VfL Bochum · VfR Garching · VfR Mannheim · VfB Eichstätt · VfB Oldenburg · VfB Stuttgart · VfL Osnabrück · VfL Wolfsburg · Viktoria Köln · VfR Neumünster · VfL Bochum 1848 · Viktoria Berlin · Vorwärts Berlin · VfB Stuttgart II · Victoria Hamburg · VfB Leipzig (-2004) · Viktoria Aschaffenburg · VfB Borussia Neunkirchen · VfL Borussia Mönchengladbach
- **W** (17): Wehen · Wiesbaden · Wolfsburg · Wismut Aue · W. Mannheim · Wuppertaler · Wattenscheid · Werder Bremen · Wormatia Worms · Wuppertaler SV · Wattenscheid 09 · Wehen Wiesbaden · Waldhof Mannheim · Werder Bremen II · Wacker Burghausen · Wacker Nordhausen · Würzburger Kickers
- **Z** (1): Zwickau




