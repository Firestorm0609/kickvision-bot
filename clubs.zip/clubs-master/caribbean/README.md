4 datafiles, 13 clubs

**caribbean/anguilla/ai.clubs.txt** _(8)_:  ALHCS Spartan FC · Diamond FC · Docks United FC · Enforcers FC · Kicks United FC · Roaring Lions FC · Salsa Ballers FC · Up Rising FC

**caribbean/haiti/ht.clubs.txt** _(2)_:  Tempête FC · Valencia FC

**caribbean/puerto-rico/pr.clubs.txt** _(1)_:  Puerto Rico Islanders

**caribbean/trinidad-n-tobago/tt.clubs.txt** _(2)_:  Caledonia AIA · W Connection

