8 clubs

- **ALHCS Spartan FC** : (1) ALHCS Spartan
- **Diamond FC** : (1) Diamond
- **Docks United FC** : (1) Docks United
- **Enforcers FC** : (1) Enforcers
- **Kicks United FC** : (1) Kicks United
- **Roaring Lions FC** : (1) Roaring Lions
- **Salsa Ballers FC** : (1) Ballers
- **Up Rising FC** : (1) Up Rising




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **The Valley** (4): 
  - ALHCS Spartan FC  (1) ALHCS Spartan
  - Diamond FC  (1) Diamond
  - Docks United FC  (1) Docks United
  - Kicks United FC  (1) Kicks United
- **George Hill** (1): Salsa Ballers FC  (1) Ballers
- **Stoney Ground** (1): Roaring Lions FC  (1) Roaring Lions
- ? (2): 
  - Enforcers FC  (1) Enforcers
  - Up Rising FC  (1) Up Rising




By Region

- **The Valley†** (4):   ALHCS Spartan FC · Diamond FC · Docks United FC · Kicks United FC
- **Stoney Ground†** (1):   Roaring Lions FC
- **George Hill†** (1):   Salsa Ballers FC




By Year

- ? (8):   ALHCS Spartan FC · Diamond FC · Docks United FC · Enforcers FC · Kicks United FC · Roaring Lions FC · Salsa Ballers FC · Up Rising FC






By A to Z

- **A** (2): ALHCS Spartan · ALHCS Spartan FC
- **B** (1): Ballers
- **D** (4): Diamond · Diamond FC · Docks United · Docks United FC
- **E** (2): Enforcers · Enforcers FC
- **K** (2): Kicks United · Kicks United FC
- **R** (2): Roaring Lions · Roaring Lions FC
- **S** (1): Salsa Ballers FC
- **U** (2): Up Rising · Up Rising FC




