20 clubs

- **Liverpool Montevideo** : (5) Liverpool · Liverpool FC · Liverpool Montevid · Liverpool Fútbol Club · Liverpool FC Montevideo ⇒ (1) ≈Liverpool Futbol Club≈
- **Nacional de Montevideo** : (5) Nacional · C. N. de F. · Club Nacional · Nacional de Footb. · Club Nacional de Football
- **Defensor Sporting** : (3) Defensor · Defensor Sp. · Defensor Sporting Club
- **CA Peñarol** : (2) Peñarol · Club Atlético Peñarol ⇒ (3) ≈Penarol≈ · ≈CA Penarol≈ · ≈Club Atletico Penarol≈
- **CA Cerro** : (2) Cerro · Club Atlético Cerro ⇒ (1) ≈Club Atletico Cerro≈
- **Danubio FC** : (2) Danubio · Danubio Fútbol Club ⇒ (1) ≈Danubio Futbol Club≈
- **El Tanque Sisley** : (1) Deportivo El Tanque Sisley
- **Centro Atlético Fénix** : (2) Fénix · CA Fénix ⇒ (3) ≈Fenix≈ · ≈CA Fenix≈ · ≈Centro Atletico Fenix≈
- **CS Miramar Misiones** : (2) Miramar Misiones · Club Sportivo Miramar Misiones
- **Montevideo Wanderers** : (4) Wanderers · Montev. Wanderers · Montevideo Wanderers FC · Montevideo Wanderers Fútbol Club ⇒ (1) ≈Montevideo Wanderers Futbol Club≈
- **Racing CM** : (3) Racing · RC Montevideo · Racing Club de Montevideo
- **CA Rentistas** : (2) Rentistas · Club Atlético Rentistas ⇒ (1) ≈Club Atletico Rentistas≈
- **CA River Plate** : (3) River Plate · Club Atlético River Plate · Club Atlético River Plate (Uruguay) ⇒ (2) ≈Club Atletico River Plate≈ · ≈Club Atletico River Plate (Uruguay)≈
- **Boston River** : (1) CA Boston River
- **CA Progreso** : (1) Progreso
- **Rampla Juniors** : (1) Rampla Juniors FC
- **Juventud de Las Piedras** : (3) Juventud · Juventud Piedras · Club Atlético Juventud de Las Piedras ⇒ (1) ≈Club Atletico Juventud de Las Piedras≈
- **Cerro Largo** : (2) Cerro Largo FC · Cerro Largo Fútbol Club ⇒ (1) ≈Cerro Largo Futbol Club≈
- **Sud América** : (2) I.A.S.A · Institución Atlética Sud América ⇒ (2) ≈Sud America≈ · ≈Institucion Atletica Sud America≈
- **Club Plaza Colonia de Deportes** : (2) Plaza Colonia · Plaza Colonia CD




Alphabet

- **Alphabet Specials** (4):  **é**  **ñ**  **ó**  **ú** 
  - **é**×13 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ñ**×3 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×4 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Montevideo** (16): 
  - Liverpool Montevideo  (5) Liverpool · Liverpool FC · Liverpool Fútbol Club · Liverpool Montevid · Liverpool FC Montevideo
  - Nacional de Montevideo  (5) Nacional · Nacional de Footb. · Club Nacional · Club Nacional de Football · C. N. de F.
  - Defensor Sporting  (3) Defensor · Defensor Sp. · Defensor Sporting Club
  - CA Peñarol  (2) Peñarol · Club Atlético Peñarol
  - CA Cerro  (2) Cerro · Club Atlético Cerro
  - Danubio FC  (2) Danubio · Danubio Fútbol Club
  - El Tanque Sisley  (1) Deportivo El Tanque Sisley
  - Centro Atlético Fénix  (2) Fénix · CA Fénix
  - CS Miramar Misiones  (2) Miramar Misiones · Club Sportivo Miramar Misiones
  - Montevideo Wanderers  (4) Wanderers · Montev. Wanderers · Montevideo Wanderers FC · Montevideo Wanderers Fútbol Club
  - Racing CM  (3) Racing · Racing Club de Montevideo · RC Montevideo
  - CA Rentistas  (2) Rentistas · Club Atlético Rentistas
  - CA River Plate  (3) River Plate · Club Atlético River Plate · Club Atlético River Plate (Uruguay)
  - Boston River  (1) CA Boston River
  - CA Progreso  (1) Progreso
  - Rampla Juniors  (1) Rampla Juniors FC
- **Colonia** (1): Club Plaza Colonia de Deportes  (2) Plaza Colonia · Plaza Colonia CD
- **Las Piedras** (1): Juventud de Las Piedras  (3) Juventud · Juventud Piedras · Club Atlético Juventud de Las Piedras
- **Melo** (1): Cerro Largo  (2) Cerro Largo FC · Cerro Largo Fútbol Club
- **San José** (1): Sud América  (2) Institución Atlética Sud América · I.A.S.A




By Region

- **Montevideo†** (16):   Liverpool Montevideo · Nacional de Montevideo · Defensor Sporting · CA Peñarol · CA Cerro · Danubio FC · El Tanque Sisley · Centro Atlético Fénix · CS Miramar Misiones · Montevideo Wanderers · Racing CM · CA Rentistas · CA River Plate · Boston River · CA Progreso · Rampla Juniors
- **Las Piedras†** (1):   Juventud de Las Piedras
- **Melo†** (1):   Cerro Largo
- **San José†** (1):   Sud América
- **Colonia†** (1):   Club Plaza Colonia de Deportes




By Year

- **1899** (1):   Nacional de Montevideo
- **1902** (1):   Montevideo Wanderers
- **1906** (1):   CS Miramar Misiones
- **1914** (1):   Sud América
- **1916** (1):   Centro Atlético Fénix
- **1919** (1):   Racing CM
- **1922** (1):   CA Cerro
- **1932** (2):   Danubio FC · CA River Plate
- **1933** (1):   CA Rentistas
- **1935** (1):   Juventud de Las Piedras
- **1941** (1):   El Tanque Sisley
- **2002** (1):   Cerro Largo
- ? (7):   Liverpool Montevideo · Defensor Sporting · CA Peñarol · Boston River · CA Progreso · Rampla Juniors · Club Plaza Colonia de Deportes






By A to Z

- **B** (1): Boston River
- **C** (24): Cerro · CA Cerro · CA Fénix · CA Peñarol · C. N. de F. · CA Progreso · Cerro Largo · CA Rentistas · Club Nacional · CA River Plate · Cerro Largo FC · CA Boston River · CS Miramar Misiones · Club Atlético Cerro · Centro Atlético Fénix · Club Atlético Peñarol · Cerro Largo Fútbol Club · Club Atlético Rentistas · Club Atlético River Plate · Club Nacional de Football · Club Plaza Colonia de Deportes · Club Sportivo Miramar Misiones · Club Atlético River Plate (Uruguay) · Club Atlético Juventud de Las Piedras
- **D** (8): Danubio · Defensor · Danubio FC · Defensor Sp. · Defensor Sporting · Danubio Fútbol Club · Defensor Sporting Club · Deportivo El Tanque Sisley
- **E** (1): El Tanque Sisley
- **F** (1): Fénix
- **I** (2): I.A.S.A · Institución Atlética Sud América
- **J** (3): Juventud · Juventud Piedras · Juventud de Las Piedras
- **L** (6): Liverpool · Liverpool FC · Liverpool Montevid · Liverpool Montevideo · Liverpool Fútbol Club · Liverpool FC Montevideo
- **M** (5): Miramar Misiones · Montev. Wanderers · Montevideo Wanderers · Montevideo Wanderers FC · Montevideo Wanderers Fútbol Club
- **N** (3): Nacional · Nacional de Footb. · Nacional de Montevideo
- **P** (4): Peñarol · Progreso · Plaza Colonia · Plaza Colonia CD
- **R** (8): Racing · Racing CM · Rentistas · River Plate · RC Montevideo · Rampla Juniors · Rampla Juniors FC · Racing Club de Montevideo
- **S** (1): Sud América
- **W** (1): Wanderers




