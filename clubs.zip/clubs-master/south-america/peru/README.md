20 clubs

- **Alianza Lima** : (1) Club Alianza Lima
- **Sporting Cristal** : (1) Club Sporting Cristal
- **Deportivo Municipal**
- **Club Deportivo Universidad de San Martín de Porres** : (1) Universidad San Martín ⇒ (2) ≈Universidad San Martin≈ · ≈Club Deportivo Universidad de San Martin de Porres≈
- **Club Universitario de Deportes** : (1) Universitario
- **Juan Aurich** : (1) Club Juan Aurich S.A
- **Molinos El Pirata**
- **Sport Huancayo**
- **Alianza Universidad** : (1) Ali. Univ. Huánuco ⇒ (1) ≈Ali. Univ. Huanuco≈
- **Real Garcilaso** : (1) Asociación Civil Real Atlético Garcilaso ⇒ (1) ≈Asociacion Civil Real Atletico Garcilaso≈
- **Universidad César Vallejo** : (1) Club Deportivo Universidad César Vallejo ⇒ (2) ≈Universidad Cesar Vallejo≈ · ≈Club Deportivo Universidad Cesar Vallejo≈
- **Carlos A. Mannucci**
- **Ayacucho FC** : (1) Ayacucho
- **Escuela Municipal Binacional** : (1) Binacional
- **Academia Cantolao** : (1) Cantolao
- **Sport Boys**
- **FBC Melgar** : (1) Melgar
- **Unión Comercio** ⇒ (1) ≈Union Comercio≈
- **Universidad Técnica de Cajamarca** : (1) UTC ⇒ (1) ≈Universidad Tecnica de Cajamarca≈
- **Club Atlético Grau** : (1) Atlético Grau ⇒ (2) ≈Atletico Grau≈ · ≈Club Atletico Grau≈




Alphabet

- **Alphabet Specials** (4):  **á**  **é**  **í**  **ó** 
  - **á**×1 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×6 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×2 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Lima** (5): 
  - Alianza Lima  (1) Club Alianza Lima
  - Sporting Cristal  (1) Club Sporting Cristal
  - Deportivo Municipal 
  - Club Deportivo Universidad de San Martín de Porres  (1) Universidad San Martín
  - Club Universitario de Deportes  (1) Universitario
- **Callao** (2): 
  - Academia Cantolao  (1) Cantolao
  - Sport Boys 
- **Chiclayo** (2): 
  - Juan Aurich  (1) Club Juan Aurich S.A
  - Molinos El Pirata 
- **Trujillo** (2): 
  - Universidad César Vallejo  (1) Club Deportivo Universidad César Vallejo
  - Carlos A. Mannucci 
- **Arequipa** (1): FBC Melgar  (1) Melgar
- **Ayacucho** (1): Ayacucho FC  (1) Ayacucho
- **Cajamarca** (1): Universidad Técnica de Cajamarca  (1) UTC
- **Cusco** (1): Real Garcilaso  (1) Asociación Civil Real Atlético Garcilaso
- **Huancayo** (1): Sport Huancayo 
- **Huánuco** (1): Alianza Universidad  (1) Ali. Univ. Huánuco
- **Juliaca** (1): Escuela Municipal Binacional  (1) Binacional
- **Nueva Cajamarca** (1): Unión Comercio 
- **Piura** (1): Club Atlético Grau  (1) Atlético Grau




By Region

- **Lima†** (5):   Alianza Lima · Sporting Cristal · Deportivo Municipal · Club Deportivo Universidad de San Martín de Porres · Club Universitario de Deportes
- **Chiclayo†** (2):   Juan Aurich · Molinos El Pirata
- **Huancayo†** (1):   Sport Huancayo
- **Huánuco†** (1):   Alianza Universidad
- **Cusco†** (1):   Real Garcilaso
- **Trujillo†** (2):   Universidad César Vallejo · Carlos A. Mannucci
- **Ayacucho†** (1):   Ayacucho FC
- **Juliaca†** (1):   Escuela Municipal Binacional
- **Callao†** (2):   Academia Cantolao · Sport Boys
- **Arequipa†** (1):   FBC Melgar
- **Nueva Cajamarca†** (1):   Unión Comercio
- **Cajamarca†** (1):   Universidad Técnica de Cajamarca
- **Piura†** (1):   Club Atlético Grau




By Year

- **1919** (1):   Club Atlético Grau
- ? (19):   Alianza Lima · Sporting Cristal · Deportivo Municipal · Club Deportivo Universidad de San Martín de Porres · Club Universitario de Deportes · Juan Aurich · Molinos El Pirata · Sport Huancayo · Alianza Universidad · Real Garcilaso · Universidad César Vallejo · Carlos A. Mannucci · Ayacucho FC · Escuela Municipal Binacional · Academia Cantolao · Sport Boys · FBC Melgar · Unión Comercio · Universidad Técnica de Cajamarca






By A to Z

- **A** (8): Ayacucho · Ayacucho FC · Alianza Lima · Atlético Grau · Academia Cantolao · Ali. Univ. Huánuco · Alianza Universidad · Asociación Civil Real Atlético Garcilaso
- **B** (1): Binacional
- **C** (9): Cantolao · Club Alianza Lima · Carlos A. Mannucci · Club Atlético Grau · Club Juan Aurich S.A · Club Sporting Cristal · Club Universitario de Deportes · Club Deportivo Universidad César Vallejo · Club Deportivo Universidad de San Martín de Porres
- **D** (1): Deportivo Municipal
- **E** (1): Escuela Municipal Binacional
- **F** (1): FBC Melgar
- **J** (1): Juan Aurich
- **M** (2): Melgar · Molinos El Pirata
- **R** (1): Real Garcilaso
- **S** (3): Sport Boys · Sport Huancayo · Sporting Cristal
- **U** (6): UTC · Universitario · Unión Comercio · Universidad San Martín · Universidad César Vallejo · Universidad Técnica de Cajamarca




