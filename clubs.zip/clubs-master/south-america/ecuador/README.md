18 clubs

- **Deportivo Quito** : (1) Sociedad Deportivo Quito
- **El Nacional** : (2) CD El Nacional · Club Deportivo El Nacional
- **LDU Quito** : (3) LDU de Quito · Liga de Quito · Liga Deportiva Universitaria de Quito
- **CD Universidad Católica del Ecuador** : (2) CD Católica · Universidad Católica ⇒ (3) ≈CD Catolica≈ · ≈Universidad Catolica≈ · ≈CD Universidad Catolica del Ecuador≈
- **América de Quito** ⇒ (1) ≈America de Quito≈
- **SD Aucas** : (1) Aucas
- **CS Emelec** : (2) Emelec · Club Sport Emelec
- **Barcelona Guayaquil** : (4) Barcelona · Barcelona SC · Barcelona SC Guayaquil · Barcelona Sporting Club
- **Guayaquil City FC** : (1) Guayaquil City
- **CSD Macará** : (1) Macará ⇒ (2) ≈Macara≈ · ≈CSD Macara≈
- **Mushuc Runa SC** : (1) Mushuc Runa
- **CD Técnico Universitario** : (1) Técnico Universitario ⇒ (2) ≈Tecnico Universitario≈ · ≈CD Tecnico Universitario≈
- **LDU Loja** : (3) LDU de Loja · Liga de Loja · Liga Deportiva Universitaria de Loja
- **Delfín SC** : (1) Delfín ⇒ (2) ≈Delfin≈ · ≈Delfin SC≈
- **CD Cuenca** : (1) Deportivo Cuenca
- **Fuerza Amarilla SC** : (1) Fuerza Amarilla
- **CSD Independiente del Valle** : (4) Ind. d. Valle · Indep. d. Valle · Indep. del Valle · Independiente del Valle
- **CD Olmedo** : (1) Olmedo




Alphabet

- **Alphabet Specials** (4):  **á**  **é**  **í**  **ó** 
  - **á**×2 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×3 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×3 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Quito** (6): 
  - Deportivo Quito  (1) Sociedad Deportivo Quito
  - El Nacional  (2) CD El Nacional · Club Deportivo El Nacional
  - LDU Quito  (3) LDU de Quito · Liga de Quito · Liga Deportiva Universitaria de Quito
  - CD Universidad Católica del Ecuador  (2) Universidad Católica · CD Católica
  - América de Quito 
  - SD Aucas  (1) Aucas
- **Ambato** (3): 
  - CSD Macará  (1) Macará
  - Mushuc Runa SC  (1) Mushuc Runa
  - CD Técnico Universitario  (1) Técnico Universitario
- **Guayaquil** (3): 
  - CS Emelec  (2) Emelec · Club Sport Emelec
  - Barcelona Guayaquil  (4) Barcelona · Barcelona SC Guayaquil · Barcelona SC · Barcelona Sporting Club
  - Guayaquil City FC  (1) Guayaquil City
- **Cuenca** (1): CD Cuenca  (1) Deportivo Cuenca
- **Loja** (1): LDU Loja  (3) LDU de Loja · Liga de Loja · Liga Deportiva Universitaria de Loja
- **Machala** (1): Fuerza Amarilla SC  (1) Fuerza Amarilla
- **Manta** (1): Delfín SC  (1) Delfín
- **Riobamba** (1): CD Olmedo  (1) Olmedo
- **Sangolquí** (1): CSD Independiente del Valle  (4) Ind. d. Valle · Indep. d. Valle · Indep. del Valle · Independiente del Valle




By Region

- **Quito†** (6):   Deportivo Quito · El Nacional · LDU Quito · CD Universidad Católica del Ecuador · América de Quito · SD Aucas
- **Guayaquil†** (3):   CS Emelec · Barcelona Guayaquil · Guayaquil City FC
- **Ambato†** (3):   CSD Macará · Mushuc Runa SC · CD Técnico Universitario
- **Loja†** (1):   LDU Loja
- **Manta†** (1):   Delfín SC
- **Cuenca†** (1):   CD Cuenca
- **Machala†** (1):   Fuerza Amarilla SC
- **Sangolquí†** (1):   CSD Independiente del Valle
- **Riobamba†** (1):   CD Olmedo




By Year

- ? (18):   Deportivo Quito · El Nacional · LDU Quito · CD Universidad Católica del Ecuador · América de Quito · SD Aucas · CS Emelec · Barcelona Guayaquil · Guayaquil City FC · CSD Macará · Mushuc Runa SC · CD Técnico Universitario · LDU Loja · Delfín SC · CD Cuenca · Fuerza Amarilla SC · CSD Independiente del Valle · CD Olmedo






By A to Z

- **A** (2): Aucas · América de Quito
- **B** (5): Barcelona · Barcelona SC · Barcelona Guayaquil · Barcelona SC Guayaquil · Barcelona Sporting Club
- **C** (11): CD Cuenca · CD Olmedo · CS Emelec · CSD Macará · CD Católica · CD El Nacional · Club Sport Emelec · CD Técnico Universitario · Club Deportivo El Nacional · CSD Independiente del Valle · CD Universidad Católica del Ecuador
- **D** (4): Delfín · Delfín SC · Deportivo Quito · Deportivo Cuenca
- **E** (2): Emelec · El Nacional
- **F** (2): Fuerza Amarilla · Fuerza Amarilla SC
- **G** (2): Guayaquil City · Guayaquil City FC
- **I** (4): Ind. d. Valle · Indep. d. Valle · Indep. del Valle · Independiente del Valle
- **L** (8): LDU Loja · LDU Quito · LDU de Loja · LDU de Quito · Liga de Loja · Liga de Quito · Liga Deportiva Universitaria de Loja · Liga Deportiva Universitaria de Quito
- **M** (3): Macará · Mushuc Runa · Mushuc Runa SC
- **O** (1): Olmedo
- **S** (2): SD Aucas · Sociedad Deportivo Quito
- **T** (1): Técnico Universitario
- **U** (1): Universidad Católica




