14 clubs

- **Club Bolívar** : (2) Bolívar · Bolívar La Paz ⇒ (3) ≈Bolivar≈ · ≈Club Bolivar≈ · ≈Bolivar La Paz≈
- **The Strongest** : (2) Strongest · Club The Strongest
- **Club Always Ready** : (2) Always Ready · Alw. Ready La Paz
- **Club Deportivo Oriente Petrolero** : (1) Oriente Petrolero
- **Club Blooming** : (1) Blooming
- **Club Destroyers** : (1) Destroyers
- **Royal Pari FC** : (2) Royal Pari · Royal Pari Sion
- **Real Potosí** : (2) Club Real Potosí · Club Bamin Real Potosí ⇒ (3) ≈Real Potosi≈ · ≈Club Real Potosi≈ · ≈Club Bamin Real Potosi≈
- **Nacional Potosí** : (1) CA Nacional Potosí ⇒ (2) ≈Nacional Potosi≈ · ≈CA Nacional Potosi≈
- **Club Deportivo San José** : (3) San José · Club San José · San José Oruro ⇒ (4) ≈San Jose≈ · ≈Club San Jose≈ · ≈San Jose Oruro≈ · ≈Club Deportivo San Jose≈
- **Club Deportivo Guabirá** : (2) Guabirá · Guabirá Montero ⇒ (3) ≈Guabira≈ · ≈Guabira Montero≈ · ≈Club Deportivo Guabira≈
- **CD Jorge Wilstermann** : (1) Jorge Wilstermann
- **Club Aurora** : (2) Aurora · Club Dep. Aurora
- **Sport Boys Warnes** : (1) Sport Boys




Alphabet

- **Alphabet Specials** (3):  **á**  **é**  **í** 
  - **á**×3 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×4 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×8 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i




Duplicates





By City

- **Santa Cruz de la Sierra** (4): 
  - Club Deportivo Oriente Petrolero  (1) Oriente Petrolero
  - Club Blooming  (1) Blooming
  - Club Destroyers  (1) Destroyers
  - Royal Pari FC  (2) Royal Pari · Royal Pari Sion
- **La Paz** (3): 
  - Club Bolívar  (2) Bolívar · Bolívar La Paz
  - The Strongest  (2) Strongest · Club The Strongest
  - Club Always Ready  (2) Always Ready · Alw. Ready La Paz
- **Cochabamba** (2): 
  - CD Jorge Wilstermann  (1) Jorge Wilstermann
  - Club Aurora  (2) Aurora · Club Dep. Aurora
- **Potosí** (2): 
  - Real Potosí  (2) Club Real Potosí · Club Bamin Real Potosí
  - Nacional Potosí  (1) CA Nacional Potosí
- **Montero** (1): Club Deportivo Guabirá  (2) Guabirá · Guabirá Montero
- **Oruro** (1): Club Deportivo San José  (3) San José · Club San José · San José Oruro
- **Warnes** (1): Sport Boys Warnes  (1) Sport Boys




By Region

- **La Paz†** (3):   Club Bolívar · The Strongest · Club Always Ready
- **Santa Cruz de la Sierra†** (4):   Club Deportivo Oriente Petrolero · Club Blooming · Club Destroyers · Royal Pari FC
- **Potosí†** (2):   Real Potosí · Nacional Potosí
- **Oruro†** (1):   Club Deportivo San José
- **Montero†** (1):   Club Deportivo Guabirá
- **Cochabamba†** (2):   CD Jorge Wilstermann · Club Aurora
- **Warnes†** (1):   Sport Boys Warnes




By Year

- ? (14):   Club Bolívar · The Strongest · Club Always Ready · Club Deportivo Oriente Petrolero · Club Blooming · Club Destroyers · Royal Pari FC · Real Potosí · Nacional Potosí · Club Deportivo San José · Club Deportivo Guabirá · CD Jorge Wilstermann · Club Aurora · Sport Boys Warnes






By A to Z

- **A** (3): Aurora · Always Ready · Alw. Ready La Paz
- **B** (3): Bolívar · Blooming · Bolívar La Paz
- **C** (15): Club Aurora · Club Bolívar · Club Blooming · Club San José · Club Destroyers · Club Dep. Aurora · Club Real Potosí · Club Always Ready · CA Nacional Potosí · Club The Strongest · CD Jorge Wilstermann · Club Bamin Real Potosí · Club Deportivo Guabirá · Club Deportivo San José · Club Deportivo Oriente Petrolero
- **D** (1): Destroyers
- **G** (2): Guabirá · Guabirá Montero
- **J** (1): Jorge Wilstermann
- **N** (1): Nacional Potosí
- **O** (1): Oriente Petrolero
- **R** (4): Royal Pari · Real Potosí · Royal Pari FC · Royal Pari Sion
- **S** (5): San José · Strongest · Sport Boys · San José Oruro · Sport Boys Warnes
- **T** (1): The Strongest




