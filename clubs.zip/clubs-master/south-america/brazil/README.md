51 clubs

- [**Corinthians SP**](https://en.wikipedia.org/wiki/Sport_Club_Corinthians_Paulista) : (4) Corinthians · Corinthians São Paulo · SC Corinthians Paulista · Sport Club Corinthians Paulista ⇒ (1) ≈Corinthians Sao Paulo≈
- [**São Paulo FC**](https://en.wikipedia.org/wiki/São_Paulo_FC) : (4) São Paulo · FC São Paulo · São Paulo SP · São Paulo Futebol Clube ⇒ (5) ≈Sao Paulo≈ · ≈Sao Paulo FC≈ · ≈Sao Paulo SP≈ · ≈FC Sao Paulo≈ · ≈Sao Paulo Futebol Clube≈
- [**Palmeiras SP**](https://en.wikipedia.org/wiki/Sociedade_Esportiva_Palmeiras) : (6) Palmeiras · SE Palmeiras · SE Palmeiras S · SE Palmeiras SP · SE Palmeiras São Paulo · Sociedade Esportiva Palmeiras ⇒ (1) ≈SE Palmeiras Sao Paulo≈
- [**Santos SP**](https://en.wikipedia.org/wiki/Santos_FC) : (4) Santos · Santos FC · FC Santos · Santos Futebol Clube
- [**Ponte Preta**](https://en.wikipedia.org/wiki/Associação_Atlética_Ponte_Preta) : (3) AA Ponte Preta · AA Ponte Preta SP · Associação Atlética Ponte Preta ⇒ (1) ≈Associacao Atletica Ponte Preta≈
- **CA Bragantino** : (2) Bragantino · Clube Atlético Bragantino ⇒ (1) ≈Clube Atletico Bragantino≈
- [**RB Bragantino**](https://en.wikipedia.org/wiki/Red_Bull_Bragantino) : (3) Bragantino · RB Bragantino SP · Red Bull Bragantino
- [**Oeste SP**](https://en.wikipedia.org/wiki/Oeste_Futebol_Clube) : (4) Oeste · Oeste FC · Oeste FC SP · Oeste Futebol Clube
- **Portuguesa** : (1) Associação Portuguesa de Desportos ⇒ (1) ≈Associacao Portuguesa de Desportos≈
- [**Botafogo SP**](https://en.wikipedia.org/wiki/Botafogo_Futebol_Clube_(SP)) : (4) Botafogo FC · Botafogo FC SP · Botafogo Futebol Clube · Botafogo Futebol Clube (SP)
- [**Guarani FC**](https://en.wikipedia.org/wiki/Guarani_FC) : (3) Guarani · Guarani FC SP · Guarani Futebol Clube
- [**São Bento**](https://en.wikipedia.org/wiki/Esporte_Clube_São_Bento) : (2) São Bento SP · Esporte Clube São Bento ⇒ (3) ≈Sao Bento≈ · ≈Sao Bento SP≈ · ≈Esporte Clube Sao Bento≈
- **AD São Caetano** : (2) São Caetano · Associação Desportiva São Caetano ⇒ (3) ≈Sao Caetano≈ · ≈AD Sao Caetano≈ · ≈Associacao Desportiva Sao Caetano≈
- [**Botafogo RJ**](https://en.wikipedia.org/wiki/Botafogo_de_Futebol_e_Regatas) : (5) Botafogo · Botafogo FR · Botafogo (RJ) · Botafogo FR RJ · Botafogo de Futebol e Regatas
- [**Flamengo RJ**](https://en.wikipedia.org/wiki/Clube_de_Regatas_do_Flamengo) : (5) Flamengo · CR Flamengo · CR Flamengo RJ · Flamengo Rio de Janeiro · Clube de Regatas do Flamengo
- [**Fluminense RJ**](https://en.wikipedia.org/wiki/Fluminense_FC) : (4) Fluminense · Fluminense FC · Fluminense Football Club · Fluminense Rio de Janeiro
- [**CR Vasco da Gama**](https://en.wikipedia.org/wiki/CR_Vasco_da_Gama) : (6) Vasco · Vasco RJ · Vasco da Gama · Vasco da Gama RJ · Vasco da Gama Rio de Janeiro · Club de Regatas Vasco da Gama
- [**Atlético MG**](https://en.wikipedia.org/wiki/Clube_Atlético_Mineiro) : (5) Atlético/MG · Atletico-MG · Atlético Mineiro · C Atlético Mineiro · Clube Atlético Mineiro ⇒ (5) ≈Atletico MG≈ · ≈Atletico/MG≈ · ≈Atletico Mineiro≈ · ≈C Atletico Mineiro≈ · ≈Clube Atletico Mineiro≈
- [**Cruzeiro MG**](https://en.wikipedia.org/wiki/Cruzeiro_Esporte_Clube) : (5) Cruzeiro · Cruzeiro EC · Cruzeiro EC MG · Cruzeiro Esporte Clube · Cruzeiro Belo Horizonte
- [**América MG**](https://en.wikipedia.org/wiki/América_Futebol_Clube_(MG)) : (5) América FC · América Mineiro · América Mineiro MG · América Futebol Clube · América Futebol Clube (MG) ⇒ (6) ≈America MG≈ · ≈America FC≈ · ≈America Mineiro≈ · ≈America Mineiro MG≈ · ≈America Futebol Clube≈ · ≈America Futebol Clube (MG)≈
- **Tupi MG** : (3) Tupi · Tupi FC · Tupi Football Club
- [**Grêmio RS**](https://en.wikipedia.org/wiki/Grêmio_Foot-Ball_Porto_Alegrense) : (5) Gremio · Grêmio · Grêmio FBPA · Grêmio Porto Alegre · Grêmio Foot-Ball Porto Alegrense ⇒ (5) ≈Gremio≈ · ≈Gremio RS≈ · ≈Gremio FBPA≈ · ≈Gremio Porto Alegre≈ · ≈Gremio Foot-Ball Porto Alegrense≈
- [**Internacional Porto Alegre**](https://en.wikipedia.org/wiki/Sport_Club_Internacional) : (4) Internacional · SC Internacional · Internacional RS · Sport Club Internacional
- [**Brasil RS**](https://en.wikipedia.org/wiki/Grêmio_Esportivo_Brasil) : (4) GE Brasil · Brasil de Pelotas · Grêmio Esportivo Brasil · Grêmio Esportivo Brasil de Pelotas ⇒ (2) ≈Gremio Esportivo Brasil≈ · ≈Gremio Esportivo Brasil de Pelotas≈
- **Esporte Clube Juventude** : (1) Juventude
- [**Atlético PR**](https://en.wikipedia.org/wiki/Club_Athletico_Paranaense) : (7) Athl Paranaense · Athletico-PR [en] · Atlético Paranaense · C Atlético Paranaense · Athletico Paranaense [en] · Clube Atlético Paranaense · Club Athletico Paranaense [en] ⇒ (4) ≈Atletico PR≈ · ≈Atletico Paranaense≈ · ≈C Atletico Paranaense≈ · ≈Clube Atletico Paranaense≈
- [**Coritiba PR**](https://en.wikipedia.org/wiki/Coritiba_Foot_Ball_Club) : (4) Coritiba · Coritiba FC · Coritiba FC PR · Coritiba Football Club
- [**Londrina EC**](https://en.wikipedia.org/wiki/Londrina_Esporte_Clube) : (3) Londrina · Londrina EC PR · Londrina Esporte Clube
- [**Paraná Clube**](https://en.wikipedia.org/wiki/Paraná_Clube) : (2) Paraná · Paraná Clube PR ⇒ (3) ≈Parana≈ · ≈Parana Clube≈ · ≈Parana Clube PR≈
- [**Operário Ferroviário**](https://en.wikipedia.org/wiki/Operário_Ferroviário_Esporte_Clube) : (5) Operário · Operário PR · Operário FEC PR · Operário Ferroviár · Operário Ferroviário Esporte Clube ⇒ (6) ≈Operario≈ · ≈Operario PR≈ · ≈Operario FEC PR≈ · ≈Operario Ferroviar≈ · ≈Operario Ferroviario≈ · ≈Operario Ferroviario Esporte Clube≈
- [**Figueirense**](https://en.wikipedia.org/wiki/Figueirense_FC) : (4) Figueirense FC · Figueirense SC · Figueirense FC SC · Figueirense Futebol Clube
- [**Chapecoense**](https://en.wikipedia.org/wiki/Associação_Chapecoense_de_Futebol) : (2) Chapecoense-SC · Associação Chapecoense de Futebol ⇒ (1) ≈Associacao Chapecoense de Futebol≈
- [**Criciúma EC**](https://en.wikipedia.org/wiki/Criciúma_Esporte_Clube) : (4) Criciúma · Criciúma SC · Criciúma EC SC · Criciúma Esporte Clube ⇒ (5) ≈Criciuma≈ · ≈Criciuma EC≈ · ≈Criciuma SC≈ · ≈Criciuma EC SC≈ · ≈Criciuma Esporte Clube≈
- [**Avaí FC**](https://en.wikipedia.org/wiki/Avaí_FC) : (3) Avaí · Avaí FC SC · Avaí Futebol Clube ⇒ (4) ≈Avai≈ · ≈Avai FC≈ · ≈Avai FC SC≈ · ≈Avai Futebol Clube≈
- **Joinvile EC** : (3) Joinvile · Joinville · Joinville Esporte Clube
- [**Sport Recife**](https://en.wikipedia.org/wiki/Sport_Club_do_Recife) : (4) Sport · Sport PE · Sport Recife PE · Sport Club do Recife
- **Santa Cruz** : (2) Santa Cruz FC · Santa Cruz Futebol Clube
- **Náutico PE** : (4) Nautico · Náutico · C Náutico Capibaribe · Clube Náutico Capibaribe ⇒ (4) ≈Nautico≈ · ≈Nautico PE≈ · ≈C Nautico Capibaribe≈ · ≈Clube Nautico Capibaribe≈
- [**EC Vitória**](https://en.wikipedia.org/wiki/Esporte_Clube_Vitória) : (4) Vitória · Vitória BA · EC Vitória BA · Esporte Clube Vitória ⇒ (5) ≈Vitoria≈ · ≈EC Vitoria≈ · ≈Vitoria BA≈ · ≈EC Vitoria BA≈ · ≈Esporte Clube Vitoria≈
- [**EC Bahia**](https://en.wikipedia.org/wiki/Esporte_Clube_Bahia) : (4) Bahia · Bahia BA · EC Bahia BA · Esporte Clube Bahia
- [**Goiás EC**](https://en.wikipedia.org/wiki/Goiás_Esporte_Clube) : (3) Goiás · Goiás EC GO · Goiás Esporte Clube ⇒ (4) ≈Goias≈ · ≈Goias EC≈ · ≈Goias EC GO≈ · ≈Goias Esporte Clube≈
- [**Atlético GO**](https://en.wikipedia.org/wiki/Atlético_Clube_Goianiense) : (3) Atletico GO · Atlético Goianiense · Atlético Clube Goianiense ⇒ (3) ≈Atletico GO≈ · ≈Atletico Goianiense≈ · ≈Atletico Clube Goianiense≈
- [**Vila Nova GO**](https://en.wikipedia.org/wiki/Vila_Nova_Futebol_Clube) : (4) Vila Nova · Vila Nova FC · Vila Nova de Goias · Vila Nova Futebol Clube
- [**Ceára SC**](https://en.wikipedia.org/wiki/Ceará_Sporting_Club) : (4) Ceará · Ceará CE · Ceará SC CE · Ceará Sporting Club ⇒ (5) ≈Ceara≈ · ≈Ceara SC≈ · ≈Ceara CE≈ · ≈Ceara SC CE≈ · ≈Ceara Sporting Club≈
- [**Fortaleza**](https://en.wikipedia.org/wiki/Fortaleza_Esporte_Clube) : (2) Fortaleza EC CE · Fortaleza Esporte Clube
- **Paysandu SC** : (2) Paysandu · Paysandu Sport Club
- [**CRB AL**](https://en.wikipedia.org/wiki/Clube_de_Regatas_Brasil) : (3) CRB · CR Brasil AL · Clube de Regatas Brasil
- [**CSA**](https://en.wikipedia.org/wiki/Centro_Sportivo_Alagoano) : (3) CSA AL · CS Alagoano AL · Centro Sportivo Alagoano
- **Luverdense EC** : (2) Luverdense · Luverdense Esporte Clube
- [**Cuiabá**](https://en.wikipedia.org/wiki/Cuiabá_Esporte_Clube) : (2) Cuiabá MT · Cuiabá Esporte Clube ⇒ (3) ≈Cuiaba≈ · ≈Cuiaba MT≈ · ≈Cuiaba Esporte Clube≈
- **Sampaio Corrêa FC** : (2) Sampaio Corrêa · Sampaio Corrêa Futebol Clube ⇒ (3) ≈Sampaio Correa≈ · ≈Sampaio Correa FC≈ · ≈Sampaio Correa Futebol Clube≈




Alphabet

- **Alphabet Specials** (8):  **á**  **ã**  **ç**  **é**  **ê**  **í**  **ó**  **ú** 
  - **á**×28 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **ã**×17 U+00E3 (227) - LATIN SMALL LETTER A WITH TILDE ⇒ a
  - **ç**×4 U+00E7 (231) - LATIN SMALL LETTER C WITH CEDILLA ⇒ c
  - **é**×20 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **ê**×10 U+00EA (234) - LATIN SMALL LETTER E WITH CIRCUMFLEX ⇒ e
  - **í**×4 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×5 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×5 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates

- **Botafogo RJ**, Rio de Janeiro (1):
  - `botafogorj` (2): Botafogo RJ · Botafogo (RJ)
- **Atlético MG**, Belo Horizonte (2):
  - `atléticomg` (2): Atlético MG · Atlético/MG
  - `atleticomg` (3): Atletico-MG · Atletico MG · Atletico/MG
- **Grêmio RS**, Porto Alegre (1):
  - `gremio` (2): **Gremio** · **Gremio**
- **Náutico PE**, Recife (1):
  - `nautico` (2): **Nautico** · **Nautico**
- **Atlético GO**, Goiânia (1):
  - `atleticogo` (2): **Atletico GO** · **Atletico GO**




By City

- **Rio de Janeiro, Rio de Janeiro** (4): 
  - Botafogo RJ  (5) Botafogo · Botafogo (RJ) · Botafogo FR · Botafogo FR RJ · Botafogo de Futebol e Regatas
  - Flamengo RJ  (5) Flamengo · CR Flamengo · CR Flamengo RJ · Flamengo Rio de Janeiro · Clube de Regatas do Flamengo
  - Fluminense RJ  (4) Fluminense · Fluminense FC · Fluminense Rio de Janeiro · Fluminense Football Club
  - CR Vasco da Gama  (6) Vasco · Vasco RJ · Vasco da Gama · Vasco da Gama RJ · Vasco da Gama Rio de Janeiro · Club de Regatas Vasco da Gama
- **São Paulo, São Paulo** (4): 
  - Corinthians SP  (4) Corinthians · SC Corinthians Paulista · Corinthians São Paulo · Sport Club Corinthians Paulista
  - São Paulo FC  (4) São Paulo · FC São Paulo · São Paulo SP · São Paulo Futebol Clube
  - Palmeiras SP  (6) Palmeiras · SE Palmeiras · SE Palmeiras S · SE Palmeiras SP · SE Palmeiras São Paulo · Sociedade Esportiva Palmeiras
  - Portuguesa  (1) Associação Portuguesa de Desportos
- **Belo Horizonte, Minas Gerais** (3): 
  - Atlético MG  (5) Atlético Mineiro · C Atlético Mineiro · Clube Atlético Mineiro · Atletico-MG · Atlético/MG
  - Cruzeiro MG  (5) Cruzeiro · Cruzeiro EC · Cruzeiro EC MG · Cruzeiro Esporte Clube · Cruzeiro Belo Horizonte
  - América MG  (5) América Mineiro · América Mineiro MG · América FC · América Futebol Clube · América Futebol Clube (MG)
- **Curitiba, Paraná** (3): 
  - Atlético PR  (7) Athl Paranaense · Atlético Paranaense · C Atlético Paranaense · Clube Atlético Paranaense · Athletico-PR [en] · Athletico Paranaense [en] · Club Athletico Paranaense [en]
  - Coritiba PR  (4) Coritiba · Coritiba FC · Coritiba Football Club · Coritiba FC PR
  - Paraná Clube  (2) Paraná · Paraná Clube PR
- **Goiânia, Goiás** (3): 
  - Goiás EC  (3) Goiás · Goiás EC GO · Goiás Esporte Clube
  - Atlético GO  (3) Atletico GO · Atlético Goianiense · Atlético Clube Goianiense
  - Vila Nova GO  (4) Vila Nova · Vila Nova de Goias · Vila Nova FC · Vila Nova Futebol Clube
- **Recife, Pernambuco** (3): 
  - Sport Recife  (4) Sport · Sport PE · Sport Recife PE · Sport Club do Recife
  - Santa Cruz  (2) Santa Cruz FC · Santa Cruz Futebol Clube
  - Náutico PE  (4) Nautico · Náutico · C Náutico Capibaribe · Clube Náutico Capibaribe
- **Bragança Paulista, São Paulo** (2): 
  - CA Bragantino  (2) Bragantino · Clube Atlético Bragantino
  - RB Bragantino  (3) Bragantino · Red Bull Bragantino · RB Bragantino SP
- **Campinas, São Paulo** (2): 
  - Ponte Preta  (3) AA Ponte Preta · Associação Atlética Ponte Preta · AA Ponte Preta SP
  - Guarani FC  (3) Guarani · Guarani FC SP · Guarani Futebol Clube
- **Florianópolis, Santa Catarina** (2): 
  - Figueirense  (4) Figueirense FC · Figueirense SC · Figueirense FC SC · Figueirense Futebol Clube
  - Avaí FC  (3) Avaí · Avaí FC SC · Avaí Futebol Clube
- **Fortaleza, Ceará** (2): 
  - Ceára SC  (4) Ceará · Ceará CE · Ceará SC CE · Ceará Sporting Club
  - Fortaleza  (2) Fortaleza EC CE · Fortaleza Esporte Clube
- **Maceió, Alagoas** (2): 
  - CRB AL  (3) CRB · CR Brasil AL · Clube de Regatas Brasil
  - CSA  (3) CSA AL · CS Alagoano AL · Centro Sportivo Alagoano
- **Porto Alegre, Rio Grande do Sul** (2): 
  - Grêmio RS  (5) Gremio · Grêmio · Grêmio Porto Alegre · Grêmio FBPA · Grêmio Foot-Ball Porto Alegrense
  - Internacional Porto Alegre  (4) Internacional · SC Internacional · Internacional RS · Sport Club Internacional
- **Salvador, Bahia** (2): 
  - EC Vitória  (4) Vitória · Vitória BA · EC Vitória BA · Esporte Clube Vitória
  - EC Bahia  (4) Bahia · Bahia BA · EC Bahia BA · Esporte Clube Bahia
- **Belém, Pará** (1): Paysandu SC  (2) Paysandu · Paysandu Sport Club
- **Caxias do Sul, Rio Grande do Sul** (1): Esporte Clube Juventude  (1) Juventude
- **Chapecó, Santa Catarina** (1): Chapecoense  (2) Chapecoense-SC · Associação Chapecoense de Futebol
- **Criciúma, Santa Catarina** (1): Criciúma EC  (4) Criciúma · Criciúma Esporte Clube · Criciúma SC · Criciúma EC SC
- **Cuiabá, Mato Grosso** (1): Cuiabá  (2) Cuiabá MT · Cuiabá Esporte Clube
- **Itápolis, São Paulo** (1): Oeste SP  (4) Oeste · Oeste FC · Oeste Futebol Clube · Oeste FC SP
- **Joinville, Santa Catarina** (1): Joinvile EC  (3) Joinvile · Joinville · Joinville Esporte Clube
- **Juiz de Fora, Minas Gerais** (1): Tupi MG  (3) Tupi · Tupi FC · Tupi Football Club
- **Londrina, Paraná** (1): Londrina EC  (3) Londrina · Londrina EC PR · Londrina Esporte Clube
- **Lucas do Rio Verde, Mato Grosso** (1): Luverdense EC  (2) Luverdense · Luverdense Esporte Clube
- **Pelotas, Rio Grande do Sul** (1): Brasil RS  (4) Brasil de Pelotas · GE Brasil · Grêmio Esportivo Brasil · Grêmio Esportivo Brasil de Pelotas
- **Ponta Grossa, Paraná** (1): Operário Ferroviário  (5) Operário · Operário Ferroviár · Operário Ferroviário Esporte Clube · Operário PR · Operário FEC PR
- **Ribeirão Preto, São Paulo** (1): Botafogo SP  (4) Botafogo FC · Botafogo Futebol Clube · Botafogo FC SP · Botafogo Futebol Clube (SP)
- **Santos, São Paulo** (1): Santos SP  (4) Santos · Santos FC · FC Santos · Santos Futebol Clube
- **Sorocaba, São Paulo** (1): São Bento  (2) São Bento SP · Esporte Clube São Bento
- **São Caetano, São Paulo** (1): AD São Caetano  (2) São Caetano · Associação Desportiva São Caetano
- **São Luís, Maranhão** (1): Sampaio Corrêa FC  (2) Sampaio Corrêa · Sampaio Corrêa Futebol Clube




By Region

- **São Paulo** (13):   Corinthians SP · São Paulo FC · Palmeiras SP · Santos SP · Ponte Preta · CA Bragantino · RB Bragantino · Oeste SP · Portuguesa · Botafogo SP · Guarani FC · São Bento · AD São Caetano
- **Rio de Janeiro** (4):   Botafogo RJ · Flamengo RJ · Fluminense RJ · CR Vasco da Gama
- **Minas Gerais** (4):   Atlético MG · Cruzeiro MG · América MG · Tupi MG
- **Rio Grande do Sul** (4):   Grêmio RS · Internacional Porto Alegre · Brasil RS · Esporte Clube Juventude
- **Paraná** (5):   Atlético PR · Coritiba PR · Londrina EC · Paraná Clube · Operário Ferroviário
- **Santa Catarina** (5):   Figueirense · Chapecoense · Criciúma EC · Avaí FC · Joinvile EC
- **Pernambuco** (3):   Sport Recife · Santa Cruz · Náutico PE
- **Bahia** (2):   EC Vitória · EC Bahia
- **Goiás** (3):   Goiás EC · Atlético GO · Vila Nova GO
- **Ceará** (2):   Ceára SC · Fortaleza
- **Pará** (1):   Paysandu SC
- **Alagoas** (2):   CRB AL · CSA
- **Mato Grosso** (2):   Luverdense EC · Cuiabá
- **Maranhão** (1):   Sampaio Corrêa FC




By Year

- **1911** (1):   Guarani FC
- **1913** (1):   Esporte Clube Juventude
- **1989** (1):   AD São Caetano
- ? (48):   Corinthians SP · São Paulo FC · Palmeiras SP · Santos SP · Ponte Preta · CA Bragantino · RB Bragantino · Oeste SP · Portuguesa · Botafogo SP · São Bento · Botafogo RJ · Flamengo RJ · Fluminense RJ · CR Vasco da Gama · Atlético MG · Cruzeiro MG · América MG · Tupi MG · Grêmio RS · Internacional Porto Alegre · Brasil RS · Atlético PR · Coritiba PR · Londrina EC · Paraná Clube · Operário Ferroviário · Figueirense · Chapecoense · Criciúma EC · Avaí FC · Joinvile EC · Sport Recife · Santa Cruz · Náutico PE · EC Vitória · EC Bahia · Goiás EC · Atlético GO · Vila Nova GO · Ceára SC · Fortaleza · Paysandu SC · CRB AL · CSA · Luverdense EC · Cuiabá · Sampaio Corrêa FC






By A to Z

- **A** (30): Avaí · Avaí FC · América FC · América MG · Avaí FC SC · Atletico GO · Atletico-MG · Atlético GO · Atlético MG · Atlético PR · Atlético/MG · AA Ponte Preta · AD São Caetano · América Mineiro · Athl Paranaense · Atlético Mineiro · AA Ponte Preta SP · Athletico-PR [en] · América Mineiro MG · Avaí Futebol Clube · Atlético Goianiense · Atlético Paranaense · América Futebol Clube · Athletico Paranaense [en] · Atlético Clube Goianiense · América Futebol Clube (MG) · Associação Atlética Ponte Preta · Associação Chapecoense de Futebol · Associação Desportiva São Caetano · Associação Portuguesa de Desportos
- **B** (16): Bahia · Bahia BA · Botafogo · Brasil RS · !! **Bragantino (2)** !! · Botafogo FC · Botafogo FR · Botafogo RJ · Botafogo SP · Botafogo (RJ) · Botafogo FC SP · Botafogo FR RJ · Brasil de Pelotas · Botafogo Futebol Clube · Botafogo Futebol Clube (SP) · Botafogo de Futebol e Regatas
- **C** (51): CRB · CSA · Ceará · CRB AL · CSA AL · Cuiabá · Ceará CE · Ceára SC · Coritiba · Criciúma · Cruzeiro · Cuiabá MT · CR Flamengo · Ceará SC CE · Chapecoense · Corinthians · Coritiba FC · Coritiba PR · Criciúma EC · Criciúma SC · Cruzeiro EC · Cruzeiro MG · CR Brasil AL · CA Bragantino · CR Flamengo RJ · CS Alagoano AL · Chapecoense-SC · Corinthians SP · Coritiba FC PR · Criciúma EC SC · Cruzeiro EC MG · CR Vasco da Gama · C Atlético Mineiro · Ceará Sporting Club · C Náutico Capibaribe · Cuiabá Esporte Clube · C Atlético Paranaense · Corinthians São Paulo · Clube Atlético Mineiro · Coritiba Football Club · Criciúma Esporte Clube · Cruzeiro Esporte Clube · Clube de Regatas Brasil · Cruzeiro Belo Horizonte · Centro Sportivo Alagoano · Clube Náutico Capibaribe · Clube Atlético Bragantino · Clube Atlético Paranaense · Clube de Regatas do Flamengo · Club de Regatas Vasco da Gama · Club Athletico Paranaense [en]
- **E** (8): EC Bahia · EC Vitória · EC Bahia BA · EC Vitória BA · Esporte Clube Bahia · Esporte Clube Vitória · Esporte Clube Juventude · Esporte Clube São Bento
- **F** (18): Flamengo · FC Santos · Fortaleza · Fluminense · Figueirense · Flamengo RJ · FC São Paulo · Fluminense FC · Fluminense RJ · Figueirense FC · Figueirense SC · Fortaleza EC CE · Figueirense FC SC · Flamengo Rio de Janeiro · Fortaleza Esporte Clube · Fluminense Football Club · Figueirense Futebol Clube · Fluminense Rio de Janeiro
- **G** (17): Goiás · Gremio · Grêmio · Guarani · Goiás EC · GE Brasil · Grêmio RS · Guarani FC · Goiás EC GO · Grêmio FBPA · Guarani FC SP · Goiás Esporte Clube · Grêmio Porto Alegre · Guarani Futebol Clube · Grêmio Esportivo Brasil · Grêmio Foot-Ball Porto Alegrense · Grêmio Esportivo Brasil de Pelotas
- **I** (3): Internacional · Internacional RS · Internacional Porto Alegre
- **J** (5): Joinvile · Joinville · Juventude · Joinvile EC · Joinville Esporte Clube
- **L** (7): Londrina · Luverdense · Londrina EC · Luverdense EC · Londrina EC PR · Londrina Esporte Clube · Luverdense Esporte Clube
- **N** (3): Nautico · Náutico · Náutico PE
- **O** (11): Oeste · Oeste FC · Oeste SP · Operário · Oeste FC SP · Operário PR · Operário FEC PR · Operário Ferroviár · Oeste Futebol Clube · Operário Ferroviário · Operário Ferroviário Esporte Clube
- **P** (10): Paraná · Paysandu · Palmeiras · Portuguesa · Paysandu SC · Ponte Preta · Palmeiras SP · Paraná Clube · Paraná Clube PR · Paysandu Sport Club
- **R** (3): RB Bragantino · RB Bragantino SP · Red Bull Bragantino
- **S** (31): Sport · Santos · Sport PE · Santos FC · Santos SP · São Bento · São Paulo · Santa Cruz · São Caetano · SE Palmeiras · Sport Recife · São Bento SP · São Paulo FC · São Paulo SP · Santa Cruz FC · SE Palmeiras S · Sampaio Corrêa · SE Palmeiras SP · Sport Recife PE · SC Internacional · Sampaio Corrêa FC · Santos Futebol Clube · Sport Club do Recife · SE Palmeiras São Paulo · SC Corinthians Paulista · São Paulo Futebol Clube · Santa Cruz Futebol Clube · Sport Club Internacional · Sampaio Corrêa Futebol Clube · Sociedade Esportiva Palmeiras · Sport Club Corinthians Paulista
- **T** (4): Tupi · Tupi FC · Tupi MG · Tupi Football Club
- **V** (12): Vasco · Vitória · Vasco RJ · Vila Nova · Vitória BA · Vila Nova FC · Vila Nova GO · Vasco da Gama · Vasco da Gama RJ · Vila Nova de Goias · Vila Nova Futebol Clube · Vasco da Gama Rio de Janeiro




