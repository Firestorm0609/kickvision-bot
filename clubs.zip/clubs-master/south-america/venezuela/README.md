24 clubs

- **Caracas FC** : (2) Caracas · Caracas Fútbol Club ⇒ (1) ≈Caracas Futbol Club≈
- **Deportivo La Guaira** : (1) Dvo. La Guaira
- **Deportivo Petare** : (1) Dvo. Petare
- **Estudiantes de Caracas** : (1) Estud. de Caracas
- **Metropolitanos FC** : (2) Metropolitanos · FC Metropolitanos
- **Atlético Venezuela** ⇒ (1) ≈Atletico Venezuela≈
- **Deportivo Táchira** : (2) Dvo. Táchira · Deportivo Táchira Fútbol Club ⇒ (3) ≈Dvo. Tachira≈ · ≈Deportivo Tachira≈ · ≈Deportivo Tachira Futbol Club≈
- **Zamora FC** : (2) Zamora · Zamora Fútbol Club ⇒ (1) ≈Zamora Futbol Club≈
- **Deportivo Lara** : (3) Dvo. Lara · Club Deportivo Lara · Asociación Civil Deportivo Lara ⇒ (1) ≈Asociacion Civil Deportivo Lara≈
- **Deportivo Anzoátegui** : (2) Dvo. Anzoátegui · Deportivo Anzoátegui Sport Club ⇒ (3) ≈Dvo. Anzoategui≈ · ≈Deportivo Anzoategui≈ · ≈Deportivo Anzoategui Sport Club≈
- **AC Mineros** : (3) Mineros · Mineros Guayana · Mineros de Guayana
- **LALA FC** : (1) LALA
- **Atlético El Vigía** ⇒ (1) ≈Atletico El Vigia≈
- **Llaneros FC** : (4) Llaneros · Llaneros Guanare · Llaneros de Guanare · Llaneros Escuela de Fútbol ⇒ (1) ≈Llaneros Escuela de Futbol≈
- **Zulia FC** : (1) Zulia
- **Aragua FC** : (1) Aragua
- **Estudiantes de Mérida** : (2) Estudiantes · Est. de Mérida ⇒ (2) ≈Est. de Merida≈ · ≈Estudiantes de Merida≈
- **Tucanes FC** : (2) Tucanes · Tucanes de Amazonas
- **Yaracuyanos FC** : (1) Yaracuyanos
- **Carabobo FC** : (1) Carabobo
- **Trujillanos FC** : (1) Trujillanos
- **Academia Puerto Cabello**
- **Monagas Sport Club** : (2) Monagas · Monagas SC
- **Portuguesa FC** : (1) Portuguesa




Alphabet

- **Alphabet Specials** (5):  **á**  **é**  **í**  **ó**  **ú** 
  - **á**×6 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×4 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×1 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×1 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×4 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Caracas** (6): 
  - Caracas FC  (2) Caracas · Caracas Fútbol Club
  - Deportivo La Guaira  (1) Dvo. La Guaira
  - Deportivo Petare  (1) Dvo. Petare
  - Estudiantes de Caracas  (1) Estud. de Caracas
  - Metropolitanos FC  (2) Metropolitanos · FC Metropolitanos
  - Atlético Venezuela 
- **Ciudad Guayana** (2): 
  - AC Mineros  (3) Mineros · Mineros Guayana · Mineros de Guayana
  - LALA FC  (1) LALA
- **Acarigua** (1): Portuguesa FC  (1) Portuguesa
- **Barinas** (1): Zamora FC  (2) Zamora · Zamora Fútbol Club
- **Barquisimeto** (1): Deportivo Lara  (3) Dvo. Lara · Club Deportivo Lara · Asociación Civil Deportivo Lara
- **El Vigía** (1): Atlético El Vigía 
- **Guanare** (1): Llaneros FC  (4) Llaneros · Llaneros Guanare · Llaneros de Guanare · Llaneros Escuela de Fútbol
- **Maracaibo** (1): Zulia FC  (1) Zulia
- **Maracay** (1): Aragua FC  (1) Aragua
- **Maturín** (1): Monagas Sport Club  (2) Monagas · Monagas SC
- **Mérida** (1): Estudiantes de Mérida  (2) Estudiantes · Est. de Mérida
- **Puerto Ayacucho** (1): Tucanes FC  (2) Tucanes · Tucanes de Amazonas
- **Puerto Cabello** (1): Academia Puerto Cabello 
- **Puerto La Cruz** (1): Deportivo Anzoátegui  (2) Dvo. Anzoátegui · Deportivo Anzoátegui Sport Club
- **San Cristóbal** (1): Deportivo Táchira  (2) Dvo. Táchira · Deportivo Táchira Fútbol Club
- **San Felipe** (1): Yaracuyanos FC  (1) Yaracuyanos
- **Valencia** (1): Carabobo FC  (1) Carabobo
- **Valera** (1): Trujillanos FC  (1) Trujillanos




By Region

- **Caracas†** (6):   Caracas FC · Deportivo La Guaira · Deportivo Petare · Estudiantes de Caracas · Metropolitanos FC · Atlético Venezuela
- **San Cristóbal†** (1):   Deportivo Táchira
- **Barinas†** (1):   Zamora FC
- **Barquisimeto†** (1):   Deportivo Lara
- **Puerto La Cruz†** (1):   Deportivo Anzoátegui
- **Ciudad Guayana†** (2):   AC Mineros · LALA FC
- **El Vigía†** (1):   Atlético El Vigía
- **Guanare†** (1):   Llaneros FC
- **Maracaibo†** (1):   Zulia FC
- **Maracay†** (1):   Aragua FC
- **Mérida†** (1):   Estudiantes de Mérida
- **Puerto Ayacucho†** (1):   Tucanes FC
- **San Felipe†** (1):   Yaracuyanos FC
- **Valencia†** (1):   Carabobo FC
- **Valera†** (1):   Trujillanos FC
- **Puerto Cabello†** (1):   Academia Puerto Cabello
- **Maturín†** (1):   Monagas Sport Club
- **Acarigua†** (1):   Portuguesa FC




By Year

- **1967** (1):   Caracas FC
- ? (23):   Deportivo La Guaira · Deportivo Petare · Estudiantes de Caracas · Metropolitanos FC · Atlético Venezuela · Deportivo Táchira · Zamora FC · Deportivo Lara · Deportivo Anzoátegui · AC Mineros · LALA FC · Atlético El Vigía · Llaneros FC · Zulia FC · Aragua FC · Estudiantes de Mérida · Tucanes FC · Yaracuyanos FC · Carabobo FC · Trujillanos FC · Academia Puerto Cabello · Monagas Sport Club · Portuguesa FC






By A to Z

- **A** (7): Aragua · Aragua FC · AC Mineros · Atlético El Vigía · Atlético Venezuela · Academia Puerto Cabello · Asociación Civil Deportivo Lara
- **C** (6): Caracas · Carabobo · Caracas FC · Carabobo FC · Caracas Fútbol Club · Club Deportivo Lara
- **D** (12): Dvo. Lara · Dvo. Petare · Dvo. Táchira · Deportivo Lara · Dvo. La Guaira · Dvo. Anzoátegui · Deportivo Petare · Deportivo Táchira · Deportivo La Guaira · Deportivo Anzoátegui · Deportivo Táchira Fútbol Club · Deportivo Anzoátegui Sport Club
- **E** (5): Estudiantes · Est. de Mérida · Estud. de Caracas · Estudiantes de Mérida · Estudiantes de Caracas
- **F** (1): FC Metropolitanos
- **L** (7): LALA · LALA FC · Llaneros · Llaneros FC · Llaneros Guanare · Llaneros de Guanare · Llaneros Escuela de Fútbol
- **M** (8): Mineros · Monagas · Monagas SC · Metropolitanos · Mineros Guayana · Metropolitanos FC · Mineros de Guayana · Monagas Sport Club
- **P** (2): Portuguesa · Portuguesa FC
- **T** (5): Tucanes · Tucanes FC · Trujillanos · Trujillanos FC · Tucanes de Amazonas
- **Y** (2): Yaracuyanos · Yaracuyanos FC
- **Z** (5): Zulia · Zamora · Zulia FC · Zamora FC · Zamora Fútbol Club




