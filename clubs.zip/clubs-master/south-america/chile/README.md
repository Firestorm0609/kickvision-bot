18 clubs

- **Universidad de Chile** : (2) U. de Chile · Club Universidad de Chile
- **Universidad Católica** : (4) CDUC · Univ. Católica · CD Universidad Católica · Club Deportivo Universidad Católica ⇒ (4) ≈Univ. Catolica≈ · ≈Universidad Catolica≈ · ≈CD Universidad Catolica≈ · ≈Club Deportivo Universidad Catolica≈
- **Unión Española** : (1) Club Unión Española S.A.D.P ⇒ (2) ≈Union Espanola≈ · ≈Club Union Espanola S.A.D.P≈
- **Audax Italiano**
- **Colo-Colo**
- **Club Deportivo Palestino** : (1) Palestino
- **CD Huachipato** : (2) Huachipato · Club Deportivo Huachipato
- **Deportes Iquique** : (2) Iquique · Club Deportes Iquique
- **CD Cobresal** : (1) Cobresal
- **Coquimbo Unido**
- **Curicó Unido** ⇒ (1) ≈Curico Unido≈
- **CD Antofagasta** : (1) Deportes Antofagasta
- **Everton de Viña del Mar** : (2) Everton · Everton Viña d. Mar ⇒ (2) ≈Everton Vina d. Mar≈ · ≈Everton de Vina del Mar≈
- **O'Higgins FC** : (1) O'Higgins
- **Unión La Calera** ⇒ (1) ≈Union La Calera≈
- **CD Universidad de Concepción** : (1) Universidad de Concepción ⇒ (2) ≈Universidad de Concepcion≈ · ≈CD Universidad de Concepcion≈
- **Deportes Vallenar** : (1) Club de Deportes Vallenar
- **Deportes La Serena** : (2) CD La Serena · Club de Deportes La Serena




Alphabet

- **Alphabet Specials** (2):  **ñ**  **ó** 
  - **ñ**×4 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×10 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Santiago** (6): 
  - Universidad de Chile  (2) U. de Chile · Club Universidad de Chile
  - Universidad Católica  (4) CDUC · Univ. Católica · CD Universidad Católica · Club Deportivo Universidad Católica
  - Unión Española  (1) Club Unión Española S.A.D.P
  - Audax Italiano 
  - Colo-Colo 
  - Club Deportivo Palestino  (1) Palestino
- **Antofagasta** (1): CD Antofagasta  (1) Deportes Antofagasta
- **Concepción** (1): CD Universidad de Concepción  (1) Universidad de Concepción
- **Coquimbo** (1): Coquimbo Unido 
- **Curicó** (1): Curicó Unido 
- **El Salvador** (1): CD Cobresal  (1) Cobresal
- **Iquique** (1): Deportes Iquique  (2) Iquique · Club Deportes Iquique
- **La Calera** (1): Unión La Calera 
- **La Serena** (1): Deportes La Serena  (2) CD La Serena · Club de Deportes La Serena
- **Rancagua** (1): O'Higgins FC  (1) O'Higgins
- **Talcahuano** (1): CD Huachipato  (2) Huachipato · Club Deportivo Huachipato
- **Vallenar** (1): Deportes Vallenar  (1) Club de Deportes Vallenar
- **Viña del Mar** (1): Everton de Viña del Mar  (2) Everton · Everton Viña d. Mar




By Region

- **Santiago†** (6):   Universidad de Chile · Universidad Católica · Unión Española · Audax Italiano · Colo-Colo · Club Deportivo Palestino
- **Talcahuano†** (1):   CD Huachipato
- **Iquique†** (1):   Deportes Iquique
- **El Salvador†** (1):   CD Cobresal
- **Coquimbo†** (1):   Coquimbo Unido
- **Curicó†** (1):   Curicó Unido
- **Antofagasta†** (1):   CD Antofagasta
- **Viña del Mar†** (1):   Everton de Viña del Mar
- **Rancagua†** (1):   O'Higgins FC
- **La Calera†** (1):   Unión La Calera
- **Concepción†** (1):   CD Universidad de Concepción
- **Vallenar†** (1):   Deportes Vallenar
- **La Serena†** (1):   Deportes La Serena




By Year

- ? (18):   Universidad de Chile · Universidad Católica · Unión Española · Audax Italiano · Colo-Colo · Club Deportivo Palestino · CD Huachipato · Deportes Iquique · CD Cobresal · Coquimbo Unido · Curicó Unido · CD Antofagasta · Everton de Viña del Mar · O'Higgins FC · Unión La Calera · CD Universidad de Concepción · Deportes Vallenar · Deportes La Serena






By A to Z

- **A** (1): Audax Italiano
- **C** (19): CDUC · Cobresal · Colo-Colo · CD Cobresal · CD La Serena · Curicó Unido · CD Huachipato · CD Antofagasta · Coquimbo Unido · Club Deportes Iquique · CD Universidad Católica · Club Deportivo Palestino · Club Deportivo Huachipato · Club Universidad de Chile · Club de Deportes Vallenar · Club de Deportes La Serena · Club Unión Española S.A.D.P · CD Universidad de Concepción · Club Deportivo Universidad Católica
- **D** (4): Deportes Iquique · Deportes Vallenar · Deportes La Serena · Deportes Antofagasta
- **E** (3): Everton · Everton Viña d. Mar · Everton de Viña del Mar
- **H** (1): Huachipato
- **I** (1): Iquique
- **O** (2): O'Higgins · O'Higgins FC
- **P** (1): Palestino
- **U** (7): U. de Chile · Univ. Católica · Unión Española · Unión La Calera · Universidad Católica · Universidad de Chile · Universidad de Concepción




