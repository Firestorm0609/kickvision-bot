12 clubs

- **Libertad Ascunción** : (3) Libertad · Club Libertad · Club Libertad Asunción ⇒ (2) ≈Libertad Ascuncion≈ · ≈Club Libertad Asuncion≈
- **Club Olimpia** : (2) Olimpia · Ol. Asunción ⇒ (1) ≈Ol. Asuncion≈
- **Club Nacional** : (2) Nacional · Nacional de Asunción ⇒ (1) ≈Nacional de Asuncion≈
- **Cerro Porteño** : (1) Club Cerro Porteño ⇒ (2) ≈Cerro Porteno≈ · ≈Club Cerro Porteno≈
- **Club Guaraní** : (1) Guaraní ⇒ (2) ≈Guarani≈ · ≈Club Guarani≈
- **Club River Plate** : (3) River Plate · River Pl. Asuncion · Club River Plate (Asunción) ⇒ (1) ≈Club River Plate (Asuncion)≈
- **Deportivo Capiatá** ⇒ (1) ≈Deportivo Capiata≈
- **Deportivo Santaní** ⇒ (1) ≈Deportivo Santani≈
- **Club General Díaz** : (2) General Díaz · Club General Díaz (Luque) ⇒ (3) ≈General Diaz≈ · ≈Club General Diaz≈ · ≈Club General Diaz (Luque)≈
- **Sportivo Luqueño** ⇒ (1) ≈Sportivo Luqueno≈
- **Club Sportivo San Lorenzo** : (1) San Lorenzo
- **Club Sol de América** : (1) Sol de América ⇒ (2) ≈Sol de America≈ · ≈Club Sol de America≈




Alphabet

- **Alphabet Specials** (5):  **á**  **é**  **í**  **ñ**  **ó** 
  - **á**×1 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×2 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×6 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ñ**×3 U+00F1 (241) - LATIN SMALL LETTER N WITH TILDE ⇒ n
  - **ó**×5 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o




Duplicates





By City

- **Asunción** (6): 
  - Libertad Ascunción  (3) Libertad · Club Libertad · Club Libertad Asunción
  - Club Olimpia  (2) Olimpia · Ol. Asunción
  - Club Nacional  (2) Nacional · Nacional de Asunción
  - Cerro Porteño  (1) Club Cerro Porteño
  - Club Guaraní  (1) Guaraní
  - Club River Plate  (3) River Plate · River Pl. Asuncion · Club River Plate (Asunción)
- **Luque** (2): 
  - Club General Díaz  (2) General Díaz · Club General Díaz (Luque)
  - Sportivo Luqueño 
- **Capiatá** (1): Deportivo Capiatá 
- **San Estanislao** (1): Deportivo Santaní 
- **San Lorenzo** (1): Club Sportivo San Lorenzo  (1) San Lorenzo
- **Villa Elisa** (1): Club Sol de América  (1) Sol de América




By Region

- **Asunción†** (6):   Libertad Ascunción · Club Olimpia · Club Nacional · Cerro Porteño · Club Guaraní · Club River Plate
- **Capiatá†** (1):   Deportivo Capiatá
- **San Estanislao†** (1):   Deportivo Santaní
- **Luque†** (2):   Club General Díaz · Sportivo Luqueño
- **San Lorenzo†** (1):   Club Sportivo San Lorenzo
- **Villa Elisa†** (1):   Club Sol de América




By Year

- ? (12):   Libertad Ascunción · Club Olimpia · Club Nacional · Cerro Porteño · Club Guaraní · Club River Plate · Deportivo Capiatá · Deportivo Santaní · Club General Díaz · Sportivo Luqueño · Club Sportivo San Lorenzo · Club Sol de América






By A to Z

- **C** (13): Club Guaraní · Club Olimpia · Cerro Porteño · Club Libertad · Club Nacional · Club River Plate · Club General Díaz · Club Cerro Porteño · Club Sol de América · Club Libertad Asunción · Club General Díaz (Luque) · Club Sportivo San Lorenzo · Club River Plate (Asunción)
- **D** (2): Deportivo Capiatá · Deportivo Santaní
- **G** (2): Guaraní · General Díaz
- **L** (2): Libertad · Libertad Ascunción
- **N** (2): Nacional · Nacional de Asunción
- **O** (2): Olimpia · Ol. Asunción
- **R** (2): River Plate · River Pl. Asuncion
- **S** (3): San Lorenzo · Sol de América · Sportivo Luqueño




