22 clubs

- **Millonarios Bogotá** : (4) Millonarios · Millonarios FC · Los Millonarios · Millonarios Fútbol Club ⇒ (2) ≈Millonarios Bogota≈ · ≈Millonarios Futbol Club≈
- **Independiente Santa Fe** : (3) Santa Fe · Indep. Santa Fe · Corporación Deportiva Santa Fe ⇒ (1) ≈Corporacion Deportiva Santa Fe≈
- **La Equidad**
- **Atlético Nacional** : (2) At. Nacional · Club Atlético Nacional S.A. ⇒ (2) ≈Atletico Nacional≈ · ≈Club Atletico Nacional S.A.≈
- **Independiente Medellín** : (1) Indep. Medellín ⇒ (2) ≈Indep. Medellin≈ · ≈Independiente Medellin≈
- **Junior de Barranquilla** : (3) Junior · Atlético Junior · Corporación Popular Deportiva Junior ⇒ (2) ≈Atletico Junior≈ · ≈Corporacion Popular Deportiva Junior≈
- **Once Caldas** : (1) Corporación Deportiva Once Caldas ⇒ (1) ≈Corporacion Deportiva Once Caldas≈
- **Deportes Tolima**
- **Alianza Petrolera FC** : (1) Alianza Petrolera
- **América de Cali** ⇒ (1) ≈America de Cali≈
- **Deportivo Cali** : (2) AD Cali · Asociación Deportivo Cali ⇒ (1) ≈Asociacion Deportivo Cali≈
- **Atlético Bucaramanga** : (3) Bucaramanga · CA Bucaramanga · Club Atlético Bucaramanga ⇒ (2) ≈Atletico Bucaramanga≈ · ≈Club Atletico Bucaramanga≈
- **Atlético Huila** ⇒ (1) ≈Atletico Huila≈
- **Cúcuta Deportivo** ⇒ (1) ≈Cucuta Deportivo≈
- **Deportivo Pasto**
- **Envigado FC** : (1) Envigado
- **Jaguares de Córdoba** : (1) Jaguares ⇒ (1) ≈Jaguares de Cordoba≈
- **Patriotas Boyacá** : (1) Patriotas ⇒ (1) ≈Patriotas Boyaca≈
- **Boyacá Chicó** : (2) Boyacá Chicó FC · Boyacá Chicó Fútbol Club ⇒ (3) ≈Boyaca Chico≈ · ≈Boyaca Chico FC≈ · ≈Boyaca Chico Futbol Club≈
- **Rionegro Águilas** ⇒ (1) ≈Rionegro Aguilas≈
- **Unión Magdalena** ⇒ (1) ≈Union Magdalena≈
- **Deportivo Pereira**




Alphabet

- **Alphabet Specials** (6):  **Á**  **á**  **é**  **í**  **ó**  **ú** 
  - **Á**×1 U+00C1 (193) - LATIN CAPITAL LETTER A WITH ACUTE ⇒ A
  - **á**×5 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×7 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×2 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×9 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×3 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates





By City

- **Bogotá** (3): 
  - Millonarios Bogotá  (4) Millonarios · Millonarios FC · Millonarios Fútbol Club · Los Millonarios
  - Independiente Santa Fe  (3) Santa Fe · Indep. Santa Fe · Corporación Deportiva Santa Fe
  - La Equidad 
- **Cali** (2): 
  - América de Cali 
  - Deportivo Cali  (2) AD Cali · Asociación Deportivo Cali
- **Medellín** (2): 
  - Atlético Nacional  (2) At. Nacional · Club Atlético Nacional S.A.
  - Independiente Medellín  (1) Indep. Medellín
- **Tunja** (2): 
  - Patriotas Boyacá  (1) Patriotas
  - Boyacá Chicó  (2) Boyacá Chicó FC · Boyacá Chicó Fútbol Club
- **Barrancabermeja** (1): Alianza Petrolera FC  (1) Alianza Petrolera
- **Barranquilla** (1): Junior de Barranquilla  (3) Junior · Corporación Popular Deportiva Junior · Atlético Junior
- **Bucaramanga** (1): Atlético Bucaramanga  (3) Bucaramanga · CA Bucaramanga · Club Atlético Bucaramanga
- **Cúcuta** (1): Cúcuta Deportivo 
- **Envigado** (1): Envigado FC  (1) Envigado
- **Ibagué** (1): Deportes Tolima 
- **Manizales** (1): Once Caldas  (1) Corporación Deportiva Once Caldas
- **Montería** (1): Jaguares de Córdoba  (1) Jaguares
- **Neiva** (1): Atlético Huila 
- **Pasto** (1): Deportivo Pasto 
- **Pereira** (1): Deportivo Pereira 
- **Rionegro** (1): Rionegro Águilas 
- **Santa Marta** (1): Unión Magdalena 




By Region

- **Bogotá†** (3):   Millonarios Bogotá · Independiente Santa Fe · La Equidad
- **Medellín†** (2):   Atlético Nacional · Independiente Medellín
- **Barranquilla†** (1):   Junior de Barranquilla
- **Manizales†** (1):   Once Caldas
- **Ibagué†** (1):   Deportes Tolima
- **Barrancabermeja†** (1):   Alianza Petrolera FC
- **Cali†** (2):   América de Cali · Deportivo Cali
- **Bucaramanga†** (1):   Atlético Bucaramanga
- **Neiva†** (1):   Atlético Huila
- **Cúcuta†** (1):   Cúcuta Deportivo
- **Pasto†** (1):   Deportivo Pasto
- **Envigado†** (1):   Envigado FC
- **Montería†** (1):   Jaguares de Córdoba
- **Tunja†** (2):   Patriotas Boyacá · Boyacá Chicó
- **Rionegro†** (1):   Rionegro Águilas
- **Santa Marta†** (1):   Unión Magdalena
- **Pereira†** (1):   Deportivo Pereira




By Year

- ? (22):   Millonarios Bogotá · Independiente Santa Fe · La Equidad · Atlético Nacional · Independiente Medellín · Junior de Barranquilla · Once Caldas · Deportes Tolima · Alianza Petrolera FC · América de Cali · Deportivo Cali · Atlético Bucaramanga · Atlético Huila · Cúcuta Deportivo · Deportivo Pasto · Envigado FC · Jaguares de Córdoba · Patriotas Boyacá · Boyacá Chicó · Rionegro Águilas · Unión Magdalena · Deportivo Pereira






By A to Z

- **A** (10): AD Cali · At. Nacional · Atlético Huila · América de Cali · Atlético Junior · Alianza Petrolera · Atlético Nacional · Alianza Petrolera FC · Atlético Bucaramanga · Asociación Deportivo Cali
- **B** (4): Bucaramanga · Boyacá Chicó · Boyacá Chicó FC · Boyacá Chicó Fútbol Club
- **C** (7): CA Bucaramanga · Cúcuta Deportivo · Club Atlético Bucaramanga · Club Atlético Nacional S.A. · Corporación Deportiva Santa Fe · Corporación Deportiva Once Caldas · Corporación Popular Deportiva Junior
- **D** (4): Deportivo Cali · Deportes Tolima · Deportivo Pasto · Deportivo Pereira
- **E** (2): Envigado · Envigado FC
- **I** (4): Indep. Medellín · Indep. Santa Fe · Independiente Medellín · Independiente Santa Fe
- **J** (4): Junior · Jaguares · Jaguares de Córdoba · Junior de Barranquilla
- **L** (2): La Equidad · Los Millonarios
- **M** (4): Millonarios · Millonarios FC · Millonarios Bogotá · Millonarios Fútbol Club
- **O** (1): Once Caldas
- **P** (2): Patriotas · Patriotas Boyacá
- **R** (1): Rionegro Águilas
- **S** (1): Santa Fe
- **U** (1): Unión Magdalena




