58 clubs

- **All Boys** : (1) Club Atlético All Boys ⇒ (1) ≈Club Atletico All Boys≈
- [**Argentinos Juniors**](https://en.wikipedia.org/wiki/Argentinos_Juniors) : (4) Argentinos · Argentinos Jrs · Argentinos Jun · Asociación Atlética Argentinos Juniors ⇒ (1) ≈Asociacion Atletica Argentinos Juniors≈
- [**Boca Juniors**](https://en.wikipedia.org/wiki/Boca_Juniors) : (3) Boca · Boca Jrs · Club Atlético Boca Juniors ⇒ (1) ≈Club Atletico Boca Juniors≈
- [**River Plate**](https://en.wikipedia.org/wiki/Club_Atlético_River_Plate) : (3) River · CA River Plate · Club Atlético River Plate ⇒ (1) ≈Club Atletico River Plate≈
- [**San Lorenzo**](https://en.wikipedia.org/wiki/San_Lorenzo_de_Almagro) : (4) CA San Lorenzo · San Lorenzo de Almagro · CA San Lorenzo de Almagro · Club Atlético San Lorenzo de Almagro ⇒ (1) ≈Club Atletico San Lorenzo de Almagro≈
- [**Vélez Sarsfield**](https://en.wikipedia.org/wiki/Club_Atlético_Vélez_Sarsfield) : (6) Vélez · CA Vélez · Vélez Sarsf · Velez Sarsfield · CA Vélez Sarsfield · Club Atlético Vélez Sarsfield ⇒ (6) ≈Velez≈ · ≈CA Velez≈ · ≈Velez Sarsf≈ · ≈Velez Sarsfield≈ · ≈CA Velez Sarsfield≈ · ≈Club Atletico Velez Sarsfield≈
- [**Huracán**](https://en.wikipedia.org/wiki/Club_Atlético_Huracán) : (2) CA Huracán · Club Atlético Huracán ⇒ (3) ≈Huracan≈ · ≈CA Huracan≈ · ≈Club Atletico Huracan≈
- **Nueva Chicago** : (1) Club Atlético Nueva Chicago ⇒ (1) ≈Club Atletico Nueva Chicago≈
- **Atlanta** : (1) Club Atlético Atlanta ⇒ (1) ≈Club Atletico Atlanta≈
- **Barracas Central** : (1) Club Atlético Barracas Central ⇒ (1) ≈Club Atletico Barracas Central≈
- **Defensores de Belgranes** : (1) Club Atlético Defensores de Belgrano ⇒ (1) ≈Club Atletico Defensores de Belgrano≈
- **Deportivo Riestra** : (1) Deportivo Riestra Asociación de Fomento Barrio Colón ⇒ (1) ≈Deportivo Riestra Asociacion de Fomento Barrio Colon≈
- **Estudiantes de Buenos Aires** : (3) Estudiantes de Caseros · Club Atlético Estudiantes · Estudiantes (Buenos Aires) ⇒ (1) ≈Club Atletico Estudiantes≈
- **Ferro Carril Oeste** : (2) Ferro · Club Ferro Carril Oeste
- **CA Tigre** : (2) Tigre · Club Atlético Tigre ⇒ (1) ≈Club Atletico Tigre≈
- [**CA Independiente de Avellaneda**](https://en.wikipedia.org/wiki/Club_Atlético_Independiente) : (3) Independiente · CA Independiente · Club Atlético Independiente ⇒ (1) ≈Club Atletico Independiente≈
- [**Racing Club**](https://en.wikipedia.org/wiki/Racing_Club_de_Avellaneda) : (2) Racing · Racing Club de Avellaneda
- **Quilmes AC** : (2) Quilmes · Quilmes Atlético Club ⇒ (1) ≈Quilmes Atletico Club≈
- [**CA Lanús**](https://en.wikipedia.org/wiki/Club_Atlético_Lanús) : (3) Lanús · Atlético Lanús · Club Atlético Lanús ⇒ (4) ≈Lanus≈ · ≈CA Lanus≈ · ≈Atletico Lanus≈ · ≈Club Atletico Lanus≈
- [**Arsenal de Sarandí**](https://en.wikipedia.org/wiki/Arsenal_de_Sarandí) : (4) Arsenal · Arsenal FC · Arsenal Sarandí · Arsenal Fútbol Club ⇒ (3) ≈Arsenal Sarandi≈ · ≈Arsenal de Sarandi≈ · ≈Arsenal Futbol Club≈
- [**Estudiantes LP**](https://en.wikipedia.org/wiki/Estudiantes_de_La_Plata) : (4) Estudiantes · Estudiantes BA · Estudiantes de La Plata · Club Estudiantes de La Plata
- [**Gimnasia y Esgrima LP**](https://en.wikipedia.org/wiki/Club_de_Gimnasia_y_Esgrima_La_Plata) : (7) GELP · Gimnasia LP · Gimnasia ELP · Gimnasia La Plata · Gimnasia y Esgrima · Gimnasia y Esgrima La Plata · Club de Gimnasia y Esgrima La Plata
- [**Club Atlético Aldosivi**](https://en.wikipedia.org/wiki/Aldosivi) : (1) Aldosivi ⇒ (1) ≈Club Atletico Aldosivi≈
- **Alvarado** : (2) Club Atlético Alvarado · Alvarado (Mar del Plata) ⇒ (1) ≈Club Atletico Alvarado≈
- [**Club Atlético Banfield**](https://en.wikipedia.org/wiki/Club_Atlético_Banfield) : (2) Banfield · CA Banfield ⇒ (1) ≈Club Atletico Banfield≈
- [**Defensa y Justicia**](https://en.wikipedia.org/wiki/Defensa_y_Justicia) : (2) Defensa y Just · Club Social y Deportivo Defensa y Justicia
- **Olimpo Bahía Blanca** : (3) Olimpo · Club Olimpo · Olimpo de Bahía Blanca ⇒ (2) ≈Olimpo Bahia Blanca≈ · ≈Olimpo de Bahia Blanca≈
- **Sarmiento Junín** : (3) Sarmiento · Club Atlético Sarmiento · Club Atlético Sarmiento (Junín) ⇒ (3) ≈Sarmiento Junin≈ · ≈Club Atletico Sarmiento≈ · ≈Club Atletico Sarmiento (Junin)≈
- **Temperley** : (1) Club Atlético Temperley ⇒ (1) ≈Club Atletico Temperley≈
- **Chacarita Juniors** : (1) Club Atlético Chacarita Juniors ⇒ (1) ≈Club Atletico Chacarita Juniors≈
- **Agropecuario Argentino** : (2) Agropecuario · Club Agropecuario Argentino
- **Almagro** : (1) Club Almagro
- **Brown** : (3) Brown (Adrogué) · Brown de Adrogué · Club Atlético Brown ⇒ (3) ≈Brown (Adrogue)≈ · ≈Brown de Adrogue≈ · ≈Club Atletico Brown≈
- **Deportivo Morón** : (1) Club Deportivo Morón ⇒ (2) ≈Deportivo Moron≈ · ≈Club Deportivo Moron≈
- **Platense** : (1) Club Atlético Platense ⇒ (1) ≈Club Atletico Platense≈
- **Santamarina** : (1) Club y Biblioteca Ramón Santamarina ⇒ (1) ≈Club y Biblioteca Ramon Santamarina≈
- **Villa Dálmine** : (2) Dálmine · Club Villa Dálmine ⇒ (3) ≈Dalmine≈ · ≈Villa Dalmine≈ · ≈Club Villa Dalmine≈
- [**Colón Santa Fe**](https://en.wikipedia.org/wiki/Club_Atlético_Colón) : (5) Colón · CA Colón · Colon Santa FE · Club Atlético Colón · Club Atlético Colón (Santa Fe) ⇒ (5) ≈Colon≈ · ≈CA Colon≈ · ≈Colon Santa Fe≈ · ≈Club Atletico Colon≈ · ≈Club Atletico Colon (Santa Fe)≈
- [**Unión Santa Fe**](https://en.wikipedia.org/wiki/Unión_de_Santa_Fe) : (4) Unión · CA Unión · Unión de Santa Fe · Club Atlético Unión ⇒ (5) ≈Union≈ · ≈CA Union≈ · ≈Union Santa Fe≈ · ≈Union de Santa Fe≈ · ≈Club Atletico Union≈
- [**Newell's Old Boys**](https://en.wikipedia.org/wiki/Newell's_Old_Boys) : (7) Newell's · N.O. Boys · Newell's OB · Newell's Old B. · Newells Old Boys · CA Newell's Old Boys · Club Atlético Newell's Old Boys ⇒ (1) ≈Club Atletico Newell's Old Boys≈
- [**Rosario Central**](https://en.wikipedia.org/wiki/Rosario_Central) : (3) Rosario Cent · CA Rosario Central · Club Atlético Rosario Central ⇒ (1) ≈Club Atletico Rosario Central≈
- **Atlético Rafaela** : (4) Atl. Rafaela · At. de Rafaela · Atlético de Rafaela · Asociación Mutual Social y Deportiva Atlético de Rafaela ⇒ (3) ≈Atletico Rafaela≈ · ≈Atletico de Rafaela≈ · ≈Asociacion Mutual Social y Deportiva Atletico de Rafaela≈
- [**Talleres de Córdoba**](https://en.wikipedia.org/wiki/Talleres_de_Córdoba) : (4) Talleres · Talleres C. · Talleres Cordoba · Club Atlético Talleres ⇒ (2) ≈Talleres de Cordoba≈ · ≈Club Atletico Talleres≈
- **Club Atlético Belgrano** : (3) Belgrano · Belgrano (Córdoba) · Belgrano de Córdoba ⇒ (3) ≈Belgrano (Cordoba)≈ · ≈Belgrano de Cordoba≈ · ≈Club Atletico Belgrano≈
- **Instituto** : (4) Instituto ACC · Instituto (Córdoba) · Instituto de Córdoba · Instituto Atlético Central Córdoba ⇒ (3) ≈Instituto (Cordoba)≈ · ≈Instituto de Cordoba≈ · ≈Instituto Atletico Central Cordoba≈
- **Estudiantes de Río Cuarto** : (1) Asociación Atlética Estudiantes ⇒ (2) ≈Estudiantes de Rio Cuarto≈ · ≈Asociacion Atletica Estudiantes≈
- [**Godoy Cruz**](https://en.wikipedia.org/wiki/Godoy_Cruz_Antonio_Tomba) : (2) Godoy Cruz Antonio Tomba · Club Deportivo Godoy Cruz Antonio Tomba
- **Gimnasia y Esgrima de Mendoza** : (3) Gimnasia (Mendoza) · Gimnasia y Esgrima · Club Gimnasia y Esgrima
- **Independiente Rivadavia** : (1) Club Sportivo Independiente Rivadavia
- **San Martín San Juan** : (3) San Martín · San Martín SJ · Club Atlético San Martín ⇒ (4) ≈San Martin≈ · ≈San Martin SJ≈ · ≈San Martin San Juan≈ · ≈Club Atletico San Martin≈
- **Gimnasia y Esgrima de Jujuy** : (3) GEJ · Gimnasia y Esgrima (Jujuy) · Club Atlético Gimnasia y Esgrima de Jujuy ⇒ (1) ≈Club Atletico Gimnasia y Esgrima de Jujuy≈
- [**Atlético Tucumán**](https://en.wikipedia.org/wiki/Atlético_Tucumán) : (2) Tucumán · Atl. Tucumán ⇒ (3) ≈Tucuman≈ · ≈Atl. Tucuman≈ · ≈Atletico Tucuman≈
- **San Martín de Tucumán** : (5) San Martín · San Martín T. · San Martín (Tucumán) · Club Atlético San Martín · Club Atlético San Martín (Tucumán) ⇒ (6) ≈San Martin≈ · ≈San Martin T.≈ · ≈San Martin (Tucuman)≈ · ≈San Martin de Tucuman≈ · ≈Club Atletico San Martin≈ · ≈Club Atletico San Martin (Tucuman)≈
- [**Patronato**](https://en.wikipedia.org/wiki/Club_Atlético_Patronato) : (2) Club Atlético Patronato · Club Atlético Patronato de la Juventud Católica ⇒ (2) ≈Club Atletico Patronato≈ · ≈Club Atletico Patronato de la Juventud Catolica≈
- **Crucero del Norte** : (1) Club Mutual Crucero del Norte
- [**Central Córdoba**](https://en.wikipedia.org/wiki/Central_Córdoba_de_Santiago_del_Estero) : (6) CC Córdoba · CA Central Córdob · Central Córdoba (SdE) · Club Atlético Central Córdoba · Central Córdoba (Santiago del Estero) · Central Córdoba de Santiago del Estero ⇒ (7) ≈CC Cordoba≈ · ≈Central Cordoba≈ · ≈CA Central Cordob≈ · ≈Central Cordoba (SdE)≈ · ≈Club Atletico Central Cordoba≈ · ≈Central Cordoba (Santiago del Estero)≈ · ≈Central Cordoba de Santiago del Estero≈
- **Mitre** : (3) Mitre (SdE) · Club Atlético Mitre · Mitre (Santiago del Estero) ⇒ (1) ≈Club Atletico Mitre≈
- **Guillermo Brown** : (2) Brown de Puerto Madryn · Guillermo Brown de Puerto Madryn




Alphabet

- **Alphabet Specials** (5):  **á**  **é**  **í**  **ó**  **ú** 
  - **á**×12 U+00E1 (225) - LATIN SMALL LETTER A WITH ACUTE ⇒ a
  - **é**×55 U+00E9 (233) - LATIN SMALL LETTER E WITH ACUTE ⇒ e
  - **í**×17 U+00ED (237) - LATIN SMALL LETTER I WITH ACUTE ⇒ i
  - **ó**×32 U+00F3 (243) - LATIN SMALL LETTER O WITH ACUTE ⇒ o
  - **ú**×5 U+00FA (250) - LATIN SMALL LETTER U WITH ACUTE ⇒ u




Duplicates

- **Vélez Sarsfield**, Buenos Aires (1):
  - `velezsarsfield` (2): **Velez Sarsfield** · **Velez Sarsfield**
- **Colón Santa Fe**, Santa Fe (1):
  - `colonsantafe` (2): Colon Santa FE · Colon Santa Fe
- **Newell's Old Boys**, Rosario (1):
  - `newellsoldboys` (2): Newell's Old Boys · Newells Old Boys




By City

- **Buenos Aires, Buenos Aires** (14): 
  - All Boys  (1) Club Atlético All Boys
  - Argentinos Juniors  (4) Argentinos · Argentinos Jrs · Argentinos Jun · Asociación Atlética Argentinos Juniors
  - Boca Juniors  (3) Boca · Boca Jrs · Club Atlético Boca Juniors
  - River Plate  (3) River · CA River Plate · Club Atlético River Plate
  - San Lorenzo  (4) San Lorenzo de Almagro · CA San Lorenzo · CA San Lorenzo de Almagro · Club Atlético San Lorenzo de Almagro
  - Vélez Sarsfield  (6) Vélez · Vélez Sarsf · Velez Sarsfield · CA Vélez · CA Vélez Sarsfield · Club Atlético Vélez Sarsfield
  - Huracán  (2) CA Huracán · Club Atlético Huracán
  - Nueva Chicago  (1) Club Atlético Nueva Chicago
  - Atlanta  (1) Club Atlético Atlanta
  - Barracas Central  (1) Club Atlético Barracas Central
  - Defensores de Belgranes  (1) Club Atlético Defensores de Belgrano
  - Deportivo Riestra  (1) Deportivo Riestra Asociación de Fomento Barrio Colón
  - Estudiantes de Buenos Aires  (3) Estudiantes (Buenos Aires) · Club Atlético Estudiantes · Estudiantes de Caseros
  - Ferro Carril Oeste  (2) Ferro · Club Ferro Carril Oeste
- **Córdoba, Córdoba** (3): 
  - Talleres de Córdoba  (4) Talleres · Talleres C. · Talleres Cordoba · Club Atlético Talleres
  - Club Atlético Belgrano  (3) Belgrano · Belgrano (Córdoba) · Belgrano de Córdoba
  - Instituto  (4) Instituto de Córdoba · Instituto (Córdoba) · Instituto ACC · Instituto Atlético Central Córdoba
- **Mendoza, Mendoza** (3): 
  - Godoy Cruz  (2) Godoy Cruz Antonio Tomba · Club Deportivo Godoy Cruz Antonio Tomba
  - Gimnasia y Esgrima de Mendoza  (3) Gimnasia (Mendoza) · Gimnasia y Esgrima · Club Gimnasia y Esgrima
  - Independiente Rivadavia  (1) Club Sportivo Independiente Rivadavia
- **Avellaneda, Buenos Aires** (2): 
  - CA Independiente de Avellaneda  (3) Independiente · CA Independiente · Club Atlético Independiente
  - Racing Club  (2) Racing · Racing Club de Avellaneda
- **La Plata, Buenos Aires** (2): 
  - Estudiantes LP  (4) Club Estudiantes de La Plata · Estudiantes de La Plata · Estudiantes · Estudiantes BA
  - Gimnasia y Esgrima LP  (7) GELP · Gimnasia LP · Gimnasia ELP · Gimnasia y Esgrima La Plata · Club de Gimnasia y Esgrima La Plata · Gimnasia La Plata · Gimnasia y Esgrima
- **Mar del Plata, Buenos Aires** (2): 
  - Club Atlético Aldosivi  (1) Aldosivi
  - Alvarado  (2) Alvarado (Mar del Plata) · Club Atlético Alvarado
- **Rosario, Santa Fe** (2): 
  - Newell's Old Boys  (7) Newell's · N.O. Boys · Newell's OB · Newell's Old B. · Newells Old Boys · CA Newell's Old Boys · Club Atlético Newell's Old Boys
  - Rosario Central  (3) Rosario Cent · CA Rosario Central · Club Atlético Rosario Central
- **San Miguel de Tucumán, Tucumán** (2): 
  - Atlético Tucumán  (2) Tucumán · Atl. Tucumán
  - San Martín de Tucumán  (5) San Martín · San Martín T. · San Martín (Tucumán) · Club Atlético San Martín · Club Atlético San Martín (Tucumán)
- **Santa Fe, Santa Fe** (2): 
  - Colón Santa Fe  (5) Colón · CA Colón · Club Atlético Colón · Club Atlético Colón (Santa Fe) · Colon Santa FE
  - Unión Santa Fe  (4) Unión · Unión de Santa Fe · CA Unión · Club Atlético Unión
- **Santiago del Estero, Santiago del Estero** (2): 
  - Central Córdoba  (6) CC Córdoba · CA Central Córdob · Club Atlético Central Córdoba · Central Córdoba de Santiago del Estero · Central Córdoba (SdE) · Central Córdoba (Santiago del Estero)
  - Mitre  (3) Mitre (SdE) · Mitre (Santiago del Estero) · Club Atlético Mitre
- **Adrogué, Buenos Aires** (1): Brown  (3) Brown de Adrogué · Brown (Adrogué) · Club Atlético Brown
- **Bahía Blanca, Buenos Aires** (1): Olimpo Bahía Blanca  (3) Olimpo · Club Olimpo · Olimpo de Bahía Blanca
- **Banfield, Buenos Aires** (1): Club Atlético Banfield  (2) Banfield · CA Banfield
- **Campana, Buenos Aires** (1): Villa Dálmine  (2) Dálmine · Club Villa Dálmine
- **Carlos Casares, Buenos Aires** (1): Agropecuario Argentino  (2) Agropecuario · Club Agropecuario Argentino
- **Florida Este, Buenos Aires** (1): Platense  (1) Club Atlético Platense
- **Garupá, Misiones** (1): Crucero del Norte  (1) Club Mutual Crucero del Norte
- **Gobernador Julio A. Costa, Buenos Aires** (1): Defensa y Justicia  (2) Defensa y Just · Club Social y Deportivo Defensa y Justicia
- **José Ingenieros, Buenos Aires** (1): Almagro  (1) Club Almagro
- **Junín, Buenos Aires** (1): Sarmiento Junín  (3) Sarmiento · Club Atlético Sarmiento · Club Atlético Sarmiento (Junín)
- **Lanús, Buenos Aires** (1): CA Lanús  (3) Lanús · Atlético Lanús · Club Atlético Lanús
- **Morón, Buenos Aires** (1): Deportivo Morón  (1) Club Deportivo Morón
- **Paraná, Entre Ríos** (1): Patronato  (2) Club Atlético Patronato · Club Atlético Patronato de la Juventud Católica
- **Puerto Madryn, Chubut** (1): Guillermo Brown  (2) Guillermo Brown de Puerto Madryn · Brown de Puerto Madryn
- **Quilmes, Buenos Aires** (1): Quilmes AC  (2) Quilmes · Quilmes Atlético Club
- **Rafaela, Santa Fe** (1): Atlético Rafaela  (4) At. de Rafaela · Atl. Rafaela · Atlético de Rafaela · Asociación Mutual Social y Deportiva Atlético de Rafaela
- **Río Cuarto, Córdoba** (1): Estudiantes de Río Cuarto  (1) Asociación Atlética Estudiantes
- **San Juan, San Juan** (1): San Martín San Juan  (3) San Martín · San Martín SJ · Club Atlético San Martín
- **San Salvador de Jujuy, Jujuy** (1): Gimnasia y Esgrima de Jujuy  (3) GEJ · Gimnasia y Esgrima (Jujuy) · Club Atlético Gimnasia y Esgrima de Jujuy
- **Sarandí, Buenos Aires** (1): Arsenal de Sarandí  (4) Arsenal · Arsenal Sarandí · Arsenal FC · Arsenal Fútbol Club
- **Tandil, Buenos Aires** (1): Santamarina  (1) Club y Biblioteca Ramón Santamarina
- **Turdera, Buenos Aires** (1): Temperley  (1) Club Atlético Temperley
- **Victoria, Buenos Aires** (1): CA Tigre  (2) Tigre · Club Atlético Tigre
- **Villa Maipú, Buenos Aires** (1): Chacarita Juniors  (1) Club Atlético Chacarita Juniors




By Region

- **Buenos Aires** (37):   All Boys · Argentinos Juniors · Boca Juniors · River Plate · San Lorenzo · Vélez Sarsfield · Huracán · Nueva Chicago · Atlanta · Barracas Central · Defensores de Belgranes · Deportivo Riestra · Estudiantes de Buenos Aires · Ferro Carril Oeste · CA Tigre · CA Independiente de Avellaneda · Racing Club · Quilmes AC · CA Lanús · Arsenal de Sarandí · Estudiantes LP · Gimnasia y Esgrima LP · Club Atlético Aldosivi · Alvarado · Club Atlético Banfield · Defensa y Justicia · Olimpo Bahía Blanca · Sarmiento Junín · Temperley · Chacarita Juniors · Agropecuario Argentino · Almagro · Brown · Deportivo Morón · Platense · Santamarina · Villa Dálmine
- **Santa Fe** (5):   Colón Santa Fe · Unión Santa Fe · Newell's Old Boys · Rosario Central · Atlético Rafaela
- **Córdoba** (4):   Talleres de Córdoba · Club Atlético Belgrano · Instituto · Estudiantes de Río Cuarto
- **Mendoza** (3):   Godoy Cruz · Gimnasia y Esgrima de Mendoza · Independiente Rivadavia
- **San Juan** (1):   San Martín San Juan
- **Jujuy** (1):   Gimnasia y Esgrima de Jujuy
- **Tucumán** (2):   Atlético Tucumán · San Martín de Tucumán
- **Entre Ríos** (1):   Patronato
- **Misiones** (1):   Crucero del Norte
- **Santiago del Estero** (2):   Central Córdoba · Mitre
- **Chubut** (1):   Guillermo Brown




By Year

- ? (58):   All Boys · Argentinos Juniors · Boca Juniors · River Plate · San Lorenzo · Vélez Sarsfield · Huracán · Nueva Chicago · Atlanta · Barracas Central · Defensores de Belgranes · Deportivo Riestra · Estudiantes de Buenos Aires · Ferro Carril Oeste · CA Tigre · CA Independiente de Avellaneda · Racing Club · Quilmes AC · CA Lanús · Arsenal de Sarandí · Estudiantes LP · Gimnasia y Esgrima LP · Club Atlético Aldosivi · Alvarado · Club Atlético Banfield · Defensa y Justicia · Olimpo Bahía Blanca · Sarmiento Junín · Temperley · Chacarita Juniors · Agropecuario Argentino · Almagro · Brown · Deportivo Morón · Platense · Santamarina · Villa Dálmine · Colón Santa Fe · Unión Santa Fe · Newell's Old Boys · Rosario Central · Atlético Rafaela · Talleres de Córdoba · Club Atlético Belgrano · Instituto · Estudiantes de Río Cuarto · Godoy Cruz · Gimnasia y Esgrima de Mendoza · Independiente Rivadavia · San Martín San Juan · Gimnasia y Esgrima de Jujuy · Atlético Tucumán · San Martín de Tucumán · Patronato · Crucero del Norte · Central Córdoba · Mitre · Guillermo Brown






By A to Z

- **A** (27): Almagro · Arsenal · Atlanta · Aldosivi · All Boys · Alvarado · Argentinos · Arsenal FC · Agropecuario · Atl. Rafaela · Atl. Tucumán · Argentinos Jrs · Argentinos Jun · At. de Rafaela · Atlético Lanús · Arsenal Sarandí · Atlético Rafaela · Atlético Tucumán · Argentinos Juniors · Arsenal de Sarandí · Arsenal Fútbol Club · Atlético de Rafaela · Agropecuario Argentino · Alvarado (Mar del Plata) · Asociación Atlética Estudiantes · Asociación Atlética Argentinos Juniors · Asociación Mutual Social y Deportiva Atlético de Rafaela
- **B** (12): Boca · Brown · Banfield · Belgrano · Boca Jrs · Boca Juniors · Brown (Adrogué) · Barracas Central · Brown de Adrogué · Belgrano (Córdoba) · Belgrano de Córdoba · Brown de Puerto Madryn
- **C** (77): Colón · CA Colón · CA Lanús · CA Tigre · CA Unión · CA Vélez · CA Huracán · CC Córdoba · CA Banfield · Club Olimpo · Club Almagro · CA River Plate · CA San Lorenzo · Colon Santa FE · Colón Santa Fe · Central Córdoba · CA Independiente · CA Central Córdob · Chacarita Juniors · Crucero del Norte · CA Rosario Central · CA Vélez Sarsfield · Club Villa Dálmine · Club Atlético Brown · Club Atlético Colón · Club Atlético Lanús · Club Atlético Mitre · Club Atlético Tigre · Club Atlético Unión · CA Newell's Old Boys · Club Deportivo Morón · Central Córdoba (SdE) · Club Atlético Atlanta · Club Atlético Huracán · Club Atlético Aldosivi · Club Atlético All Boys · Club Atlético Alvarado · Club Atlético Banfield · Club Atlético Belgrano · Club Atlético Platense · Club Atlético Talleres · Club Atlético Patronato · Club Atlético Sarmiento · Club Atlético Temperley · Club Ferro Carril Oeste · Club Gimnasia y Esgrima · !! **Club Atlético San Martín (2)** !! · CA San Lorenzo de Almagro · Club Atlético Estudiantes · Club Atlético River Plate · Club Atlético Boca Juniors · Club Agropecuario Argentino · Club Atlético Independiente · Club Atlético Nueva Chicago · Club Estudiantes de La Plata · Club Atlético Central Córdoba · Club Atlético Rosario Central · Club Atlético Vélez Sarsfield · Club Mutual Crucero del Norte · CA Independiente de Avellaneda · Club Atlético Barracas Central · Club Atlético Colón (Santa Fe) · Club Atlético Chacarita Juniors · Club Atlético Newell's Old Boys · Club Atlético Sarmiento (Junín) · Club Atlético San Martín (Tucumán) · Club de Gimnasia y Esgrima La Plata · Club y Biblioteca Ramón Santamarina · Club Atlético Defensores de Belgrano · Club Atlético San Lorenzo de Almagro · Central Córdoba (Santiago del Estero) · Club Sportivo Independiente Rivadavia · Central Córdoba de Santiago del Estero · Club Deportivo Godoy Cruz Antonio Tomba · Club Atlético Gimnasia y Esgrima de Jujuy · Club Social y Deportivo Defensa y Justicia · Club Atlético Patronato de la Juventud Católica
- **D** (7): Dálmine · Defensa y Just · Deportivo Morón · Deportivo Riestra · Defensa y Justicia · Defensores de Belgranes · Deportivo Riestra Asociación de Fomento Barrio Colón
- **E** (8): Estudiantes · Estudiantes BA · Estudiantes LP · Estudiantes de Caseros · Estudiantes de La Plata · Estudiantes de Río Cuarto · Estudiantes (Buenos Aires) · Estudiantes de Buenos Aires
- **F** (2): Ferro · Ferro Carril Oeste
- **G** (16): GEJ · GELP · Godoy Cruz · Gimnasia LP · Gimnasia ELP · Guillermo Brown · Gimnasia La Plata · Gimnasia (Mendoza) · !! **Gimnasia y Esgrima (2)** !! · Gimnasia y Esgrima LP · Godoy Cruz Antonio Tomba · Gimnasia y Esgrima (Jujuy) · Gimnasia y Esgrima La Plata · Gimnasia y Esgrima de Jujuy · Gimnasia y Esgrima de Mendoza · Guillermo Brown de Puerto Madryn
- **H** (1): Huracán
- **I** (7): Instituto · Independiente · Instituto ACC · Instituto (Córdoba) · Instituto de Córdoba · Independiente Rivadavia · Instituto Atlético Central Córdoba
- **L** (1): Lanús
- **M** (3): Mitre · Mitre (SdE) · Mitre (Santiago del Estero)
- **N** (7): Newell's · N.O. Boys · Newell's OB · Nueva Chicago · Newell's Old B. · Newells Old Boys · Newell's Old Boys
- **O** (3): Olimpo · Olimpo Bahía Blanca · Olimpo de Bahía Blanca
- **P** (2): Platense · Patronato
- **Q** (3): Quilmes · Quilmes AC · Quilmes Atlético Club
- **R** (7): River · Racing · Racing Club · River Plate · Rosario Cent · Rosario Central · Racing Club de Avellaneda
- **S** (11): Sarmiento · !! **San Martín (2)** !! · San Lorenzo · Santamarina · San Martín SJ · San Martín T. · Sarmiento Junín · San Martín San Juan · San Martín (Tucumán) · San Martín de Tucumán · San Lorenzo de Almagro
- **T** (7): Tigre · Tucumán · Talleres · Temperley · Talleres C. · Talleres Cordoba · Talleres de Córdoba
- **U** (3): Unión · Unión Santa Fe · Unión de Santa Fe
- **V** (5): Vélez · Vélez Sarsf · Villa Dálmine · Velez Sarsfield · Vélez Sarsfield




