30 clubs

- [**Hapoel Tel-Aviv FC**](https://en.wikipedia.org/wiki/Hapoel_Tel_Aviv_F.C.) : (2) H. Tel-Aviv · Hapoel Tel-Aviv
- [**Maccabi Tel-Aviv FC**](https://en.wikipedia.org/wiki/Maccabi_Tel_Aviv_F.C.) : (3) M. Tel-Aviv · Macc. Tel Aviv · Maccabi Tel Aviv
- [**Bnei Yehuda Tel-Aviv FC**](https://en.wikipedia.org/wiki/Bnei_Yehuda_Tel_Aviv_F.C.) : (2) Bnei Yehuda · Bnei Yehuda Tel Aviv
- **Beitar Tel Aviv Bat Yam FC** : (2) Beitar Tel Aviv · Beitar Tel Aviv Bat Yam
- [**Maccabi Haifa FC**](https://en.wikipedia.org/wiki/Maccabi_Haifa_F.C.) : (2) M. Haifa · Maccabi Haifa
- [**Hapoel Haifa FC**](https://en.wikipedia.org/wiki/Hapoel_Haifa_F.C.) : (2) H. Haifa · Hapoel Haifa
- [**Hapoel Kiryat Shmona FC**](https://en.wikipedia.org/wiki/Hapoel_Ironi_Kiryat_Shmona_F.C.) : (7) Ironi K. Shmona · H. Kiryat Shmona · Ironi Kiryat Shmona · Hapoel Kiryat Shmona · Ironi Kiryat Schmona · Hapoel Ironi Kiryat Shmona · Hapoel Ironi Kiryat Shmona FC
- [**Maccabi Netanya FC**](https://en.wikipedia.org/wiki/Maccabi_Netanya_F.C.) : (2) M. Netanya · Maccabi Netanya
- [**Beitar Jerusalem FC**](https://en.wikipedia.org/wiki/Beitar_Jerusalem_F.C.) : (1) Beitar Jerusalem
- **Hapoel Katamon Jerusalem FC** : (2) Hap. Kat. Jerusalem · Hapoel Katamon Jerusalem
- [**Hapoel Beer-Sheva FC**](https://en.wikipedia.org/wiki/Hapoel_Be'er_Sheva_F.C.) : (4) Hapoel Be'er · H. Beer-Sheva · Hap. Beer-Sheva · Hapoel Be'er Sheva
- [**FC Ashdod**](https://en.wikipedia.org/wiki/F.C._Ashdod) : (3) Ashdod · FC Ironi Ashdod · Moadon Sport Ashdod
- [**Hapoel Hadera FC**](https://en.wikipedia.org/wiki/Hapoel_Hadera_F.C.) : (1) Hapoel Hadera
- [**Hapoel Ra'anana AFC**](https://en.wikipedia.org/wiki/Hapoel_Ra'anana_A.F.C.) : (3) H. Ra'anana · Hapoel Ra'anana · Hapoel Ra'anana FC
- [**Maccabi Petah Tikva FC**](https://en.wikipedia.org/wiki/Maccabi_Petah_Tikva_F.C.) : (4) Macc. Petach Tikva · Maccabi Petah Tikva · Maccabi Petach-Tikva · Maccabi Petach-Tikva FC
- **Hapoel Petah Tikva FC** : (4) H. Petach Tikva · Hapoel Petah Tikva · Hapoel Petach-Tikva · Hapoel Petach-Tikva FC
- **Hapoel Kfar-Saba FC** : (2) H. Kfar-Saba · Hapoel Kfar-Saba
- **Sektzia Nes Tziona FC** : (4) Nes Tziona · Sectzya Nes Ziona · Sektzia Nes Tziona · Sektzia Ness Ziona FC
- [**Bnei Sakhnin FC**](https://en.wikipedia.org/wiki/Bnei_Sakhnin_F.C.) : (2) Bnei Sakhnin · Bnei Sachnin FC
- **FC Kafr Qasim** : (1) SC Kfar Qasem
- **Hapoel Acre FC** : (3) Hapoel Acre · Hapoel Akko · Hapoel Ironi Akko
- **Hapoel Afula FC** : (1) Hapoel Afula
- **Hapoel Ashkelon FC** : (1) Hapoel Ashkelon
- **Hapoel Bnei Lod FC** : (1) Hapoel Bnei Lod
- **Hapoel Nof HaGalil FC** : (1) Hapoel Nof HaGalil
- **Hapoel Ramat Gan Giv'atayim FC** : (3) H. Ramat Gan · Hapoel Ramat Gan · Hapoel Ramat Gan FC
- **Hapoel Ramat HaSharon FC** : (3) I. Ramat Hasharon · Ironi Ramat HaSharon · Hapoel Ramat HaSharon
- **Hapoel Rishon LeZion FC** : (3) Hap. Rishon LeZion · Hapoel Rishon Lezi · Hapoel Rishon LeZion
- **Hapoel Umm al-Fahm FC** : (2) Hapoel Umm al-Fahm · Hapoel Um el-Fahem
- **Maccabi Ahi Nazareth FC** : (2) M. Ahi Nazareth · Maccabi Ahi Nazareth




Alphabet

- **Alphabet Specials** (0): 




Duplicates





By City

- **Petah Tikva** (2): 
  - Maccabi Petah Tikva FC  (4) Maccabi Petah Tikva · Macc. Petach Tikva · Maccabi Petach-Tikva FC · Maccabi Petach-Tikva
  - Hapoel Petah Tikva FC  (4) H. Petach Tikva · Hapoel Petah Tikva · Hapoel Petach-Tikva FC · Hapoel Petach-Tikva
- **Acre** (1): Hapoel Acre FC  (3) Hapoel Acre · Hapoel Akko · Hapoel Ironi Akko
- **Afula** (1): Hapoel Afula FC  (1) Hapoel Afula
- **Ashdod** (1): FC Ashdod  (3) Ashdod · FC Ironi Ashdod · Moadon Sport Ashdod
- **Ashkelon** (1): Hapoel Ashkelon FC  (1) Hapoel Ashkelon
- **Be'er Sheva** (1): Hapoel Beer-Sheva FC  (4) H. Beer-Sheva · Hap. Beer-Sheva · Hapoel Be'er · Hapoel Be'er Sheva
- **Hadera** (1): Hapoel Hadera FC  (1) Hapoel Hadera
- **Jerusalem** (1): Hapoel Katamon Jerusalem FC  (2) Hap. Kat. Jerusalem · Hapoel Katamon Jerusalem
- **Kafr Qasim** (1): FC Kafr Qasim  (1) SC Kfar Qasem
- **Lod** (1): Hapoel Bnei Lod FC  (1) Hapoel Bnei Lod
- **Nazareth** (1): Maccabi Ahi Nazareth FC  (2) M. Ahi Nazareth · Maccabi Ahi Nazareth
- **Ness Ziona** (1): Sektzia Nes Tziona FC  (4) Nes Tziona · Sektzia Nes Tziona · Sectzya Nes Ziona · Sektzia Ness Ziona FC
- **Nof HaGalil** (1): Hapoel Nof HaGalil FC  (1) Hapoel Nof HaGalil
- **Ra'anana** (1): Hapoel Ra'anana AFC  (3) H. Ra'anana · Hapoel Ra'anana · Hapoel Ra'anana FC
- **Ramat Gan** (1): Hapoel Ramat Gan Giv'atayim FC  (3) Hapoel Ramat Gan · H. Ramat Gan · Hapoel Ramat Gan FC
- **Ramat HaSharon** (1): Hapoel Ramat HaSharon FC  (3) Hapoel Ramat HaSharon · Ironi Ramat HaSharon · I. Ramat Hasharon
- **Rishon LeZion** (1): Hapoel Rishon LeZion FC  (3) Hap. Rishon LeZion · Hapoel Rishon LeZion · Hapoel Rishon Lezi
- **Sakhnin** (1): Bnei Sakhnin FC  (2) Bnei Sakhnin · Bnei Sachnin FC
- **Tel Aviv** (1): Beitar Tel Aviv Bat Yam FC  (2) Beitar Tel Aviv · Beitar Tel Aviv Bat Yam
- **Umm al-Fahm** (1): Hapoel Umm al-Fahm FC  (2) Hapoel Umm al-Fahm · Hapoel Um el-Fahem
- ? (9): 
  - Hapoel Tel-Aviv FC  (2) H. Tel-Aviv · Hapoel Tel-Aviv
  - Maccabi Tel-Aviv FC  (3) Maccabi Tel Aviv · Macc. Tel Aviv · M. Tel-Aviv
  - Bnei Yehuda Tel-Aviv FC  (2) Bnei Yehuda · Bnei Yehuda Tel Aviv
  - Maccabi Haifa FC  (2) M. Haifa · Maccabi Haifa
  - Hapoel Haifa FC  (2) H. Haifa · Hapoel Haifa
  - Hapoel Kiryat Shmona FC  (7) H. Kiryat Shmona · Hapoel Kiryat Shmona · Hapoel Ironi Kiryat Shmona FC · Hapoel Ironi Kiryat Shmona · Ironi K. Shmona · Ironi Kiryat Shmona · Ironi Kiryat Schmona
  - Maccabi Netanya FC  (2) M. Netanya · Maccabi Netanya
  - Beitar Jerusalem FC  (1) Beitar Jerusalem
  - Hapoel Kfar-Saba FC  (2) H. Kfar-Saba · Hapoel Kfar-Saba




By Region

- **Tel Aviv†** (1):   Beitar Tel Aviv Bat Yam FC
- **Jerusalem†** (1):   Hapoel Katamon Jerusalem FC
- **Be'er Sheva†** (1):   Hapoel Beer-Sheva FC
- **Ashdod†** (1):   FC Ashdod
- **Hadera†** (1):   Hapoel Hadera FC
- **Ra'anana†** (1):   Hapoel Ra'anana AFC
- **Petah Tikva†** (2):   Maccabi Petah Tikva FC · Hapoel Petah Tikva FC
- **Ness Ziona†** (1):   Sektzia Nes Tziona FC
- **Sakhnin†** (1):   Bnei Sakhnin FC
- **Kafr Qasim†** (1):   FC Kafr Qasim
- **Acre†** (1):   Hapoel Acre FC
- **Afula†** (1):   Hapoel Afula FC
- **Ashkelon†** (1):   Hapoel Ashkelon FC
- **Lod†** (1):   Hapoel Bnei Lod FC
- **Nof HaGalil†** (1):   Hapoel Nof HaGalil FC
- **Ramat Gan†** (1):   Hapoel Ramat Gan Giv'atayim FC
- **Ramat HaSharon†** (1):   Hapoel Ramat HaSharon FC
- **Rishon LeZion†** (1):   Hapoel Rishon LeZion FC
- **Umm al-Fahm†** (1):   Hapoel Umm al-Fahm FC
- **Nazareth†** (1):   Maccabi Ahi Nazareth FC




By Year

- **1949** (1):   Hapoel Beer-Sheva FC
- **1999** (1):   FC Ashdod
- ? (28):   Hapoel Tel-Aviv FC · Maccabi Tel-Aviv FC · Bnei Yehuda Tel-Aviv FC · Beitar Tel Aviv Bat Yam FC · Maccabi Haifa FC · Hapoel Haifa FC · Hapoel Kiryat Shmona FC · Maccabi Netanya FC · Beitar Jerusalem FC · Hapoel Katamon Jerusalem FC · Hapoel Hadera FC · Hapoel Ra'anana AFC · Maccabi Petah Tikva FC · Hapoel Petah Tikva FC · Hapoel Kfar-Saba FC · Sektzia Nes Tziona FC · Bnei Sakhnin FC · FC Kafr Qasim · Hapoel Acre FC · Hapoel Afula FC · Hapoel Ashkelon FC · Hapoel Bnei Lod FC · Hapoel Nof HaGalil FC · Hapoel Ramat Gan Giv'atayim FC · Hapoel Ramat HaSharon FC · Hapoel Rishon LeZion FC · Hapoel Umm al-Fahm FC · Maccabi Ahi Nazareth FC






By A to Z

- **A** (1): Ashdod
- **B** (11): Bnei Yehuda · Bnei Sakhnin · Beitar Tel Aviv · Bnei Sachnin FC · Bnei Sakhnin FC · Beitar Jerusalem · Beitar Jerusalem FC · Bnei Yehuda Tel Aviv · Beitar Tel Aviv Bat Yam · Bnei Yehuda Tel-Aviv FC · Beitar Tel Aviv Bat Yam FC
- **F** (3): FC Ashdod · FC Kafr Qasim · FC Ironi Ashdod
- **H** (58): H. Haifa · H. Ra'anana · H. Tel-Aviv · Hapoel Acre · Hapoel Akko · H. Kfar-Saba · H. Ramat Gan · Hapoel Afula · Hapoel Be'er · Hapoel Haifa · H. Beer-Sheva · Hapoel Hadera · Hapoel Acre FC · H. Petach Tikva · Hap. Beer-Sheva · Hapoel Afula FC · Hapoel Ashkelon · Hapoel Bnei Lod · Hapoel Haifa FC · Hapoel Ra'anana · Hapoel Tel-Aviv · H. Kiryat Shmona · Hapoel Hadera FC · Hapoel Kfar-Saba · Hapoel Ramat Gan · Hapoel Ironi Akko · Hap. Rishon LeZion · Hapoel Ashkelon FC · Hapoel Be'er Sheva · Hapoel Bnei Lod FC · Hapoel Nof HaGalil · Hapoel Petah Tikva · Hapoel Ra'anana FC · Hapoel Rishon Lezi · Hapoel Tel-Aviv FC · Hapoel Um el-Fahem · Hapoel Umm al-Fahm · Hap. Kat. Jerusalem · Hapoel Kfar-Saba FC · Hapoel Petach-Tikva · Hapoel Ra'anana AFC · Hapoel Ramat Gan FC · Hapoel Beer-Sheva FC · Hapoel Kiryat Shmona · Hapoel Rishon LeZion · Hapoel Nof HaGalil FC · Hapoel Petah Tikva FC · Hapoel Ramat HaSharon · Hapoel Umm al-Fahm FC · Hapoel Petach-Tikva FC · Hapoel Kiryat Shmona FC · Hapoel Rishon LeZion FC · Hapoel Katamon Jerusalem · Hapoel Ramat HaSharon FC · Hapoel Ironi Kiryat Shmona · Hapoel Katamon Jerusalem FC · Hapoel Ironi Kiryat Shmona FC · Hapoel Ramat Gan Giv'atayim FC
- **I** (5): Ironi K. Shmona · I. Ramat Hasharon · Ironi Kiryat Shmona · Ironi Kiryat Schmona · Ironi Ramat HaSharon
- **M** (19): M. Haifa · M. Netanya · M. Tel-Aviv · Maccabi Haifa · Macc. Tel Aviv · M. Ahi Nazareth · Maccabi Netanya · Maccabi Haifa FC · Maccabi Tel Aviv · Macc. Petach Tikva · Maccabi Netanya FC · Maccabi Petah Tikva · Maccabi Tel-Aviv FC · Moadon Sport Ashdod · Maccabi Ahi Nazareth · Maccabi Petach-Tikva · Maccabi Petah Tikva FC · Maccabi Ahi Nazareth FC · Maccabi Petach-Tikva FC
- **N** (1): Nes Tziona
- **S** (5): SC Kfar Qasem · Sectzya Nes Ziona · Sektzia Nes Tziona · Sektzia Nes Tziona FC · Sektzia Ness Ziona FC




