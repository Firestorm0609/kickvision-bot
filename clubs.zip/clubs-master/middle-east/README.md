6 datafiles, 43 clubs

**middle-east/iran/ir.clubs.txt** _(2)_:  Pars Jonoubi Jam · Peykan

**middle-east/israel/il.clubs.txt** _(30)_:  **[Hapoel Tel-Aviv FC](https://en.wikipedia.org/wiki/Hapoel_Tel_Aviv_F.C.)** · **[Maccabi Tel-Aviv FC](https://en.wikipedia.org/wiki/Maccabi_Tel_Aviv_F.C.)** · **[Bnei Yehuda Tel-Aviv FC](https://en.wikipedia.org/wiki/Bnei_Yehuda_Tel_Aviv_F.C.)** · Beitar Tel Aviv Bat Yam FC · **[Maccabi Haifa FC](https://en.wikipedia.org/wiki/Maccabi_Haifa_F.C.)** · **[Hapoel Haifa FC](https://en.wikipedia.org/wiki/Hapoel_Haifa_F.C.)** · **[Hapoel Kiryat Shmona FC](https://en.wikipedia.org/wiki/Hapoel_Ironi_Kiryat_Shmona_F.C.)** · **[Maccabi Netanya FC](https://en.wikipedia.org/wiki/Maccabi_Netanya_F.C.)** · **[Beitar Jerusalem FC](https://en.wikipedia.org/wiki/Beitar_Jerusalem_F.C.)** · Hapoel Katamon Jerusalem FC · **[Hapoel Beer-Sheva FC](https://en.wikipedia.org/wiki/Hapoel_Be'er_Sheva_F.C.)** · **[FC Ashdod](https://en.wikipedia.org/wiki/F.C._Ashdod)** · **[Hapoel Hadera FC](https://en.wikipedia.org/wiki/Hapoel_Hadera_F.C.)** · **[Hapoel Ra'anana AFC](https://en.wikipedia.org/wiki/Hapoel_Ra'anana_A.F.C.)** · **[Maccabi Petah Tikva FC](https://en.wikipedia.org/wiki/Maccabi_Petah_Tikva_F.C.)** · Hapoel Petah Tikva FC · Hapoel Kfar-Saba FC · Sektzia Nes Tziona FC · **[Bnei Sakhnin FC](https://en.wikipedia.org/wiki/Bnei_Sakhnin_F.C.)** · FC Kafr Qasim · Hapoel Acre FC · Hapoel Afula FC · Hapoel Ashkelon FC · Hapoel Bnei Lod FC · Hapoel Nof HaGalil FC · Hapoel Ramat Gan Giv'atayim FC · Hapoel Ramat HaSharon FC · Hapoel Rishon LeZion FC · Hapoel Umm al-Fahm FC · Maccabi Ahi Nazareth FC

**middle-east/jordan/jo.clubs.txt** _(1)_:  Al Wehdat

**middle-east/lebanon/lb.clubs.txt** _(1)_:  Al Ahed

**middle-east/qatar/qa.clubs.txt** _(6)_:  Al-Sadd SC · Al Shahaniya · Al Khoor · Al Gharafa SC · Al Ahli Doha SC · Al-Duhail SC

**middle-east/saudi-arabia/sa.clubs.txt** _(3)_:  Al Nassr · Al Hilal FC · Al-Ahli Jeddah

